# 📍 Onde Cada Variável de Ambiente é Usada

Guia técnico mostrando em quais arquivos do app cada variável de ambiente é utilizada.

---

## 🗂️ Mapa de Uso das Variáveis

### 1. DATABASE_URL

**Descrição:** Conexão com o banco PostgreSQL

**Arquivos que usam:**

```
┌─ lib/prisma.ts
│  └─ Inicializa cliente Prisma com DATABASE_URL
│  └─ Linha: const prisma = new PrismaClient();
│  └─ Prisma lê automaticamente do .env
│
└─ prisma/schema.prisma
   └─ Configuração de datasource
   └─ Linha: url = env("DATABASE_URL")
```

**Como funciona:**

1. Prisma lê `DATABASE_URL` do ambiente
2. Conecta ao PostgreSQL especificado
3. Todas as queries do banco usam essa conexão

**Roteadores que usam:**

- `/api/auth/*` - Valida credenciais do usuário no banco
- `/api/dashboards/*` - CRUD de dashboards
- `/api/forms/*` - CRUD de formulários
- `/api/users/*` - CRUD de usuários
- Todos os `/api/*` endpoints

**Teste local:**

```bash
npx prisma db push      # Conecta e sincroniza schema
npx prisma studio      # Interface visual do banco
```

---

### 2. JWT_SECRET

**Descrição:** Chave para assinar tokens de autenticação (JSON Web Tokens)

**Arquivos que usam:**

```
┌─ lib/auth/jwt.ts (ARQUIVO PRINCIPAL)
│  └─ Assina tokens com JWT_SECRET
│  └─ Valida tokens usando JWT_SECRET
│  └─ Linha 12: const JWT_SECRET = process.env.JWT_SECRET
│
├─ app/api/auth/login/route.ts
│  └─ Chama generateAccessToken() que usa JWT_SECRET
│
├─ app/api/auth/refresh/route.ts
│  └─ Renova tokens usando JWT_SECRET
│
├─ app/api/auth/logout/route.ts
│  └─ Valida token before logout
│
├─ middleware.ts
│  └─ Valida JWT em todas as rotas protegidas
│
└─ lib/auth/validate.ts
   └─ validateAuth() verifica JWT_SECRET
```

**Como funciona:**

1. Usuário faz login
2. App gera token JWT assinado com JWT_SECRET
3. Cliente armazena token em localStorage
4. Token enviado em requisições `/api/*`
5. Middleware valida assinatura usando JWT_SECRET

**Fluxo completo:**

```
Login request
  ↓
generateAccessToken(userId, email, tenantId)
  ↓
jwt.sign(payload, JWT_SECRET, {expiresIn: '15m'})
  ↓
Token enviado ao cliente
  ↓
Cliente envia token em Authorization header
  ↓
Middleware checa: verifyToken(token) com JWT_SECRET
  ↓
Token válido? Deixa passar : Bloqueia
```

**Teste local:**

```bash
# Faz login e testa se JWT funciona
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"pass"}'

# Se receber token no response, JWT_SECRET tá ok
```

**Importante:** Se trocar JWT_SECRET em produção, todos os tokens antigos viram inválidos (usuários precisam fazer login de novo).

---

### 3. NEXT_PUBLIC_APP_URL

**Descrição:** URL pública da aplicação (para links em emails, redirects, etc)

**Arquivos que usam:**

```
┌─ lib/email/resend.ts (EMAILS)
│  └─ Usa em links de password reset
│  └─ Usa em links de dashboard share
│  └─ Exemplo: href="${NEXT_PUBLIC_APP_URL}/reset-password?token=..."
│
├─ app/api/auth/forgot-password/route.ts
│  └─ Constrói link de reset com NEXT_PUBLIC_APP_URL
│
├─ app/api/dashboards/[dashboardId]/share/route.ts
│  └─ Constrói link de share com NEXT_PUBLIC_APP_URL
│
└─ (Pode ser usado em qualquer lugar que precise de link absoluto)
```

**Como funciona:**

1. Usuário pede para resetar senha
2. App gera token seguro
3. App constrói link: `{NEXT_PUBLIC_APP_URL}/reset-password?token={token}`
4. Link enviado por email
5. Usuário clica link
6. Browser vai para `/reset-password` e processa token

**Exemplo de link gerado:**

```
https://app.dpwai.com.br/reset-password?token=eyJhbGciOiJIUzI1NiI...
```

**Importante:**

- ✅ DEVE ser HTTPS (não HTTP)
- ✅ DEVE ser URL final (não localhost, não Vercel temp)
- ✅ Sem barra no final
- ✗ Se errado, links em emails ficam quebrados

**Teste local:**

```bash
# No .env local:
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Em produção na Vercel:
NEXT_PUBLIC_APP_URL=https://app.dpwai.com.br

# Teste: Forgot Password → email deve ter link correto
```

---

### 4. RESEND_API_KEY

**Descrição:** API key do serviço Resend (envio de emails)

**Arquivos que usam:**

```
┌─ lib/email/resend.ts (ARQUIVO PRINCIPAL)
│  └─ Inicializa cliente Resend
│  └─ Linha 3: const RESEND_API_KEY = process.env.RESEND_API_KEY;
│  └─ Linha 13: resend = new Resend(RESEND_API_KEY);
│
├─ app/api/auth/forgot-password/route.ts
│  └─ Chama sendForgotPasswordEmail()
│
├─ app/api/dashboards/[dashboardId]/share/route.ts
│  └─ Chama sendDashboardShareEmail()
│
└─ (Qualquer API que queira enviar email)
```

**Como funciona:**

1. App quer enviar email (ex: password reset)
2. Chama sendForgotPasswordEmail(email, resetLink)
3. Função em lib/email/resend.ts constrói HTML
4. Envia via Resend usando RESEND_API_KEY
5. Email chega em segundos no inbox do usuário

**Fluxo de email:**

```
Forgot Password request
  ↓
generatePasswordResetToken()
  ↓
sendForgotPasswordEmail(email, resetLink)
  ↓
fetch("https://api.resend.com/emails", {
  from: EMAIL_FROM,
  to: email,
  subject: "Reset Your Password",
  html: "<html>...</html>"
})
  ↓
Resend recebe com RESEND_API_KEY
  ↓
Email chega em ~5-10 segundos
```

**Tipos de email enviados:**

1. **Password Reset** - Quando usuário clica "Forgot Password"
2. **Dashboard Share** - Quando usuário compartilha dashboard
3. **Alert Emails** - Para notificações (usado em future features)

**Teste local:**

```bash
# Se RESEND_API_KEY não for setada:
# - Email throws error
# - Solução: Adicione API key em .env local

# Teste: Forgot Password → deve chegar email em inbox
# Se não chegar: Verificar:
# 1. RESEND_API_KEY está correto?
# 2. Account Resend está verificada?
# 3. Email não foi para spam?
```

**Importante:** Se RESEND_API_KEY errada, password reset quebra, mas app não crashes (erro capturado).

---

### 5. EMAIL_FROM

**Descrição:** Quem envia os emails (nome e endereço)

**Arquivos que usam:**

```
┌─ lib/email/resend.ts (ARQUIVO PRINCIPAL)
│  └─ Define quem envia
│  └─ Linha 4: const EMAIL_FROM = process.env.EMAIL_FROM || 'DPWAI <noreply@dpwai.com.br>';
│  └─ Padrão: 'DPWAI <noreply@dpwai.com.br>'
│
├─ Email templates (no mesmo arquivo)
│  └─ sendForgotPasswordEmail()
│  └─ sendDashboardShareEmail()
│  └─ sendAlertEmail()
│  └─ Todos usam: from: EMAIL_FROM
```

**Como funciona:**

Exemplo de email recebido:

```
De: DPWAI Agro <noreply@dpwai.com.br>
Para: user@example.com
Assunto: Reset Your Password
```

**Teste local:**

```bash
# Se não setar EMAIL_FROM, usa padrão
# Padrão é ok pra testes

# Se quiser customizar:
EMAIL_FROM="Minha Empresa <noreply@meu-dominio.com>"

# Importante: Email precisa ser verificado no Resend
```

---

## 📊 Tabela de Uso Rápida

| Variável | Arquivo Principal | Tipo | Sensível | Padrão |
|----------|------------------|------|----------|--------|
| DATABASE_URL | lib/prisma.ts | Connection String | ✅ SIM | NENHUM |
| JWT_SECRET | lib/auth/jwt.ts | String (64 chars) | ✅ SIM | NENHUM |
| NEXT_PUBLIC_APP_URL | lib/email/resend.ts | URL (https://) | ❌ NÃO | NENHUM |
| RESEND_API_KEY | lib/email/resend.ts | String (re_...) | ✅ SIM | NENHUM |
| EMAIL_FROM | lib/email/resend.ts | String | ❌ NÃO | DPWAI <noreply@dpwai.com.br> |

---

## 🔍 Como Debugar se Algo Quebrar

### ❌ Build falha com erro de variável

```bash
# Passo 1: Verificar qual variável falta
npm run build

# Se error mencionar DATABASE_URL, JWT_SECRET, etc
# = Variável não foi adicionada na Vercel

# Solução:
# 1. Ir em Vercel → Settings → Environment Variables
# 2. Adicionar variável que falta
# 3. Redeploy
```

### ❌ Login não funciona

```
Checklist:
✓ JWT_SECRET foi adicionada?
✓ DATABASE_URL foi adicionada?
✓ User existe no banco?
✓ Redeploy foi feito após adicionar vars?

Se todos acima ok:
→ Ir em Vercel → Deployments → Ver logs do build
→ Procurar por erros relacionados a JWT
```

### ❌ Emails não chegam

```
Checklist:
✓ RESEND_API_KEY foi adicionada?
✓ NEXT_PUBLIC_APP_URL está correto?
✓ EMAIL_FROM está configurado (ou padrão)?
✓ Resend account foi verificada?

Se todos acima ok:
→ Ir em resend.com → Dashboard → Emails
→ Ver se email aparece lá com erro
→ Checar spam do email
```

---

## 📚 Arquivos de Referência

- **lib/auth/jwt.ts** - Lógica de JWT
- **lib/email/resend.ts** - Lógica de emails
- **lib/prisma.ts** - Conexão com banco
- **middleware.ts** - Validação de autenticação
- **.env** - Variáveis locais (não committar!)
- **VERCEL_SETUP.md** - Como configurar na Vercel

---

## ✅ Checklist Técnico

Antes de considerar pronto:

- [ ] DATABASE_URL conecta ao banco (npx prisma db push)
- [ ] JWT_SECRET é aleatório (32+ chars)
- [ ] NEXT_PUBLIC_APP_URL é seu domínio final
- [ ] RESEND_API_KEY está válida (começa com re_)
- [ ] EMAIL_FROM usa domínio verificado (ou padrão)
- [ ] Todas as 5 variáveis estão em Vercel
- [ ] Build passou (verde na Vercel)
- [ ] Login funciona
- [ ] Password reset envia email
- [ ] Email tem link com NEXT_PUBLIC_APP_URL correto

🎉 **Quando tudo acima estiver ok, app está 100% pronto!**
