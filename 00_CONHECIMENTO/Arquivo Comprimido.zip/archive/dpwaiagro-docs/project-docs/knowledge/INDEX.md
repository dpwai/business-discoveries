# DPWAI Knowledge Base - Complete Index

Master table of contents for all documentation.

## Core Documentation

### 00-overview/ - Overview & Architecture
- CLAUDE-CONTEXT.md - Core context for agents
- HOW-THE-REPO-WORKS.md - System design
- ARCHITECTURE.md - Technical architecture
- TECH-STACK.md - Technologies used
- DESIGN-SYSTEM.md - UI/design patterns
- README.md - Overview index

### 01-setup-local/ - Setup & Testing
- QUICK-START.md - Get running in 5 minutes
- PREREQUISITES.md - Prerequisites checklist
- TESTING-SETUP.md - Test configuration
- TEST-SUITE-QUICK.md - Quick test guide
- TESTING-SUITE-FULL.md - Full testing
- RESEND-EMAIL-SETUP.md - Email service
- I18N-SETUP.md - Internationalization

### 02-frontend/ - Frontend Documentation
- RESPONSIVE-DESIGN.md - Mobile responsiveness
- UI-MODERNIZATION.md - Modern UI patterns
- COMPONENT-LIBRARY.md - React components
- MOBILE-DRAWER-FIX.md - Mobile fixes
- MOBILE-PATTERNS.md - Mobile UX patterns

### 03-backend/ - Backend & API
- ERROR-HANDLING-GUIDE.md - Error handling
- I18N-HARDCODED-AUDIT.md - String audit
- API-ENDPOINTS.md - API reference

### 04-env-vars/ - Environment Variables
- ENV-REFERENCE.md - All env vars

### 05-ci-cd/ - CI/CD Pipeline
- CI-CD-README.md - GitHub Actions + Vercel

### 06-deploy/ - Deployment & Hosting
- VERCEL-DEPLOYMENT.md - Vercel setup
- VERCEL-QUICK-SETUP.md - Quick setup
- HOSTINGER-DEPLOYMENT.md - DNS + domain
- DEPLOYMENT-OVERVIEW.md - Deployment flow
- DEPLOYMENT-CHECKLIST.md - Pre-launch

### 07-troubleshooting/ - QA & Troubleshooting
- QA-INDEX.md - QA documentation
- QA-SUMMARY.md - QA results
- AUDIT-COMPLETION.md - Final audit

### 08-security/ - Security Documentation
- MULTI-TENANT-SECURITY-AUDIT.md - Security audit
- SECURITY-FIXES-PLAN.md - Fix plan

### 09-otp-email-system/ - Email & OTP System
- OTP-EMAIL-SYSTEM-PLAN.md - System plan

### archive/ - Old/Legacy Documentation
- Keep for reference only

## Search Strategy

1. Check INDEX.md first (this file)
2. Search by topic (00-09 folders)
3. Use filename patterns
4. Check archive/ for old references

## Recent Updates

- Consolidated all docs in /knowledge
- Organized by topic (00-09 structure)
- Removed duplicate files from root
- Cleaned cache directories
- Updated CLAUDE.md to reference /knowledge

