# DPWAI Hardening Sprint - Agent Contracts

**Date**: Jan 26, 2026
**Orchestrator**: Claude (Haiku 4.5)
**Parallel Agents**: 5 (Agents 01-05)
**Status**: Deployment ready

---

## Overview

This document defines shared contracts between parallel agents working on the DPWAI hardening sprint. Each agent works independently, references these contracts, and reports status to the worklog.

---

## Shared State & Auth

**JWT Token Structure**:
```typescript
interface AccessToken {
  userId: string;
  email: string;
  username: string;
  tenantId: string;
  iat: number;
  exp: number;
}

interface RefreshToken {
  userId: string;
  tenantId: string;
  iat: number;
  exp: number;
}
```

**Multi-Tenant Isolation**: All API queries MUST filter by `tenantId` from JWT.

**Test Credentials**:
```
Email: admin@dpwai.com
Password: Admin@123456
Tenant: Demo Farm (15a01efb-04bd-4aa7-bb7b-a38bcd45a65c)
```

**Security Rules**:
- All protected routes require `Authorization: Bearer {token}` header
- Cookies stored: `accessToken`, `refreshToken`, `user`, `tenant`
- Share links expire in 24 hours
- OTP codes expire in 15 minutes

---

## Agent Responsibilities

### Agent 01: Auth Flows (Login, Logout, OTP, Password Reset, Signup)

**Screens to Fix**:
- `/login` - Fix English text, add password reset link, verify flow
- `/logout` - Verify token clearing, redirect to login
- `/otp` - Test OTP verification, expiry, resend
- `/forgot-password` - Create/fix UI, test flow
- `/signup` - Create page if missing, test self-registration

**API Contracts** (must exist and work):
```typescript
POST /api/auth/login
  Body: { email: string, password: string }
  Response: { accessToken, refreshToken, user, tenant }

POST /api/auth/logout
  Headers: { Authorization: Bearer {token} }
  Response: { success: true }

POST /api/auth/otp/request
  Body: { email: string }
  Response: { expiresAt: ISO8601 }

POST /api/auth/otp/verify
  Body: { email: string, code: string }
  Response: { accessToken, refreshToken, user, tenant }

POST /api/auth/forgot-password
  Body: { email: string }
  Response: { message: "Password reset link sent" }

POST /api/auth/reset-password
  Body: { token: string, password: string }
  Response: { success: true }

POST /api/auth/signup
  Body: { email, password, firstName, lastName }
  Response: { user, tenant }
```

**Acceptance Criteria**:
- [ ] All text Portuguese (pt-BR) with no English on auth pages
- [ ] Login → token in cookie → dashboard accessible
- [ ] Logout → cookies cleared → redirected to login
- [ ] OTP 15-min expiry working
- [ ] Password reset UI functional
- [ ] Signup creates user + auto-adds to default tenant
- [ ] All API endpoints return proper auth errors (401, 403)

**Provides To**: All other agents (auth is foundation)

**Depends On**: None

---

### Agent 02: Dashboard CRUD & Viewer

**Screens to Fix**:
- `/{tenant}/dashboards` - List view, pagination, archive/active tabs, NEW button
- `/{tenant}/dashboards/{id}` - Dashboard viewer, embedUrl iframe, metadata
- Dashboard modal dialogs - Create, Edit, Archive, Delete, Share

**API Contracts** (must exist and work):
```typescript
GET /api/dashboards
  Headers: { Authorization: Bearer {token} }
  Response: Dashboard[] with pagination

GET /api/dashboards/{id}
  Headers: { Authorization: Bearer {token} }
  Response: Dashboard (includes embedUrl, lastModified, owner)

POST /api/dashboards
  Headers: { Authorization: Bearer {token} }
  Body: { name, description, embedUrl, config? }
  Response: Dashboard (with id, createdAt)

PUT /api/dashboards/{id}
  Headers: { Authorization: Bearer {token} }
  Body: { name?, description?, embedUrl?, config? }
  Response: Dashboard (updated)

DELETE /api/dashboards/{id}
  Headers: { Authorization: Bearer {token} }
  Response: { success: true }

POST /api/dashboards/{id}/archive
  Headers: { Authorization: Bearer {token} }
  Body: { archived: boolean }
  Response: Dashboard

POST /api/dashboards/{id}/share
  Headers: { Authorization: Bearer {token} }
  Response: { shareUrl: string, expiresAt: ISO8601 }
```

**Dashboard Schema**:
```typescript
interface Dashboard {
  id: string;
  name: string;
  description?: string;
  embedUrl?: string;
  config?: Json;
  archived: boolean;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string; // userId
  tenantId: string;
  shareLinks?: DashboardShareLink[];
}
```

**Acceptance Criteria**:
- [ ] List shows all active dashboards with pagination
- [ ] Archive tab shows archived dashboards
- [ ] NEW button opens create modal
- [ ] Create saves: name, description, embedUrl
- [ ] Edit modal shows current values, updates work
- [ ] Archive soft-deletes (moves to archive tab)
- [ ] Delete hard-removes with confirmation
- [ ] Share link valid for 24h, works without auth
- [ ] embedUrl persists and renders in iframe (if provided)
- [ ] Multi-tenant isolation (can't access other tenant's dashboards)

**Provides To**: Agent 04 (needs dashboard URLs), Agent 05 (tests)

**Depends On**: Agent 01 (auth must work first)

---

### Agent 03: Admin Screens

**Screens to Fix**:
- `/{tenant}/admin/my-account` - Edit profile, change password, delete account
- `/{tenant}/admin/users` - User list, invite, permissions, deactivate
- `/{tenant}/admin/settings` - Tenant settings, Looker config, branding
- `/{tenant}/audit` - Audit log viewer, filters, export

**API Contracts** (must exist and work):
```typescript
GET /api/users
  Headers: { Authorization: Bearer {token} }
  Response: User[]

POST /api/users/invite
  Headers: { Authorization: Bearer {token} }
  Body: { email, firstName, lastName, role }
  Response: { inviteToken, inviteLink }

PUT /api/users/{userId}
  Headers: { Authorization: Bearer {token} }
  Body: { firstName?, lastName?, role? }
  Response: User

DELETE /api/users/{userId}
  Headers: { Authorization: Bearer {token} }
  Response: { success: true }

GET /api/audit-logs
  Headers: { Authorization: Bearer {token} }
  Params: { limit, offset, filter?, startDate?, endDate? }
  Response: AuditLog[]

PUT /api/account/profile
  Headers: { Authorization: Bearer {token} }
  Body: { firstName, lastName }
  Response: User

POST /api/account/change-password
  Headers: { Authorization: Bearer {token} }
  Body: { currentPassword, newPassword }
  Response: { success: true }
```

**Acceptance Criteria**:
- [ ] My Account page loads user data
- [ ] Edit profile updates user
- [ ] Change password validates old password
- [ ] Delete account with 2-step confirmation
- [ ] Users page lists all tenant members
- [ ] Invite modal sends invite email (Resend)
- [ ] Edit user permissions works
- [ ] Deactivate user removes from tenant
- [ ] Audit log shows all actions with timestamps
- [ ] Audit filters by action type, user, date range work
- [ ] All routes check authorization (admin or owner only)

**Provides To**: Agent 05 (needs routes for test coverage)

**Depends On**: Agent 01 (auth), Agent 02 (dashboards)

---

### Agent 04: Mobile Responsiveness & UX

**Screens to Test**:
- All screens from Agents 01, 02, 03 on mobile widths:
  - 375px (iPhone SE)
  - 768px (iPad)
  - 1024px (iPad Pro)

**Responsive Design Contract**:
```typescript
interface ResponsiveBreakpoints {
  mobile: 375,      // iPhone SE
  tablet: 768,      // iPad
  desktop: 1024,    // iPad Pro / Desktop
}
```

**Mobile-Specific Fixes**:
- Hamburger menu always visible (z-index 99999)
- Touch targets 44px minimum
- Modals full-width on mobile
- Tables scrollable horizontally
- Form inputs full-width
- No horizontal scroll
- Bottom action buttons (not top-fixed)

**Acceptance Criteria**:
- [ ] No horizontal scroll on any screen
- [ ] Hamburger menu visible on all mobile screens
- [ ] All buttons touch-target compliant (44px)
- [ ] Forms fill width with proper spacing
- [ ] Modals stack properly on mobile
- [ ] Navigation readable (14px+ font)
- [ ] Dropdowns don't overflow screen
- [ ] Images responsive (max-width: 100%)
- [ ] Dark mode consistent across all widths
- [ ] Manual QA pass: 375px, 768px, 1024px

**Provides To**: Final integration

**Depends On**: Agents 01, 02, 03 (all pages must exist first)

---

### Agent 05: Security Audit & E2E Tests

**Security Checks**:
- All protected routes require JWT token
- Multi-tenant isolation enforced (can't access other tenant's data)
- OTP rate limiting (max 5 attempts per hour)
- Share links validated before access
- Passwords hashed with bcrypt
- No secrets in client code
- CORS headers correct
- No SQL injection vectors
- No XSS vulnerabilities in forms

**E2E Tests** (Playwright):
```typescript
test("Complete login flow", async ({ page }) => {
  // Visit login, enter creds, verify dashboard loads
})

test("Dashboard CRUD operations", async ({ page }) => {
  // Create, read, update, archive, delete dashboard
})

test("Multi-tenant isolation", async ({ page }) => {
  // Try accessing other tenant's data, verify 403
})

test("Share link 24h expiry", async ({ page }) => {
  // Generate share link, verify work, check expiry
})

test("OTP flow with expiry", async ({ page }) => {
  // Request OTP, verify 15-min expiry, test resend
})

test("Mobile responsiveness", async ({ page }) => {
  // Test on 3 breakpoints: 375px, 768px, 1024px
})
```

**Acceptance Criteria**:
- [ ] All E2E tests pass (6 tests minimum)
- [ ] Security audit checklist 100% passing
- [ ] No console errors on any screen
- [ ] No auth bypass vulnerabilities found
- [ ] API returns 401 without token
- [ ] API returns 403 for wrong tenant
- [ ] Rate limiting on OTP working
- [ ] No hardcoded secrets in codebase

**Provides To**: Final report

**Depends On**: Agents 01, 02, 03, 04 (all components must be complete)

---

## Dependency Graph

```
Agent 01 (Auth)
  ↓
Agent 02 (Dashboard) + Agent 03 (Admin)
  ↓
Agent 04 (Mobile)
  ↓
Agent 05 (Security & Tests)
```

**Parallel Execution**:
- Agent 01 starts first (blocking)
- Agents 02 + 03 start after Agent 01 ready
- Agent 04 starts after Agents 02 + 03 ready
- Agent 05 starts after Agents 01-04 ready

**Integration Sequence** (commits):
1. Agent 01 → Auth system (login, logout, OTP, password reset, signup)
2. Agent 02 → Dashboard CRUD & viewer
3. Agent 03 → Admin screens & audit
4. Agent 04 → Mobile fixes
5. Agent 05 → Tests & security fixes
6. Orchestrator → Final integration + report

---

## Error Handling Contract

All endpoints MUST return consistent error format:

```typescript
interface ErrorResponse {
  error: string;
  code: string;
  statusCode: number;
  timestamp: ISO8601;
  path?: string;
  details?: Record<string, any>;
}

// Examples:
{
  "error": "Unauthorized",
  "code": "UNAUTHORIZED",
  "statusCode": 401,
  "timestamp": "2026-01-26T01:36:00Z"
}

{
  "error": "Invalid OTP",
  "code": "OTP_INVALID",
  "statusCode": 400,
  "timestamp": "2026-01-26T01:36:00Z",
  "details": { "attemptsRemaining": 4 }
}
```

---

## Status Updates

Each agent reports progress in the worklog using this format:

```markdown
| Agent | Component | Start | Status | ETA | Notes |
|-------|-----------|-------|--------|-----|-------|
| **01** | Auth | 02:00 | ✅ COMPLETE | - | Login, logout, OTP, reset, signup all working |
| **02** | Dashboard | 02:30 | ⏳ IN PROGRESS | 03:30 | CRUD endpoints verified, UI needs fixes |
| **03** | Admin | 02:30 | ⏳ IN PROGRESS | 04:00 | Users list, audit log, settings |
| **04** | Mobile | 03:30 | ⏳ PENDING | 04:00 | Waiting on Agents 02+03 |
| **05** | Security | 04:00 | ⏳ PENDING | 05:00 | Waiting on all agents |
```

---

## Success Criteria

**Agent 01**: ✓ All auth flows working, all text Portuguese
**Agent 02**: ✓ Dashboard list, CRUD, viewer, share links all functional
**Agent 03**: ✓ Admin screens accessible, user management working, audit log populated
**Agent 04**: ✓ Manual QA pass on 3 breakpoints (375px, 768px, 1024px), no horizontal scroll
**Agent 05**: ✓ 6+ E2E tests pass, security audit 100%, no console errors

**Final**: Build passes, no TypeScript errors, app functional end-to-end

---

**Last Updated**: Jan 26, 2026, 02:00 UTC
**Next Review**: After each agent checkpoint (30 min intervals)
