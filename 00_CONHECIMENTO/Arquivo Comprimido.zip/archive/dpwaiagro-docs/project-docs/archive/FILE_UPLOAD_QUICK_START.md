# File Upload System - Quick Start Guide

## 5-Minute Setup

### 1. Environment Variables

Add to `.env`:

```bash
# Storage Configuration
STORAGE_PROVIDER=LOCAL              # Options: LOCAL, R2, S3, GCS
MAX_FILE_SIZE=52428800              # 50MB in bytes
PRESIGNED_URL_EXPIRY=3600           # 1 hour

# For LOCAL storage only
LOCAL_STORAGE_DIR=/tmp/dpwai-uploads
```

### 2. Create Directory (LOCAL only)

```bash
mkdir -p /tmp/dpwai-uploads
chmod 755 /tmp/dpwai-uploads
```

### 3. Run Prisma Migration

```bash
# Apply schema changes
npx prisma migrate dev --name add_file_upload_models

# Sync database
npx prisma db push
```

### 4. Use in React Component

```tsx
import { FileUploadField } from '@/components/forms/FileUploadField';

export function MyForm({ publicFormId }) {
  return (
    <FileUploadField
      fieldId="q_001"
      label="Upload Document"
      description="PDF, images accepted"
      required={true}
      maxSize={52428800}
      accept="application/pdf,image/*"
      publicFormId={publicFormId}
      onFilesSelected={(files) => {
        console.log('Uploaded:', files);
      }}
      onError={(error) => {
        console.error('Error:', error);
      }}
    />
  );
}
```

## API Examples

### JavaScript / TypeScript

```typescript
// 1. Initialize upload
const initResponse = await fetch(
  `/api/public/forms/${publicId}/files/init`,
  {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      fieldId: 'q_001',
      fileName: 'document.pdf',
      fileSize: 1048576,
      mimeType: 'application/pdf',
    }),
  }
);

const { fileId, uploadUrl, expiresIn } = await initResponse.json();

// 2. Upload file
const uploadResponse = await fetch(uploadUrl, {
  method: 'PUT',
  headers: { 'Content-Type': 'application/pdf' },
  body: file,
});

// 3. Complete upload
const completeResponse = await fetch(
  `/api/public/forms/${publicId}/files/complete`,
  {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fileId }),
  }
);

const { storageUrl } = await completeResponse.json();
console.log('File available at:', storageUrl);
```

### cURL

```bash
# Initialize upload
curl -X POST http://localhost:3000/api/public/forms/my-form/files/init \
  -H "Content-Type: application/json" \
  -d '{
    "fieldId": "q_001",
    "fileName": "document.pdf",
    "fileSize": 1048576,
    "mimeType": "application/pdf"
  }'

# Upload file (LOCAL)
curl -X PUT http://localhost:3000/api/public/forms/my-form/files/file-id-123/upload \
  -H "Content-Type: application/pdf" \
  --data-binary @document.pdf

# Complete upload
curl -X POST http://localhost:3000/api/public/forms/my-form/files/complete \
  -H "Content-Type: application/json" \
  -d '{"fileId": "file-id-123"}'

# Download file
curl http://localhost:3000/api/public/forms/my-form/files/file-id-123/download \
  -o downloaded.pdf
```

## Common Tasks

### Validate File Before Upload

```typescript
// Client-side validation
const file = document.querySelector('input[type="file"]').files[0];

// Check size
if (file.size > 52428800) {
  alert('File too large (max 50MB)');
  return;
}

// Check type
const allowed = ['application/pdf', 'image/jpeg', 'image/png'];
if (!allowed.includes(file.type)) {
  alert('File type not allowed');
  return;
}

// Proceed with upload
```

### Handle Upload Progress

```typescript
const xhr = new XMLHttpRequest();

xhr.upload.addEventListener('progress', (event) => {
  if (event.lengthComputable) {
    const progress = (event.loaded / event.total) * 100;
    console.log(`Upload progress: ${progress}%`);
    updateProgressBar(progress);
  }
});

xhr.open('PUT', uploadUrl);
xhr.send(file);
```

### Retry Failed Upload

```typescript
async function uploadWithRetry(file, maxRetries = 3) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(uploadUrl, {
        method: 'PUT',
        body: file,
      });
      if (response.ok) return response;
    } catch (error) {
      if (attempt < maxRetries) {
        await new Promise((r) => setTimeout(r, 1000 * attempt)); // Exponential backoff
        continue;
      }
      throw error;
    }
  }
}
```

### Collect Files in Form Submission

```typescript
export function FormSubmission() {
  const [files, setFiles] = useState<Record<string, string>>({});

  const handleSubmit = async (formData) => {
    const submission = {
      answersJson: formData,
      fileIds: files, // { q_001: 'file-id-1', q_002: 'file-id-2' }
    };

    await fetch(`/api/public/google-forms/${publicId}`, {
      method: 'POST',
      body: JSON.stringify(submission),
    });
  };

  return (
    <form>
      <FileUploadField
        fieldId="q_001"
        label="Attachment"
        publicFormId={publicId}
        onFilesSelected={(uploadedFiles) => {
          setFiles((prev) => ({
            ...prev,
            q_001: uploadedFiles[0].fileId,
          }));
        }}
      />
      <button onClick={handleSubmit}>Submit</button>
    </form>
  );
}
```

## Configuration by Provider

### LOCAL Storage (Development)

```bash
STORAGE_PROVIDER=LOCAL
LOCAL_STORAGE_DIR=/tmp/dpwai-uploads
```

✅ **Good for**: Development, testing
❌ **Not for**: Production (single server only)

### R2 (Cloudflare) - Production Recommended

```bash
STORAGE_PROVIDER=R2
R2_BUCKET=dpwai-uploads
R2_ACCOUNT_ID=YOUR_ACCOUNT_ID
R2_ACCESS_KEY_ID=YOUR_ACCESS_KEY
R2_SECRET_ACCESS_KEY=YOUR_SECRET
R2_PUBLIC_URL=https://upload.example.com
```

1. Create R2 bucket
2. Generate API token with read/write
3. Enable CORS in R2 settings
4. Set up CNAME (optional)

### S3 (AWS)

```bash
STORAGE_PROVIDER=S3
S3_BUCKET=dpwai-uploads
S3_REGION=us-east-1
S3_ACCESS_KEY=YOUR_ACCESS_KEY
S3_SECRET_KEY=YOUR_SECRET
```

1. Create S3 bucket
2. Create IAM user with S3 access
3. Generate access key/secret
4. Enable CORS in bucket settings

### GCS (Google Cloud Storage)

```bash
STORAGE_PROVIDER=GCS
GCS_PROJECT_ID=your-project-id
GCS_BUCKET=dpwai-uploads
GCS_KEY_FILE=/path/to/service-account-key.json
```

1. Create GCS bucket
2. Create service account
3. Download JSON key
4. Set up CORS

## Troubleshooting

### Upload Fails with 413 Payload Too Large

**Problem**: File exceeds MAX_FILE_SIZE
**Solution**:
```bash
# Increase limit in .env
MAX_FILE_SIZE=104857600  # 100MB
```

### Upload Fails with 429 Too Many Requests

**Problem**: Rate limit exceeded (50/min)
**Solution**: Wait 1 minute, try again

### Upload Hangs/Times Out

**Problem**: Large file on slow connection
**Solution**:
- Enable chunked uploads (not yet implemented)
- Compress file before upload
- Use faster network

### File Not Found After Upload

**Problem**: Upload marked complete but file missing
**Solution**:
- Check storage provider credentials
- Verify LOCAL_STORAGE_DIR exists and has permissions
- Check cloud storage bucket

### CORS Error on Cloud Upload

**Problem**: Browser blocks cross-origin request
**Solution**: Enable CORS in cloud storage settings

```json
[
  {
    "origin": ["*"],
    "method": ["PUT", "GET", "HEAD"],
    "responseHeader": ["Content-Type"]
  }
]
```

## Performance Tips

1. **Use R2/S3 for production** - Direct browser-to-cloud uploads
2. **Compress images** before upload (75% smaller)
3. **Limit file size** to actual needs (e.g., 10MB for PDFs)
4. **Enable caching** - Cache completed uploads
5. **Monitor rate limits** - Adjust per use case

## Testing

```bash
# Run upload tests
npm run test -- file-upload

# Test specific validation
npm run test -- file-upload --testNamePattern="validateFile"

# Test rate limiting
npm run test -- file-upload --testNamePattern="Rate Limiting"
```

## Next Steps

1. ✅ Set STORAGE_PROVIDER in .env
2. ✅ Run Prisma migration
3. ✅ Import FileUploadField in your component
4. ✅ Test upload in browser
5. ✅ Monitor file uploads in database
6. ✅ Set up cloud storage (optional)

## Documentation

- Full docs: `FILE_UPLOAD_SYSTEM.md`
- API reference: `FILE_UPLOAD_SYSTEM.md#api-endpoints`
- Security: `FILE_UPLOAD_SYSTEM.md#validation--security`
- Cloud setup: `FILE_UPLOAD_SYSTEM.md#storage-providers`

---

**Ready to upload!** 🚀
