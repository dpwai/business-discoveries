# 🔧 DPWAI Login Diagnostic Guide

## Overview

This document provides step-by-step instructions to diagnose and fix login issues in DPWAI using the implemented TASKS 6-10.

---

## 📋 Quick Start: Run Diagnostic Script

### Local Development
```bash
# Ensure your app is running (typically http://localhost:3000)
LOGIN_URL="http://localhost:3000/api/auth/login" \
LOGIN_EMAIL="admin@dpwai.com" \
LOGIN_PASSWORD="Admin@123456" \
node debug-login.mjs
```

### Production (app.dpwai.com.br)
```bash
# Using defaults (or customize as needed)
node debug-login.mjs

# Or explicitly specify:
LOGIN_URL="https://app.dpwai.com.br/api/auth/login" \
LOGIN_EMAIL="admin@dpwai.com" \
LOGIN_PASSWORD="Admin@123456" \
node debug-login.mjs
```

---

## 📊 Expected Responses & What They Mean

### ✅ Success (Status 200)
```json
{
  "response": {
    "status": 200,
    "statusText": "OK",
    "body": {
      "type": "json",
      "value": {
        "accessToken": "eyJhbGc...",
        "user": { "id": "...", "email": "admin@dpwai.com" },
        "tenant": { "id": "...", "name": "Fazenda Demo" }
      }
    }
  }
}
```
**→ Login is working! Check browser console for frontend logs (TASK 6).**

---

### ❌ Error 401: Invalid Credentials

```json
{
  "response": {
    "status": 401,
    "statusText": "Unauthorized",
    "body": {
      "type": "json",
      "value": { "error": "auth.invalid_credentials" }
    }
  }
}
```

**Possible causes:**
1. **Email not found in database** → Check TASK 10 seeding
2. **Email has invisible whitespace** → Run TASK 8 migration
3. **Password hash is invalid** → Run TASK 10 seeding
4. **Email case mismatch** → Already fixed in TASK 6 (toLowerCase + trim)

**Solutions:**
```bash
# 1. Check database for admin@dpwai.com
psql $DATABASE_URL -c "SELECT id, email, status FROM \"User\" WHERE email = 'admin@dpwai.com';"

# 2. Run email normalization (TASK 8)
psql $DATABASE_URL -f prisma/migrations/normalize_emails.sql

# 3. Run demo admin seeding (TASK 10)
npm run seed

# 4. Verify password hash strength
psql $DATABASE_URL -c "SELECT id, email, LENGTH(\"passwordHash\") as hash_length FROM \"User\" WHERE email = 'admin@dpwai.com';"
```

---

### ❌ Error 400: Missing Field

```json
{
  "response": {
    "status": 400,
    "body": {
      "type": "json",
      "value": { "error": "Missing field: tenant" }
    }
  }
}
```

**Cause:** Backend requires tenant_id in login payload.

**Solution (TASK 7):** The login endpoint should not require tenant. It should:
- Accept email/password only
- Return all available tenants
- Let frontend/user select tenant afterward

---

### ❌ Error 404: Endpoint Not Found

```json
{
  "response": {
    "status": 404,
    "body": { "value": "Not Found" }
  }
}
```

**Cause:** Wrong endpoint path.

**Solutions (TASK 6):**
- ✅ `/api/auth/login` ← Correct
- ❌ `/auth/login` ← Wrong
- ❌ `/api/login` ← Wrong
- Check `NEXT_PUBLIC_API_URL` environment variable

---

### ❌ Error 403: Cloudflare/WAF Block

```json
{
  "response": {
    "status": 403,
    "statusText": "Forbidden"
  }
}
```

**Cause:** Rate limiting or WAF rule blocking login.

**Solutions:**
1. Whitelist your IP in Cloudflare
2. Disable WAF temporarily for testing
3. Check Cloudflare analytics for block reason

---

## 🗄️ Database Diagnostics (TASK 9)

When the app boots, it logs database information. Check:

```bash
# In production logs, look for:
# 🗄️  DATABASE INITIALIZATION INFO
# This shows: host, database name, user, schema

# Or query directly:
psql $DATABASE_URL -c "\conninfo"
```

**Expected output:**
```
You are connected to database "dpwai" as user "postgres" on host "localhost" port 5432.
```

---

## 🌱 Seeding Demo Admin (TASK 10)

Idempotent seeding ensures admin@dpwai.com always works:

```bash
# Method 1: Run seed script
npm run seed

# Method 2: Import seedDemoAdmin in your app boot
# See: lib/init/seed-demo-admin.ts

# Method 3: Check if admin exists
psql $DATABASE_URL -c "
SELECT
  u.id,
  u.email,
  u.status,
  COUNT(m.id) as tenant_count
FROM \"User\" u
LEFT JOIN \"Membership\" m ON m.\"userId\" = u.id
WHERE LOWER(TRIM(u.email)) = 'admin@dpwai.com'
GROUP BY u.id;
"
```

---

## 📧 Email Normalization (TASK 8)

Ensures emails never have invisible whitespace or mixed case:

```bash
# Run migration to normalize existing emails
psql $DATABASE_URL -f prisma/migrations/normalize_emails.sql

# Verify normalization worked
psql $DATABASE_URL -c "
SELECT
  id,
  email,
  LENGTH(email) as length,
  email ~ '^\S+@\S+\.\S+$' as valid_format
FROM \"User\"
WHERE status = 'ACTIVE'
LIMIT 10;
"
```

---

## 🔍 Frontend Logging (TASK 6)

The login form now logs detailed information. Check browser console:

```javascript
// You'll see:
[LOGIN] Frontend: Full URL = https://app.dpwai.com.br/api/auth/login
[LOGIN] Frontend: Environment = {
  origin: "https://app.dpwai.com.br",
  NODE_ENV: "production",
  NEXT_PUBLIC_API_URL: "...",
  NEXT_PUBLIC_APP_URL: "..."
}
[LOGIN] Frontend: Email = admin@dpwai.com | Password length = 12
[LOGIN] Frontend: Response status = 200 OK
```

---

## 🚀 Complete Diagnostic Checklist

- [ ] Run `node debug-login.mjs` and save output
- [ ] Check browser console for TASK 6 logs
- [ ] Verify database info in app logs (TASK 9)
- [ ] Check admin exists: `psql ... WHERE email = 'admin@dpwai.com'`
- [ ] Run email normalization: `psql ... -f prisma/migrations/normalize_emails.sql`
- [ ] Run seeding: `npm run seed`
- [ ] Test login again

---

## 🐛 If Still Broken

1. **Share the JSON output** from `debug-login.mjs` (status + body)
2. **Share database query results** from checking admin user
3. **Share app boot logs** (look for DATABASE INITIALIZATION INFO)
4. **Share browser console logs** from TASK 6

With these 4 pieces, we can pinpoint the exact cause.

---

## 📚 Implementation Files

- **Frontend logging (TASK 6):** `app/login/page.tsx` (handleLogin function)
- **Email normalization (TASK 8):** `app/api/auth/login/route.ts` + `prisma/migrations/normalize_emails.sql`
- **Database info logging (TASK 9):** `lib/init/database-info.ts`
- **Idempotent seeding (TASK 10):** `lib/init/seed-demo-admin.ts`
- **Diagnostic script:** `debug-login.mjs`

---

## 🔗 Next Steps

After fixing login:
1. Implement TASK 7 (remove tenant requirement from login)
2. Test multi-tenant selection flow
3. Implement password reset flow
4. Set up email verification for new users

---

*Last updated: 2026-01-25*
