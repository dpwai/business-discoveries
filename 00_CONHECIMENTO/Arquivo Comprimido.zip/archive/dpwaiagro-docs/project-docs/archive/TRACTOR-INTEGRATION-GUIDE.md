# 🚜 Guia de Integração - Tractor Loader

Exemplo prático de como integrar o Tractor Loader em diferentes cenários da sua aplicação.

---

## 🎯 Cenário 1: Loading de Dados em Cliente (Client Component)

### Problema
Você tem um componente que faz fetch de dados e precisa mostrar feedback visual durante o carregamento.

### Solução

```tsx
// app/dashboard/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { TractorLoader, useTractorLoader } from '@/components';

export default function DashboardPage() {
  const [data, setData] = useState(null);
  const { isLoading, startLoading, stopLoading, currentMessage } =
    useTractorLoader({
      messages: [
        'Buscando dados de propriedades 🌾',
        'Carregando safras 🌽',
        'Processando métricas 📊',
        'Sincronizando sistema ⚙️',
      ],
    });

  const loadData = async () => {
    startLoading();
    try {
      const res = await fetch('/api/dashboard/data');
      const result = await res.json();
      setData(result);
    } catch (error) {
      console.error('Erro ao carregar:', error);
    } finally {
      stopLoading();
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (isLoading) {
    return <TractorLoader message={currentMessage} intensity="exhaustive" />;
  }

  return (
    <div className="p-8">
      <h1>Dashboard</h1>
      {/* Seus dados aqui */}
    </div>
  );
}
```

---

## 🎯 Cenário 2: Server Component com Suspense

### Problema
Você tem um Server Component async que leva tempo para carregar dados do banco.

### Solução

```tsx
// app/relatorio/page.tsx
import { SuspenseWithTractor } from '@/components/SuspenseWithTractor';
import { RelatorioContent } from './RelatorioContent'; // async server component

export default function RelatorioPage() {
  return (
    <SuspenseWithTractor
      message="Gerando relatório agrícola..."
      intensity="exhaustive"
    >
      <RelatorioContent />
    </SuspenseWithTractor>
  );
}

// app/relatorio/RelatorioContent.tsx
async function RelatorioContent() {
  // Simula processamento pesado
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const dados = await fetch('database');

  return (
    <div className="p-8">
      <h1>Relatório</h1>
      {/* Seus dados */}
    </div>
  );
}
```

---

## 🎯 Cenário 3: Multiple Loading States

### Problema
Sua página tem múltiplas seções que carregam dados independentemente.

### Solução

```tsx
// app/plantacoes/page.tsx
'use client';

import { useState } from 'react';
import { TractorLoader } from '@/components';

export default function PlantacoesPage() {
  const [loadingSection, setLoadingSection] = useState<string | null>(null);

  const loadPlantacoes = async () => {
    setLoadingSection('plantacoes');
    try {
      await fetch('/api/plantacoes');
      // Process
    } finally {
      setLoadingSection(null);
    }
  };

  const loadSafras = async () => {
    setLoadingSection('safras');
    try {
      await fetch('/api/safras');
      // Process
    } finally {
      setLoadingSection(null);
    }
  };

  if (loadingSection) {
    return (
      <TractorLoader
        message={`Carregando ${loadingSection}...`}
        intensity="medium"
      />
    );
  }

  return (
    <div className="p-8 space-y-8">
      <section>
        <h2>Plantações</h2>
        <button
          onClick={loadPlantacoes}
          className="px-6 py-2 bg-green-600 text-white rounded"
        >
          Carregar Plantações
        </button>
      </section>

      <section>
        <h2>Safras</h2>
        <button
          onClick={loadSafras}
          className="px-6 py-2 bg-green-600 text-white rounded"
        >
          Carregar Safras
        </button>
      </section>
    </div>
  );
}
```

---

## 🎯 Cenário 4: Upload de Arquivos

### Problema
Usuário faz upload de um arquivo pesado e precisa de feedback visual.

### Solução

```tsx
// components/FileUploadWithTractor.tsx
'use client';

import { useState, useRef } from 'react';
import { TractorLoader, useTractorLoader } from '@/components';

export default function FileUploadWithTractor() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { isLoading, startLoading, stopLoading, currentMessage } =
    useTractorLoader({
      messages: [
        'Enviando arquivo 📤',
        'Processando dados 🔄',
        'Validando informações ✓',
        'Salvando no servidor 💾',
      ],
    });

  const handleFileUpload = async (file: File) => {
    startLoading('Iniciando upload...');

    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) throw new Error('Upload failed');

      alert('Upload realizado com sucesso! ✨');
    } catch (error) {
      alert('Erro no upload: ' + error.message);
    } finally {
      stopLoading();
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileUpload(file);
  };

  if (isLoading) {
    return <TractorLoader message={currentMessage} intensity="exhaustive" />;
  }

  return (
    <div className="p-8 text-center">
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleChange}
        className="hidden"
      />
      <button
        onClick={() => fileInputRef.current?.click()}
        className="px-8 py-4 bg-gradient-to-r from-green-400 to-blue-500 text-white rounded-lg font-bold text-lg hover:shadow-lg transition"
      >
        📁 Selecionar Arquivo
      </button>
      <p className="text-gray-400 mt-4 text-sm">
        Suporta imagens, documentos e arquivos de dados
      </p>
    </div>
  );
}
```

---

## 🎯 Cenário 5: Loading Wrapper Global

### Problema
Você quer um loader global que funcione para qualquer loading state.

### Solução

```tsx
// context/LoadingContext.tsx
'use client';

import React, { createContext, useContext, useState, ReactNode } from 'react';
import { TractorLoader } from '@/components';

interface LoadingContextType {
  isLoading: boolean;
  startLoading: (message?: string) => void;
  stopLoading: () => void;
  message: string;
}

const LoadingContext = createContext<LoadingContextType | undefined>(
  undefined
);

export const LoadingProvider = ({ children }: { children: ReactNode }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('Carregando...');

  const startLoading = (msg?: string) => {
    setMessage(msg || 'Carregando...');
    setIsLoading(true);
  };

  const stopLoading = () => {
    setIsLoading(false);
  };

  return (
    <LoadingContext.Provider
      value={{ isLoading, startLoading, stopLoading, message }}
    >
      {isLoading && (
        <TractorLoader message={message} intensity="exhaustive" />
      )}
      {!isLoading && children}
    </LoadingContext.Provider>
  );
};

export const useGlobalLoading = () => {
  const context = useContext(LoadingContext);
  if (!context) {
    throw new Error('useGlobalLoading deve ser usado dentro do LoadingProvider');
  }
  return context;
};
```

**Uso:**

```tsx
// app/layout.tsx
import { LoadingProvider } from '@/context/LoadingContext';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html>
      <body>
        <LoadingProvider>{children}</LoadingProvider>
      </body>
    </html>
  );
}

// Qualquer componente
'use client';

const { startLoading, stopLoading } = useGlobalLoading();

const loadData = async () => {
  startLoading('Processando dados pesados...');
  try {
    await fetch('/api/heavy');
  } finally {
    stopLoading();
  }
};
```

---

## 🎯 Cenário 6: Loading com Timeout

### Problema
Você quer mostrar o tractor por máximo X segundos, depois forçar fallback.

### Solução

```tsx
'use client';

import { useState, useEffect } from 'react';
import { TractorLoader } from '@/components';

export default function DataWithTimeout() {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    let timeoutId: NodeJS.Timeout;

    const loadData = async () => {
      try {
        // Simula fetch
        await Promise.race([
          fetch('/api/data').then((r) => r.json()),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Timeout')), 10000) // 10s max
          ),
        ]);

        if (isMounted) {
          setData(null); // Resultado
          setIsLoading(false);
        }
      } catch (err) {
        if (isMounted) {
          setError('Operação demorou muito. Tente novamente.');
          setIsLoading(false);
        }
      }
    };

    loadData();

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, []);

  if (isLoading) {
    return (
      <TractorLoader
        message="Carregando dados (máx 10s)..."
        intensity="medium"
      />
    );
  }

  if (error) {
    return <div className="text-red-600 p-8">{error}</div>;
  }

  return <div className="p-8">Dados carregados!</div>;
}
```

---

## 🎯 Cenário 7: Integração com Form Submit

### Problema
Form longo está sendo processado no backend.

### Solução

```tsx
'use client';

import { useState } from 'react';
import { TractorLoader, useTractorLoader } from '@/components';

export default function HeavyFormPage() {
  const [formData, setFormData] = useState({});
  const { isLoading, startLoading, stopLoading, currentMessage } =
    useTractorLoader({
      messages: [
        'Validando formulário 📋',
        'Processando dados 🔄',
        'Armazenando no banco 💾',
        'Confirmando operação ✓',
      ],
    });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    startLoading();

    try {
      const res = await fetch('/api/form-submit', {
        method: 'POST',
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        alert('Formulário enviado com sucesso! 🎉');
      }
    } catch (error) {
      console.error(error);
    } finally {
      stopLoading();
    }
  };

  if (isLoading) {
    return <TractorLoader message={currentMessage} intensity="exhaustive" />;
  }

  return (
    <form onSubmit={handleSubmit} className="p-8 max-w-2xl">
      {/* Seus campos de form */}
      <button type="submit" className="px-6 py-2 bg-green-600 text-white rounded">
        Enviar
      </button>
    </form>
  );
}
```

---

## 🎯 Cenário 8: Progresso em Etapas

### Problema
Operação tem múltiplas etapas e você quer informar progresso.

### Solução

```tsx
'use client';

import { useState } from 'react';
import { TractorLoader } from '@/components';

const STEPS = [
  'Iniciando processamento',
  'Validando dados',
  'Transformando informações',
  'Salvando resultados',
  'Finalizando',
];

export default function MultiStepLoading() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);

  const processData = async () => {
    setIsProcessing(true);

    for (let i = 0; i < STEPS.length; i++) {
      setCurrentStep(i);
      // Simula cada etapa
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }

    setIsProcessing(false);
    alert('Processamento concluído! ✨');
  };

  if (isProcessing) {
    const progress = ((currentStep + 1) / STEPS.length) * 100;

    return (
      <div className="w-full h-screen flex flex-col items-center justify-center gap-8 bg-gradient-to-b from-slate-950 to-slate-900">
        <TractorLoader
          message={STEPS[currentStep]}
          intensity="exhaustive"
        />

        {/* Progress bar */}
        <div className="w-64 h-2 bg-slate-700 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-green-400 to-blue-500 transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>

        <p className="text-gray-400 font-mono text-sm">
          Etapa {currentStep + 1} de {STEPS.length}
        </p>
      </div>
    );
  }

  return (
    <button
      onClick={processData}
      className="px-8 py-4 bg-green-600 text-white rounded-lg font-bold"
    >
      Iniciar Processamento 🚜
    </button>
  );
}
```

---

## 📋 Checklist de Integração

- [ ] Importar `TractorLoader` ou `useTractorLoader`
- [ ] Adicionar `'use client'` se em Client Component
- [ ] Envolver lógica de loading apropriadamente
- [ ] Testar em desktop e mobile
- [ ] Usar `intensity="light"` em mobile
- [ ] Adicionar mensagens customizadas relevantes
- [ ] Implementar error fallback
- [ ] Testar timeout e casos de erro

---

## 🚀 Dicas de Performance

1. **Lazy load** o componente TractorLoader:
   ```tsx
   const TractorLoader = dynamic(() => import('@/components/TractorLoader'));
   ```

2. **Use `intensity="light"`** em dispositivos antigos ou conexões lentas

3. **Cancele requisições** quando componente unmount:
   ```tsx
   useEffect(() => {
     return () => {
       controller.abort(); // AbortController
     };
   }, []);
   ```

---

Pronto para integrar! 🚜✨
