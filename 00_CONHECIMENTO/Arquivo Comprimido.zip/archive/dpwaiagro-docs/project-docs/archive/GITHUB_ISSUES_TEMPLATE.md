# 🎫 GitHub Issues Template - Rastreamento DPWAI Fixes

Use isso como template para criar issues no GitHub. Copia a seção correspondente e ajusta conforme necessário.

---

## ISSUE #1: Login Screen - Tradução Completa

```markdown
## 🎯 [LOGIN] Traduzir login screen para português

### Descrição
Toda a tela de login deve estar em português. Atualmente há strings em inglês.

### Checklist Técnico
- [ ] "Sign in" → "Entrar"
- [ ] "Forgot password" → "Esqueci minha senha"
- [ ] "Please enter email" → "Por favor, digite seu email"
- [ ] "Please enter password" → "Por favor, digite sua senha"
- [ ] Placeholder texts in Portuguese
- [ ] Error messages in Portuguese
- [ ] Toast notifications in Portuguese

### Prova de Funcionamento
```bash
grep -r "Sign in\|Forgot password\|Please" app/login/
# Deve retornar: (no matches)
```

### Aceitação
- ✅ Todo texto em português
- ✅ Sem strings em inglês
- ✅ Dark theme aplicado
- ✅ Layout responsivo

### Labels
`bug` `frontend` `i18n` `critical`

### Prioridade
CRITICAL - Bloqueia login
```

---

## ISSUE #2: Forgot Password - Email Validation

```markdown
## 🔐 [AUTH] Forgot password - Validação de email

### Descrição
Fluxo de password reset está retornando mensagens falsas.

#### Problema Atual
1. Email NÃO existe no DB → sistema diz "email enviado" (ERRADO)
2. Email EXISTE → nenhum email é enviado (ERRADO)
3. Resend dashboard mostra: 0 emails sent

### Requisitos
1. Email não existe:
   - [ ] Mostrar erro: "Este e-mail não está cadastrado."
2. Email existe:
   - [ ] Enviar email via Resend (CHECK API_KEY)
   - [ ] Mostrar: "Enviamos um e-mail com instruções para redefinir sua senha."
   - [ ] Resend dashboard confirma entrega
3. Reset page:
   - [ ] Token validation works
   - [ ] Password update saves to DB
   - [ ] Redirect to login

### Prova de Funcionamento
```bash
# Test com email inexistente
curl -X POST http://localhost:3000/api/auth/forgot-password \
  -H "Content-Type: application/json" \
  -d '{"email":"nonexistent@test.com"}' \
  | jq .

# Esperado: error message "Este e-mail não está cadastrado."

# Test com email válido
curl -X POST http://localhost:3000/api/auth/forgot-password \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@dpwai.com"}' \
  | jq .

# Esperado: success message + check Resend dashboard for delivery
```

### Aceitação
- ✅ Validação de email correto
- ✅ Email realmente enviado (Resend dashboard)
- ✅ Token gerado
- ✅ Reset password page funciona
- ✅ Update password salva no DB

### Labels
`bug` `backend` `auth` `critical`

### Prioridade
CRITICAL - Bloqueia reset password
```

---

## ISSUE #3: Welcome Page - Duplicate Hamburger Menu

```markdown
## 🍔 [UX] Remove duplicate hamburger menu

### Descrição
Há TWO hamburger menus aparecendo na tela. Manter apenas UMA.

### Checklist
- [ ] Identificar ambos hamburgers (grep ou DevTools)
- [ ] Remover um (qual é duplicata?)
- [ ] Manter apenas LEFT-aligned hamburger
- [ ] Verificar que menu abre/fecha corretamente
- [ ] Testar no mobile (responsivo)

### Prova de Funcionamento
```bash
# Deve encontrar apenas UMA referência
grep -r "hamburger\|MenuIcon" app/dpwai/\[tenant_snake\]/welcome/ --include="*.tsx"
```

### Aceitação
- ✅ Apenas UMA hamburger menu visível
- ✅ Alinhada à esquerda
- ✅ Abre/fecha corretamente
- ✅ Mobile responsivo

### Labels
`bug` `frontend` `ux`

### Prioridade
HIGH
```

---

## ISSUE #4: Welcome Page - Header Layout

```markdown
## 👤 [UX] Fix header layout - greeting + avatar

### Descrição
Header deve conter: Hamburger | Greeting | Avatar

#### Atual (ERRADO)
- Greeting está floating fora do header
- Avatar não está no header
- Layout quebrado

#### Esperado (CORRETO)
```
┌─────────────────────────────────────┐
│ ☰  Olá, João Silva    [Avatar] 👤   │
└─────────────────────────────────────┘
```

### Checklist
- [ ] Hamburger menu (left)
- [ ] "Olá, <userName>" (inside header)
- [ ] User avatar (top-right)
- [ ] Dark theme colors
- [ ] Proper spacing/padding
- [ ] Mobile responsive

### Prova de Funcionamento
- DevTools > Inspect header element
- Verify all 3 items visible
- Measure spacing (should be consistent)

### Aceitação
- ✅ All 3 elements in header
- ✅ Properly aligned
- ✅ Dark theme
- ✅ Responsive

### Labels
`bug` `frontend` `ux`

### Prioridade
HIGH
```

---

## ISSUE #5: Welcome Page - Remove Footer

```markdown
## 🚫 [UX] Remove footer from welcome page

### Descrição
Footer é redundante e confuso. Toda navegação já existe em hamburger menu.

### Checklist
- [ ] Identify footer component/code
- [ ] Remove from welcome page
- [ ] Verify no orphaned content
- [ ] Test mobile layout
- [ ] Check responsiveness

### Prova de Funcionamento
```bash
# Footer should not appear in welcome page
grep -r "footer" app/dpwai/\[tenant_snake\]/welcome/ --include="*.tsx"
# Resultado: (no matches)
```

### Aceitação
- ✅ Footer completely removed
- ✅ Layout looks clean
- ✅ Mobile responsive
- ✅ No broken elements

### Labels
`bug` `frontend` `ux`

### Prioridade
MEDIUM
```

---

## ISSUE #6: Welcome Page - Add Choice Buttons

```markdown
## 🎯 [UX] Add personalization choice on welcome screen

### Descrição
User deve escolher onde ir: Dashboards ou Ralph Chat

### Implementação
Adicionar 2 cards/buttons:
- "Ver Dashboards" → /dpwai/{tenant}/dashboards
- "Abrir Ralph Chat" → /dpwai/{tenant}/ralph-chat

### Checklist
- [ ] Cards/buttons UI criados
- [ ] "Ver Dashboards" button funciona
- [ ] "Abrir Ralph Chat" button funciona
- [ ] Dark theme aplicado
- [ ] Responsive layout
- [ ] Hover states visíveis

### Aceitação
- ✅ 2 buttons visible
- ✅ Both functional
- ✅ Good UX (clear text, good contrast)
- ✅ Responsive

### Labels
`feature` `frontend` `ux`

### Prioridade
MEDIUM
```

---

## ISSUE #7: Dashboards - Fetch Error Handling

```markdown
## 🔴 [BUG] Dashboard fetch error - "failed to fetch dashboards"

### Descrição
Quando dashboards API falha, usuario vê raw error message.

### Problema
Erro: "failed to fetch dashboards"
Deveria ser: Mensagem amigável em português

### Checklist
- [ ] API call has proper auth (accessToken)
- [ ] Error response handled
- [ ] Show loading state while fetching
- [ ] Empty state if no dashboards
- [ ] User-friendly error message in Portuguese

### Prova de Funcionamento
```bash
# Test sem token
curl http://localhost:3000/api/dashboards
# Esperado: 401 Unauthorized

# Test com token inválido
curl -H "Authorization: Bearer invalid" http://localhost:3000/api/dashboards
# Esperado: 401 Unauthorized

# Frontend deve mostrar mensagem friendy, não raw error
```

### Aceitação
- ✅ Auth token properly used
- ✅ Error handling clean
- ✅ User-friendly messages in Portuguese
- ✅ Loading state visible

### Labels
`bug` `frontend` `api`

### Prioridade
HIGH
```

---

## ISSUE #8: New Dashboard - Creation Flow

```markdown
## ➕ [BUG] "Novo Painel" button - "error evaluating"

### Descrição
Clicando "Novo Painel" causa erro "error evaluating".

### Checklist
- [ ] Modal opens without errors
- [ ] Form fields present: name, description
- [ ] Validation: name required
- [ ] Submit creates dashboard (backend)
- [ ] Success response handled
- [ ] Redirect to dashboards list
- [ ] Error messages friendly (Portuguese)

### Prova de Funcionamento
1. Click "Novo Painel" button
2. Modal should open (no errors)
3. Fill "Name: Test Dashboard"
4. Click Submit
5. Should redirect to list
6. New dashboard should be visible

### Aceitação
- ✅ Modal opens cleanly
- ✅ Form works
- ✅ Creation succeeds
- ✅ Proper error handling

### Labels
`bug` `frontend` `forms`

### Prioridade
CRITICAL
```

---

## ISSUE #9: Forms Page - Dark Theme

```markdown
## 🌙 [UX] Forms page - Apply dark theme

### Descrição
Forms page está branca. Deve ser dark theme como resto da app.

### Checklist
- [ ] Background: slate-950
- [ ] Cards: slate-900 com border slate-800
- [ ] Text: white/slate-200
- [ ] Buttons: green-600 para primary
- [ ] No white backgrounds anywhere
- [ ] Proper contrast

### Prova de Funcionamento
```bash
grep -r "bg-white" app/dpwai/\[tenant_snake\]/forms/ --include="*.tsx"
# Resultado: (no matches)
```

### Aceitação
- ✅ Dark theme applied
- ✅ Good contrast (readable)
- ✅ Consistent colors
- ✅ No white backgrounds

### Labels
`bug` `frontend` `theme`

### Prioridade
HIGH
```

---

## ISSUE #10: Forms Page - Edit Button Visibility

```markdown
## 👁️ [UX] Edit button not visible on form cards

### Descrição
Edit button está invisível ou baixo contraste.

### Checklist
- [ ] Edit button visible on each form card
- [ ] Good contrast (readable)
- [ ] Proper size (44px+ for touch)
- [ ] Hover state visible
- [ ] Click goes to Form Builder
- [ ] Mobile responsive

### Aceitação
- ✅ Button clearly visible
- ✅ Good contrast
- ✅ Touch-friendly size
- ✅ Works on mobile

### Labels
`bug` `frontend` `ux`

### Prioridade
MEDIUM
```

---

## ISSUE #11: Forms - Create to Builder Redirect

```markdown
## 🔄 [UX] After create form → go directly to Builder

### Descrição
Quando user cria form, volta pra lista. Deveria ir pro Form Builder.

#### Atual (ERRADO)
Create form → redirect to forms list

#### Esperado (CORRETO)
Create form → redirect to /dpwai/{tenant}/forms/{formId}/builder

### Checklist
- [ ] Form creation works
- [ ] Redirect goes to Builder (not list)
- [ ] Builder loads correctly
- [ ] Form data is present

### Aceitação
- ✅ Redirect to Builder works
- ✅ Can immediately edit form
- ✅ Good UX

### Labels
`feature` `frontend` `ux`

### Prioridade
HIGH
```

---

## ISSUE #12: Form Builder - Complete Overhaul

```markdown
## 🏗️ [MAJOR] Form Builder - Fix broken layout + hide JSON

### Descrição
Form builder está completamente quebrado. Precisa de refactor completo.

### Problemas
- [ ] Layout quebrado
- [ ] Fields misaligned
- [ ] Inputs unreadable
- [ ] "salvo" message intrusive + ugly
- [ ] Number fields unreadable
- [ ] JSON constraints exposed (CONFUSING)

### Soluções Necessárias
- [ ] Clean, user-friendly layout
- [ ] Fields properly aligned + readable
- [ ] Hide all JSON / technical constraints
- [ ] Subtle "Saved" notification (not intrusive)
- [ ] Number input works (proper UI)
- [ ] Text input works (proper UI)
- [ ] All field types functional
- [ ] Dark theme applied

### Prova de Funcionamento
1. Create a form
2. Go to Builder
3. Add various field types (text, number, select, etc)
4. All should be readable + usable
5. Save should work (subtle message)
6. No JSON exposed to user

### Aceitação
- ✅ Layout clean + professional
- ✅ All fields readable
- ✅ No technical jargon shown
- ✅ UX is intuitive

### Labels
`bug` `frontend` `forms` `critical`

### Prioridade
CRITICAL
```

---

## ISSUE #13: Roth Chat - Responsive Design

```markdown
## 💬 [UX] Roth Chat - Make responsive + usable

### Descrição
Chat interface é quebrada em mobile. Precisa redesign completo.

### Problemas
- [ ] Not responsive
- [ ] Layout broken on mobile
- [ ] Only shows chat list (no chat window)
- [ ] Terrible UX
- [ ] Dark theme not applied
- [ ] Input area not visible

### Soluções
- [ ] Responsive layout (mobile-first)
- [ ] Chat window visible
- [ ] Message input clear
- [ ] Send button accessible
- [ ] Messages scroll properly
- [ ] Dark theme applied
- [ ] User avatars visible
- [ ] Timestamps on messages
- [ ] Good contrast

### Prova de Funcionamento
1. Send a message
2. See it appear in chat
3. Receive response
4. Test on mobile (360px)
5. Everything readable + usable

### Aceitação
- ✅ Responsive design
- ✅ Clean UI
- ✅ Functional chat
- ✅ Mobile works

### Labels
`bug` `frontend` `ux` `chat`

### Prioridade
CRITICAL
```

---

## ISSUE #14: Users Page - Responsive + Contrast

```markdown
## 👥 [UX] Users page - Fix responsiveness + contrast

### Descrição
Users page não é responsivo. Fonts pequenas, baixo contraste.

### Checklist
- [ ] Mobile responsive (360px+)
- [ ] Text readable (good contrast)
- [ ] User list shows all users
- [ ] Buttons accessible (44px+)
- [ ] Dark theme applied
- [ ] Roles visible (OWNER, ADMIN, USER)

### Aceitação
- ✅ Responsive layout
- ✅ Good contrast
- ✅ Touch-friendly buttons
- ✅ Dark theme

### Labels
`bug` `frontend` `ux`

### Prioridade
MEDIUM
```

---

## ISSUE #15: Roles Implementation - Complete

```markdown
## 🔐 [FEATURE] Implement roles: OWNER, ADMIN, USER

### Descrição
Implementar sistema de roles com permissões corretas.

### OWNER
- [ ] Can manage organization
- [ ] Create/delete organization
- [ ] Create users
- [ ] Assign roles
- [ ] Delete other users

### ADMIN
- [ ] Can edit forms
- [ ] Can edit dashboards
- [ ] Can manage users
- [ ] CANNOT delete organization

### USER
- [ ] Can view dashboards
- [ ] Can fill public forms (no login)
- [ ] CANNOT edit anything
- [ ] CANNOT access settings

### Backend Checks
- [ ] Middleware validates roles
- [ ] API endpoints check permissions
- [ ] Unauthorized returns 403

### Aceitação
- ✅ All 3 roles implemented
- ✅ Permissions enforced
- ✅ Backend validation
- ✅ No permission bypasses

### Labels
`feature` `backend` `security`

### Prioridade
CRITICAL
```

---

## COMO USAR ESTE TEMPLATE

1. **Copia uma seção acima** (ex: ISSUE #1)
2. **Vai em GitHub > New Issue**
3. **Cola o markdown**
4. **Ajusta conforme necessário**
5. **Cria a issue**
6. **Marca com labels e priority**

Quando issue está pronta:
- [ ] Close issue
- [ ] Add comment: "✅ Verificado e pronto"
- [ ] Move para "Done" (se estiver usando Projects)

---

## RASTREAMENTO DE PROGRESSO

Use isso pra monitorar:

| # | Issue | Status | Done |
|-|--------|--------|------|
| 1 | Login tradução | 🔴 To Do | |
| 2 | Forgot password | 🔴 To Do | |
| 3 | Duplicate hamburger | 🔴 To Do | |
| 4 | Header layout | 🔴 To Do | |
| 5 | Remove footer | 🔴 To Do | |
| 6 | Choice buttons | 🔴 To Do | |
| 7 | Dashboard fetch error | 🔴 To Do | |
| 8 | New dashboard | 🔴 To Do | |
| 9 | Forms dark theme | 🔴 To Do | |
| 10 | Edit button visibility | 🔴 To Do | |
| 11 | Create to builder | 🔴 To Do | |
| 12 | Form builder refactor | 🔴 To Do | |
| 13 | Roth chat responsive | 🔴 To Do | |
| 14 | Users page UX | 🔴 To Do | |
| 15 | Roles implementation | 🔴 To Do | |

Total: **15 issues**
Done: **0**
Progress: **0%**

