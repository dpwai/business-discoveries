# 📊 Looker Studio Embed - Visual Testing Guide

**Status:** 🔄 **READY FOR VISUAL TESTING**
**Date:** 2026-01-25
**Looker URL:** `https://lookerstudio.google.com/reporting/bb2655f9-5458-4231-a919-35554c1cee93`

---

## 🎯 Test Objective

Validate that Looker Studio embed appears correctly (no white screen, no iframe blocks, proper height, no scrolling issues) on desktop and mobile.

---

## 📍 Dashboard Pages to Test (3 total)

### **1. Dashboard List Page**
- **Route:** `/dpwai/[tenant]/dashboards`
- **Path Example:** `http://localhost:3000/dpwai/fazenda-demo/dashboards`
- **Embed Location:** Below header, above dashboard grid
- **Expected:** Looker embed visible below "Dashboards" title

### **2. Individual Dashboard Page**
- **Route:** `/dpwai/[tenant]/dashboards/[id]`
- **Path Example:** `http://localhost:3000/dpwai/fazenda-demo/dashboards/{any-dashboard-id}`
- **Embed Location:** Below existing dashboard iframe (if configured)
- **Expected:** Looker embed visible below dashboard content

### **3. Public Shared Dashboard Page**
- **Route:** `/share/dashboard/[token]`
- **Path Example:** `http://localhost:3000/share/dashboard/{token}`
- **Embed Location:** Below placeholder content
- **Expected:** Looker embed visible on public page

---

## 🖥️ Desktop Testing (Chrome/Firefox/Safari)

### **Checklist:**

```
[ ] Page 1 - Dashboard List
    [ ] Embed loads without white/blank area
    [ ] "Loading..." text appears briefly
    [ ] Iframe renders the Looker dashboard
    [ ] No horizontal scrollbar on page
    [ ] Width is 100% (full container width)
    [ ] Height is ~700px (decent size)
    [ ] "Open report" link visible in header

[ ] Page 2 - Individual Dashboard
    [ ] Same checks as Page 1
    [ ] Embed appears below existing dashboard content
    [ ] No layout conflicts with dashboard above

[ ] Page 3 - Public Shared Dashboard
    [ ] Same checks as Page 1
    [ ] Works without authentication
    [ ] Styling matches light background (not dark theme)
```

### **Success Criteria:**
✅ All 3 pages load embed correctly
✅ No white/blank areas
✅ No "Embed blocked" message
✅ Can scroll within page without breaking layout

---

## 📱 Mobile Testing (iPhone Safari)

### **Checklist:**

```
[ ] Page 1 - Dashboard List (Portrait)
    [ ] Embed loads (not white)
    [ ] Not cut off by bottom Safari bar
    [ ] Can scroll up/down within page
    [ ] Embed has good height (600-800px min)
    [ ] No horizontal overflow/scrollbar
    [ ] Text is readable (not too small)

[ ] Page 1 - Dashboard List (Landscape)
    [ ] Embed still loads correctly
    [ ] No layout issues in landscape
    [ ] Still scrollable vertically

[ ] Page 2 - Individual Dashboard (Portrait + Landscape)
    [ ] Same checks as Page 1
    [ ] Works in both orientations

[ ] Page 3 - Public Shared (Portrait + Landscape)
    [ ] Same checks as Page 1
    [ ] Public page renders correctly on mobile
```

### **Success Criteria:**
✅ Embed loads on iPhone (not white)
✅ Not cut off by Safari bottom bar
✅ Can scroll page smoothly
✅ No horizontal overflow
✅ Usable in both portrait and landscape

---

## 🔍 What to Watch For (Failure Modes)

### **❌ If Embed Shows Blank/White:**
- **Cause:** Likely `Enable embedding` not turned on in Looker Studio, or private report
- **Solution:** Check Looker Studio File > Embed report settings
- **Fallback:** "Open report" button should work (opens in new tab)

### **❌ If You See "Embed blocked or not loading":**
- **Cause:** CSP headers or X-Frame-Options blocking iframe
- **Solution:** This is expected on some browsers/auth configs
- **Fallback:** Click "Open report" button → Opens in new tab (works fine)

### **❌ If Embed Appears but is Tiny/Cut Off:**
- **Cause:** Height not set correctly or container too small
- **Solution:** Check minHeight prop (should be 720px or more)
- **Expected:** Height is ~700px, full width

### **❌ If Page Has Horizontal Scrollbar:**
- **Cause:** Iframe too wide or padding/margin issues
- **Solution:** Check width is 100% and no extra margins
- **Expected:** Width is exactly 100% of container

### **⚠️ On iPhone Safari - White Screen:**
- **Cause:** Private report + Safari auth/cookie blockers (known issue)
- **Solution:** Fallback "Open report" button works
- **Workaround:** Make report "Anyone with link can view" or "Public"
- **Expected:** Either embed works OR fallback button is visible and clickable

---

## 📋 Testing Template

Copy and fill out while testing:

```markdown
## Desktop Testing

### Page 1: Dashboard List
- URL: `http://localhost:3000/dpwai/fazenda-demo/dashboards`
- Browser: [Chrome/Firefox/Safari]
- ✅/❌ Embed loaded without white screen
- ✅/❌ "Loading..." appeared
- ✅/❌ Iframe renders dashboard
- ✅/❌ No horizontal scrollbar
- Notes: [Any issues?]

### Page 2: Individual Dashboard
- URL: `http://localhost:3000/dpwai/fazenda-demo/dashboards/{id}`
- Status: [Testing / OK / FAIL]
- Notes: [Any issues?]

### Page 3: Public Shared
- URL: `http://localhost:3000/share/dashboard/{token}`
- Status: [Testing / OK / FAIL]
- Notes: [Any issues?]

## Mobile Testing (iPhone Safari)

### Portrait
- ✅/❌ Embed loads (not white)
- ✅/❌ Not cut by bottom bar
- ✅/❌ Can scroll page
- Notes: [Any issues?]

### Landscape
- ✅/❌ Still loads and scrolls
- Notes: [Any issues?]

## Summary
- Desktop: [OK/FAIL]
- Mobile: [OK/FAIL]
- Overall: [READY / NEEDS FIX]
```

---

## 🛠️ If Testing Reveals Issues

### **Issue: Embed shows blank/white**
**Check:**
1. Is "Enable embedding" turned ON in Looker Studio?
   - File > Embed report > checkbox "Enable embedding"
2. Is the report private?
   - Try making it "Anyone with the link can view"
3. Is the embed URL correct?
   - Should start with `https://lookerstudio.google.com/embed/reporting/...`
   - NOT `/reporting/...` (that's for viewing only)

**If you have the correct Embed URL:**
```
Contact: Need to update the embed URL in code
Files to update:
- app/dpwai/[tenant_snake]/dashboards/page.tsx (line ~250)
- app/dpwai/[tenant_snake]/dashboards/[id]/page.tsx (line ~171)
- app/share/dashboard/[token]/page.tsx (line ~112)

Replace `embedUrl` prop with your actual embed URL
```

### **Issue: "Embed blocked or not loading" appears**
**Expected behavior:** This is a fallback state
- Click "Open report" → Opens in new tab (works)
- On iPhone Safari: Common with private reports (expected)
- **Not a failure**, fallback is working as designed

### **Issue: Embed is too small or cut off on mobile**
**Check:**
1. minHeight might be too small for mobile
2. Container has proper padding
3. No width constraints limiting iframe

**Current:** minHeight={720} (might be too tall on small screens)

---

## 📊 Component Details

**File:** `components/LookerEmbed.tsx`

**Props:**
```typescript
interface LookerStudioEmbedProps {
  embedUrl: string;      // https://lookerstudio.google.com/embed/reporting/...
  openUrl: string;       // https://lookerstudio.google.com/reporting/... (fallback)
  title?: string;        // Report title (default: "Looker Studio")
  minHeight?: number;    // Min height in px (default: 720)
  className?: string;    // Optional CSS classes
}
```

**Behavior:**
- ✅ Validates URLs before rendering
- ✅ Shows "Loading..." while iframe loads
- ✅ 5-second timeout → shows fallback if stuck
- ✅ onLoad → clears timeout and shows embed
- ✅ onError → shows fallback "Embed blocked" + button
- ✅ Always shows "Open report" link at top

---

## ✅ Acceptance Criteria Checklist

- [ ] Dashboard list page has embed
- [ ] Individual dashboard page has embed
- [ ] Public shared page has embed
- [ ] Embed loads on desktop without white screen
- [ ] Embed loads on iPhone Safari (or shows fallback)
- [ ] No horizontal scrollbar on any page
- [ ] "Open report" button visible and works
- [ ] Can scroll page smoothly
- [ ] Not cut off by Safari bottom bar (mobile)
- [ ] Fallback shows if embed blocks (expected)

---

## 🚀 Next Steps After Testing

1. **If all tests pass:** Mark as ✅ COMPLETE
2. **If embed shows blank on mobile:**
   - Check if report needs public sharing
   - Consider mobile-specific minHeight
3. **If layout breaks:**
   - Check container widths/paddings
   - May need to adjust responsive design

---

**Start testing now:** Login to `http://localhost:3000` with `admin@dpwai.com` / `Admin@123456`

Then navigate to the 3 dashboard routes above and fill out the testing template! 🎯

