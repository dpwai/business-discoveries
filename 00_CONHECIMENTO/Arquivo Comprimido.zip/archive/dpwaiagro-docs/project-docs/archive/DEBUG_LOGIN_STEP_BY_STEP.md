# 🔍 Debug Login Issue - Step by Step

## Step 1: Check if Admin Exists in Database

Go to this endpoint in your browser:
```
http://localhost:3000/api/debug/seed-status
```

**Expected response:**
```json
{
  "database": {
    "usersTotal": 1,
    "tenantsTotal": 1
  },
  "admin": {
    "id": "...",
    "email": "admin@dpwai.com",
    "username": "admin",
    "status": "ACTIVE",
    "passwordHashLength": 60,
    "memberships": 1,
    "tenants": [
      {
        "id": "...",
        "name": "Fazenda Demo",
        "snake": "fazenda-demo",
        "isOwner": true,
        "isAdmin": true
      }
    ]
  },
  "demoTenant": {
    "id": "...",
    "name": "Fazenda Demo",
    "snake": "fazenda-demo"
  }
}
```

**If admin is null:**
- User doesn't exist - continue to Step 2
- **If you see an error instead:** Database connection might be broken - check DATABASE_URL

---

## Step 2: Manually Trigger Seeding

Send a POST request:
```bash
curl -X POST http://localhost:3000/api/debug/manual-seed
```

Or visit this in your browser and reload:
```
http://localhost:3000/api/debug/manual-seed
```

**Expected response:**
```json
{
  "seedResult": {
    "created": true,
    "admin": {
      "id": "...",
      "email": "admin@dpwai.com",
      ...
    }
  },
  "verified": {
    "adminExists": true,
    "admin": { ... }
  }
}
```

**If you see an error like "Unique constraint failed":**
- User or username already exists
- Go to Step 3 to check database directly

---

## Step 3: Check Server Logs

After trying to login with `admin@dpwai.com` / `Admin@123456`:

Look for these log lines:
```
[LOGIN] Request received at endpoint /api/auth/login
[SEED] Starting idempotent demo admin seed...
[SEED] ✓ Demo tenant already exists: [ID]
[SEED] ✓ Admin user exists: admin@dpwai.com ID: [ID]
[SEED] ✓ Password hash already valid
[SEED] ✓ Admin already has membership to demo tenant
[LOGIN] Attempting to seed demo admin...
[LOGIN] Seed result: { created: false, hasAdmin: true, hasError: false }
[LOGIN] Raw email: admin@dpwai.com
[LOGIN] Normalized email: admin@dpwai.com
[LOGIN] Querying database for user...
[LOGIN] User found: admin@dpwai.com
[LOGIN] Password valid
[LOGIN] Success, returning response
```

**If you DON'T see these logs:**
- App might not be restarted
- Restart: `npm run dev` (or redeploy if on production)

**If you see `[SEED] ❌ Error seeding demo admin:`**
- Check the error message that follows
- It will tell you exactly what's wrong

---

## Step 4: Check What's Causing the Error

If seeding fails, look for error patterns:

### Error: "Unique constraint failed on the fields: (`email`)"
**Cause:** User with email `admin@dpwai.com` already exists (maybe with wrong password)
**Solution:**
- Delete the existing user from database:
```sql
DELETE FROM "User" WHERE email = 'admin@dpwai.com';
DELETE FROM "Tenant" WHERE snake = 'fazenda-demo';
```
- Then try login again (will re-seed with correct password)

### Error: "Unique constraint failed on the fields: (`username`)"
**Cause:** User with username `admin` already exists
**Solution:**
- Same as above - delete existing user

### Error: "Foreign key constraint failed"
**Cause:** Tenant doesn't exist but user is trying to reference it
**Solution:**
- This should be fixed by improved seeding
- Check that tenant is created before user

### Error: "Connection refused"
**Cause:** Database is not accessible
**Solution:**
- Verify DATABASE_URL is correct
- Check database is running
- For production: verify connection string and network

---

## Step 5: Direct Database Query (Advanced)

If nothing else works, query directly:

```sql
-- Check if admin user exists
SELECT id, email, username, status, "passwordHash" FROM "User"
WHERE email = 'admin@dpwai.com';

-- Check if admin has memberships
SELECT * FROM "Membership"
WHERE "userId" = (SELECT id FROM "User" WHERE email = 'admin@dpwai.com');

-- Check if demo tenant exists
SELECT * FROM "Tenant" WHERE snake = 'fazenda-demo';

-- Check all users in database
SELECT id, email, username, status FROM "User" LIMIT 10;
```

**If admin doesn't exist at all:**
- Database schema might be wrong
- Check that migrations were run: `npx prisma migrate deploy`

**If admin exists but password hash is invalid:**
- Update it directly:
```sql
-- Generate new hash (use bcrypt hash of 'Admin@123456')
-- In production: use proper password hashing tool
UPDATE "User"
SET "passwordHash" = '$2b$10$...' -- replace with bcrypt hash
WHERE email = 'admin@dpwai.com';
```

---

## Quick Diagnostic Checklist

- [ ] Call `/api/debug/seed-status` → Check admin exists
- [ ] If not, call `/api/debug/manual-seed` → Force seeding
- [ ] Try login again with `admin@dpwai.com` / `Admin@123456`
- [ ] Check server logs for `[SEED]` and `[LOGIN]` messages
- [ ] If still fails, check Database URL and connection
- [ ] If still fails, query database directly for admin user
- [ ] If admin doesn't exist, delete tenant and user, try again

---

## Production Debugging

If app is deployed (not localhost):

### Using curl to test API:
```bash
# Check seed status
curl https://app.dpwai.com.br/api/debug/seed-status

# Manually seed
curl -X POST https://app.dpwai.com.br/api/debug/manual-seed

# Test login (raw)
curl -X POST https://app.dpwai.com.br/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@dpwai.com","password":"Admin@123456"}'
```

### View production logs:
- **Vercel:** Console in Vercel dashboard → Deployments → Function Logs
- **Other hosting:** Check app logs where you deployed

### Check production database:
- Use database client/tool to connect to production DATABASE_URL
- Run queries from Step 5 above

---

## If All Else Fails

1. **Check if migrations were applied:**
   ```bash
   npx prisma migrate status
   ```

2. **Re-run migrations:**
   ```bash
   npx prisma migrate deploy
   ```

3. **Regenerate Prisma client:**
   ```bash
   npx prisma generate
   ```

4. **Reset database (CAUTION - loses all data):**
   ```bash
   npx prisma migrate reset
   ```

5. **Full redeploy (if on Vercel):**
   - Push to main branch
   - Vercel will re-run migrations and redeploy

---

## Summary: Most Likely Issue

**99% chance:** Seed never ran, admin doesn't exist in database

**Solution:**
1. Call `/api/debug/manual-seed`
2. Check server logs for any errors
3. Try login again

**If that fails:** User exists but password hash is wrong or database connection is broken

Use the debug endpoints and logs to identify which one! 🎯
