# 🚜 Tractor Global Loading - Loader para TUDO

Animação de trator 8-bit que aparece **automaticamente** em qualquer carregamento de dados da sua aplicação.

---

## ⚡ Como Funciona

O `GlobalLoadingProvider` já está integrado no `layout.tsx`, então o trator aparece **automaticamente** quando você:

- ✅ Faz um fetch com `fetchWithLoader()`
- ✅ Processa dados com `useStepLoading()`
- ✅ Carrega qualquer página/componente
- ✅ Executa operações assíncronas

---

## 🚀 Uso Rápido

### Opção 1: Fetch Automático com Loader

```tsx
'use client';

import { useAutoLoadingFetch } from '@/hooks/useAutoLoadingFetch';

export default function MyComponent() {
  const { fetchWithLoader } = useAutoLoadingFetch();

  const loadData = async () => {
    // Trator aparece automaticamente!
    const response = await fetchWithLoader(
      '/api/dashboards',
      undefined,
      'Carregando dashboards...' // mensagem customizada (opcional)
    );
    const data = await response.json();
    // Trator desaparece automaticamente
  };

  return <button onClick={loadData}>Carregar</button>;
}
```

---

### Opção 2: Etapas Múltiplas com Trator

```tsx
'use client';

import { useStepLoading } from '@/hooks/useAutoLoadingFetch';

export default function ProcessData() {
  const { startLoading, updateMessage, stopLoading } = useStepLoading();

  const process = async () => {
    // Inicia trator com mensagem
    startLoading('Validando dados...');
    await delay(2000);

    // Atualiza mensagem (trator continua)
    updateMessage('Processando...');
    await delay(2000);

    // Outra mensagem
    updateMessage('Salvando...');
    await delay(2000);

    // Para trator
    stopLoading();
  };

  return <button onClick={process}>Processar</button>;
}
```

---

## 📝 Exemplos Reais

### Exemplo 1: Carregar Dashboards

```tsx
'use client';

import { useAutoLoadingFetch } from '@/hooks/useAutoLoadingFetch';
import { useState } from 'react';

export default function DashboardsPage() {
  const [dashboards, setDashboards] = useState([]);
  const { fetchWithLoader } = useAutoLoadingFetch();

  const loadDashboards = async () => {
    const response = await fetchWithLoader(
      '/api/dashboards',
      { method: 'GET' },
      'Carregando seus dashboards...'
    );
    const data = await response.json();
    setDashboards(data);
  };

  return (
    <div>
      <button onClick={loadDashboards}>Carregar Dashboards</button>
      {dashboards.map((d) => (
        <div key={d.id}>{d.name}</div>
      ))}
    </div>
  );
}
```

### Exemplo 2: Criar Novo Dashboard

```tsx
'use client';

import { useStepLoading } from '@/hooks/useAutoLoadingFetch';

export default function CreateDashboard() {
  const { startLoading, updateMessage, stopLoading } = useStepLoading();

  const handleCreate = async (formData: FormData) => {
    startLoading('Criando dashboard...');

    try {
      updateMessage('Salvando configurações...');
      const res = await fetch('/api/dashboards', {
        method: 'POST',
        body: JSON.stringify(Object.fromEntries(formData)),
      });

      if (!res.ok) throw new Error('Falha ao criar');

      updateMessage('Dashboard criado! Redirecionando...');
      await new Promise((r) => setTimeout(r, 1000));

      // Redireciona
      window.location.href = '/dpwai/select-tenant/dashboards';
    } catch (error) {
      console.error(error);
    } finally {
      stopLoading();
    }
  };

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        handleCreate(new FormData(e.currentTarget));
      }}
    >
      {/* Seus campos do form */}
      <button type="submit">Criar</button>
    </form>
  );
}
```

### Exemplo 3: Upload de Arquivo Pesado

```tsx
'use client';

import { useStepLoading } from '@/hooks/useAutoLoadingFetch';

export default function FileUpload() {
  const { startLoading, updateMessage, stopLoading } = useStepLoading();

  const handleUpload = async (file: File) => {
    startLoading('Preparando arquivo...');

    const formData = new FormData();
    formData.append('file', file);

    try {
      updateMessage('Enviando arquivo...');
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      updateMessage('Processando dados...');
      const data = await res.json();

      updateMessage('Salvando no banco...');
      await new Promise((r) => setTimeout(r, 1000));

      console.log('Upload concluído:', data);
    } finally {
      stopLoading();
    }
  };

  return (
    <input
      type="file"
      onChange={(e) => {
        const file = e.target.files?.[0];
        if (file) handleUpload(file);
      }}
    />
  );
}
```

### Exemplo 4: Operação Complexa com Progresso

```tsx
'use client';

import { useStepLoading } from '@/hooks/useAutoLoadingFetch';

export default function ComplexOperation() {
  const { startLoading, updateMessage, stopLoading } = useStepLoading();

  const steps = [
    { msg: 'Fase 1: Análise de dados', time: 2000 },
    { msg: 'Fase 2: Processamento', time: 3000 },
    { msg: 'Fase 3: Agregação', time: 2000 },
    { msg: 'Fase 4: Salvamento', time: 1000 },
  ];

  const run = async () => {
    startLoading(steps[0].msg);

    for (let i = 0; i < steps.length; i++) {
      if (i > 0) {
        updateMessage(steps[i].msg);
      }
      await new Promise((r) => setTimeout(r, steps[i].time));
    }

    stopLoading();
  };

  return (
    <button onClick={run} className="px-6 py-3 bg-green-600 text-white rounded">
      Executar Operação Complexa
    </button>
  );
}
```

---

## 🎯 Mensagens Padrão

Se você não passar uma mensagem customizada, as mensagens são alternadas automaticamente:

```
'Arando a terra 🌾'
'Plantando dados 🌱'
'Regando campos 💧'
'Colhendo informações 🌽'
'Processando safra 📊'
'Analisando solo 🔬'
'Cultivando resultados 🚜'
'Sincronizando máquina ⚙️'
```

Para usar suas próprias mensagens, edite `/hooks/useAutoLoadingFetch.ts`:

```tsx
const messages = [
  'Sua mensagem 1',
  'Sua mensagem 2',
  // ...
];
```

---

## 🔧 Customização

### Mudar Intensidade do Trator

Edit `/context/GlobalLoadingContext.tsx`:

```tsx
<TractorLoader
  message={message}
  intensity="exhaustive" // ← mude para 'light', 'medium', 'exhaustive'
  showHUD={true}
/>
```

### Remover HUD (painel de status)

```tsx
<TractorLoader
  message={message}
  intensity="exhaustive"
  showHUD={false} // ← sem o painel
/>
```

### Alterar Z-Index

Se o trator não aparecer acima de outros elementos:

```tsx
// Em GlobalLoadingContext.tsx
<div className="fixed inset-0 z-9999"> {/* ← aumente o z-index */}
```

---

## ⚙️ Como Funciona

1. **GlobalLoadingProvider** está no `layout.tsx` e envolve toda a app
2. Quando você chama `startLoading()`, o trator aparece com `z-index: 9999` (acima de tudo)
3. Quando você chama `stopLoading()`, o trator desaparece
4. Mensagens são atualizadas com `updateMessage()` ou `setMessage()`

```
Layout
├── GlobalLoadingProvider (renderiza trator se isLoading=true)
└── Seu conteúdo
```

---

## 🔍 Debug

### Trator não aparece?

```tsx
// Teste manualmente:
const { startLoading, stopLoading } = useGlobalLoading();

useEffect(() => {
  startLoading('Teste');
  setTimeout(() => stopLoading(), 3000);
}, []);
```

### Mensagem não atualiza?

Certifique-se que você está chamando `updateMessage()` (não `setMessage()`):

```tsx
// ✅ Correto
const { updateMessage } = useStepLoading();
updateMessage('Nova mensagem');

// ❌ Errado
setMessage('Nova mensagem'); // não vai funcionar
```

### Fetch não mostra trator?

Use `fetchWithLoader()`, não `fetch()` direto:

```tsx
// ✅ Mostra trator
const response = await fetchWithLoader('/api/data');

// ❌ Não mostra trator
const response = await fetch('/api/data');
```

---

## 📱 Mobile

O trator funciona perfeitamente em mobile! As animações automaticamente se adaptam ao tamanho da tela.

```tsx
// Para forçar modo light em mobile (mais rápido):
const isMobile = window.innerWidth < 768;
const intensity = isMobile ? 'light' : 'exhaustive';
```

---

## 🎨 Estrutura de Arquivos

```
/context/
└── GlobalLoadingContext.tsx   # Provider global

/hooks/
├── useAutoLoadingFetch.ts    # Auto-loader para fetch
├── useTractorLoader.ts       # Hook básico
└── index.ts                  # Exports

/app/
└── layout.tsx                # GlobalLoadingProvider integrado
```

---

## 💡 Boas Práticas

✅ **Use `fetchWithLoader()` para:**
- API calls normais
- Carregamento de dados
- Operações rápidas

✅ **Use `useStepLoading()` para:**
- Operações multi-etapa
- Processamento complexo
- Upload de arquivos
- Cálculos pesados

❌ **NÃO use para:**
- Operações muito rápidas (< 500ms)
- Validações instantâneas
- Animations apenas visuais

---

## 🚀 Próximos Passos

1. ✅ GlobalLoadingProvider já configurado no layout
2. Substitua seus `fetch()` por `fetchWithLoader()`
3. Adicione `useStepLoading()` em operações complexas
4. Customzie as mensagens conforme necessário

Pronto! Agora **TUDO** que carrega mostra o trator 8-bit! 🚜✨
