# Forms System - API Reference

Complete API documentation for the Jotform-like forms system.

---

## Public APIs (Unauthenticated)

### 1. Get Form Details
**GET** `/api/public/forms/[publicId]`

Fetch a public form with schema and page template.

**Parameters:**
- `publicId` (path) - Unique public identifier of the form

**Response (200 OK):**
```json
{
  "id": "form_uuid",
  "name": "Customer Feedback Form",
  "publicId": "abc123xyz",
  "description": "Help us improve",
  "schema": {
    "fields": [
      {
        "id": "field_1",
        "type": "text",
        "label": "Full Name",
        "required": true
      },
      {
        "id": "field_2",
        "type": "email",
        "label": "Email Address",
        "required": true
      }
    ]
  },
  "pageTemplate": {
    "templateType": "SINGLE_PAGE",
    "pageJson": {}
  },
  "settings": {
    "accessMode": "ANYONE_WITH_LINK",
    "publicEnabled": true,
    "identityLevel": "MINIMAL",
    "requireSelfie": false,
    "requireDocumentPhoto": false,
    "requireAudioProof": false,
    "maxFileSizeMB": 100,
    "maxFilesPerSubmission": 10,
    "draftResumeEnabled": true,
    "draftExpiryDays": 30
  }
}
```

**Error Responses:**
- `404` - Form not found
- `403` - Form is not publicly available
- `400` - Form has no published version

---

### 2. Submit Form
**POST** `/api/public/forms/[publicId]/submissions`

Submit form responses with identity data.

**Parameters:**
- `publicId` (path) - Form's public ID

**Request Body:**
```json
{
  "identityData": {
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+5511999999999"
  },
  "answersJson": {
    "field_1": "John Doe",
    "field_2": "john@example.com",
    "field_3": "Some answer"
  },
  "fileIds": ["file_uuid_1", "file_uuid_2"],
  "draftToken": "draft_token_xyz",
  "otpToken": "jwt_token_from_verify"
}
```

**Response (200 OK):**
```json
{
  "submissionId": "submission_uuid",
  "confirmationUrl": "/f/abc123xyz/submitted/submission_uuid",
  "message": "Formulário enviado com sucesso"
}
```

**Error Responses:**
- `400` - Invalid form data or honeypot triggered
- `403` - Access denied (OTP not verified, not in allowlist, etc.)
- `404` - Form not found
- `429` - Rate limited

**Request Headers:**
```
Content-Type: application/json
X-Forwarded-For: (optional, for IP tracking)
```

---

### 3. Send OTP Code
**POST** `/api/public/forms/[publicId]/otp/send`

Request OTP code for email verification.

**Parameters:**
- `publicId` (path) - Form's public ID

**Request Body:**
```json
{
  "email": "user@example.com"
}
```

**Response (200 OK):**
```json
{
  "otpId": "otp_uuid",
  "expiresIn": 900,
  "message": "Código enviado para o email"
}
```

**Error Responses:**
- `400` - Invalid email format
- `429` - Rate limited (max 3 per email per hour)
- `404` - Form not found

**Rate Limiting:**
- Maximum: 3 OTP requests per email per 1 hour
- Expiry: 15 minutes (900 seconds)

---

### 4. Verify OTP Code
**POST** `/api/public/forms/[publicId]/otp/verify`

Verify OTP code and get verification token.

**Parameters:**
- `publicId` (path) - Form's public ID

**Request Body:**
```json
{
  "otpId": "otp_uuid",
  "code": "123456"
}
```

**Response (200 OK):**
```json
{
  "verified": true,
  "verificationToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "email": "user@example.com",
  "message": "Email verificado com sucesso"
}
```

**Error Responses:**
- `400` - Invalid or expired code
- `429` - Too many attempts

**Token Usage:**
Use the `verificationToken` in the submission `otpToken` field when submitting forms in OTP_EMAIL mode.

---

## Admin APIs (Authenticated)

> All admin APIs require JWT token in `Authorization: Bearer {token}` header

### 1. Get Form
**GET** `/api/agro/[tenant]/forms/[formId]`

Fetch a form with all details (for admin).

**Parameters:**
- `tenant` (path) - Tenant identifier
- `formId` (path) - Form UUID

**Response (200 OK):**
```json
{
  "id": "form_uuid",
  "name": "Feedback Form",
  "slug": "feedback-form",
  "description": "...",
  "publicId": "abc123xyz",
  "status": "PUBLISHED",
  "currentVersionId": "version_uuid",
  "settings": { ... },
  "createdBy": "user_uuid",
  "createdAt": "2026-01-26T10:00:00Z",
  "updatedAt": "2026-01-26T10:00:00Z"
}
```

---

### 2. Update Form Settings
**PUT** `/api/agro/[tenant]/forms/[formId]/settings`

Update form configuration.

**Parameters:**
- `tenant` (path) - Tenant identifier
- `formId` (path) - Form UUID

**Request Body:**
```json
{
  "accessMode": "OTP_EMAIL",
  "publicEnabled": true,
  "identityLevel": "MINIMAL",
  "requireSelfie": false,
  "requireDocumentPhoto": false,
  "requireAudioProof": false,
  "maxFileSizeMB": 100,
  "allowedMimeTypes": ["image/*", "application/pdf"],
  "maxFilesPerSubmission": 10,
  "draftResumeEnabled": true,
  "draftExpiryDays": 30
}
```

**Response (200 OK):**
```json
{
  "id": "form_uuid",
  "settings": { ... },
  "updatedAt": "2026-01-26T10:05:00Z"
}
```

---

### 3. Publish Form
**POST** `/api/agro/[tenant]/forms/[formId]/publish`

Publish form to make it public.

**Parameters:**
- `tenant` (path) - Tenant identifier
- `formId` (path) - Form UUID

**Request Body:** (empty)

**Response (200 OK):**
```json
{
  "id": "form_uuid",
  "publicId": "abc123xyz",
  "status": "PUBLISHED",
  "publicUrl": "https://app.dpwai.com/f/abc123xyz",
  "publishedAt": "2026-01-26T10:10:00Z"
}
```

---

## Field Types

The form schema supports these field types:

| Type | Description | Example |
|------|-------------|---------|
| `text` | Single-line text | Name, Company |
| `email` | Email address | Email field |
| `phone` | Phone number | Contact number |
| `textarea` | Multi-line text | Comments, feedback |
| `select` | Dropdown list | Dropdown selector |
| `checkbox` | Multiple checkboxes | Yes/No, options |
| `radio` | Radio buttons | Single choice |
| `file` | File upload | Document upload |
| `date` | Date picker | Birth date, deadline |

---

## Form Settings - Access Modes

| Mode | Description | Requirements |
|------|-------------|--------------|
| `ANYONE_WITH_LINK` | Anyone with link can submit | None |
| `INTERNAL_ONLY` | Authenticated users only | User must be logged in |
| `OTP_EMAIL` | Email verification required | OTP code from email |
| `RESTRICTED_USERS` | Allowlist only | Email in allowlist |

---

## Form Settings - Identity Levels

| Level | Fields Required | Description |
|-------|-----------------|-------------|
| `MINIMAL` | Name | Basic identity |
| `OTP_EMAIL` | Name + Verified Email | Email verified via OTP |
| `ALLOWLIST` | Name + Allowlist Check | Email must be in list |

---

## Error Codes

| Code | Meaning | Action |
|------|---------|--------|
| `400` | Bad Request | Check request body format |
| `401` | Unauthorized | Missing or invalid token |
| `403` | Forbidden | Access denied (not public, OTP not verified, etc.) |
| `404` | Not Found | Form or resource doesn't exist |
| `429` | Too Many Requests | Rate limited, wait before retry |
| `500` | Server Error | Report to support team |

---

## Rate Limiting

| Endpoint | Limit | Window |
|----------|-------|--------|
| POST `/submissions` | 10 requests | Per IP, per minute |
| POST `/otp/send` | 3 requests | Per email, per hour |
| GET `/forms/[publicId]` | 100 requests | Per IP, per minute |

---

## File Upload Flow

### Step 1: Initialize Upload
**POST** `/api/public/forms/[publicId]/files/init`
```json
{
  "fileName": "document.pdf",
  "fileSize": 2048576,
  "mimeType": "application/pdf"
}
```

Response:
```json
{
  "fileId": "file_uuid",
  "uploadUrl": "https://storage.example.com/presigned-url",
  "expiresIn": 3600
}
```

### Step 2: Upload File to URL
Upload binary file to the provided `uploadUrl`

### Step 3: Complete Upload
**POST** `/api/public/forms/[publicId]/files/complete`
```json
{
  "fileId": "file_uuid"
}
```

Response:
```json
{
  "fileId": "file_uuid",
  "status": "COMPLETED",
  "storageUrl": "https://storage.example.com/file_uuid"
}
```

### Step 4: Link to Submission
Include `fileIds` in form submission request.

---

## Draft Resume Flow

### Step 1: Save Draft
**POST** `/api/public/forms/[publicId]/drafts`
```json
{
  "identitySnapshotJson": { "name": "John", "email": "john@example.com" },
  "answersJson": { "field_1": "answer" }
}
```

Response:
```json
{
  "draftToken": "draft_token_xyz",
  "draftUrl": "/d/draft_token_xyz",
  "expiresAt": "2026-02-25T10:00:00Z"
}
```

### Step 2: Load Draft (Pre-fills Form)
**GET** `/api/public/drafts/[draftToken]`

Response:
```json
{
  "identity": { "name": "John" },
  "answers": { "field_1": "answer" }
}
```

### Step 3: Update Draft
**PUT** `/api/public/drafts/[draftToken]`
```json
{
  "answersJson": { "field_1": "updated answer" }
}
```

### Step 4: Submit (Consumes Draft)
Include `draftToken` in submission request.

---

## Response Times SLA

| Operation | Target | Notes |
|-----------|--------|-------|
| Get Form | < 100ms | Cached |
| Submit Form | < 500ms | Sync validation only |
| OTP Send | < 2s | Email delivery async |
| OTP Verify | < 100ms | Local validation |

---

## Webhook Payload Structure

When webhook fires, payload includes:

```json
{
  "eventId": "event_uuid",
  "eventType": "submission.created",
  "timestamp": 1706267100,
  "data": {
    "submissionId": "sub_uuid",
    "formId": "form_uuid",
    "identityData": {
      "name": "John Doe",
      "email": "john@example.com"
    },
    "answers": { ... },
    "submittedAt": "2026-01-26T10:00:00Z"
  }
}
```

**Webhook Headers:**
```
X-DPWAI-Event-Id: event_uuid
X-DPWAI-Event-Type: submission.created
X-DPWAI-Timestamp: 1706267100
X-DPWAI-Signature: hmac_sha256_signature
```

---

## Examples

### JavaScript / Fetch API

#### Get Form
```javascript
const response = await fetch('/api/public/forms/abc123xyz');
const form = await response.json();
console.log(form.schema.fields);
```

#### Submit Form
```javascript
const submission = await fetch('/api/public/forms/abc123xyz/submissions', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    identityData: { name: 'John', email: 'john@example.com' },
    answersJson: { field_1: 'answer' }
  })
});
```

#### Send & Verify OTP
```javascript
// Send OTP
const sendResponse = await fetch('/api/public/forms/abc123xyz/otp/send', {
  method: 'POST',
  body: JSON.stringify({ email: 'john@example.com' })
});
const { otpId } = await sendResponse.json();

// User enters code...

// Verify OTP
const verifyResponse = await fetch('/api/public/forms/abc123xyz/otp/verify', {
  method: 'POST',
  body: JSON.stringify({ otpId, code: '123456' })
});
const { verificationToken } = await verifyResponse.json();

// Use verificationToken in submission
```

---

**API Version**: 1.0
**Last Updated**: 2026-01-26
**Status**: Production Ready (core endpoints)
