# 🎨 COPY & PASTE THIS PROMPT TO CLAUDE

---

```
YOU ARE A SENIOR FRONTEND ENGINEER. IMPLEMENT UI/UX FIXES FOR DPWAI (PRODUCT QUALITY).
A COMPREHENSIVE AUDIT HAS BEEN CREATED AT: knowledge/02-frontend/UI-UX-AUDIT-FINDINGS.md

YOUR TASK: IMPLEMENT PHASE 1 - CRITICAL UX BLOCKS (5 commits, 7.5 hours)

CRITICAL: Core user experience is impaired. These fixes must happen first.

WHAT TO DO:

1. Read the audit (comprehensive, don't skip):
   Location: /knowledge/02-frontend/UI-UX-AUDIT-FINDINGS.md

2. Read implementation plan with code examples:
   Location: /knowledge/02-frontend/UI-UX-FIXES-PLAN.md

3. Implement FIVE commits in order:

   COMMIT 1.1 - Make Cards Fully Clickable (1 hour)
   ════════════════════════════════════════════════════════════════════
   Files: app/dpwai/[tenant_snake]/welcome/page.tsx
          app/dpwai/[tenant_snake]/dashboards/page.tsx

   Problem: Only small arrow on cards is clickable, not entire card body
   Fix: Wrap entire card in <Link> instead of nested button

   Changes:
   ✓ Find: <div className="card">...{onClick on nested button}</div>
   ✓ Replace: <Link href="..." className="block card">...</Link>
   ✓ Test: Click card body → should navigate (not just the arrow)

   Example pattern (from plan):
   ```
   // BEFORE (wrong):
   <div className="card">
     <h3>Painéis</h3>
     <button onClick={() => router.push('/dashboards')}>→</button>
   </div>

   // AFTER (correct):
   <Link href="/dashboards" className="block card">
     <h3>Painéis</h3>
     <div>→</div>
   </Link>
   ```

   COMMIT 1.2 - Fix Chat Input (Always Visible) (1 hour)
   ════════════════════════════════════════════════════════════════════
   File: app/dpwai/[tenant_snake]/chat/page.tsx (find Chat component)

   Problem: Input box hidden below fold, users think they can't type
   Fix: Keep input always visible using flexbox layout

   Changes:
   ✓ Use flex-grow on messages container (makes messages scrollable)
   ✓ Use sticky bottom-0 on input area (stays visible)
   ✓ Add overflow-y-auto to messages (only messages scroll)
   ✓ Add border/spacing to input area

   Example pattern (from plan):
   ```
   <div className="flex flex-col h-screen">
     <div className="flex-grow overflow-y-auto">
       <ChatMessages messages={messages} />
     </div>
     <div className="sticky bottom-0 bg-slate-950 border-t p-4">
       <ChatInput onSend={handleSend} />
     </div>
   </div>
   ```

   Test: Load chat page → see input box immediately (no scrolling needed)

   COMMIT 1.3 - Fix Dropdown Menu Behavior (1.5 hours)
   ════════════════════════════════════════════════════════════════════
   Files: All dropdowns in app (dashboard menu, selectors, etc.)

   Problem: Menus stay open after clicking elsewhere (breaks web standard)
   Expected: Click outside OR press Esc → closes menu

   Changes:
   ✓ Add useRef to track menu element
   ✓ Add mousedown listener for click-outside detection
   ✓ Add keydown listener for Escape key
   ✓ Apply pattern to ALL dropdowns/menus

   Critical pattern from plan (copy this exactly):
   ```
   const menuRef = useRef(null);

   // Close on outside click
   useEffect(() => {
     const handleClickOutside = (event) => {
       if (menuRef.current && !menuRef.current.contains(event.target)) {
         setMenuOpen(false);
       }
     };

     if (menuOpen) {
       document.addEventListener('mousedown', handleClickOutside);
       return () => document.removeEventListener('mousedown', handleClickOutside);
     }
   }, [menuOpen]);

   // Close on Escape
   useEffect(() => {
     const handleEscKey = (event) => {
       if (event.key === 'Escape' && menuOpen) {
         setMenuOpen(false);
       }
     };

     if (menuOpen) {
       document.addEventListener('keydown', handleEscKey);
       return () => document.removeEventListener('keydown', handleEscKey);
     }
   }, [menuOpen]);
   ```

   Test:
   ✓ Click menu → opens
   ✓ Click elsewhere → closes
   ✓ Click menu again → opens
   ✓ Press Esc → closes

   COMMIT 1.4 - Language Audit & Translation (2 hours)
   ════════════════════════════════════════════════════════════════════
   Scope: Find and replace ALL English strings with Portuguese

   Files: Entire app (use grep to find English)

   Common translations (from plan):
   - Welcome → Bem-vindo
   - Add new form → Adicionar novo formulário
   - Save changes → Salvar alterações
   - Display Name → Nome de Exibição
   - New Panel → Novo Painel
   - Edit → Editar
   - Delete → Remover
   - Cancel → Cancelar
   - My Account → Minha Conta
   - Language → Idioma
   - Security → Segurança

   Process:
   1. Search codebase for hardcoded English text
   2. Replace with Portuguese equivalents
   3. Check context (Delete vs Remover vs Excluir)
   4. Update all: labels, buttons, placeholders, titles, error messages
   5. Run: npm run build (must pass with no errors)

   Verify: Visit each page, verify NO English text visible

   COMMIT 1.5 - Fix Text Contrast (Dark Theme) (2 hours)
   ════════════════════════════════════════════════════════════════════
   Problem: Blue text on dark blue is unreadable
   Required: WCAG AA 4.5:1 minimum contrast ratio

   Current (BAD): #3b82f6 (blue) on #0f172a (dark blue) = 2.5:1
   Fixed (GOOD): #ffffff (white) on #0f172a = 10:1

   Changes:
   ✓ Audit all text-color classes vs background colors
   ✓ Change dark text to white or light gray
   ✓ Test contrast ratio (use WebAIM checker)
   ✓ Verify WCAG AA compliance (4.5:1 minimum)

   Example fixes:
   - text-blue-500 on dark → change to text-white
   - text-gray-600 on dark → change to text-slate-200
   - text-slate-800 on dark → change to text-slate-300

   Classes to look for:
   ✓ text-blue-* on dark backgrounds
   ✓ text-gray-* that might be too dark
   ✓ All labels and input text
   ✓ All button text
   ✓ All link colors

   Test: Visit every page, verify readability of ALL text

CONSTRAINTS:
- Follow existing project patterns (Next.js, React, Tailwind)
- No breaking changes to functionality
- No backend changes (frontend only)
- Use existing components where possible
- Test on desktop (1920x1080) and mobile (375x667)
- npm run build must pass with ZERO errors

DELIVERABLE:
- Commit 1.1: Cards fully clickable
- Commit 1.2: Chat input always visible
- Commit 1.3: Dropdowns close on outside click + Escape
- Commit 1.4: No English text visible anywhere
- Commit 1.5: All text meets WCAG AA contrast requirements
- npm run build: ✅ PASSES with 0 errors
- All features work end-to-end
- Phase 1 (5 commits) complete

NEXT: After Phase 1, we implement Phase 2 (high usability issues).

---

GIT COMMIT MESSAGE:

For all 5 commits combined, one message:

ui: fix critical UX issues - clickable cards, chat input, dropdowns, language, contrast (Phase 1/3)

Critical user experience fixes:
- Made quick-action cards fully clickable (entire card, not just arrow)
- Fixed chat input visibility (sticky footer, always visible)
- Fixed dropdown behavior (close on outside click + Escape key)
- Translated all hardcoded English strings to Portuguese
- Fixed text contrast to WCAG AA standard (4.5:1 minimum)

Impact:
- Users no longer frustrated by clicking wrong area of cards
- Chat interface usable without scrolling for input
- Dropdowns behave like standard web components
- 100% Portuguese UI (no language mixing)
- All text readable on dark theme

Tests: ✅ Manual testing all pages
Build: ✅ npm run build passes
Accessibility: ✅ WCAG AA compliant

Co-Authored-By: Claude Haiku 4.5 <noreply@anthropic.com>
```

---

## HOW TO USE

1. Copy the prompt above (everything inside the ``` blocks)
2. Paste into Claude.com or Claude Code
3. Wait for Phase 1 to complete (should take ~7.5 hours)
4. Verify build passes: `npm run build`
5. Manual test each feature mentioned in commits
6. Come back here for Phase 2 prompt

---

## FULL UI/UX FIX SEQUENCE

**Phase 1: CRITICAL UX BLOCKS (7.5 hours)**
- Commit 1.1: Cards fully clickable (1h)
- Commit 1.2: Chat input always visible (1h)
- Commit 1.3: Dropdown menu behavior (1.5h)
- Commit 1.4: Language/translation (2h)
- Commit 1.5: Text contrast (2h)

**Phase 2: HIGH USABILITY (7 hours)** ← After Phase 1
- Commit 2.1: Sidebar tooltips (1h)
- Commit 2.2: Chat list items (1.5h)
- Commit 2.3: Form editor labels (1.5h)
- Commit 2.4: Dashboard visualization (1h)
- Commit 2.5: Action feedback/toasts (1.5h)

**Phase 3: MEDIUM ISSUES (3.5 hours)** ← After Phase 2
- Commit 3.1: Property selection (0.5h)
- Commit 3.2: Disabled field tooltips (0.5h)
- Commit 3.3: Button translations (0.5h)
- Commit 3.4: Clean test data (1h)
- Commit 3.5: Standardize dropdowns (1h)

---

**Audit:** ✅ Complete at `/knowledge/02-frontend/UI-UX-AUDIT-FINDINGS.md`
**Plan:** ✅ Complete at `/knowledge/02-frontend/UI-UX-FIXES-PLAN.md`
**Phase 1 Status:** ← **START HERE**
**Next prompt:** Phase 2 after Phase 1 succeeds
