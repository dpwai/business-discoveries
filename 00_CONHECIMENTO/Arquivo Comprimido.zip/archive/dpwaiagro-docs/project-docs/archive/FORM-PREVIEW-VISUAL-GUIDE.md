# Form Preview Page - Visual & Interaction Guide

## Page Layout

### Desktop View (≥1024px)
```
┌─────────────────────────────────────────────────────────────────────┐
│  ◀ Voltar                                                           │
│  Form Name                                  [Published/Rascunho]     │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌─────────────┐ │
│  │   Toolbar            │  │   Preview Frame      │  │  Checklist  │ │
│  │  [M] [T] [D]        │  │  ┌────────────────┐  │  │  □ Renders  │ │
│  │  Zoom: [━━━━━]      │  │  │                │  │  │  □ Fields   │ │
│  │  ▼ Light/Dark       │  │  │  Form (375×812)│  │  │  □ Identity │ │
│  │  📤 Open Tab        │  │  │                │  │  │  □ Buttons  │ │
│  │                      │  │  │                │  │  │  □ Errors   │ │
│  │  public-id-xyz      │  │  └────────────────┘  │  │  □ Submit   │ │
│  │                      │  │  Device: iPhone 12   │  │  □ Success  │ │
│  └──────────────────────┘  │  Zoom: 100%         │  │  [■ Nota]   │ │
│                             │  Theme: Light       │  │  [Save]     │ │
│                             │  URL: /f/public...  │  │  [Clear]    │ │
│                             └──────────────────────┘  └─────────────┘ │
└────────────────────────────────────────────────────────────────────────┘
```

### Mobile View (<1024px)
```
┌──────────────────────────────┐
│  ◀ Form Name  [Published]    │
├──────────────────────────────┤
│  ┌────────────────────────┐  │
│  │      Toolbar           │  │
│  │  [M] [T] [D]          │  │
│  │  Zoom, Theme, etc     │  │
│  └────────────────────────┘  │
├──────────────────────────────┤
│  ┌────────────────────────┐  │
│  │   Preview Frame        │  │
│  │  ┌──────────────────┐  │  │
│  │  │  Form Preview    │  │  │
│  │  │  (responsive)    │  │  │
│  │  └──────────────────┘  │  │
│  └────────────────────────┘  │
├──────────────────────────────┤
│  ┌────────────────────────┐  │
│  │     Checklist          │  │
│  │  □ Field 1            │  │
│  │  □ Field 2            │  │
│  │  [Save] [Clear]       │  │
│  └────────────────────────┘  │
└──────────────────────────────┘
```

## Component Interactions

### Toolbar - Device Selection
```
Before Click:
┌─────────────────────────────────────────┐
│  [Mobile] [Tablet] [Desktop]            │
│  Mobile: 375×812px                      │
│  Tablet: 768×1024px                     │
│  Desktop: 1024×768px (SELECTED)         │
└─────────────────────────────────────────┘

After Click (Mobile):
┌─────────────────────────────────────────┐
│  [Mobile] [Tablet] [Desktop]            │  ← Mobile highlighted
│  Mobile: 375×812px (SELECTED)           │  ← Frame updates
│  Frame size: 375×812 (100% zoom)        │
└─────────────────────────────────────────┘
```

### Toolbar - Zoom Control
```
┌──────────────────────────────────────────┐
│  Zoom: [−] [━━━━━━━] [+]  100%          │
│                                          │
│  Min (50%): [−] disabled                │
│  Mid (100%): Both buttons enabled        │
│  Max (200%): [+] disabled               │
│                                          │
│  Result: Frame resizes from 50% to 200% │
│  of device base dimensions              │
└──────────────────────────────────────────┘

Zoom Examples:
Device: Mobile (375×812)
- 50% zoom → 187×406px
- 100% zoom → 375×812px (default)
- 150% zoom → 562×1218px
- 200% zoom → 750×1624px
```

### Toolbar - Theme Toggle
```
Before (Light Mode):
┌──────────────────────────────┐
│  Theme: [☀️ Mode Claro]     │
│  Background: gray-50         │
│  Text: gray-900             │
│  Result: Bright, light page  │
└──────────────────────────────┘

After (Dark Mode):
┌──────────────────────────────┐
│  Theme: [🌙 Mode Escuro]     │
│  Background: gray-900        │
│  Text: gray-100             │
│  Result: Dark, comfortable   │
└──────────────────────────────┘
```

### Frame Container

#### Light Mode Frame
```
┌─────────────────────────────────────────┐
│  iPhone 12 (375×812) | Zoom: 100%       │
├─────────────────────────────────────────┤
│                                         │
│  ┌─ Frame (white background) ──────┐   │
│  │  ┌──────────────────────────┐   │   │
│  │  │   Public Form (iframe)   │   │   │
│  │  │   /f/[publicId]         │   │   │
│  │  │   ?theme=light          │   │   │
│  │  │                          │   │   │
│  │  │   [Form Content Here]    │   │   │
│  │  │                          │   │   │
│  │  └──────────────────────────┘   │   │
│  └─ (rounded, shadow) ────────────┘   │
│                                         │
│  Frame Size: 375×812px (100% zoom)     │
│  Theme: Light | URL: /f/[publicId]     │
└─────────────────────────────────────────┘
```

#### Dark Mode Frame
```
Same structure but:
- Background: gray-900
- Frame: gray-950
- Text: gray-100
- Border: gray-700
```

### Checklist

#### Uncompleted State
```
┌──────────────────────────────────────┐
│  Checklist Item (uncompleted)        │
├──────────────────────────────────────┤
│  ○ Form renderiza sem erros          │
│  ○ Todos os campos visíveis          │
│  ○ Identity block visível            │
└──────────────────────────────────────┘

Visual:
- Empty circle (○) icon
- Regular text (no strikethrough)
- Clickable, hover effect
- Progress: 0/7 (0%)
```

#### Completed State
```
┌──────────────────────────────────────┐
│  Checklist Item (completed)          │
├──────────────────────────────────────┤
│  ✓ Form renderiza sem erros          │
│  ○ Todos os campos visíveis          │
│  ✓ Identity block visível            │
└──────────────────────────────────────┘

Visual:
- Checkmark (✓) icon, green color
- Strikethrough text (╱╱╱╱╱)
- Faded text (gray-500 dark:gray-400)
- Still clickable (to uncomplete)
- Progress: 2/7 (29%)
```

#### Progress Bar
```
0/7 items (0%):
Progress: [░░░░░░░░░░] 0%

2/7 items (29%):
Progress: [████░░░░░░] 29%

5/7 items (71%):
Progress: [██████████░] 71%

7/7 items (100%):
Progress: [████████████] 100%
        ↑ Bar fills with green as progress increases
```

### Notes Section

#### Empty State
```
┌────────────────────────────────────┐
│  Notes & Observations              │
├────────────────────────────────────┤
│  ┌─────────────────────────────┐   │
│  │ Digite aqui problemas...    │   │
│  │                             │   │
│  │ (placeholder text)          │   │
│  │                             │   │
│  └─────────────────────────────┘   │
│  [Salvar Notas] [Limpar Tudo]     │
└────────────────────────────────────┘
```

#### With Notes
```
┌────────────────────────────────────┐
│  Notes & Observations              │
├────────────────────────────────────┤
│  ┌─────────────────────────────┐   │
│  │ - Button not clickable      │   │
│  │   on mobile at 150% zoom    │   │
│  │ - Form submits but no       │   │
│  │   success message           │   │
│  │ - Dark mode colors OK       │   │
│  └─────────────────────────────┘   │
│  [Salvar Notas] [Limpar Tudo]     │
│  ✓ Notas salvas com sucesso!       │
└────────────────────────────────────┘
        ↑ Success message auto-disappears
```

## User Interactions Flow

### Typical Testing Flow

```
1. LOAD PAGE
   ├── Form data fetches from API
   ├── Verify form name displays
   └── See public ID in toolbar

2. MOBILE TESTING
   ├── Click [Mobile] button
   ├── Frame resizes to 375×812
   ├── View at 100% zoom
   ├── Test form functionality
   ├── Zoom to 150% (accessibility test)
   ├── Verify buttons are clickable (44px+)
   └── Check all fields visible

3. TABLET TESTING
   ├── Click [Tablet] button
   ├── Frame resizes to 768×1024
   ├── Review layout/spacing
   └── Check responsive behavior

4. DESKTOP TESTING
   ├── Click [Desktop] button
   ├── Test at 75%, 100%, 125% zoom
   ├── Verify full layout
   └── Check edge cases

5. THEME TESTING
   ├── Click theme button
   ├── Verify dark mode display
   ├── Check text contrast
   ├── Click again for light mode
   └── Both readable? ✓

6. VALIDATION
   ├── Click checklist items as you verify
   ├── Watch progress bar fill
   ├── Type notes on any issues
   └── Click "Salvar Notas"

7. FULL-SCREEN TEST
   ├── Click "Abrir em Nova Aba"
   ├── Form opens in new tab
   ├── Test without preview UI
   └── Return to preview page

8. SAVE & COMPLETE
   ├── Verify all critical items checked
   ├── Click "Salvar Notas"
   ├── See success message
   └── Done! Form ready to publish
```

## Visual States & Feedback

### Button States

#### Device Buttons
```
Unselected:
┌──────────┐
│ [Mobile] │  Gray background
└──────────┘  Text visible
   ↓ (click)
Selected:
┌──────────┐
│ [Mobile] │  Blue background
└──────────┘  Blue text highlight
```

#### Zoom Buttons (+ / -)
```
Enabled (50% < zoom < 200%):
┌───┐
│ + │  Clickable, hover effect
└───┘

Disabled (zoom ≥ 200%):
┌───┐
│ + │  Grayed out, cursor: not-allowed
└───┘
```

#### Save/Clear Buttons
```
Save Button:
Idle:     [Salvar Notas]  Blue background
Saving:   [Salvando...]   Loading animation
Success:  [Salvar Notas]  Green border (2s)
Error:    [Salvar Notas]  Red border (3s)

Clear Button:
Default:  [Limpar Tudo]   Gray border
Hover:    [Limpar Tudo]   Gray background
Click:    Confirm dialog  Are you sure?
```

### Message States

#### Success Message
```
┌─────────────────────────────────────┐
│ ✓ Notas salvas com sucesso!        │  Green background
│   Auto-hides after 2 seconds        │
└─────────────────────────────────────┘
```

#### Error Message
```
┌─────────────────────────────────────┐
│ ✗ Erro ao salvar notas             │  Red background
│   Auto-hides after 3 seconds        │
└─────────────────────────────────────┘
```

#### Loading State
```
┌─────────────────────────────────────┐
│   ⟳ Carregando formulário...       │  Spinner animation
│   (page displays loading indicator) │
└─────────────────────────────────────┘
```

#### Error State (Page)
```
┌──────────────────────────────────────┐
│  ◀ Voltar                            │
│                                      │
│  ┌────────────────────────────────┐  │
│  │  Erro ao carregar formulário   │  │ Red background
│  │  Failed to load form: [error]  │  │
│  │                                │  │
│  │  [◀ Voltar]                    │  │
│  └────────────────────────────────┘  │
└──────────────────────────────────────┘
```

## Responsive Breakpoints

### Desktop (lg: ≥1024px)
```
Grid: grid-cols-1 lg:col-span-1 lg:col-span-2 lg:col-span-1
Layout: 3 columns (1/4, 2/4, 1/4)
Sidebar: sticky top-6 (stays visible on scroll)
Height: Full screen with scrollable content
```

### Tablet (md: 768px - 1023px)
```
Grid: Single column grid
Layout: Toolbar → Frame → Checklist (vertical stack)
Sidebar: Sticky (still works at this size)
Spacing: Reduced to fit screen
```

### Mobile (< 768px)
```
Grid: Single column grid
Layout: Vertical stack, full width
Sidebar: Sticky but takes full width
Font: Slightly smaller, larger touch targets
Buttons: 44px+ height for mobile tap
```

## Color Scheme

### Light Mode
```
Background:     bg-gray-50      (#f9fafb)
Surface:        bg-white        (#ffffff)
Text Primary:   text-gray-900   (#111827)
Text Secondary: text-gray-600   (#4b5563)
Border:         border-gray-200 (#e5e7eb)
Primary:        bg-blue-600     (#2563eb)
Success:        bg-green-500    (#22c55e)
Error:          bg-red-600      (#dc2626)
Warning:        bg-yellow-500   (#eab308)
```

### Dark Mode
```
Background:     bg-gray-900     (#111827)
Surface:        bg-gray-800     (#1f2937)
Text Primary:   text-gray-100   (#f3f4f6)
Text Secondary: text-gray-400   (#9ca3af)
Border:         border-gray-700 (#374151)
Primary:        bg-blue-600     (#2563eb)
Success:        bg-green-500    (#22c55e)
Error:          bg-red-600      (#dc2626)
Warning:        bg-yellow-500   (#eab308)
```

## Accessibility Features

### Keyboard Navigation
```
Tab:        Navigate between buttons/inputs
Enter:      Activate button, submit form
Space:      Toggle checklist item
Esc:        Close any dialogs (if implemented)
```

### Visual Indicators
```
Focus State:    Visible outline (focus:outline-none focus:ring-1)
Hover State:    Background color change, cursor pointer
Active State:   Different background color, pressed appearance
Disabled State: Reduced opacity, cursor: not-allowed
```

### Color Contrast
```
Light Mode:     WCAG AA compliant
Dark Mode:      WCAG AA compliant
Both modes      Sufficient contrast for readability
maintain        Text vs backgrounds, buttons, etc.
```

## Performance Indicators

### Expected Performance
```
Page Load:        < 1 second
Device Switch:    Instant (< 50ms)
Zoom Update:      Instant (< 50ms)
Theme Toggle:     Instant (< 50ms)
Note Save:        < 100ms
localStorage ops: < 5ms
```

### Visual Feedback
```
Device Switch:     Immediate highlight change
Zoom Update:       Frame dimensions change instantly
Theme Toggle:      Entire page changes color instantly
Save:              Message appears/disappears
```

## Error States & Recovery

### "Form not found"
```
┌─────────────────────────────────────┐
│  ◀ Voltar                           │
│                                     │
│  Formulário não encontrado          │
│  O formulário que você está         │
│  procurando não existe ou foi       │
│  removido.                          │
└─────────────────────────────────────┘
```

### "Unauthorized (404 on API)"
```
Auto-redirect to /dpwai/login
localStorage.accessToken cleared
```

### "Network error"
```
┌─────────────────────────────────────┐
│  Erro ao carregar formulário        │
│  Network request failed             │
│  [◀ Voltar]                         │
└─────────────────────────────────────┘
```

---

**This visual guide shows the complete user interface and interaction patterns for the Form Preview Page.**
