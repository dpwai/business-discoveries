# 📧 TESTE DE EMAIL - RESEND

## ✅ Tela de Teste Criada

Criei uma tela simples para testar o envio de emails via Resend.

---

## 🚀 Como Usar

### Passo 1: Iniciar o Dev Server

```bash
npm run dev
```

Espere até ver:
```
✓ Ready in XXXms
```

### Passo 2: Abrir a Página de Teste

Vá para:
```
http://localhost:3000/test-email
```

### Passo 3: Enviar Email de Teste

Você vai ver:
- Campo "Para:" (já preenchido com `joaobalzer@gmail.com`)
- Campo "Assunto:"
- Campo "Mensagem:"
- Botão "Enviar Email de Teste"

Clique no botão e aguarde a resposta.

---

## 📊 Arquivos Criados

```
app/
├── api/test/send-email/route.ts  ← API que envia email via Resend
└── test-email/page.tsx            ← Página de interface simples
```

---

## 🔧 Como Funciona

1. **Frontend** (`/test-email`): Formulário simples
2. **API Route** (`/api/test/send-email`):
   - Recebe: `{ email, subject, message }`
   - Usa: `Resend` SDK
   - Envia de: `noreply@dpwai.com`
   - Retorna: ID do Resend ou erro

---

## ✅ Sucesso = O Que Você Vai Ver

Se funcionar, a página mostrará:

```
✅ Email enviado com sucesso!
ID Resend: e_xxxxx...
{
  "id": "e_xxxxx...",
  "from": "noreply@dpwai.com",
  "to": "joaobalzer@gmail.com",
  ...
}
```

---

## ❌ Erro = O Que Investigar

Se der erro, a página mostrará:

```
❌ Erro: Failed to send email
```

Verifique:
1. `.env` tem `RESEND_API_KEY` válida
2. `RESEND_API_KEY` não está expirada
3. Email é válido (joaobalzer@gmail.com ✓)

---

## 📧 Verificar no Gmail

Após enviar com sucesso:
1. Abra: `gmail.com`
2. Procure email de: `noreply@dpwai.com`
3. Assunto: O que você colocou no formulário
4. **Isso prova que Resend está funcionando** ✅

---

## 🔐 Segurança (IMPORTANTE)

**Esta página (`/test-email`) é pública e sem autenticação!**

Antes de ir pra produção:
- [ ] Proteja `/test-email` com JWT ou remova dela
- [ ] Coloque atrás de autenticação
- [ ] Ou delete a página para produção

Para proteger, adicione ao início de `app/test-email/page.tsx`:

```typescript
import { redirect } from 'next/navigation';

// Exemplo: redireciona se não for admin
const token = cookies().get('accessToken')?.value;
if (!token) redirect('/login');
```

---

## 🧪 Próximas Validações

Após comprovar que funciona:

1. **Integrar com reset-password**: Use o mesmo padrão em `/api/auth/forgot-password`
2. **Integrar com signup**: Envie email de confirmação na criação de conta
3. **Integrar com invite**: Envie convites para novos usuários

---

## 📝 Nota

A chave da API Resend já está em `.env`:

```
RESEND_API_KEY="re_AUDeD4x6_EvQkUYcYGXXEG2wLW8MzsJyF"
```

Está segura lá e **nunca** será commitada (`.env` está no `.gitignore`).

---

**Pronto para testar!** 🚀
