# 📋 DPWAI Forms System - Current State Documentation

**Last Updated**: 2026-01-26
**Version**: 1.0
**Status**: Production-Ready

---

## Table of Contents

1. [Overview](#overview)
2. [Form Routes and Pages](#form-routes-and-pages)
3. [Form Types](#form-types)
4. [Database Schema](#database-schema)
5. [API Endpoints](#api-endpoints)
6. [Form Builder](#form-builder)
7. [Submission and Records](#submission-and-records)
8. [Permissions and Access Control](#permissions-and-access-control)
9. [Implementation Status](#implementation-status)
10. [Component Architecture](#component-architecture)
11. [Quick Reference](#quick-reference)

---

## Overview

The DPWAI forms system provides a comprehensive solution for data collection with two distinct form types:

- **Manual Forms**: Internal data collection with versioning, inline editing, and export
- **Google Forms-like**: Public and internal forms with auto-save, multiple question types, and file uploads

### Key Statistics

| Aspect | Details |
|--------|---------|
| **Form Types** | 2 (Manual, Google Forms-like) |
| **Field Types** | 12+ (text, number, email, phone, date, time, boolean, dropdown, etc.) |
| **Templates** | 4 pre-built templates (Manual Forms) |
| **Supported Operations** | CRUD, versioning, export, import, sharing |
| **Public Access** | Yes (Google Forms via public slug) |
| **Multi-tenant** | Yes (full tenant isolation) |

---

## Form Routes and Pages

### Route Structure

```
/dpwai/[tenant_snake]/
├── forms/                                    # Manual forms listing
├── forms/[formId]                           # Form detail/editor (legacy)
├── forms/[formId]/records                   # Form records/submissions
├── forms/builder                            # Alternative form builder
├── manual/                                  # Manual forms overview
├── manual/forms/[form_id]                   # Manual form records
├── manual/forms/[form_id]/builder           # Manual form builder
├── google-forms/                            # Google Forms listing
├── google-forms/new                         # Create new Google Form
├── google-forms/[id]/builder                # Google Form builder
└── google-forms/[id]/submissions            # Google Form submissions

/f/[slug]                                    # Public form submission (Google Forms)
```

### Pages Description

#### 1. Forms Listing Page
**Route**: `/dpwai/[tenant_snake]/forms/page.tsx`

**Features**:
- Display all active forms in grid layout
- Search by form name
- Filter by status (ACTIVE, INACTIVE, ARCHIVED)
- Create new form dialog
- Actions: Edit, View Submissions, Archive
- Form metadata: Type, version, status, creation date

**Form Types Available**:
- `DATA_ONLY`: Pure data collection without files
- `SINGLE_FILE`: Data with single file upload
- `CSV_IMPORT`: Bulk import via CSV

**UI**: Grid layout, dark theme (slate-900), responsive design

---

#### 2. Manual Forms Page
**Route**: `/dpwai/[tenant_snake]/manual/page.tsx`

**Features**:
- Alternative UI for managing manual forms
- 4 Built-in templates:
  - 🔍 **Inspection Checklist** (inspeção)
  - 💉 **Application Record** (aplicação de pesticida)
  - 🚜 **Field Occurrences** (ocorrências em campo)
  - 📄 **Document Upload** (envio de documentos)
- Duplicate form functionality
- Archive/Reactivate forms
- Desktop table + Mobile card views
- Permission-based access control

**Templates Detail**:
```
Inspection Checklist (6 fields)
├── Property/Farm
├── Inspection Date
├── Inspector Name
├── Issues Found (multiselect)
├── Notes
└── Inspection Photos (file)

Application Record (9 fields)
├── Property
├── Application Date
├── Product Name
├── Quantity Applied
├── Area Covered
├── Application Method
├── Weather Conditions
├── Equipment Used
└── Application Photo (file)

[... and 2 more templates]
```

---

#### 3. Forms Records/Submissions Page
**Routes**:
- `/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx`
- `/dpwai/[tenant_snake]/manual/forms/[form_id]/page.tsx`

**Features**:
- Paginated table view of form submissions (25 items per page)
- Card view on mobile
- Inline field editing with auto-save
- Search across all fields
- Copy record IDs
- Delete individual records
- CSV export functionality
- New record creation modal (⚠️ partial implementation)
- Per-field filtering and sorting
- Desktop table + Mobile card views

**Data Display**:
- All form fields as table columns
- Record metadata (created date, created by)
- Edit state indication
- Validation error display

---

#### 4. Form Builder Pages
**Routes**:
- `/dpwai/[tenant_snake]/forms/builder/page.tsx` (simple)
- `/dpwai/[tenant_snake]/manual/forms/[form_id]/builder/page.tsx` (advanced)
- `/dpwai/[tenant_snake]/google-forms/[id]/builder/page.tsx` (Google Forms)

**Features**:
- Real-time form preview
- Field type selector with dropdown
- Field property editor (right panel)
- Field reordering (implied)
- Add/delete fields
- Version history display
- Auto-save (Google Forms: every 3 seconds)
- Validation configuration
- Constraint setting (min/max, patterns, etc.)

**Visual Layout**:
```
┌─────────────────────────────────────────────┐
│ Form Title & Description                     │
├──────────────────┬──────────────────────────┤
│ Field Type       │ Form Preview             │
│ Selector         │ (Real-time)              │
│ + Add Field      │                          │
│ Field List       ├──────────────────────────┤
│                  │ Properties Panel         │
│                  │ (Selected Field Config)  │
│                  │                          │
└──────────────────┴──────────────────────────┘
```

---

#### 5. Google Forms Pages
**Routes**:
- `/dpwai/[tenant_snake]/google-forms/page.tsx`
- `/dpwai/[tenant_snake]/google-forms/[id]/submissions/page.tsx`
- `/f/[slug]/page.tsx` (public submission)

**Features**:
- List forms with status (DRAFT, PUBLISHED, ARCHIVED)
- Publish/Archive/Delete actions
- Copy public share link
- Submission count tracking
- View all submissions
- Export to CSV
- Import from CSV (batch)
- Public anonymous submission

**Public Form Features**:
- No authentication required
- File upload support per question
- Progress indication
- Responsive design
- Thank you message on submission

---

## Form Types

### Type 1: Manual Forms

| Property | Value |
|----------|-------|
| **Model** | `Form` + `FormVersion` + `Record` |
| **Storage** | Prisma database |
| **Visibility** | Internal only (tenant members) |
| **Versioning** | Full immutable versions |
| **Editing** | Inline record editing |
| **Schema** | JSON-based field definitions |
| **Access** | Requires authentication |

**Characteristics**:
- Immutable version history (each schema change creates new version)
- Records linked to specific form version
- Field-level validation constraints
- Support for 3 form types: DATA_ONLY, SINGLE_FILE, CSV_IMPORT
- Template system with pre-built forms
- Inline editing with auto-save
- CSV export

**Example Schema**:
```json
{
  "fields": [
    {
      "id": "field_001",
      "label": "Farm Name",
      "type": "TEXT",
      "required": true,
      "constraints": {
        "minLength": 3,
        "maxLength": 100
      }
    },
    {
      "id": "field_002",
      "label": "Inspection Date",
      "type": "DATE",
      "required": true,
      "constraints": {
        "minDate": "2020-01-01",
        "maxDate": null
      }
    },
    {
      "id": "field_003",
      "label": "Issues Found",
      "type": "MULTISELECT",
      "required": false,
      "options": ["Pest", "Disease", "Nutrient"],
      "constraints": {
        "maxSelections": 5
      }
    }
  ]
}
```

---

### Type 2: Google Forms-like

| Property | Value |
|----------|-------|
| **Model** | `GoogleForm` + `GoogleFormSubmission` |
| **Storage** | Prisma database |
| **Visibility** | Internal + Public (when published) |
| **Versioning** | Single current version |
| **Status** | DRAFT, PUBLISHED, ARCHIVED |
| **Schema** | JSON-based questions |
| **Access** | Public if published, internal editor |

**Characteristics**:
- Dynamic status management (draft/published/archived)
- Auto-save every 3 seconds while editing
- Public submission via unique slug
- File upload support per question
- Multiple question types (11 types)
- CSV import/export for batch operations
- File storage with metadata tracking
- Submission metadata (IP, userAgent, timestamp)

**Question Types**:
1. `short_text` - Single line text
2. `long_text` - Multiple lines text
3. `number` - Numeric input
4. `email` - Email validation
5. `phone` - Phone number
6. `date` - Date picker
7. `time` - Time picker
8. `single_choice` - Radio buttons
9. `multiple_choice` - Checkboxes
10. `dropdown` - Select list
11. `file_upload` - File attachment

**Example Schema**:
```json
{
  "questions": [
    {
      "id": "q_001",
      "type": "short_text",
      "label": "What is your name?",
      "description": "Your full name",
      "required": true
    },
    {
      "id": "q_002",
      "type": "file_upload",
      "label": "Upload proof",
      "description": "PDF or image file",
      "required": true
    },
    {
      "id": "q_003",
      "type": "multiple_choice",
      "label": "Select all that apply",
      "required": false,
      "options": ["Option A", "Option B", "Option C"]
    }
  ]
}
```

---

### Type Comparison Matrix

| Feature | Manual | Google Forms |
|---------|--------|--------------|
| **Visibility** | Internal only | Public + Internal |
| **Record Editing** | ✅ Yes (inline) | ❌ No |
| **Versioning** | ✅ Full history | ❌ Single version |
| **Field Constraints** | ✅ Rich (min/max/pattern) | ⚠️ Basic (required) |
| **Templates** | ✅ 4 built-in | ❌ None |
| **CSV Import** | ✅ For CSV_IMPORT type | ✅ Batch import |
| **File Upload** | ✅ Single per form | ✅ Per question |
| **Auto-save** | ⚠️ Manual | ✅ Every 3 seconds |
| **Public Sharing** | ❌ No | ✅ Yes (slug) |
| **Metadata Tracking** | ⚠️ Basic | ✅ IP, userAgent, timestamp |

---

## Database Schema

### Manual Forms Schema

```prisma
model Form {
  id                    String   @id @default(cuid())
  tenantId              String
  name                  String
  type                  FormType @default(DATA_ONLY)  // DATA_ONLY | SINGLE_FILE | CSV_IMPORT
  status                String   @default("ACTIVE")    // ACTIVE | ARCHIVED
  currentSchemaJson     Json                           // Complete schema snapshot
  currentVersion        Int      @default(1)
  createdById           String?
  createdAt             DateTime @default(now())
  updatedAt             DateTime @updatedAt

  versions              FormVersion[]
  records               Record[]
  tenant                Tenant   @relation(fields: [tenantId], references: [id])
  createdBy             User?    @relation(fields: [createdById], references: [id])

  @@index([tenantId])
  @@index([status])
}

model FormVersion {
  id                    String   @id @default(cuid())
  formId                String
  version               Int
  schemaJson            Json     // Immutable schema snapshot
  createdById           String?
  isActive              Boolean  @default(true)
  createdAt             DateTime @default(now())

  form                  Form     @relation(fields: [formId], references: [id], onDelete: Cascade)
  submissions           FormSubmission[]
  records               Record[]
  createdBy             User?    @relation(fields: [createdById], references: [id])

  @@unique([formId, version])
  @@index([formId])
}

model Record {
  id                    String   @id @default(cuid())
  tenantId              String
  formId                String
  formVersionId         String
  data                  Json     // { fieldId: value, ... }
  isArchived            Boolean  @default(false)
  createdById           String?
  updatedById           String?
  createdAt             DateTime @default(now())
  updatedAt             DateTime @updatedAt

  form                  Form     @relation(fields: [formId], references: [id], onDelete: Cascade)
  version               FormVersion @relation(fields: [formVersionId], references: [id])
  tenant                Tenant   @relation(fields: [tenantId], references: [id])
  submission            FormSubmission?
  createdBy             User?    @relation("RecordCreatedBy", fields: [createdById], references: [id])
  updatedBy             User?    @relation("RecordUpdatedBy", fields: [updatedById], references: [id])

  @@index([formId])
  @@index([tenantId])
  @@index([isArchived])
}

model FormSubmission {
  id                    String   @id @default(cuid())
  recordId              String   @unique
  formVersionId         String
  shareLinkId           String?
  actorType             String   @default("USER")     // USER | GUEST
  actorUserId           String?
  actorPhoneMasked      String?
  authMethod            String   @default("PASSWORD") // PASSWORD | OTP | GUEST
  ipAddress             String?
  userAgent             String?
  submittedAt           DateTime @default(now())

  record                Record   @relation(fields: [recordId], references: [id], onDelete: Cascade)
  version               FormVersion @relation(fields: [formVersionId], references: [id])
}
```

### Google Forms Schema

```prisma
model GoogleForm {
  id                    String   @id @default(cuid())
  tenantId              String
  createdByUserId       String?
  title                 String
  description           String?
  status                String   @default("DRAFT")    // DRAFT | PUBLISHED | ARCHIVED
  schemaJson            Json     // { questions: [...] }
  publicSlug            String?  @unique
  publishedAt           DateTime?
  createdAt             DateTime @default(now())
  updatedAt             DateTime @updatedAt

  tenant                Tenant   @relation(fields: [tenantId], references: [id])
  createdBy             User?    @relation(fields: [createdByUserId], references: [id])
  submissions           GoogleFormSubmission[]
  files                 GoogleFormSubmissionFile[]

  @@index([tenantId])
  @@index([status])
  @@index([publicSlug])
}

model GoogleFormSubmission {
  id                    String   @id @default(cuid())
  formId                String
  tenantId              String
  answersJson           Json     // { questionId: answer, ... }
  submitterMeta         Json?    // { ip, userAgent, ... }
  submittedAt           DateTime @default(now())
  createdAt             DateTime @default(now())
  updatedAt             DateTime @updatedAt

  form                  GoogleForm @relation(fields: [formId], references: [id], onDelete: Cascade)
  tenant                Tenant   @relation(fields: [tenantId], references: [id])
  files                 GoogleFormSubmissionFile[]

  @@index([formId])
  @@index([tenantId])
}

model GoogleFormSubmissionFile {
  id                    String   @id @default(cuid())
  submissionId          String
  formId                String
  tenantId              String
  questionId            String
  fileName              String
  contentType           String
  sizeBytes             BigInt
  storageKey            String
  publicUrl             String?
  createdAt             DateTime @default(now())

  submission            GoogleFormSubmission @relation(fields: [submissionId], references: [id], onDelete: Cascade)
  form                  GoogleForm @relation(fields: [formId], references: [id], onDelete: Cascade)
  tenant                Tenant   @relation(fields: [tenantId], references: [id])

  @@index([submissionId])
  @@index([formId])
}
```

### Supporting Models

```prisma
model ShareLink {
  id                    String   @id @default(cuid())
  formId                String
  token                 String   @unique
  status                String   @default("ACTIVE")
  expiresAt             DateTime?
  maxSubmissions        Int?
  currentSubmissions    Int      @default(0)
  requireInternalLogin  Boolean  @default(false)
  allowGuestOtp         Boolean  @default(false)
  createdAt             DateTime @default(now())

  form                  Form     @relation(fields: [formId], references: [id])
  sessions              ShareLinkSession[]
}

model ShareLinkSession {
  id                    String   @id @default(cuid())
  shareLinkId           String
  authMethod            String   // OTP | PASSWORD | GUEST
  otpVerifiedAt         DateTime?
  status                String   @default("ACTIVE")

  shareLink             ShareLink @relation(fields: [shareLinkId], references: [id])
}
```

---

## API Endpoints

### Manual Forms API

**Base URL**: `/api/agro/[tenant]/forms`

#### List Forms
```
GET /forms
Query: (none)
Response: Form[]
Auth: Required
```

**Response Example**:
```json
[
  {
    "id": "form_123",
    "name": "Inspection Checklist",
    "type": "DATA_ONLY",
    "status": "ACTIVE",
    "currentVersion": 3,
    "createdAt": "2026-01-20T10:00:00Z",
    "createdBy": { "id": "user_1", "email": "admin@farm.com" }
  }
]
```

#### Create Form
```
POST /forms
Body: {
  "name": "New Form",
  "type": "DATA_ONLY",
  "schema": { "fields": [...] }
}
Response: Form (with id, version: 1)
Auth: Required (forms.create)
```

#### Get Form with Versions
```
GET /forms/[formId]
Response: {
  "form": Form,
  "versions": FormVersion[]
}
Auth: Required
```

#### Update Form (Create New Version)
```
PUT /forms/[formId]
Body: { "schema": { "fields": [...] } }
Response: Form (with incremented version)
Auth: Required (forms.edit)
```

#### Change Form Status
```
PATCH /forms/[formId]
Body: { "status": "ARCHIVED" | "ACTIVE" }
Response: Form
Auth: Required (forms.archive)
```

#### Delete Form (Archive)
```
DELETE /forms/[formId]
Response: { "success": true }
Auth: Required (forms.archive)
```

#### Get Form Permissions
```
GET /forms/permissions
Response: {
  "forms": { "create": boolean, "edit": boolean, "archive": boolean },
  "records": { "create": boolean, "edit": boolean, "archive": boolean }
}
Auth: Required
```

---

### Form Records API

**Base URL**: `/api/agro/[tenant]/forms/[formId]/records`

#### List Records (Paginated)
```
GET /records?page=1&limit=25
Response: {
  "records": Record[],
  "pagination": { "page": 1, "limit": 25, "total": 150 }
}
Auth: Required
```

#### Create Record
```
POST /records
Body: { "data": { "fieldId": value, ... } }
Response: Record (with id, createdAt)
Auth: Required (records.create)
```

#### Update Record Fields
```
PATCH /records/[recordId]
Body: { "data": { "fieldId": newValue } }
Response: Record (updated)
Auth: Required (records.edit)
```

#### Delete Record
```
DELETE /records/[recordId]
Response: { "success": true }
Auth: Required (records.archive)
```

#### Export Records as CSV
```
GET /records/export?includeInactive=false
Response: CSV file download
Auth: Required (records.export_all)
```

---

### Google Forms API

**Base URL**: `/api/agro/[tenant]/google-forms`

#### List Google Forms
```
GET /google-forms
Response: GoogleForm[]
Auth: Optional
```

#### Create Google Form
```
POST /google-forms
Body: {
  "title": "Form Title",
  "description": "Description",
  "schema": { "questions": [...] }
}
Response: GoogleForm (status: DRAFT)
Auth: Required
```

#### Get Form Details
```
GET /google-forms/[id]
Response: GoogleForm
Auth: Required
```

#### Update Form
```
PATCH /google-forms/[id]
Body: { "title": "...", "description": "...", "schema": {...} }
Response: GoogleForm
Auth: Required
```

#### Publish Form
```
POST /google-forms/[id]/publish
Body: (none)
Response: GoogleForm (status: PUBLISHED, publicSlug assigned)
Auth: Required
```

#### Archive Form
```
POST /google-forms/[id]/archive
Body: (none)
Response: GoogleForm (status: ARCHIVED)
Auth: Required
```

#### Delete Form
```
DELETE /google-forms/[id]
Response: { "success": true }
Auth: Required
```

#### Get Submissions
```
GET /google-forms/[id]/submissions?page=1&limit=25
Response: {
  "submissions": GoogleFormSubmission[],
  "pagination": { "page": 1, "limit": 25, "total": 500 }
}
Auth: Required
```

#### Batch Submission Operations
```
POST /google-forms/[id]/submissions/batch
Body: {
  "action": "delete" | "archive",
  "submissionIds": [...]
}
Response: { "success": true, "count": number }
Auth: Required
```

#### Export Submissions to CSV
```
GET /google-forms/[id]/submissions/export-csv
Response: CSV file download
Auth: Required
```

#### Import Submissions from CSV
```
POST /google-forms/[id]/submissions/import-csv
Body: FormData with CSV file
Response: { "imported": number, "errors": [...] }
Auth: Required
```

---

### Public Google Forms API

**Base URL**: `/api/public/google-forms`

#### Get Published Form
```
GET /[slug]
Response: GoogleForm
Auth: None (public)
Status: 404 if not published
```

**Example Response**:
```json
{
  "id": "form_456",
  "title": "Customer Feedback",
  "description": "Please rate our service",
  "status": "PUBLISHED",
  "schema": {
    "questions": [
      {
        "id": "q_001",
        "type": "short_text",
        "label": "Your name",
        "required": true
      }
    ]
  }
}
```

#### Submit Response
```
POST /[slug]
Body: {
  "answersJson": { "q_001": "John", "q_002": "Excellent" },
  "files": [{ "questionId": "q_003", "file": File }]
}
Response: {
  "success": true,
  "submissionId": "sub_789"
}
Auth: None (public)
```

---

## Form Builder

### Component Architecture

```
FormBuilder System
├── Simple Builder (FormBuilder.tsx)
│   ├── Canvas (form preview)
│   ├── Field Editor (properties panel)
│   └── Field Type Selector
│
├── Advanced Builder (FormBuilderLayout.tsx)
│   ├── FormPreview.tsx (canvas)
│   ├── PropertiesPanel.tsx (config panel)
│   ├── QuestionCard.tsx (individual question)
│   └── QuestionTypes/
│       ├── TextQuestion.tsx
│       ├── NumberQuestion.tsx
│       ├── DateQuestion.tsx
│       ├── SelectQuestion.tsx
│       ├── FileQuestion.tsx
│       └── ... (other types)
│
└── Auto-save System
    ├── Debounced saves (3 seconds Google Forms)
    ├── Version management
    └── Conflict resolution
```

### Supported Field Types and Constraints

#### Manual Forms Field Types

| Type | Input | Constraints | Example |
|------|-------|-------------|---------|
| **TEXT** | Text input | minLength, maxLength, pattern | `{ type: "TEXT", constraints: { minLength: 3 } }` |
| **NUMBER** | Number input | min, max, decimals | `{ type: "NUMBER", constraints: { min: 0, max: 100 } }` |
| **EMAIL** | Email field | regex validation | Auto-validates email format |
| **PHONE** | Phone field | 10-11 digits | Validates +55 (11) 9xxxx-xxxx |
| **DATE** | Date picker | minDate, maxDate | `{ constraints: { minDate: "2020-01-01" } }` |
| **TIME** | Time picker | stepMinutes | 15-minute increments |
| **BOOLEAN** | Toggle/checkbox | N/A | True/false selection |
| **DROPDOWN** | Select list | fixed options | `{ options: ["Option 1", "Option 2"] }` |
| **MULTISELECT** | Multi-checkbox | maxSelections | `{ options: [...], constraints: { max: 3 } }` |
| **FILE** | File upload | formats, size limit | `{ constraints: { formats: ["pdf", "jpg"] } }` |

#### Google Forms Question Types

| Type | Input | Configuration | Example |
|------|-------|-----------------|---------|
| **short_text** | Text line | required | Single-line text answer |
| **long_text** | Text area | required | Multi-line text answer |
| **number** | Number | required | Numeric answer |
| **email** | Email | required | Email validation |
| **phone** | Phone | required | Phone number |
| **date** | Date picker | required | Date selection |
| **time** | Time picker | required | Time selection |
| **single_choice** | Radio buttons | required, options | One selection from list |
| **multiple_choice** | Checkboxes | required, options | Multiple from list |
| **dropdown** | Select list | required, options | Dropdown selection |
| **file_upload** | File picker | required | File attachment |

### Builder Workflow

```
User Opens Form Builder
    ↓
[Initial State: Empty or Load Existing]
    ↓
[Canvas displays: Form name, description, questions]
    ↓
User Actions:
├─ Add Question → Type selector → Properties panel
├─ Edit Question → Click question → Modify in properties panel
├─ Reorder → Drag-drop (implied)
├─ Delete → Click delete button
└─ Preview → Real-time preview in canvas
    ↓
[Auto-save triggered every 3 seconds (Google Forms)]
[Manual save required (Manual Forms)]
    ↓
[Validation run: Check required fields, constraints]
    ↓
[On Save: Create new version if schema changed]
    ↓
[Success notification + Version increment]
```

### Builder Features Checklist

- ✅ Add/remove questions
- ✅ Edit question properties (label, required, description)
- ✅ Change question type
- ✅ Set validation rules
- ✅ Preview form in real-time
- ✅ Auto-save (Google Forms)
- ✅ Version history (Manual Forms)
- ✅ Duplicate form
- ✅ Share/publish (Google Forms)
- ⚠️ Reorder questions (drag-drop)
- ⚠️ Question logic/branching
- ❌ Template management UI

---

## Submission and Records

### Manual Form Submission Flow

```
User Views Records Page
    ↓
[Load form schema + paginated records]
    ↓
User Actions:
├─ View record (table row)
├─ Edit inline → Double-click field → Validate → Save
├─ Create new → Modal dialog (⚠️ partial)
├─ Delete → Confirmation → Archive
├─ Search → Filter results
└─ Export → Download CSV
    ↓
Validation:
├─ Type validation (TEXT, NUMBER, EMAIL, etc.)
├─ Constraint validation (min/max length, range)
├─ Required field validation
└─ Pattern matching (email, phone)
    ↓
On Save:
├─ Update Record.data JSON
├─ Update Record.updatedBy, updatedAt
├─ Return to view
└─ Show success notification
```

### Google Forms Submission Flow (Public)

```
User Visits /f/[slug]
    ↓
[Fetch published form via publicSlug]
    ↓
[Render form with all questions]
    ↓
User Fills Form:
├─ Answer questions
├─ Upload files (per question)
├─ Validation on blur
└─ Progress indicator
    ↓
User Clicks Submit
    ↓
Validate all required fields
    ↓
POST /api/public/google-forms/[slug]
    {
      "answersJson": { "q_001": "answer", ... },
      "files": [{ "questionId": "q_003", "file": File }]
    }
    ↓
Backend:
├─ Create GoogleFormSubmission record
├─ Store answers in answersJson
├─ Upload files with metadata
├─ Track submitter IP, userAgent
└─ Return submissionId
    ↓
Show Thank You Message
```

### CSV Export Format

#### Manual Forms Export
```csv
field_001_Farm Name,field_002_Inspection Date,field_003_Issues Found,Created At,Created By
John's Farm,2026-01-20,"Pest,Disease",2026-01-20T10:30:00Z,admin@farm.com
Smith Farm,2026-01-19,"Nutrient",2026-01-19T14:15:00Z,inspector@farm.com
```

#### Google Forms Export
```csv
q_001_Name,q_002_Email,q_003_Rating,Submitted At
John Doe,john@example.com,5,2026-01-20T10:30:00Z
Jane Smith,jane@example.com,4,2026-01-19T14:15:00Z
```

### Batch Operations (Google Forms)

#### Import from CSV
```python
POST /api/agro/[tenant]/google-forms/[id]/submissions/import-csv

# CSV file format:
q_001,q_002,q_003
Answer 1,Answer 2,Answer 3
Answer A,Answer B,Answer C

# Response:
{
  "imported": 2,
  "errors": [
    { "row": 3, "error": "Missing required field q_002" }
  ]
}
```

#### Batch Delete
```javascript
POST /api/agro/[tenant]/google-forms/[id]/submissions/batch
{
  "action": "delete",
  "submissionIds": ["sub_001", "sub_002", "sub_003"]
}
// Response: { "success": true, "count": 3 }
```

---

## Permissions and Access Control

### Permission Model (RBAC)

```typescript
interface FormPermissions {
  forms: {
    create: boolean;   // Can create new forms
    edit: boolean;     // Can edit form schema
    archive: boolean;  // Can archive/delete forms
  };
  records: {
    create: boolean;   // Can create new records/submissions
    edit: boolean;     // Can edit existing records
    archive: boolean;  // Can delete records
    export_all: boolean; // Can export all records
  };
  role: {
    isOwner: boolean;  // Tenant owner
    isAdmin: boolean;  // Tenant admin
  };
}
```

### Role Hierarchy

```
Tenant Owner
├─ Full access to all forms
├─ Full access to all records
├─ Can manage users and permissions
└─ Can delete forms/records

Tenant Admin
├─ Full access to all forms
├─ Full access to all records
├─ Can edit form permissions
└─ Limited user management

Custom Role (via customPermissions)
├─ forms.create: [boolean]
├─ forms.edit: [boolean]
├─ forms.archive: [boolean]
├─ records.create: [boolean]
├─ records.edit: [boolean]
├─ records.archive: [boolean]
└─ records.export_all: [boolean]

Tenant Member
├─ Can create records (if allowed)
├─ Can view shared forms
└─ Cannot edit form schema
```

### Implementation Details

**Permission Check Points**:
1. API authentication via Bearer token (JWT)
2. Membership verification (user belongs to tenant)
3. Custom permissions evaluation if defined
4. Field-level access control (partial)

**Storage**:
```javascript
// In Membership model:
{
  userId: "user_123",
  tenantId: "tenant_456",
  role: "MEMBER",
  customPermissions: {
    forms: {
      create: true,
      edit: false,
      archive: false
    },
    records: {
      create: true,
      edit: true,
      archive: false
    }
  }
}
```

**Public Forms Exception**:
- Google Forms can be published without authentication
- Public submissions require no user account
- Accessed via `/f/[slug]` (no auth header needed)

---

## Implementation Status

### ✅ COMPLETE/PRODUCTION-READY

**Manual Forms**:
- ✅ CRUD operations (Create, Read, Update, Delete)
- ✅ Schema versioning with immutable history
- ✅ Record management with full CRUD
- ✅ Inline editing with auto-save
- ✅ CSV export with field headers
- ✅ Search and filtering across fields
- ✅ Sorting by any column
- ✅ Pagination (25 items/page)
- ✅ Permission-based access control
- ✅ Mobile-responsive UI (card view on mobile)
- ✅ Dark theme integration
- ✅ 4 template forms (pre-built)

**Google Forms-like Feature**:
- ✅ Full CRUD operations
- ✅ Draft/Published/Archived state management
- ✅ Public form submission via slug
- ✅ 11 question types
- ✅ Auto-save every 3 seconds
- ✅ File upload per question
- ✅ Submission tracking with metadata (IP, userAgent)
- ✅ CSV import (batch submission upload)
- ✅ CSV export (all submissions)
- ✅ Batch delete operations
- ✅ Mobile-responsive form display

**Permissions & Auth**:
- ✅ Role-based access control (Owner, Admin, Member)
- ✅ Custom permission support (JSON storage)
- ✅ API authentication (Bearer token, JWT)
- ✅ Tenant isolation enforcement
- ✅ Public form access (no auth required)

**UI/UX**:
- ✅ Dark mode (slate-950, slate-900 palette)
- ✅ Mobile-first responsive design
- ✅ Table view (desktop) + Card view (mobile)
- ✅ Inline editing with validation
- ✅ Search/filter/sort functionality
- ✅ Confirmation dialogs for destructive actions
- ✅ Success/error notifications
- ✅ Loading states and spinners
- ✅ Keyboard shortcuts (some)

---

### ⚠️ PARTIAL/IN-PROGRESS

**New Record Creation Modal** (Manual Forms):
- ⚠️ Modal UI exists at `/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx`
- ⚠️ Shows "Funcionalidade em desenvolvimento" (Feature in development)
- ⚠️ API endpoint exists: `POST /api/agro/[tenant]/forms/[formId]/records`
- ⚠️ Frontend form input not yet implemented
- **Status**: Need to implement form field inputs in modal

**Form Versioning UI**:
- ⚠️ Versioning fully functional in database
- ⚠️ Version history displayed in form detail page
- ⚠️ No rollback UI to switch between versions
- **Status**: Display works, need rollback functionality

**Advanced Constraints**:
- ⚠️ Basic constraints implemented (minLength, maxLength, min, max)
- ⚠️ Pattern-based validation partially implemented
- ⚠️ File naming patterns partially implemented
- **Status**: Core constraints work, edge cases remain

**Field-level Permissions**:
- ⚠️ Structure exists in Membership.customPermissions
- ⚠️ No UI for configuring field-level access
- **Status**: Backend support exists, frontend UI missing

---

### ❌ NOT IMPLEMENTED

**Record Edit Modal** (Google Forms):
- ❌ Cannot edit submitted records
- ❌ View-only mode for submissions
- **Reason**: Design choice for survey integrity
- **Status**: May implement in future version

**Real-time Collaboration**:
- ❌ No simultaneous editing support
- ❌ No concurrent user conflict resolution
- ❌ No presence indicators
- **Status**: Not planned

**Form Sharing/Access Links**:
- ❌ ShareLink model exists but minimal UI
- ❌ Guest OTP access not fully implemented
- ❌ Share link expiry UI missing
- **Status**: Backend ready, frontend incomplete

**Advanced Form Logic**:
- ❌ Conditional questions (show/hide based on answers)
- ❌ Calculated fields
- ❌ Cross-field validation
- **Status**: Not yet designed

**Notifications**:
- ❌ Email notifications on new submissions
- ❌ Webhook support for form events
- **Status**: Not implemented

**Form Analytics**:
- ❌ Submission rate graphs
- ❌ Field-level completion rates
- ❌ Average submission time
- **Status**: Not implemented

---

## Component Architecture

### File Structure

```
dpwaiagro/
├── app/dpwai/[tenant_snake]/
│   ├── forms/
│   │   ├── page.tsx                    # Forms list page
│   │   ├── [formId]/
│   │   │   ├── page.tsx                # Form editor (legacy)
│   │   │   └── records/
│   │   │       └── page.tsx            # Records/submissions view
│   │   └── builder/
│   │       └── page.tsx                # Alternative builder
│   ├── manual/
│   │   ├── page.tsx                    # Manual forms overview
│   │   └── forms/
│   │       ├── [form_id]/
│   │       │   ├── page.tsx            # Manual form records
│   │       │   └── builder/
│   │       │       └── page.tsx        # Manual form builder
│   ├── google-forms/
│   │   ├── page.tsx                    # Google Forms list
│   │   ├── new/
│   │   │   └── page.tsx                # Create new (redirects to builder)
│   │   └── [id]/
│   │       ├── builder/
│   │       │   └── page.tsx            # Google Forms builder
│   │       └── submissions/
│   │           └── page.tsx            # Submissions view
│   └── f/
│       └── [slug]/
│           └── page.tsx                # Public form submission
│
├── components/
│   ├── forms/
│   │   └── FormBuilder.tsx             # Simple form builder
│   ├── FormBuilder/                    # Advanced builder components
│   │   ├── FormBuilderLayout.tsx       # Main builder layout
│   │   ├── FormPreview.tsx             # Canvas/preview area
│   │   ├── PropertiesPanel.tsx         # Properties editor
│   │   ├── QuestionCard.tsx            # Question display
│   │   └── QuestionTypes/              # Type-specific editors
│   │       ├── TextQuestion.tsx
│   │       ├── NumberQuestion.tsx
│   │       ├── DateQuestion.tsx
│   │       ├── SelectQuestion.tsx
│   │       ├── FileQuestion.tsx
│   │       └── ... (other types)
│   ├── RecordsList.tsx                 # Records table/card view
│   ├── RecordsTable.tsx                # Desktop table layout
│   ├── RecordsCards.tsx                # Mobile card layout
│   ├── RecordEditModal.tsx             # Inline record editor
│   ├── NewRecordModal.tsx              # New record dialog
│   └── FormDialog.tsx                  # Create form dialog
│
├── app/api/agro/[tenant]/
│   ├── forms/
│   │   ├── route.ts                    # GET (list), POST (create)
│   │   ├── [formId]/
│   │   │   ├── route.ts                # GET, PUT, PATCH, DELETE
│   │   │   └── records/
│   │   │       ├── route.ts            # GET (list), POST (create)
│   │   │       ├── [recordId]/
│   │   │       │   └── route.ts        # PATCH, DELETE
│   │   │       └── export/
│   │   │           └── route.ts        # GET (CSV export)
│   │   └── permissions/
│   │       └── route.ts                # GET (user permissions)
│   └── google-forms/
│       ├── route.ts                    # GET, POST
│       ├── [id]/
│       │   ├── route.ts                # GET, PATCH, DELETE
│       │   ├── publish/
│       │   │   └── route.ts            # POST
│       │   ├── archive/
│       │   │   └── route.ts            # POST
│       │   └── submissions/
│       │       ├── route.ts            # GET submissions
│       │       ├── batch/
│       │       │   └── route.ts        # POST (batch ops)
│       │       ├── export-csv/
│       │       │   └── route.ts        # GET (CSV export)
│       │       └── import-csv/
│       │           └── route.ts        # POST (CSV import)
│
├── app/api/public/
│   └── google-forms/
│       └── [slug]/
│           └── route.ts                # GET (public form), POST (submit)
│
├── lib/
│   ├── forms/
│   │   ├── schema-validator.ts         # Validation logic
│   │   ├── csv-export.ts               # CSV generation
│   │   └── form-parser.ts              # Schema parsing
│   └── ... (other utilities)
│
└── prisma/
    └── schema.prisma                   # Database schema
```

### Key Component Props

**RecordsList Component**:
```typescript
interface RecordsListProps {
  formId: string;
  records: Record[];
  schema: FormSchema;
  onEdit: (recordId: string, data: object) => void;
  onDelete: (recordId: string) => void;
  onExport: () => void;
  isLoading?: boolean;
}
```

**FormBuilder Component**:
```typescript
interface FormBuilderProps {
  formId?: string;
  initialSchema?: FormSchema;
  onSave: (schema: FormSchema) => void;
  onPublish?: () => void;
}
```

**FormDialog Component**:
```typescript
interface FormDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateForm: (formData: CreateFormData) => void;
}
```

---

## Quick Reference

### Common Tasks

#### Create a Manual Form
```
1. Navigate to /dpwai/[tenant]/forms
2. Click "Novo Formulário" (New Form)
3. Select form type (DATA_ONLY, SINGLE_FILE, CSV_IMPORT)
4. Fill name and optionally select template
5. Click Create → Redirects to builder
6. Add fields, configure constraints
7. Click Save → Creates form version 1
```

#### Add Record to Form
```
1. Open /dpwai/[tenant]/forms/[formId]/records
2. Click "Novo Registro" (New Record)
3. Fill form fields in modal
4. Validate on save
5. Record created with ID, timestamp, and createdBy
```

#### Export Form Records
```
1. Open /dpwai/[tenant]/forms/[formId]/records
2. Click "Exportar CSV" (Export)
3. Browser downloads CSV with all records
4. Format: Field names as headers, one record per row
```

#### Publish Google Form
```
1. Open /dpwai/[tenant]/google-forms/[id]/builder
2. Edit form title, description, questions
3. Click "Publicar" (Publish)
4. System generates publicSlug
5. Share link: /f/[slug] (public)
```

#### Submit to Public Form
```
1. Visit /f/[slug] (no auth required)
2. Fill all required fields
3. Upload files if present
4. Click Submit
5. Submission created, show thank you message
```

### Environment Variables

```bash
# Forms require these env vars:
DATABASE_URL=                   # Prisma database connection
NEXT_PUBLIC_API_URL=           # API base URL
JWT_SECRET=                    # For token generation
```

### Common Errors & Solutions

| Error | Cause | Solution |
|-------|-------|----------|
| "Form not found" | Wrong tenant or form deleted | Check form ID and tenant slug |
| "Permission denied" | User lacks required permission | Contact tenant admin for permission |
| "Validation failed" | Field doesn't match constraints | Check field type and constraints in schema |
| "CSV export failed" | Corrupted records or storage issue | Try with subset of records |
| "Public form not found" | Form not published or slug incorrect | Publish form first, verify slug |

---

## Related Documentation

- **Authentication**: See `/docs/auth.md`
- **Tenant System**: See `/docs/tenants.md`
- **File Storage**: See `/docs/file-upload.md`
- **API Standards**: See `/docs/api.md`
- **Permissions Model**: See `/docs/permissions.md`

---

## Glossary

| Term | Definition |
|------|-----------|
| **Form** | A template with fields for data collection |
| **Record** | A single submission/entry to a form |
| **Submission** | Same as record (used interchangeably) |
| **Version** | Immutable snapshot of form schema at specific point in time |
| **Schema** | JSON definition of form fields/questions and constraints |
| **Constraint** | Validation rule (minLength, maxLength, min, max, etc.) |
| **Slug** | URL-friendly unique identifier (e.g., "customer-feedback") |
| **Tenant** | Organization or workspace (multi-tenant isolation) |
| **Share Link** | Temporary or permanent link to form for guests |
| **Batch Operation** | Multiple records operation in single request |

---

**Document Version**: 1.0
**Last Updated**: 2026-01-26
**Maintained By**: Development Team
**Status**: Active
