# 🚜 Tractor Loader - 8-Bit Animations

Componentes React com animações exhaustivas de um trator em pixel art 8-bit para loading screens, 404 pages e data fetching.

## 📦 Componentes

### 1. **TractorLoader** (Principal)

Component principal com múltiplas animações do trator.

```tsx
import { TractorLoader } from '@/components';

// Uso básico
<TractorLoader />

// Com customização
<TractorLoader
  message="Carregando dados..."
  showHUD={true}
  intensity="exhaustive"
/>
```

#### Props

| Prop | Type | Default | Descrição |
|------|------|---------|-----------|
| `message` | string | "Carregando dados..." | Mensagem customizada |
| `showHUD` | boolean | true | Mostra painel HUD com status |
| `intensity` | 'light' \| 'medium' \| 'exhaustive' | 'exhaustive' | Nível de animações |

#### Intensidades

- **light**: Animações básicas, sem HUD, performance otimizada
- **medium**: Animações moderadas com algumas efeitos extras
- **exhaustive**: Todas as animações - partículas, órbitas, ondas, CRT flicker, etc.

---

### 2. **useTractorLoader** (Hook)

Hook para controlar loading state com mensagens dinâmicas.

```tsx
import { useTractorLoader } from '@/hooks/useTractorLoader';

const MyComponent = () => {
  const { isLoading, startLoading, stopLoading, currentMessage } =
    useTractorLoader({
      messages: [
        'Arando a terra 🌾',
        'Plantando dados 🌱',
        'Regando campos 💧',
      ],
    });

  const handleFetch = async () => {
    startLoading('Iniciando...');
    try {
      // API call
      await fetch('/api/data');
    } finally {
      stopLoading();
    }
  };

  if (isLoading) {
    return <TractorLoader message={currentMessage} />;
  }

  return <button onClick={handleFetch}>Carregar</button>;
};
```

---

### 3. **SuspenseWithTractor** (Wrapper)

Wrapper do React Suspense com TractorLoader como fallback.

```tsx
import { SuspenseWithTractor } from '@/components/SuspenseWithTractor';

// Com async server component
<SuspenseWithTractor
  message="Carregando dados..."
  intensity="exhaustive"
>
  <YourAsyncComponent />
</SuspenseWithTractor>

// Com fallback customizado
<SuspenseWithTractor fallback={<div>Loading...</div>}>
  <YourComponent />
</SuspenseWithTractor>
```

---

### 4. **404 Not Found Page**

Página automática de 404 com trator animado.

```
Arquivo: /dpwaiagro/app/not-found.tsx
Rota: Qualquer rota não encontrada
Atalhos:
  - L: Go to Login
  - W: Go to Welcome
  - R: Reload
```

---

## 🎨 Recursos Visuais

### Animações Incluídas

✨ **Exhaustive Mode:**
- Bounce do trator
- Rodas girando
- Fumaça saindo do motor
- Partículas flutuando
- Órbitas ao redor do trator
- Efeito glow pulsante
- Barra de progresso ondulante
- Indicadores de status piscando
- Grid animado de fundo
- Texto dinâmico rotativo

🎯 **Medium Mode:**
- Bounce do trator
- Rodas girando
- Fumaça
- Algumas partículas
- Barra de progresso

💨 **Light Mode:**
- Bounce simples
- Rodas girando
- Desempenho otimizado

---

## 📝 Exemplos de Uso

### Exemplo 1: Loading Simples

```tsx
import { TractorLoader } from '@/components';

export default function LoadingPage() {
  return <TractorLoader intensity="medium" />;
}
```

### Exemplo 2: API Call com Hook

```tsx
'use client';

import { useTractorLoader } from '@/hooks/useTractorLoader';
import { TractorLoader } from '@/components';

export default function DataFetcher() {
  const { isLoading, startLoading, stopLoading, currentMessage } =
    useTractorLoader();

  const fetchData = async () => {
    startLoading();
    try {
      const res = await fetch('/api/heavy-computation');
      // Process data
    } finally {
      stopLoading();
    }
  };

  return (
    <div>
      {isLoading && <TractorLoader message={currentMessage} />}
      {!isLoading && (
        <button onClick={fetchData}>
          Processar Dados 🚜
        </button>
      )}
    </div>
  );
}
```

### Exemplo 3: Server Component com Suspense

```tsx
// app/dashboard/page.tsx
import { SuspenseWithTractor } from '@/components/SuspenseWithTractor';
import { HeavyDataComponent } from './HeavyDataComponent'; // async server component

export default function Dashboard() {
  return (
    <SuspenseWithTractor intensity="exhaustive">
      <HeavyDataComponent />
    </SuspenseWithTractor>
  );
}
```

### Exemplo 4: Múltiplas Mensagens Customizadas

```tsx
<TractorLoader
  message="Seu texto aqui"
  intensity="exhaustive"
/>

// Com hook e mensagens customizadas
const { startLoading } = useTractorLoader({
  messages: [
    'Processando 🌾',
    'Salvando 💾',
    'Sincronizando ⚙️',
    'Finalizando ✨',
  ],
});
```

---

## 🎯 Casos de Uso

✅ **Loading de Dados**
- Fetch de APIs pesadas
- Upload de arquivos
- Processamento de dados

✅ **404 Pages**
- Página não encontrada automática
- Com navegação rápida

✅ **Suspense Boundaries**
- Server components assíncronos
- Code splitting

✅ **UX Melhorada**
- Feedback visual durante operações
- Temas agrícolas/rural
- Pixel art retro

---

## 🎬 Animações CSS

Animações disponíveis (todas customizáveis):

```css
@keyframes bounce - Salto do trator
@keyframes spin - Rodas girando
@keyframes float - Partículas flutuando
@keyframes orbit - Órbita ao redor
@keyframes wave - Barra ondulante
@keyframes pulse - Pulsação de luz
@keyframes twinkle - Brilho de estrelas
```

---

## 🚀 Performance

**Otimizações:**

- ✅ CSS animations (GPU accelerated)
- ✅ Lazy rendering de partículas
- ✅ Modo light para dispositivos lentos
- ✅ Suspense para code-splitting
- ✅ Zero dependencies (apenas React)

**Recomendações:**

- Use `intensity="light"` para dispositivos mobile
- Use `intensity="medium"` como padrão
- Use `intensity="exhaustive"` para destaque visual

---

## 🔧 Customização

### Cores

Edite `TractorLoader.tsx`:

```tsx
// Cores do trator
#2bd974 - Verde principal
#ffdc6a - Amarelo da cabine
#3c4a62 - Cinza das rodas
#1fc763 - Verde escuro
#ff5aa5 - Rosa (luzes)
#ffd166 - Amarelo (luzes)
```

### Mensagens Padrão

Edite `useTractorLoader.ts`:

```tsx
const defaultMessages = [
  'Arando a terra 🌾',
  'Plantando dados 🌱',
  // Adicione suas próprias
];
```

### Duração das Animações

Modifique os valores de `animation-duration` e `animation-delay` no CSS.

---

## 📱 Responsividade

Componentes são totalmente responsivos:

- Desktop: Trator grande, múltiplas animações
- Tablet: Trator médio, animações balanceadas
- Mobile: Modo light otimizado, menos efeitos

```tsx
// Para forçar light mode em mobile
intensity={isMobile ? 'light' : 'exhaustive'}
```

---

## 🎮 Atalhos de Teclado (404 Page)

- **L** - Go to Login
- **W** - Go to Welcome
- **R** - Reload page

---

## 🐛 Troubleshooting

**Trator não aparece:**
- Verifique se `TractorLoader` está importado corretamente
- Confirme que Tailwind CSS está configurado

**Animações lentas:**
- Use `intensity="light"` em dispositivos antigos
- Verifique se CSS animations estão habilitadas

**Mensagens não aparecem:**
- Confirme que o hook está em um componente `'use client'`
- Use `setCurrentMessage()` para atualizar manualmente

---

## 📚 Estrutura de Arquivos

```
/components/
├── TractorLoader.tsx           # Componente principal
├── SuspenseWithTractor.tsx     # Wrapper Suspense
└── examples/
    └── TractorLoaderExample.tsx # Exemplos de uso

/hooks/
├── useTractorLoader.ts         # Hook para controle

/app/
└── not-found.tsx               # Página 404 automática
```

---

## 🌟 Melhorias Futuras

- [ ] Modo dark/light selector
- [ ] Animations preferences (prefers-reduced-motion)
- [ ] Mais variações do trator
- [ ] Canvas version para melhor performance
- [ ] Tractor mini-games durante loading
- [ ] Suporte a SVG animado

---

## 📄 Licença

Faz parte do projeto DPI Platform.

---

## 🤝 Contribuições

Para melhorias ou novas animações, modifique os componentes conforme necessário.

Aproveite seu trator 8-bit! 🚜✨
