# 👤 Setup Admin User - admin@dpwai.com

## Quick Start (One Command)

```bash
npm run prisma:seed
```

This creates/updates the admin user in your database with:
- **Email:** admin@dpwai.com
- **Password:** Admin@123456
- **Tenant:** Fazenda Demo
- **Role:** Owner + Admin

---

## What It Does

When you run `npm run prisma:seed`, it:

1. ✅ Creates tenant `Fazenda Demo` (if doesn't exist)
2. ✅ Creates user `admin@dpwai.com` with bcrypt-hashed password (if doesn't exist)
3. ✅ Creates membership linking admin to tenant
4. ✅ Sets `Fazenda Demo` as default tenant
5. ✅ Updates password if needed (idempotent - safe to run multiple times)

---

## How It Works

### First Time
```
npm run prisma:seed
→ Creates tenant
→ Creates user with hashed password
→ Creates membership
→ Shows: ✅ SEED COMPLETED SUCCESSFULLY!
```

### Subsequent Times
```
npm run prisma:seed
→ Tenant already exists (skips)
→ User already exists (skips)
→ Everything is up to date (idempotent)
→ Shows: ✅ SEED COMPLETED SUCCESSFULLY!
```

---

## Testing Login

After seeding:

1. Start app: `npm run dev`
2. Go to: `http://localhost:3000/login`
3. Enter credentials:
   - Email: `admin@dpwai.com`
   - Password: `Admin@123456`
4. Click Login → Should work! ✅

---

## What's Created in Database

### User Table
```
id          | email              | username | status  | passwordHash
uuid        | admin@dpwai.com    | admin    | ACTIVE  | $2b$10$...
```

### Tenant Table
```
id   | name           | snake
uuid | Fazenda Demo   | fazenda-demo
```

### Membership Table
```
userId | tenantId | isOwner | isAdmin
uuid   | uuid     | true    | true
```

---

## Auto-Seeding on Login

The login endpoint **automatically calls seedDemoAdmin()** on every login attempt:

- If user doesn't exist → creates it
- If user exists → does nothing (idempotent)
- This means you can try login and it will auto-create if needed

So even if you forgot to run seed, trying to login will trigger seeding!

---

## Manual Seed Trigger

You can also manually trigger seeding via API:

```bash
curl -X POST http://localhost:3000/api/debug/manual-seed
```

Returns:
```json
{
  "seedResult": { "created": true/false, "admin": {...} },
  "verified": { "adminExists": true, "admin": {...} }
}
```

---

## Check Current State

To see if admin exists and view details:

```bash
curl http://localhost:3000/api/debug/seed-status
```

Returns current database state with admin info, tenant info, and counts.

---

## If Something Goes Wrong

### Admin doesn't exist after seed
1. Check if migrations were applied: `npx prisma migrate status`
2. Run migrations: `npx prisma migrate deploy`
3. Try seed again: `npm run prisma:seed`

### Password doesn't work
1. Delete admin and seed again:
   ```sql
   DELETE FROM "User" WHERE email = 'admin@dpwai.com';
   ```
2. Run: `npm run prisma:seed`

### Database connection error
1. Verify DATABASE_URL is set
2. Check database is running
3. Try again

---

## Production Deployment

When deploying to production:

**On Vercel (automatic):**
- Migrations run during deploy
- Seed is called on first login attempt
- Admin will be created automatically

**Manual:**
```bash
# If needed, run seed manually:
npx prisma db seed
```

---

## Summary

✅ **Run:** `npm run prisma:seed`
✅ **Wait for:** ✅ SEED COMPLETED SUCCESSFULLY!
✅ **Login with:** admin@dpwai.com / Admin@123456
✅ **Done!**

The admin user is now in your database with a bcrypt-hashed password. You can login! 🎉
