# Quick Command Reference - Agent 05 Tests & Security Audit

## Build & Setup

```bash
# Install dependencies
npm install

# Fix imports and auth module
npm run build

# If build fails, fix imports manually then retry
npm run build
```

## Run Tests

```bash
# Terminal 1: Start dev server
npm run dev

# Terminal 2: Run all E2E tests
npm run test:e2e

# Run with debug UI
npx playwright test --ui

# Run specific test group
npx playwright test -g "Test 1: Complete Login Flow"

# Run specific test
npx playwright test -g "should complete full login flow"

# Run specific browser only
npx playwright test --project=chromium

# Run with verbose output
npx playwright test --reporter=verbose
```

## View Results

```bash
# Show HTML report
npx playwright show-report

# Show JSON report
cat test-results.json

# Show trace viewer
npx playwright show-trace [trace-file]
```

## Check Security

```bash
# Review security audit
cat docs/SECURITY-AUDIT-REPORT.md

# Review final report
cat docs/AGENT-05-FINAL-REPORT.md

# Review testing guide
cat TESTING-README.md
```

## Troubleshooting

```bash
# Check if port 3000 is in use
lsof -i :3000

# Kill process on port 3000
kill -9 <PID>

# Reinstall Playwright browsers
npx playwright install

# Clear Playwright cache
rm -rf ~/.cache/ms-playwright

# Run tests with trace
npx playwright test --trace on
```

## Git Operations

```bash
# Check status
git status

# View changes
git diff

# View logs
git log --oneline -10

# Verify no build errors before committing
npm run build

# Verify tests pass before committing
npm run test:e2e
```

## Documentation Files

```bash
# Navigate to docs
cd docs

# Main security audit
cat SECURITY-AUDIT-REPORT.md

# Final report
cat AGENT-05-FINAL-REPORT.md

# Worklog status
cat WORKLOG/hardening_parallel.md

# Back to root
cd ..
```

## Testing Specific Components

```bash
# Login flow only
npx playwright test -g "Complete Login Flow"

# Multi-tenant isolation only
npx playwright test -g "Multi-Tenant Isolation"

# Mobile responsiveness only
npx playwright test -g "Mobile Responsiveness"

# Console errors only
npx playwright test -g "Console Errors"

# Auth error handling only
npx playwright test -g "Authentication Error"
```

## Performance

```bash
# Run tests in parallel (default)
npm run test:e2e

# Run tests sequentially
npx playwright test --workers=1

# Run with timeout override (in ms)
npx playwright test --timeout=60000

# Run with max retries
npx playwright test --retries=3
```

## CI/CD

```bash
# Set environment for CI
export CI=true

# Run tests on CI (fewer workers, more retries)
npm run test:e2e

# Generate CI report
npx playwright test --reporter=html,json
```

## Debugging

```bash
# Run single test with debug
npx playwright test --debug -g "should complete full login"

# Use VSCode debugger
code --inspect-brk ./node_modules/.bin/playwright test

# Enable PWDebug
PWDEBUG=1 npm run test:e2e

# Enable console logging
npx playwright test --reporter=verbose
```

## Clean Up

```bash
# Remove test artifacts
rm -rf test-results/ playwright-report/

# Remove node_modules (if needed)
rm -rf node_modules

# Clear cache
rm -rf .next .playwright

# Reinstall everything
npm install && npx playwright install
```

## Final Verification Checklist

```bash
# 1. Build passes
npm run build

# 2. All tests pass
npm run test:e2e

# 3. No console errors
# Check test 8 results

# 4. Security checks pass
# Review docs/SECURITY-AUDIT-REPORT.md

# 5. Mobile tests pass
# Tests 6 should pass for all 3 breakpoints

# 6. Auth tests pass
# Tests 1 & 7 should pass

# 7. Multi-tenant tests pass
# Test 3 should pass with isolation verified

# 8. Console report generated
npx playwright show-report

# 9. All files committed
git status

# 10. Deploy ready
# All green, ready to push
```

---

## Environment Setup

```bash
# .env file should contain:
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret-key
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Or use default test values (not for production)
JWT_SECRET=test-secret-key-change-in-production
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## Test Credentials

```
Email: admin@dpwai.com
Password: Admin@123456
```

Used in all authentication tests.

---

## Quick Links

- Test Suite: `/tests/e2e/hardening.spec.ts`
- Security Audit: `/docs/SECURITY-AUDIT-REPORT.md`
- Final Report: `/docs/AGENT-05-FINAL-REPORT.md`
- Testing Guide: `/TESTING-README.md`
- Command Reference: `/TEST-COMMANDS.md` (this file)

---

Last updated: January 26, 2026
Agent: Agent 05 - Security Audit & E2E Tests
