# ✅ CHECKLIST TÉCNICO - FULL FIX

**Data**: 25 January 2026
**Status**: Ready to implement
**Target**: Fix ALL items end-to-end

---

## 🔴 CRITICAL (Bloqueia app)

### LOGIN SCREEN
- [ ] ALL text in Portuguese
  - [ ] "Esqueci minha senha" (not "Forgot password")
  - [ ] "Entrar" (not "Sign in")
  - [ ] "Enviar instruções"
  - [ ] All placeholders Portuguese
- [ ] Dark theme applied
- [ ] Layout responsive (mobile works)

### FORGOT PASSWORD FLOW
- [ ] Email NOT in DB → show "Este e-mail não está cadastrado."
- [ ] Email EXISTS → send via Resend (actually sends, not fakes)
- [ ] Check Resend dashboard confirms emails sent
- [ ] Success message: "Enviamos um e-mail com instruções para redefinir sua senha."
- [ ] Token generation works
- [ ] Reset password page loads with token
- [ ] Password update saves to DB
- [ ] Redirect to login after success

### WELCOME PAGE
- [ ] Hamburger menu appears ONCE (remove duplicates)
- [ ] Header shows:
  - [ ] Hamburger menu (left)
  - [ ] "Olá, <nome>" greeting (in header, not floating)
  - [ ] User profile photo (top-right in header)
- [ ] Header is properly styled (dark theme, proper spacing)
- [ ] Farm selector shows ONLY demo farm (if single tenant)
- [ ] Farm selector works (if multi-tenant exists)
- [ ] Remove footer entirely
- [ ] Add choice buttons:
  - [ ] "Ver Dashboards"
  - [ ] "Abrir Ralph Chat"

### LOGOUT
- [ ] Button visible in header/menu
- [ ] Clears accessToken from localStorage
- [ ] Clears user data
- [ ] Clears tenant data
- [ ] Redirects to /login

---

## 🟠 HIGH (Breaks features)

### DASHBOARDS PAGE
- [ ] Fetch error handling (no raw error messages)
- [ ] Empty state when no dashboards
- [ ] Loading spinner while fetching
- [ ] Each dashboard card clickable
- [ ] Click dashboard → goes to dashboard viewer

### NEW DASHBOARD BUTTON
- [ ] "Novo Painel" button visible
- [ ] Click opens modal
- [ ] Modal has form (name, description)
- [ ] Submit creates dashboard (no "error evaluating")
- [ ] Success → redirect to dashboards list
- [ ] Validation: name required

### DASHBOARD VIEWER
- [ ] Page loads (no errors)
- [ ] Shows dashboard title
- [ ] Shows Looker embed (if embedUrl exists)
- [ ] If no embedUrl → show message (not error)
- [ ] Responsive (mobile works)
- [ ] Dark theme

### ROTH CHAT
- [ ] Responsive layout (mobile-first)
- [ ] Chat window shows messages
- [ ] Input field visible
- [ ] Send button works
- [ ] Messages scroll properly
- [ ] Dark theme respected
- [ ] User avatar visible
- [ ] Timestamp on messages

---

## 🟡 MEDIUM (UX issues)

### FORMS PAGE
- [ ] Dark theme applied (no white backgrounds)
- [ ] Forms list shows all forms
- [ ] Edit button visible + clickable
- [ ] Delete button visible + clickable
- [ ] Create form button works
- [ ] After create → redirect to Form Builder (not back to list)
- [ ] Responsive layout
- [ ] Form cards have proper spacing

### FORM BUILDER
- [ ] Layout is clean (not broken)
- [ ] Fields are aligned properly
- [ ] Field inputs are readable
- [ ] Add field button works
- [ ] Remove field button works
- [ ] "Salvo" message is subtle (not intrusive)
- [ ] JSON constraints are HIDDEN (user shouldn't see raw JSON)
- [ ] Number field is usable
- [ ] Text field is usable
- [ ] All field types work
- [ ] Dark theme applied
- [ ] Save button works
- [ ] Validation shows helpful errors (not raw exceptions)

### AUTOMATED ENTRIES
- [ ] Shows Looker embed (if exists)
- [ ] "Em breve" is acceptable placeholder
- [ ] No extra confusing UI
- [ ] Dark theme

### USERS PAGE
- [ ] Responsive layout (readable on mobile)
- [ ] Good contrast (text visible)
- [ ] User list shows all users
- [ ] Add user button works
- [ ] Edit user button works
- [ ] Delete user button works (with confirmation)
- [ ] Roles are visible:
  - [ ] OWNER (pode gerenciar organização)
  - [ ] ADMIN (pode editar dados)
  - [ ] USER (apenas visualiza)
- [ ] Role assignment works

### ORGANIZATION SETTINGS
- [ ] All labels in Portuguese:
  - [ ] "Nome da organização"
  - [ ] "Nome de exibição"
- [ ] Switch organization works
- [ ] Create organization works
- [ ] Organization deletion:
  - [ ] User clicks delete
  - [ ] Shows message: "Um pedido foi enviado para o time técnico para exclusão da organização."
  - [ ] No immediate deletion
  - [ ] Backend flag created for admin review

---

## 🟢 LOW (Nice to have)

### OVERALL
- [ ] NO English strings anywhere in UI
- [ ] Dark theme consistent (all pages)
- [ ] No duplicate UI elements
- [ ] No fake success messages
- [ ] All modals are clean
- [ ] All form validation is helpful

### ROLES IMPLEMENTATION (VERIFY)
- [ ] OWNER:
  - [ ] Can delete organization (with confirmation)
  - [ ] Can create new organization
  - [ ] Can add users
  - [ ] Can assign roles
- [ ] ADMIN:
  - [ ] Can edit forms
  - [ ] Can edit dashboards
  - [ ] Can manage users
  - [ ] CANNOT delete organization
- [ ] USER:
  - [ ] Can view dashboards
  - [ ] Can fill public forms (no login required)
  - [ ] CANNOT edit anything

### PUBLIC FORMS
- [ ] Form link shareable
- [ ] User does NOT need login to fill
- [ ] Submission saves to DB
- [ ] Confirmation message shown

---

## 📋 IMPLEMENTATION ORDER

1. **FIRST** (login works)
   - [ ] Login screen Portuguese
   - [ ] Logout works
   - [ ] Forgot password flow complete

2. **SECOND** (welcome page clean)
   - [ ] Remove duplicate hamburger
   - [ ] Fix header layout
   - [ ] Remove footer
   - [ ] Add choice buttons

3. **THIRD** (core features)
   - [ ] Dashboards (list, create, view)
   - [ ] Forms (list, create, build)
   - [ ] Users (list, create, roles)

4. **FOURTH** (Polish)
   - [ ] Dark theme everywhere
   - [ ] Responsive everywhere
   - [ ] All text Portuguese
   - [ ] No error leaks

5. **FIFTH** (Verify)
   - [ ] Run validation script
   - [ ] Create GitHub issues from results
   - [ ] Sign off on each

---

## 🧪 TESTING PER ITEM

For EACH checkbox above, verify:

1. **Does it work?**
   - In browser: YES/NO

2. **Is UX good?**
   - Error messages helpful?
   - Loading states visible?
   - No lag/slowness?

3. **Is it Portuguese?**
   - All text in PT-BR?
   - No English words?

4. **Is it dark theme?**
   - White backgrounds? (should be none)
   - Text readable?

5. **Is it responsive?**
   - Mobile view OK? (360px)
   - Desktop view OK? (1440px)

---

## ✅ SIGN-OFF TEMPLATE

When all items done:

```
FINAL VERIFICATION:

❌ Start: [date/time]
✅ End: [date/time]

PASSED:
- [ ] All 50+ items checked
- [ ] No English strings found
- [ ] Dark theme verified
- [ ] Mobile responsiveness OK
- [ ] All features working

FAILED:
- (none if complete)

STATUS: READY FOR PRODUCTION
```

---

## 📊 PROGRESS TRACKER

| Section | Total | Done | % |
|---------|-------|------|---|
| Critical | 11 | 0 | 0% |
| High | 13 | 0 | 0% |
| Medium | 24 | 0 | 0% |
| Low | 8 | 0 | 0% |
| **TOTAL** | **56** | **0** | **0%** |

Update this as you go.

