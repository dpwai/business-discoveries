# 🛡️ COPY & PASTE THIS PROMPT TO CLAUDE

---

```
YOU ARE A SENIOR FULL-STACK SECURITY ENGINEER. IMPLEMENT SECURITY FIXES FOR DPWAI (MULTI-TENANT).
A DETAILED SECURITY AUDIT HAS BEEN CREATED AT: knowledge/08-security/MULTI-TENANT-SECURITY-AUDIT.md

YOUR TASK: IMPLEMENT COMMIT 1 - ADD AUTHENTICATION TO GOOGLE FORMS ROUTES (2.5 hours)

CRITICAL: 14 routes are completely unauthenticated. This is production-blocking.

WHAT TO DO:

1. Read the audit (it's comprehensive, don't wing it)
   Location: /knowledge/08-security/MULTI-TENANT-SECURITY-AUDIT.md

2. Create verifyAuth() helper (or verify it exists):
   File: lib/api/verify-auth.ts
   - Import jwtVerify from 'jose'
   - Extract userId, email, tenantId from JWT payload
   - Return null if token invalid/expired
   - Secret from process.env.JWT_SECRET

3. Add authentication to 8 Google Forms routes:
   - /app/api/agro/[tenant]/google-forms/route.ts (GET + POST)
   - /app/api/agro/[tenant]/google-forms/[id]/route.ts (GET + PUT)
   - /app/api/agro/[tenant]/google-forms/[id]/export/route.ts (GET)
   - /app/api/agro/[tenant]/google-forms/[id]/settings/route.ts (GET + PUT)
   - /app/api/agro/[tenant]/google-forms/[id]/submissions/import-csv/route.ts (POST)

   For EACH route:
   a) Call verifyAuth() at start of handler
   b) Return 401 if not authenticated
   c) Verify tenantId from JWT matches URL tenant
   d) Return 403 if tenant doesn't match

   Example pattern:
   ```typescript
   const auth = await verifyAuth(request);
   if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

   const tenant = await prisma.tenant.findUnique({
     where: { snake: params.tenant }
   });
   if (tenant?.id !== auth.tenantId) {
     return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
   }
   ```

4. Test with curl:
   - No auth → 401 Unauthorized
   - Invalid token → 401 Unauthorized
   - Valid JWT → 200 OK + data
   - Wrong tenant → 403 Forbidden

5. Verify build:
   npm run build
   - Must pass with 0 errors
   - TypeScript types must be correct
   - All 8 routes must require auth

CONSTRAINTS:
- Follow existing project patterns (Prisma, TypeScript, JWT)
- Use verifyAuth() helper (DRY principle)
- Don't duplicate code across routes
- No breaking changes to response schema
- Maintain backward compatibility for authenticated clients

DELIVERABLE:
- verifyAuth() helper in lib/api/verify-auth.ts
- 8 routes updated with auth checks
- No TypeScript errors: npm run build succeeds
- All routes now return 401 when unauthenticated
- Commit 1/6 complete

NEXT: After this commit, we fix form builder type safety bug.

---

GIT COMMIT MESSAGE:
security: add authentication to Google Forms routes (Commit 1/6)

Add JWT authentication to all Google Forms API endpoints:
- Created verifyAuth() helper to extract and validate JWT tokens
- Added auth checks to 8 previously-unauthenticated routes
- Implemented tenant validation via JWT tenantId check
- Routes now return 401 for missing/invalid auth, 403 for wrong tenant
- All Google Forms operations now require valid JWT

Security Impact:
- BLOCKS: Unauthenticated form creation/modification
- BLOCKS: Unauthorized data export
- BLOCKS: CSV injection attacks via import
- REQUIRED: Valid JWT for all Google Forms API access

Fixes: https://github.com/issue/14-unauthenticated-routes (Critical)

Co-Authored-By: Claude Haiku 4.5 <noreply@anthropic.com>
```

---

## HOW TO USE

1. Copy the prompt above (everything inside the ``` blocks)
2. Paste into Claude.com or Claude Code
3. Wait for Commit 1 to complete
4. Verify build passes: `npm run build`
5. Check that routes now require auth: curl tests
6. Come back here for Commit 2 prompt

---

## FULL SECURITY FIX SEQUENCE

| Commit | Task | Depends On | Status |
|--------|------|-----------|--------|
| 1 | Google Forms authentication | - | ← **START HERE** |
| 2 | Form builder type safety | Commit 1 | Waiting |
| 3 | Account route auth | Commit 2 | Waiting |
| 4 | Rate limiting + audit logs | Commit 3 | Waiting |
| 5 | Add hash fields to schema | Commit 4 | Waiting |
| 6 | Create Integrations model | Commit 5 | Waiting |

---

**Audit:** ✅ Complete at `/knowledge/08-security/MULTI-TENANT-SECURITY-AUDIT.md`
**Plan:** ✅ Complete at `/knowledge/08-security/SECURITY-FIXES-PLAN.md`
**Next prompt:** Will be generated after Commit 1 succeeds
