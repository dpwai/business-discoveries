# CLAUDE.md - Instruções para o Claude Code

## Regras de Commit

**SEMPRE fazer commit quando o build funcionar.**

Após qualquer alteração no código que passar no `npm run build`:
1. Fazer `git add` dos arquivos alterados
2. Criar um commit descritivo em português
3. Usar mensagens de commit claras e objetivas

Exemplo:
```bash
git add -A
git commit -m "fix: corrige criação de formulários e adiciona traduções"
```

## Padrões do Projeto

### Idioma
- Interface em **português brasileiro (pt-BR)**
- Código e comentários em inglês
- Mensagens de commit em português

### Traduções
- Arquivos de tradução em `/lib/i18n/messages/` (pt-BR.json, en-US.json)
- Tipos de tradução em `/lib/i18n/translations.ts`
- Sempre adicionar chaves em AMBOS os idiomas

### Tecnologias
- Next.js 16+ com App Router
- TypeScript
- Prisma ORM
- TailwindCSS
- PostgreSQL

### Estrutura de Pastas
- `/app` - Rotas e páginas (App Router)
- `/components` - Componentes React reutilizáveis
- `/components/layout` - Componentes de layout (header, sidebar)
- `/lib` - Utilitários, contextos e hooks
- `/lib/context` - Contextos React (Theme, Sidebar, etc)
- `/lib/hooks` - Hooks customizados
- `/lib/i18n` - Internacionalização e traduções
- `/prisma` - Schema do banco de dados
- `/scripts` - Scripts utilitários
- `/docs` - Documentação

## Comandos Úteis

```bash
npm run dev      # Iniciar desenvolvimento
npm run build    # Build de produção
npm run lint     # Verificar linting
```
