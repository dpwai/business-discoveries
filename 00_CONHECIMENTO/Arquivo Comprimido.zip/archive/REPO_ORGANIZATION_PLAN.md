# DPWAI Repo Organization - Parallel Agents Plan

**Date**: Jan 26, 2026
**Goal**: Organize entire repo (knowledge + code + scripts + docs)
**Method**: 6 parallel agents
**Status**: DEPLOYING

---

## Agent Responsibilities

### Agent 1: Knowledge Base Organization
**Task**: Centralize ALL documentation in `/knowledge/`
- Move: `/DPWAI_HARDENING_KNOWLEDGE_BASE.md` → `/knowledge/00-overview/`
- Move: `/UNIVERSAL_DPWAI_PROMPT.md` → `/knowledge/00-overview/`
- Move: `/ERRORS_YOU_WILL_ENCOUNTER.md` → `/knowledge/07-troubleshooting/`
- Move: `/ALL_CREATED_DOCS.md` → `/knowledge/INDEX-NAVIGATION.md` (rename)
- Create: Master index in `/knowledge/INDEX.md` (update)
- Create: `/knowledge/README.md` (quick navigation)
- Organize all hardening docs into `/knowledge/08-hardening/` category
- Status: Complete by 06:00

### Agent 2: Scripts Organization
**Task**: Centralize ALL scripts in `/scripts/`
- Create subdirs: `/scripts/build/`, `/scripts/test/`, `/scripts/deploy/`, `/scripts/db/`
- Move all build scripts
- Move all test scripts
- Create: `/scripts/README.md` (master index)
- Create: `/scripts/QUICK-REFERENCE.md`
- Status: Complete by 06:00

### Agent 3: Clean Repository Root
**Task**: Remove scattered docs from root
- Delete (or move): Old markdown files scattered in root
- Keep ONLY essential: `.md` files that are critical
- Move: All project docs to `/knowledge/`
- Delete: Empty directories
- Status: Complete by 06:00

### Agent 4: Organize `/dpwaiagro/` Project
**Task**: Clean project directory structure
- Move: E2E tests to standard location
- Organize: `/dpwaiagro/docs/` properly
- Create: `/dpwaiagro/CONTRIBUTING.md`
- Update: `/dpwaiagro/README.md` (project overview)
- Status: Complete by 06:00

### Agent 5: Create Navigation & Indices
**Task**: Build master navigation system
- Create: `/knowledge/INDEX.md` (master table of contents)
- Create: `/REPO_STRUCTURE.md` (visual structure)
- Create: `/GETTING_STARTED.md` (new dev quick start)
- Create: `/REPO_MAP.md` (file locations)
- Create: Navigation links in all key files
- Status: Complete by 06:00

### Agent 6: Final Verification & Report
**Task**: Audit and create final report
- Verify all files in correct locations
- Check all links work
- Create summary of changes
- Create `/ORGANIZATION-COMPLETE.md` report
- Update `/CLAUDE.md` with new structure
- Status: Complete by 06:00

---

## Expected Outcome

After all agents complete:

✅ `/knowledge/` = Master documentation hub
✅ `/scripts/` = All automation scripts organized
✅ `/dpwaiagro/` = Clean project structure
✅ Root = Only essential files
✅ Navigation = Clear pathways to everything
✅ Report = What was done and where

---

## Timeline

```
Start: NOW
Agents 1-5: In parallel (30-45 min)
Agent 6: Verification (15-20 min)
Complete: Within 1 hour
```

---

## Success Criteria

- [ ] All documentation centralized in `/knowledge/`
- [ ] All scripts in `/scripts/` with clear organization
- [ ] Root directory clean (only essential files)
- [ ] Master index works (all links valid)
- [ ] Clear navigation pathways
- [ ] No orphaned files
- [ ] Comprehensive organization report

---

Status: 🚀 READY TO DEPLOY
