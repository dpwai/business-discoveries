# Sistema de Rascunhos (Draft) de Formulários

Guia completo de implementação e testes do sistema de rascunhos para formulários públicos.

## Visão Geral

O sistema de drafts permite aos usuários:
1. Salvar formulários incompletos como "rascunhos"
2. Receber um link compartilhável para retomar o preenchimento
3. Gerar QR codes para compartilhar via WhatsApp ou outros canais
4. Carregar dados salvos automaticamente ao retomar o formulário

## Arquitetura

### Banco de Dados

**Modelo: FormDraft**
```prisma
model FormDraft {
  id                  String    @id @default(uuid())
  draftToken          String    @unique // nanoid(32)
  publicFormId        String    // Reference to form
  ipAddress           String?   // Client IP
  userAgent           String?   // Device info
  identitySnapshotJson Json?    // User identity data
  answersJson         Json?     // Form answers
  resumeUrl           String?   // Generated URL
  expiresAt           DateTime  // Expiration (30 days default)
  completedAt         DateTime? // When submitted
  createdAt           DateTime
  updatedAt           DateTime
}
```

### API Endpoints

#### 1. Salvar Novo Rascunho
```
POST /api/public/forms/[publicId]/drafts
```

**Request:**
```json
{
  "identitySnapshot": { "name": "John", "email": "john@example.com" },
  "answers": { "field1": "value1", "field2": "value2" },
  "draftExpiryDays": 30
}
```

**Response (200):**
```json
{
  "success": true,
  "draftToken": "abc123def456...",
  "draftUrl": "https://app.dpwai.com.br/f/[publicId]?draft=abc123def456...",
  "resumeUrl": "https://app.dpwai.com.br/d/abc123def456...",
  "expiresAt": "2026-02-25T10:30:00Z"
}
```

**Error Responses:**
- `400` - Campo obrigatório faltando
- `500` - Erro ao salvar draft

---

#### 2. Listar Rascunhos do Usuário
```
GET /api/public/forms/[publicId]/drafts
```

**Response (200):**
```json
{
  "success": true,
  "drafts": [
    {
      "draftToken": "abc123...",
      "publicFormId": "form-123",
      "createdAt": "2026-01-26T10:30:00Z",
      "expiresAt": "2026-02-25T10:30:00Z",
      "isExpired": false
    }
  ]
}
```

---

#### 3. Carregar Rascunho
```
GET /api/public/drafts/[draftToken]
```

**Response (200):**
```json
{
  "success": true,
  "publicFormId": "form-123",
  "identity": { "name": "John", "email": "john@example.com" },
  "answers": { "field1": "value1", "field2": "value2" },
  "expiresAt": "2026-02-25T10:30:00Z",
  "isExpired": false
}
```

**Error Responses:**
- `404` - Draft não encontrado ou expirou
- `500` - Erro ao carregar

---

#### 4. Atualizar Rascunho (Autosave)
```
PUT /api/public/drafts/[draftToken]
```

**Request:**
```json
{
  "identitySnapshot": { "name": "Jane" },
  "answers": { "field1": "new value" }
}
```

**Response (200):**
```json
{
  "success": true,
  "expiresAt": "2026-02-25T10:30:00Z"
}
```

---

## Componentes

### DraftSaveButton (`components/forms/DraftSaveButton.tsx`)

Botão reutilizável que:
- Salva o formulário como rascunho
- Exibe modal com confirmação
- Mostra QR code do link
- Permite compartilhar via WhatsApp
- Copia link para área de transferência

**Props:**
```typescript
interface DraftSaveButtonProps {
  publicFormId: string;          // ID do formulário
  formName?: string;             // Nome do formulário (para mensagens)
  identitySnapshot?: Record<string, any>; // Dados de identidade
  answers?: Record<string, any>; // Respostas do formulário
  onDraftSaved?: (draftToken: string) => void; // Callback
  className?: string;            // Tailwind classes
}
```

**Uso:**
```tsx
<DraftSaveButton
  publicFormId="form-123"
  formName="Formulário de Cadastro"
  identitySnapshot={identityData}
  answers={formAnswers}
  onDraftSaved={(token) => console.log('Draft saved:', token)}
/>
```

---

## Páginas

### 1. Formulário Público (`app/f/[publicId]/page.tsx`)

Página que renderiza o formulário:
- Se `?draft=TOKEN` está na URL, carrega dados do draft
- Mostra botão de salvar rascunho
- Permite enviar o formulário

**URL Examples:**
- `/f/form-123` - Novo formulário
- `/f/form-123?draft=abc123def456...` - Com draft carregado

---

### 2. Retomar Rascunho (`app/d/[draftToken]/page.tsx`)

Página intermediária que:
1. Recebe o token do rascunho
2. Carrega dados do draft da API
3. Redireciona para `/f/[publicId]?draft=[token]`

**URL Example:**
- `/d/abc123def456...` - Retoma o rascunho

---

## Fluxo de Uso

### Salvar Rascunho
```
1. Usuário preenche formulário
2. Clica "Salvar e Continuar Depois"
3. API gera token único (nanoid 32 chars)
4. Modal abre com:
   - Link compartilhável
   - QR code
   - Botões de compartilhar (WhatsApp, etc)
5. Usuário copia link ou escaneia QR code
```

### Retomar Rascunho

**Cenário 1: Link direto (short resume link)**
```
1. Usuário clica em /d/[draftToken]
2. Página carrega o draft
3. Redireciona para /f/[publicId]?draft=[token]
4. Form renderiza com dados pré-preenchidos
```

**Cenário 2: Link com draft parameter**
```
1. Usuário clica em /f/[publicId]?draft=[token]
2. Page.tsx carrega draft automaticamente
3. Form renderiza com dados pré-preenchidos
```

---

## Testes Manuais

### 1. Testar Salvamento de Draft
```bash
# 1. Abrir formulário
http://localhost:3000/f/form-123

# 2. Preencher alguns campos
# 3. Clicar "Salvar e Continuar Depois"
# 4. Verificar:
#    - Modal aparece
#    - Link é gerado
#    - QR code é exibido
#    - Botão "Copiar" funciona
#    - Botão WhatsApp funciona
```

### 2. Testar Carregamento de Draft
```bash
# 1. Obter draftToken do passo anterior
# 2. Abrir: /f/form-123?draft=[draftToken]
# 3. Verificar:
#    - Dados foram carregados
#    - Formulário está pré-preenchido
#    - Mensagem de expiração aparece
```

### 3. Testar Retoma via Link Curto
```bash
# 1. Abrir: /d/[draftToken]
# 2. Verificar:
#    - Loading spinner aparece
#    - Redireciona para /f/form-123?draft=[token]
#    - Formulário carrega corretamente
```

### 4. Testar Expiração
```bash
# 1. Editar prisma schema para 1 segundo:
#    calculateDraftExpiration(1/86400) // 1 segundo
# 2. Salvar draft
# 3. Esperar 2 segundos
# 4. Tentar carregar: /d/[draftToken]
# 5. Deve exibir "Rascunho não encontrado ou expirou"
```

### 5. Testar Autosave
```bash
# 1. Formulário com dados carregados
# 2. Editar algum campo
# 3. Verificar: PUT /api/public/drafts/[token] é chamado
# 4. Após submit, verificar completedAt foi setado
```

---

## Validação de Dados

### Campos Obrigatórios
- `publicFormId` - Identificador único do formulário
- `draftToken` - Gerado automaticamente (nanoid 32 chars)

### Validação de Expiração
- Draft expira automaticamente após `draftExpiryDays` (padrão: 30 dias)
- Ao carregar, se expirado, retorna 404
- Timestamp é verificado no servidor

### Segurança
- IP address é armazenado para auditoria
- User agent é armazenado para device tracking
- Dados são armazenados como JSON criptografado em produção (recomendado)
- Links são únicos e impossíveis de adivinhar (nanoid 32 chars)

---

## Integração com Formulários

Para integrar o sistema de drafts em um formulário existente:

```tsx
import { DraftSaveButton } from '@/components/forms/DraftSaveButton';

export function MyForm() {
  const [formData, setFormData] = useState({});
  const [identity, setIdentity] = useState({});

  return (
    <div>
      {/* Form fields */}

      <DraftSaveButton
        publicFormId="form-123"
        formName="Meu Formulário"
        identitySnapshot={identity}
        answers={formData}
      />
    </div>
  );
}
```

---

## Limitações Conhecidas

1. **Página /d/[draftToken] incompleta** - Atualmente faz redirecionamento simples
2. **Sem autenticação** - Drafts são identificados por IP (pode ser melhorado)
3. **Sem tracking de edições** - Não há histórico de versões de draft
4. **IP pode mudar** - Se usuário trocar rede, draft não será listado como seu

---

## Melhorias Futuras

1. Adicionar autenticação de usuário
2. Implementar histórico de versões de draft
3. Adicionar notificação quando draft vai expirar (email/SMS)
4. Permitir renomear drafts
5. Compartilhamento seguro com senha
6. Colaboração em tempo real (múltiplos usuários)

---

## Troubleshooting

### Draft não carrega
- Verificar se token é válido
- Verificar se não expirou
- Verificar logs no console do servidor

### Modal não aparece
- Verificar se QRCode está instalado: `npm list qrcode`
- Verificar se component está importado corretamente

### Link não funciona
- Verificar se URL está correta
- Verificar se publicFormId é válido
- Verificar se draft existe no banco

### Dados não são pré-preenchidos
- Verificar se query param `?draft=` está na URL
- Verificar se fetch do draft retornou 200
- Verificar console para erros

---

## Referências

- [Nanoid Documentation](https://github.com/ai/nanoid)
- [QRCode.js Documentation](https://davidshimjs.github.io/qrcodejs/)
- [Prisma JSON Fields](https://www.prisma.io/docs/concepts/components/prisma-client/working-with-json-fields)

---

**Last Updated:** 2026-01-26
**Status:** Implementation Complete
