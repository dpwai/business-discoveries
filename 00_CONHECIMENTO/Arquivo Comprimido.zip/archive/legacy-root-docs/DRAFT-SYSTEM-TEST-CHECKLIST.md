# Draft System - Test Checklist

Complete checklist para validação do sistema de rascunhos.

## Pre-requisites
- [ ] Database está conectado
- [ ] Prisma migration foi aplicada (`npx prisma db push`)
- [ ] `nanoid` está instalado no package.json
- [ ] `qrcode` está instalado no package.json

## Unit Tests

### Draft Helpers
- [ ] `calculateDraftExpiration()` calcula corretamente
- [ ] `isDraftExpired()` detecta drafts expirados
- [ ] `saveDraft()` cria registro no banco
- [ ] `saveDraft()` retorna token, URL e data
- [ ] `loadDraft()` carrega dados corretos
- [ ] `loadDraft()` retorna 404 se expirado
- [ ] `updateDraft()` atualiza answers
- [ ] `updateDraft()` atualiza identity
- [ ] `completeDraft()` marca como completo
- [ ] `deleteExpiredDrafts()` remove vencidos

### API Endpoints

#### POST /api/public/forms/[publicId]/drafts
- [ ] Aceita `identitySnapshot` e `answers`
- [ ] Valida campos obrigatórios
- [ ] Retorna status 200 com token
- [ ] Gera token único
- [ ] Calcula expiração corretamente
- [ ] Armazena IP address
- [ ] Armazena user agent
- [ ] Retorna draftUrl correto
- [ ] Retorna resumeUrl correto
- [ ] Erro 400 se nenhum dado
- [ ] Erro 500 em erro de servidor

#### GET /api/public/forms/[publicId]/drafts
- [ ] Lista drafts do usuário (por IP)
- [ ] Retorna apenas drafts não expirados
- [ ] Retorna apenas drafts não completados
- [ ] Ordena por createdAt descending
- [ ] Inclui isExpired flag
- [ ] Erro 400 se publicId vazio
- [ ] Erro 500 em erro de servidor

#### GET /api/public/drafts/[draftToken]
- [ ] Carrega draft existente
- [ ] Retorna publicFormId
- [ ] Retorna identity snapshot
- [ ] Retorna answers
- [ ] Retorna expiresAt
- [ ] Retorna isExpired flag
- [ ] Erro 404 se token inválido
- [ ] Erro 404 se draft expirou
- [ ] Erro 400 se token vazio

#### PUT /api/public/drafts/[draftToken]
- [ ] Atualiza answers
- [ ] Atualiza identity
- [ ] Valida token existe
- [ ] Retorna 404 se expirou
- [ ] Retorna novo expiresAt
- [ ] Não reseta updatedAt desnecessariamente
- [ ] Erro 400 se nenhum dado
- [ ] Erro 404 se token inválido

## Component Tests

### DraftSaveButton
- [ ] Renderiza botão corretamente
- [ ] Desabilita quando isLoading
- [ ] Mostra loading state
- [ ] Validação: erro se sem dados
- [ ] Chama POST ao clicar
- [ ] Abre modal após sucesso
- [ ] Modal mostra QR code
- [ ] QR code é escaneável
- [ ] Link é copiável
- [ ] WhatsApp share funciona
- [ ] Generic share funciona (se suportado)
- [ ] Modal fecha ao clicar fechar
- [ ] Callback `onDraftSaved` é chamado

## Integration Tests

### Fluxo Completo: Salvar e Retomar
1. [ ] Abrir `/f/[publicId]`
2. [ ] Preencher dados
3. [ ] Clicar "Salvar e Continuar"
4. [ ] Modal aparece com link
5. [ ] Copiar link
6. [ ] Abrir em nova aba
7. [ ] Dados aparecem pré-preenchidos
8. [ ] Editar dados
9. [ ] Clicar "Enviar"
10. [ ] Sucesso/erro mensagem

### Fluxo 2: Retomar via Short Link
1. [ ] Obter `draftToken`
2. [ ] Abrir `/d/[draftToken]`
3. [ ] Loading spinner aparece
4. [ ] Redireciona para `/f/[publicId]?draft=[token]`
5. [ ] Dados carregam corretamente

### Fluxo 3: QR Code
1. [ ] Escanear QR code
2. [ ] Browser abre link
3. [ ] Dados carregam corretamente

### Fluxo 4: WhatsApp Share
1. [ ] Clicar "Compartilhar no WhatsApp"
2. [ ] WhatsApp Web abre
3. [ ] Link na mensagem funciona
4. [ ] Dados carregam corretamente

### Fluxo 5: Expiração
1. [ ] Criar draft com 1 segundo de expiração
2. [ ] Esperar 2 segundos
3. [ ] Tentar carregar: `/d/[token]`
4. [ ] Erro "não encontrado ou expirou"

## Mobile Tests

### Responsiveness
- [ ] Botão funciona em mobile
- [ ] Modal é responsivo
- [ ] QR code legível em mobile
- [ ] Link é copiável em mobile
- [ ] WhatsApp abre corretamente

### User Agent
- [ ] iPhone Safari
- [ ] Android Chrome
- [ ] Android Samsung Internet
- [ ] Firefox mobile

## Edge Cases

### Invalid Inputs
- [ ] publicId inválido
- [ ] draftToken inválido
- [ ] IP address não disponível
- [ ] Dados muito grandes (>1MB)
- [ ] Caracteres especiais em dados

### Concurrent Requests
- [ ] Salvar múltiplos drafts simultaneamente
- [ ] Atualizar draft enquanto outro atualiza
- [ ] Carregar draft durante expiração

### Security
- [ ] Não é possível adivinhar token (nanoid 32)
- [ ] Draft de outro IP não carrega
- [ ] Dados são JSON válido
- [ ] Sem SQL injection
- [ ] Sem XSS em dados

## Performance

### Load Times
- [ ] POST /drafts < 500ms
- [ ] GET /drafts < 500ms
- [ ] GET /drafts/[token] < 300ms
- [ ] PUT /drafts/[token] < 300ms

### Database
- [ ] Índices criados corretamente
- [ ] Queries são otimizadas
- [ ] Expiração funciona em larga escala

## Browser Compatibility

- [ ] Chrome 90+
- [ ] Firefox 88+
- [ ] Safari 14+
- [ ] Edge 90+
- [ ] Mobile browsers (acima)

## Error Handling

- [ ] Mensagens de erro são i18n
- [ ] Network errors tratados
- [ ] Timeout tratado
- [ ] Database errors tratados
- [ ] Invalid JSON tratado
- [ ] Missing fields tratado

## Logging

- [ ] Logs no salvamento
- [ ] Logs no carregamento
- [ ] Logs no erro
- [ ] Logs com contexto (publicId, draftToken)
- [ ] Sem logs sensíveis (senhas, etc)

## Database

- [ ] Tabela FormDraft criada
- [ ] Índices criados
- [ ] draftToken é @unique
- [ ] Campos NOT NULL corretos
- [ ] expiresAt é DateTime
- [ ] completedAt é nullable
- [ ] ipAddress é armazenado
- [ ] userAgent é armazenado

## Documentation

- [ ] README foi atualizado
- [ ] API endpoints documentados
- [ ] Props do component documentadas
- [ ] Exemplos de uso fornecidos
- [ ] Guia de troubleshooting incluído

## Deployment

- [ ] Build sem erros
- [ ] Sem console errors
- [ ] Migrations prontas
- [ ] Environment variables configuradas
- [ ] .env.example atualizado

## Post-Deployment

- [ ] Monitore storage do DB
- [ ] Monitore limpeza de drafts expirados
- [ ] Reporte de uso de drafts
- [ ] Performance em produção
- [ ] User feedback

---

## Sign-Off

- [ ] QA aprovado
- [ ] Security aprovado
- [ ] Performance aprovado
- [ ] Pronto para produção

**Tester:** ________________
**Date:** ________________
**Version:** 1.0
