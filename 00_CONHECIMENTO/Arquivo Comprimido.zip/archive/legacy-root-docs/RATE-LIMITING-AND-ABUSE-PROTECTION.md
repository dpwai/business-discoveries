# Rate Limiting and Anti-Abuse Protection System

## Overview

This document describes the comprehensive rate limiting and anti-abuse protection system implemented for the DPWAI Forms platform. The system provides multi-layered protection against abuse, spam, and attacks while maintaining a smooth user experience for legitimate users.

## Architecture

### 1. Rate Limiting Library (`/lib/ratelimit/`)

**File:** `/lib/ratelimit/index.ts`

The core rate limiting engine uses an in-memory Map-based approach:

```typescript
// Check if request should be allowed
const result = globalRateLimiter.checkLimit(key, maxRequests, windowMs);
// Returns: { allowed: boolean, remaining: number, resetAt: Date, retryAfterSeconds?: number }
```

**Features:**
- Timestamp-based sliding window algorithm
- Per-key request tracking
- Automatic cleanup of expired entries
- Memory-efficient design with configurable retention
- Non-blocking status checks (getStatus method)

**Memory Management:**
- Automatic cleanup interval (5 minutes)
- Timestamps older than 1 hour are removed
- Empty entries are deleted automatically

### 2. Middleware (`/lib/middleware/rateLimit.ts`)

**Key Exports:**
- `createRateLimiter(config)` - Generic rate limiter factory
- `createIpRateLimiter()` - IP-based rate limiting
- `createEmailRateLimiter()` - Email-based rate limiting
- `getClientIp(request)` - Extract client IP (handles proxies, CloudFlare, etc.)
- `attachRateLimitHeaders()` - Attach HTTP headers to responses

**HTTP Headers:**
```
X-RateLimit-Limit: 10
X-RateLimit-Remaining: 3
X-RateLimit-Reset: 2026-01-26T12:30:00Z
Retry-After: 45
```

### 3. Anti-Abuse Utilities (`/lib/abuse/`)

#### 3.1 Main Validators (`/lib/abuse/index.ts`)

**Honeypot Detection:**
```typescript
validateHoneypot(data, fieldName)
// Silently rejects if hidden field is filled (indicates bot)
```

**Payload Size Validation:**
```typescript
validatePayloadSize(req, maxSizeMb)
// Rejects requests larger than limit (default 10MB)
```

**File Validations:**
```typescript
validateFileSizes(formData, maxFileSizeMb)      // Max 5MB per file
validateFileCount(formData, maxFiles)            // Max 10 files
validateFileTypes(formData, allowedTypes)        // Check MIME types
```

**Spam Pattern Detection:**
```typescript
detectAbusePatterns(data)
// Returns: { suspicious: boolean, patterns: string[] }
// Detects:
// - Excessive special characters (> 50%)
// - Spam keywords (viagra, casino, lottery, etc.)
// - Excessive URLs (> 5)
```

#### 3.2 Submission Tracking (`/lib/abuse/submission-tracking.ts`)

**Track Events:**
```typescript
trackSubmissionEvent({
  formId, publicId, ipAddress,
  eventType: 'submission_success' | 'rate_limit_triggered' | 'spam_detected',
  reason, metadata
})
```

**Get Statistics:**
```typescript
getFormSubmissionStats(formId, publicId, days)
// Returns: { totalSubmissions, failedSubmissions, spamSubmissions, rateLimitTriggered, topBlockingIPs }
```

**IP Blocking:**
```typescript
isIpBlocked(formId, ipAddress, maxAttemptsInHour)
// Auto-blocks IPs with excessive abuse attempts
```

## API Endpoints Protection

### 1. Form Submission (`POST /api/public/forms/[publicId]/submissions`)

**Rate Limit:** 10 per minute per IP

**Validations:**
1. Rate limit check
2. IP blocking check
3. Payload size validation (max 10MB)
4. Honeypot validation
5. File size validation (max 5MB each)
6. File count validation (max 10 files)
7. Spam pattern detection

**Response on Limit Exceeded:**
```json
{
  "success": false,
  "error": "Too many submissions",
  "message": "Rate limit exceeded. Please try again later.",
  "retryAfter": 45
}
```

### 2. OTP Request (`POST /api/public/forms/[publicId]/otp/send`)

**Rate Limit:** 3 per hour per email

**Validations:**
1. Rate limit check (email-based)
2. Email format validation

**Response on Limit Exceeded:**
```json
{
  "success": false,
  "error": "Too many OTP requests",
  "message": "Please wait before requesting another code.",
  "retryAfter": 3200
}
```

### 3. Form Retrieval (`GET /api/public/forms/[publicId]`)

**Rate Limit:** 100 per minute per IP

**Purpose:** Prevent information enumeration attacks

### 4. File Upload Init (`POST /api/public/forms/[publicId]/files/init`)

**Rate Limit:** 50 per minute per IP

**Purpose:** Prevent resource exhaustion attacks

## Security Settings Admin Page

**Route:** `/dpwai/[tenant_snake]/forms/[formId]/security`

### Features:

1. **Statistics Dashboard:**
   - Total submissions
   - Failed submissions
   - Spam detected count
   - Rate limit triggers
   - Top blocking IPs

2. **Configuration Panel:**
   - Max file size (MB)
   - Max files per submission
   - Submission rate limit
   - OTP rate limit

3. **Protection Status:**
   - Honeypot status
   - Rate limiting
   - Payload validation
   - File validation
   - Spam detection

## Testing

### Test Files:

1. **`/lib/__tests__/ratelimit.test.ts`** (7 test suites, 30+ tests)
   - Basic limiting
   - Window management
   - Reset functionality
   - Performance benchmarks

2. **`/lib/__tests__/abuse-protection.test.ts`** (5 test suites, 25+ tests)
   - Honeypot validation
   - File count/type validation
   - Spam pattern detection
   - Edge cases

3. **`/lib/__tests__/rate-limit-api.test.ts`** (6 test suites, 25+ tests)
   - Endpoint-specific rate limits
   - Attack prevention
   - Distributed attacks
   - Status checking

### Running Tests:

```bash
# Run all tests
npm run test

# Run specific test file
npm run test -- ratelimit.test.ts

# Run with coverage
npm run test -- --coverage
```

## Testing Scenarios

### Scenario 1: Normal Submission Flow
```
1. User visits form
2. Fills out fields normally
3. Uploads 2 valid files (each < 5MB)
4. Submits form
✓ Request succeeds, submission recorded
✓ Rate limit shows 9/10 remaining
```

### Scenario 2: Submission Rate Limit
```
1. Attacker sends 10 submissions rapidly
✓ First 10 succeed
2. 11th attempt sent
✗ 429 response with "Retry-After: 45"
✓ Submission tracked as rate_limit_triggered
```

### Scenario 3: OTP Abuse
```
1. Attacker requests OTP 3 times
✓ First 3 succeed
2. 4th request attempted
✗ 429 response with "Retry-After: 3200"
✓ Event tracked as rate_limit_triggered
```

### Scenario 4: Honeypot Trigger
```
1. Bot submits form with honeypot field filled
✗ Request silently rejected
✓ No error shown to user (bot doesn't know)
✓ Submission tracked as honeypot_triggered
```

### Scenario 5: Spam Detection
```
1. Attacker submits with spam keywords: "VIAGRA", "CASINO"
✓ Patterns detected
✗ Request silently accepted (fake success to confuse attacker)
✓ Submission tracked as spam_detected
```

### Scenario 6: Large File Upload
```
1. User attempts to upload 6MB file (limit is 5MB)
✗ 400 response: "File too large: file.jpg (6.00MB, max 5.00MB)"
✓ Submission tracked as file_validation_failed
```

### Scenario 7: Excessive Files
```
1. User attempts to upload 11 files (limit is 10)
✗ 400 response: "Too many files (max 10)"
✓ Submission tracked as file_validation_failed
```

### Scenario 8: IP Blocking
```
1. IP 192.168.1.50 triggers 100+ rate limit events in 1 hour
2. All subsequent requests from that IP within that form
✗ 403 response: "Your IP has been temporarily blocked"
✓ Tracking shows increased attempts from same IP
```

## Implementation Checklist

### Core Library
- [x] RateLimiter class with sliding window
- [x] Memory cleanup system
- [x] Per-key rate limiting
- [x] Reset and flush methods
- [x] Status check without incrementing

### Middleware
- [x] IP extraction (handles proxies)
- [x] Email-based rate limiting
- [x] HTTP header attachment
- [x] 429 responses

### Anti-Abuse
- [x] Honeypot validation
- [x] Payload size validation
- [x] File size validation
- [x] File count validation
- [x] File type validation
- [x] Spam pattern detection

### API Endpoints
- [x] POST /api/public/forms/[publicId]/submissions (10/min)
- [x] POST /api/public/forms/[publicId]/otp/send (3/hour)
- [x] GET /api/public/forms/[publicId] (100/min)
- [x] POST /api/public/forms/[publicId]/files/init (50/min)

### Admin UI
- [x] Security settings page
- [x] Statistics dashboard
- [x] Configuration panel
- [x] Protection status display

### Testing
- [x] Rate limiter unit tests (30+ tests)
- [x] Anti-abuse tests (25+ tests)
- [x] API integration tests (25+ tests)

## Best Practices

### For Developers:

1. **Always check rate limits first**
   - Before processing any public form request
   - Before sending emails/OTPs

2. **Use appropriate key formats**
   - IP-based: `endpoint:ip_address`
   - Email-based: `email:user@example.com`
   - User-based: `user:user_id`

3. **Attach headers to responses**
   - Use `attachRateLimitHeaders()` for successful responses
   - Helps clients understand limits

4. **Log abuse events**
   - Use `trackSubmissionEvent()` for statistics
   - Enables abuse pattern analysis

### For Operations:

1. **Monitor top blocking IPs**
   - Check admin security dashboard regularly
   - Identify patterns of attacks

2. **Adjust limits based on usage**
   - Analyze submission statistics
   - Increase limits if too restrictive
   - Decrease if seeing abuse

3. **Regular cleanup**
   - Automatic cleanup runs every 5 minutes
   - Manual cleanup available via API
   - No performance degradation expected

## Performance Considerations

### Memory Usage:
- Each rate limit entry: ~100 bytes
- 1000 concurrent users: ~100KB
- Automatic cleanup prevents unbounded growth

### CPU Usage:
- Rate limit check: O(1) operation
- 10,000 checks/second possible
- Negligible impact on requests

### Disk Storage:
- Audit log entries: ~500 bytes each
- 1000 submissions/day: ~500KB
- Annual: ~180MB (manageable)

## Future Enhancements

1. **Redis Integration**
   - For distributed deployments
   - Shared rate limits across instances

2. **Machine Learning**
   - Pattern analysis for better spam detection
   - Adaptive rate limits based on behavior

3. **Geographic Blocking**
   - Block requests from specific countries
   - GeoIP-based rate limiting

4. **User Reputation**
   - Trust scores for users
   - Dynamic limits based on reputation

5. **DDoS Protection**
   - Integration with CDN providers
   - Advanced traffic analysis

## Troubleshooting

### High Rate Limit Triggers?

**Solution:**
1. Check if legitimate users are hitting limits
2. Increase rate limit in security settings
3. Review top blocking IPs for patterns

### Honeypot Too Aggressive?

**Solution:**
1. Disable honeypot if not needed
2. Use custom field name if conflicts exist
3. Monitor honeypot_triggered events

### Performance Degradation?

**Solution:**
1. Check memory usage: `globalRateLimiter.getSize()`
2. Force cleanup: `cleanupOldTrackingData()`
3. Scale to Redis if needed

## Support

For issues or questions:
1. Check the test files for usage examples
2. Review specific endpoint implementations
3. Contact the development team

---

**Last Updated:** 2026-01-26
**Status:** Production Ready
