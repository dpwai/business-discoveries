# Form Draft & Resume System

## Overview

The draft system allows users to save form progress, close their browser, and resume later using a shareable link. Drafts expire after 30 days and are automatically cleaned up.

## Architecture

### Data Model

```typescript
model FormDraft {
  id              String   @id @default(uuid())
  formId          String
  formVersionId   String
  resumeToken     String   @unique                 // Unique, shareable token
  draftData       Json     @db.Text               // Partial form answers
  identity        Json?    @db.Text               // Partial identity info
  expiresAt       DateTime                        // 30 days from creation
  createdAt       DateTime @default(now())
  lastAccessedAt  DateTime @default(now())        // Updated on every access
  createdDeviceId String?                         // For device binding (optional)

  form        Form        @relation(fields: [formId], references: [id], onDelete: Cascade)
  version     FormVersion @relation(fields: [formVersionId], references: [id], onDelete: Cascade)

  @@unique([resumeToken])
  @@index([formId])
  @@index([formVersionId])
  @@index([expiresAt])
}
```

### Resume Token

- **Format**: 32-character alphanumeric string (URL-safe)
- **Generation**: `randomBytes(24).toString('base64url').substring(0, 32)`
- **Uniqueness**: Guaranteed by database unique constraint
- **Shareability**: Can be shared via email, SMS, or QR code
- **Security**: Long random string is unfindable without sharing

Example: `aBcDeF1234567890xYzAbCdEf123456`

### Resume URL

```
https://app.dpwai.com.br/d/{resumeToken}
```

Public endpoints (no authentication required):
- `GET /api/public/drafts/{draftToken}` - Load draft data
- `POST /api/public/drafts/{draftToken}/submit` - Submit final form

## API Routes

### Create Draft

```bash
POST /api/tenant/{tenant}/drafts
```

**Request**:
```json
{
  "formVersionId": "uuid",
  "draftData": {
    "field_1": "value",
    "field_2": "another value"
  },
  "identity": {
    "firstName": "João",
    "lastName": "Silva",
    "email": "joao@example.com",
    "phone": "+55 11 98765-4321"
  }
}
```

**Response**:
```json
{
  "draftId": "uuid",
  "resumeToken": "aBcDeF1234567890xYzAbCdEf123456",
  "expiresAt": "2026-02-25T10:30:00.000Z",
  "resumeUrl": "https://app.dpwai.com.br/d/aBcDeF1234567890xYzAbCdEf123456"
}
```

### Update Draft (Autosave)

```bash
PUT /api/tenant/{tenant}/drafts/{draftToken}
```

**Request**:
```json
{
  "draftData": {
    "field_1": "updated value"
  },
  "identity": {
    "firstName": "João"
  }
}
```

**Response**:
```json
{
  "draftId": "uuid",
  "lastSavedAt": "2026-01-26T10:30:00.000Z"
}
```

**Notes**:
- Updates are merged (not replaced)
- `lastAccessedAt` is updated on every call
- Returns 410 Gone if draft is expired

### Load Draft (Public)

```bash
GET /api/public/drafts/{draftToken}
```

**Response**:
```json
{
  "formId": "uuid",
  "formName": "Contact Form",
  "schema": { /* Coltorapps schema */ },
  "pageTemplate": { /* GrapesJS template */ } | null,
  "draftData": { /* Current draft answers */ },
  "identity": { /* Current identity data */ } | null,
  "expiresAt": "2026-02-25T10:30:00.000Z"
}
```

**Status Codes**:
- `200` - Draft loaded successfully
- `404` - Draft not found
- `410` - Draft has expired

### Submit Draft (Public)

```bash
POST /api/public/drafts/{draftToken}/submit
```

**Request**:
```json
{
  "data": { /* Complete form data */ },
  "identity": { /* Complete identity data */ },
  "submitterEmail": "user@example.com",
  "submitterIP": "192.168.1.1"
}
```

**Response**:
```json
{
  "submissionId": "uuid",
  "status": "SUBMITTED",
  "redirectUrl": "/success/uuid"
}
```

**Side Effects**:
1. Creates `FormSubmission` record
2. Triggers webhook delivery (if configured)
3. Sets draft `expiresAt` to now (expires immediately)
4. Deletes draft on next cleanup job

## Frontend Integration

### 1. Save Draft Button

When user clicks "Save Draft":

```typescript
const saveDraft = async () => {
  const response = await fetch(
    `/api/tenant/${tenantId}/drafts`,
    {
      method: 'POST',
      body: JSON.stringify({
        formVersionId,
        draftData: currentFormData,
        identity: currentIdentity,
      }),
    }
  );

  const { resumeToken, resumeUrl, expiresAt } = await response.json();

  // Show modal with shareable link
  setShowDraftModal(true);
  setResumeUrl(resumeUrl);
};
```

### 2. Autosave Hook

```typescript
const { updateDraftData, saveDraft, forceSave } = useDraftAutosave({
  draftToken: resumeToken,
  formVersionId,
  tenantId,
  debounceMs: 30000, // Save every 30 seconds
  onSaveSuccess: (lastSavedAt) => {
    console.log('Draft saved:', lastSavedAt);
  },
});

// Update on field change
const handleFieldChange = (fieldId, value) => {
  setFormData({ ...formData, [fieldId]: value });
  updateDraftData({ ...formData, [fieldId]: value });
};
```

### 3. Resume Form

When user visits `/d/{draftToken}`:

```typescript
const loadDraft = async () => {
  const response = await fetch(
    `/api/public/drafts/${draftToken}`
  );
  const draft = await response.json();

  // Pre-fill form with draft data
  setFormData(draft.draftData);
  setIdentity(draft.identity);

  // Enable autosave
  enableAutosave(draftToken, draft.formId);
};
```

### 4. Submit Draft

```typescript
const submitDraft = async () => {
  const response = await fetch(
    `/api/public/drafts/${draftToken}/submit`,
    {
      method: 'POST',
      body: JSON.stringify({
        data: finalFormData,
        identity: finalIdentity,
      }),
    }
  );

  const { submissionId, redirectUrl } = await response.json();
  window.location.href = redirectUrl;
};
```

## Cleanup

### Automatic Cleanup (Cron Job)

Runs daily at midnight UTC (configurable in `vercel.json`):

```bash
GET /api/cron/cleanup-drafts
```

This job:
1. Finds all drafts where `expiresAt < now()`
2. Deletes them from the database
3. Cleans up orphaned files

### Manual Cleanup

```typescript
import { cleanupExpiredDrafts } from '@/lib/forms/draft-cleanup';

const result = await cleanupExpiredDrafts();
console.log(`Deleted ${result.deletedCount} drafts`);
```

## Security Considerations

### 1. Token Uniqueness

- Tokens are 32 characters, randomly generated
- Database enforces uniqueness
- Collision probability: negligible (1 in 10^19)

### 2. Public Endpoints

- `/d/{token}` page is publicly accessible (by design)
- No authentication required (token IS the authentication)
- Can be shared via email, SMS, QR code

### 3. Device Binding (Optional)

If you want to restrict draft access to the device that created it:

```typescript
// When creating draft, capture device ID
const deviceId = getDeviceId(); // fingerprint or session ID
draft.createdDeviceId = deviceId;

// When loading draft, verify device
if (draft.createdDeviceId !== currentDeviceId) {
  // Show warning or require PIN
}
```

### 4. PIN Protection (Optional)

```typescript
// When creating draft, generate optional PIN
const pin = generateRandomPin(4); // 1000-9999
draft.pinHash = hash(pin);

// Return PIN to user separately (email/SMS)

// When loading draft, require PIN
const enteredPin = prompt('Enter 4-digit PIN');
if (!verifyPin(enteredPin, draft.pinHash)) {
  throw new Error('Invalid PIN');
}
```

## Expiry Management

### 30-Day Expiry

- Set when draft is created: `expiresAt = now + 30 days`
- Updated on every access: `lastAccessedAt = now`
- NOT extended on access (TTL is absolute)

### Expiry Warnings

Show UI warnings when:
- Less than 7 days remaining: `"Expires in {{days}} days"`
- Less than 24 hours remaining: `"Expires tomorrow"`
- Less than 1 hour remaining: `"Expires in {{minutes}} minutes"`

### After Expiry

- Draft returns 410 Gone status
- User sees: "This draft has expired. Please start a new form."
- Link shared with collaborators becomes invalid
- Daily cleanup deletes expired drafts

## Translations

All user-facing strings are translated:

**Portuguese (pt-BR)**:
- `draft.title` - Rascunho do Formulário
- `draft.saved-at` - Rascunho salvo em:
- `draft.save-button` - Salvar Rascunho
- `draft.copy-link` - Copiar Link
- `draft.link-copied` - Link copiado para a área de transferência!
- `draft.expires-in` - Expira em {{days}} dias

**English (en-US)**:
- `draft.title` - Form Draft
- `draft.saved-at` - Draft saved at:
- `draft.save-button` - Save Draft
- `draft.copy-link` - Copy Link
- `draft.link-copied` - Link copied to clipboard!
- `draft.expires-in` - Expires in {{days}} days

See `/src/messages/pt-BR.json` and `/src/messages/en-US.json` for complete list.

## Testing

### Unit Tests

```typescript
import { generateResumeToken, calculateDraftExpiryDate } from '@/lib/forms/draft-utils';

test('generates 32-char alphanumeric tokens', () => {
  const token = generateResumeToken();
  expect(token).toMatch(/^[a-zA-Z0-9_-]{32}$/);
});

test('calculates 30-day expiry', () => {
  const expiry = calculateDraftExpiryDate();
  const days = (expiry.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24);
  expect(days).toBeCloseTo(30, 1);
});
```

### Integration Tests

```typescript
test('create and resume draft', async () => {
  // 1. Create draft
  const createRes = await fetch('/api/tenant/demo/drafts', {
    method: 'POST',
    body: JSON.stringify({ formVersionId, draftData: { field_1: 'value' } }),
  });
  const { resumeToken } = await createRes.json();

  // 2. Load draft
  const loadRes = await fetch(`/api/public/drafts/${resumeToken}`);
  const draft = await loadRes.json();
  expect(draft.draftData.field_1).toBe('value');

  // 3. Autosave
  const updateRes = await fetch(`/api/tenant/demo/drafts/${resumeToken}`, {
    method: 'PUT',
    body: JSON.stringify({ draftData: { field_1: 'updated' } }),
  });
  expect(updateRes.ok).toBe(true);

  // 4. Submit draft
  const submitRes = await fetch(`/api/public/drafts/${resumeToken}/submit`, {
    method: 'POST',
    body: JSON.stringify({ data: { field_1: 'final' } }),
  });
  const submission = await submitRes.json();
  expect(submission.status).toBe('SUBMITTED');
});
```

## Monitoring & Observability

### Metrics to Track

1. **Draft Creation Rate**
   - `forms.draft.created` - Drafts created per day
   - `forms.draft.resumeRate` - % of drafts that are resumed

2. **Draft Abandonment**
   - Average time from creation to expiry
   - Percentage of drafts that expire without submission

3. **Cleanup Job**
   - `forms.draft.cleanup.duration` - Time to run cleanup
   - `forms.draft.cleanup.deletedCount` - Number of drafts deleted

### Logs to Watch

```typescript
// Success
console.log(`Draft created: ${draftId} (expires ${expiresAt})`);
console.log(`Draft resumed: ${draftToken} (${daysOld} days old)`);
console.log(`Draft submitted: ${draftId} → ${submissionId}`);

// Errors
console.error('Draft token collision detected');
console.error(`Draft expired: ${draftToken}`);
console.error(`Cleanup job failed: ${error}`);
```

## Limitations & Future Enhancements

### Current Limitations

1. **No conflict resolution** - If multiple users resume same draft, last write wins
2. **No versioning** - Draft revisions not tracked
3. **No encryption** - Draft data stored plaintext in database
4. **No file attachments** - File uploads on drafts not yet supported
5. **No offline support** - Autosave requires internet

### Future Enhancements

1. **Encryption at rest** - Encrypt `draftData` and `identity` fields
2. **Collaborative drafts** - Multiple users editing same draft
3. **Draft history** - Track changes and allow reverting
4. **File attachments** - Store files attached to draft (with cleanup)
5. **Offline mode** - LocalStorage sync + conflict resolution
6. **WebSocket autosave** - Real-time sync instead of HTTP polling
7. **Draft templates** - Save common form patterns as templates
8. **Recurring drafts** - Auto-create new draft when expired

## Troubleshooting

### "Draft not found" error

**Causes**:
- Token typo
- Draft has expired (cleanup job deleted it)
- User accessed wrong link

**Solution**: Show user error page with option to start new form

### "Draft has expired" (410 Gone)

**Causes**:
- 30 days have passed since creation
- Draft was manually submitted (expiresAt set to now)

**Solution**: Show message: "This draft has expired. Please start a new form."

### Autosave failures

**Causes**:
- Network error
- Backend API error (bug in PUT endpoint)
- Database unavailable

**Solution**:
- Show warning banner: "Autosave failed. Changes not saved."
- Retry automatically after 5 seconds
- Allow user to force save manually
- Show timestamp of last successful save

### Orphaned drafts in database

**Causes**:
- Cleanup cron job didn't run
- Cron job errored silently

**Solution**:
- Monitor cron job completion
- Add alerts if job fails 2+ times in a row
- Manual cleanup: `DELETE FROM FormDraft WHERE expiresAt < now()`

## Reference

### Files Created

- `/lib/forms/draft-utils.ts` - Token generation, expiry calculation
- `/lib/forms/useDraftAutosave.ts` - React hook for autosave
- `/lib/forms/draft-cleanup.ts` - Cron job cleanup logic
- `/app/api/tenant/[tenant]/drafts/route.ts` - Create draft
- `/app/api/tenant/[tenant]/drafts/[draftToken]/route.ts` - Update draft
- `/app/api/public/drafts/[draftToken]/route.ts` - Load draft (public)
- `/app/api/public/drafts/[draftToken]/submit/route.ts` - Submit draft
- `/app/api/cron/cleanup-drafts/route.ts` - Cleanup cron job
- `/app/d/[draftToken]/page.tsx` - Resume page
- `/components/forms/DraftSaveModal.tsx` - Share modal component
- `/src/messages/pt-BR.json` - Portuguese translations
- `/src/messages/en-US.json` - English translations

### Related Documentation

- `/docs/CONTRACTS/forms_contracts.md` - Full API contracts
- `/docs/WORKLOG/forms_builder_parallel.md` - Implementation progress
- `/knowledge/02-frontend/` - Frontend architecture

---

**Last Updated**: 2026-01-26
**Status**: ✅ Implementation Complete
**Agent**: 08 - Draft Resumption Architect
