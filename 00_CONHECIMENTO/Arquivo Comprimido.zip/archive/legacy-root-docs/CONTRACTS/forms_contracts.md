# Forms Product - Data & API Contracts

## Database Models (Prisma)

### Core Form Models

```typescript
// Form - Main form entity
interface Form {
  id: string;                        // UUID
  tenantId: string;                  // UUID (FK Tenant)
  name: string;                      // Form name
  slug: string;                       // URL slug (unique per tenant)
  description: string | null;         // Optional description
  publicId: string;                   // Public-facing form ID (unique globally)
  status: 'DRAFT' | 'PUBLISHED' | 'ARCHIVED';
  currentVersionId: string | null;   // FK FormVersion
  createdBy: string;                 // UUID (FK User)
  updatedBy: string;                 // UUID (FK User)
  createdAt: Date;
  updatedAt: Date;
  settings: FormSettings;             // JSON: isPublic, allowAnyoneSubmit, requireAuth, etc.
  publicMetadata: object | null;      // JSON: custom public metadata
}

// FormVersion - Immutable snapshots of form schema
interface FormVersion {
  id: string;                        // UUID
  formId: string;                    // UUID (FK Form)
  versionNumber: number;              // 1, 2, 3, ...
  schema: FormSchema;                // JSON: Coltorapps normalized schema
  pageTemplateId: string | null;     // FK FormPageTemplate (optional page wrapper)
  isPublished: boolean;
  publishedAt: Date | null;
  createdBy: string;                 // UUID (FK User)
  createdAt: Date;
  updatedAt: Date;
}

// FormPageTemplate - GrapesJS page design with form slot
interface FormPageTemplate {
  id: string;                        // UUID
  formId: string;                    // UUID (FK Form)
  pageJson: object;                  // JSON: GrapesJS HTML/CSS structure
  templateType: 'SINGLE_PAGE' | 'MULTI_PAGE';
  devicePreview: 'DESKTOP' | 'MOBILE' | 'TABLET';
  createdBy: string;                 // UUID (FK User)
  updatedAt: Date;
  publishedVersion: object | null;   // JSON: Published template snapshot
}

// FormSubmission - Individual form response
interface FormSubmission {
  id: string;                        // UUID
  formVersionId: string;              // UUID (FK FormVersion)
  formId: string;                    // UUID (FK Form) - denormalized for query speed
  submitterEmail: string | null;
  submitterIP: string | null;
  userAgent: string | null;
  data: object;                       // JSON: form answers {fieldId: value, ...}
  identity: SubmissionIdentity;      // Embedded: user identity data
  status: 'DRAFT' | 'SUBMITTED' | 'SPAM';
  submittedAt: Date;
  createdAt: Date;
  webhookDelivered: boolean;
  webhookDeliveredAt: Date | null;
  stripeSessionId: string | null;    // If integrated with payments
  metadata: object | null;            // JSON: custom fields
}

// SubmissionIdentity - Embedded identity info
interface SubmissionIdentity {
  firstName: string | null;
  lastName: string | null;
  email: string | null;
  phone: string | null;
  captureMethod: 'FORM_FIELD' | 'PREFILLED' | 'OTP';
  otpVerified: boolean;
  otpVerifiedAt: Date | null;
}

// FormFile - File uploads attached to submissions
interface FormFile {
  id: string;                        // UUID
  submissionId: string;               // UUID (FK FormSubmission)
  fieldId: string;                   // Which field uploaded this file
  fileName: string;
  fileSize: number;                   // bytes
  mimeType: string;                  // 'image/jpeg', 'application/pdf', etc.
  storageUrl: string;                // Presigned URL or R2 path
  storageProvider: 'R2' | 'S3' | 'GCS' | 'LOCAL';
  uploadedAt: Date;
}

// FormDraft - Resume-able submission drafts
interface FormDraft {
  id: string;                        // UUID
  formVersionId: string;              // UUID (FK FormVersion)
  formId: string;                    // UUID (FK Form)
  resumeToken: string;                // Unique token for /d/{token} route
  draftData: object;                  // JSON: partial form answers
  identity: Partial<SubmissionIdentity>;  // Partially filled identity
  expiresAt: Date;                   // 30 days from creation
  createdAt: Date;
  lastAccessedAt: Date;
  createdDeviceId: string | null;    // For device binding (optional)
}

// WebhookEndpoint - POST-submission webhook config
interface WebhookEndpoint {
  id: string;                        // UUID
  formId: string;                    // UUID (FK Form)
  url: string;
  events: string[];                  // ['submission.created', 'submission.spam_flagged']
  active: boolean;
  secret: string;                    // For HMAC-SHA256 signature verification
  retryPolicy: WebhookRetryPolicy;   // JSON: exponential backoff config
  createdAt: Date;
  updatedAt: Date;
}

// WebhookDelivery - Webhook attempt log
interface WebhookDelivery {
  id: string;                        // UUID
  webhookEndpointId: string;          // UUID (FK WebhookEndpoint)
  submissionId: string;               // UUID (FK FormSubmission)
  attempt: number;                    // 1, 2, 3, ... (retries)
  httpStatus: number | null;
  responseBody: string | null;
  sentAt: Date;
  nextRetryAt: Date | null;
  deliveredAt: Date | null;
}

// FormAccessAllowlist - Multi-tenant access control
interface FormAccessAllowlist {
  id: string;                        // UUID
  formId: string;                    // UUID (FK Form)
  tenantId: string;                  // UUID (FK Tenant) - secondary tenant access
  role: 'VIEWER' | 'EDITOR' | 'ADMIN';
  createdAt: Date;
}

// EmailTemplate - Resend email design (GrapesJS)
interface EmailTemplate {
  id: string;                        // UUID
  tenantId: string;                  // UUID (FK Tenant)
  name: string;
  subject: string;
  htmlContent: string;               // GrapesJS rendered HTML
  textContent: string | null;        // Plain text fallback
  fromEmail: string;
  fromName: string;
  createdAt: Date;
  updatedAt: Date;
}

// EmailEvent - Link/OTP email tracking
interface EmailEvent {
  id: string;                        // UUID
  templateId: string | null;         // FK EmailTemplate
  submissionId: string | null;       // FK FormSubmission (if from form)
  recipientEmail: string;
  eventType: 'LINK_INVITE' | 'OTP' | 'CONFIRMATION' | 'CUSTOM';
  linkToken: string | null;          // For /d/{token} draft resume links
  sentAt: Date;
  openedAt: Date | null;
  clickedAt: Date | null;
}

// EmailOtp - OTP for identity verification
interface EmailOtp {
  id: string;                        // UUID
  submissionId: string | null;       // FK FormSubmission
  recipientEmail: string;
  code: string;                       // 6-digit code
  hashedCode: string;                // bcrypt hash
  attempts: number;
  maxAttempts: number;               // Usually 5
  expiresAt: Date;
  verifiedAt: Date | null;
  createdAt: Date;
}
```

## Request/Response Interfaces

### Form Builder API

```typescript
// POST /api/tenants/{tenant}/forms
interface CreateFormRequest {
  name: string;
  description?: string;
  template?: 'BLANK' | 'CONTACT' | 'SURVEY';
}

interface CreateFormResponse {
  id: string;
  publicId: string;
  slug: string;
  currentVersionId: string;
  status: 'DRAFT';
}

// PUT /api/tenants/{tenant}/forms/{formId}/builder
interface UpdateFormSchemaRequest {
  schema: FormSchema;             // Coltorapps normalized schema
  autosave?: boolean;             // If true, don't create new version yet
}

interface UpdateFormSchemaResponse {
  versionId: string;
  versionNumber: number;
}

// POST /api/tenants/{tenant}/forms/{formId}/publish
interface PublishFormRequest {
  makePublic?: boolean;           // Allow public submissions
  successPageSchema?: object;     // Optional success page
}

interface PublishFormResponse {
  versionNumber: number;
  publicUrl: string;              // https://app.dpwai.com.br/f/{publicId}
  publishedAt: Date;
}

// PUT /api/tenants/{tenant}/forms/{formId}/page-template
interface UpdatePageTemplateRequest {
  pageJson: object;               // GrapesJS structure
  templateType: 'SINGLE_PAGE' | 'MULTI_PAGE';
}

interface UpdatePageTemplateResponse {
  templateId: string;
  updatedAt: Date;
}

// GET /api/tenants/{tenant}/forms/{formId}/preview
interface FormPreviewResponse {
  formId: string;
  versionNumber: number;
  schema: FormSchema;
  pageTemplate: object | null;
  status: 'DRAFT' | 'PUBLISHED';
}
```

### Public Form API

```typescript
// GET /f/{publicId}
interface PublicFormLoadResponse {
  formId: string;
  publicId: string;
  schema: FormSchema;
  pageTemplate: object | null;
  requiresIdentity: boolean;
  requiresOtp: boolean;
  formName: string;
}

// POST /f/{publicId}/submit
interface FormSubmitRequest {
  data: object;                   // {fieldId: value, ...}
  identity?: SubmissionIdentity;
  draftToken?: string;            // If resuming from draft
  captchaToken?: string;
}

interface FormSubmitResponse {
  submissionId: string;
  status: 'SUBMITTED';
  redirectUrl?: string;           // Success page or custom URL
  resumeToken?: string;           // Draft token if saved for later
}

// POST /api/public/otp/send
interface SendOtpRequest {
  formPublicId: string;
  email: string;
}

interface SendOtpResponse {
  otpId: string;
  expiresIn: number;              // seconds
}

// POST /api/public/otp/verify
interface VerifyOtpRequest {
  otpId: string;
  code: string;
}

interface VerifyOtpResponse {
  verified: boolean;
  submissionIdentityToken: string; // Signed JWT with identity data
}
```

### Draft Resume API

```typescript
// POST /api/tenants/{tenant}/drafts
interface CreateDraftRequest {
  formVersionId: string;
  draftData?: object;
  identity?: Partial<SubmissionIdentity>;
}

interface CreateDraftResponse {
  draftId: string;
  resumeToken: string;
  expiresAt: Date;
  resumeUrl: string;              // /d/{resumeToken}
}

// GET /d/{draftToken}
interface LoadDraftResponse {
  formId: string;
  formName: string;
  schema: FormSchema;
  pageTemplate: object | null;
  draftData: object;
  identity: Partial<SubmissionIdentity>;
  expiresAt: Date;
}

// PUT /api/drafts/{draftToken}
interface UpdateDraftRequest {
  draftData: object;              // Partial update
  identity?: Partial<SubmissionIdentity>;
}

interface UpdateDraftResponse {
  draftId: string;
  lastSavedAt: Date;
}
```

### Webhook API

```typescript
// POST /api/tenants/{tenant}/forms/{formId}/webhooks
interface CreateWebhookRequest {
  url: string;
  events: string[];
  active?: boolean;
}

interface CreateWebhookResponse {
  webhookId: string;
  secret: string;
  testUrl: string;
}

// POST /api/tenants/{tenant}/forms/{formId}/webhooks/{webhookId}/test
interface TestWebhookResponse {
  deliveryId: string;
  httpStatus: number;
  responseTime: number;            // ms
  success: boolean;
}

// Webhook Payload Structure
interface WebhookPayload {
  event: string;                  // 'submission.created'
  timestamp: Date;
  data: {
    submission: FormSubmission;
    form: Form;
    metadata?: object;
  };
  signature: string;              // HMAC-SHA256(payload, secret)
}
```

### Submissions API

```typescript
// GET /api/tenants/{tenant}/forms/{formId}/submissions
interface ListSubmissionsResponse {
  submissions: Array<{
    id: string;
    submitterEmail: string;
    submittedAt: Date;
    status: 'SUBMITTED' | 'SPAM';
  }>;
  total: number;
  pageSize: number;
  currentPage: number;
}

// GET /api/tenants/{tenant}/forms/{formId}/submissions/{submissionId}
interface GetSubmissionResponse {
  id: string;
  data: object;
  identity: SubmissionIdentity;
  files: Array<{
    fieldId: string;
    fileName: string;
    url: string;
  }>;
  submittedAt: Date;
  webhookStatus: {
    delivered: boolean;
    attempts: number;
  };
}

// POST /api/tenants/{tenant}/forms/{formId}/submissions/export
interface ExportSubmissionsRequest {
  format: 'CSV' | 'JSON';
  fields?: string[];              // Specific fields to export
  dateRange?: {
    startDate: Date;
    endDate: Date;
  };
}

interface ExportSubmissionsResponse {
  downloadUrl: string;
  expiresIn: number;              // seconds
}
```

### File Upload API

```typescript
// POST /api/public/files/presigned-init
interface InitPresignedUploadRequest {
  formPublicId: string;
  fieldId: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
}

interface InitPresignedUploadResponse {
  uploadId: string;
  presignedUrl: string;           // For PUT direct upload
  expiresIn: number;              // seconds
}

// POST /api/public/files/presigned-complete
interface CompletePresignedUploadRequest {
  uploadId: string;
  etag: string;                   // From S3/R2 response
}

interface CompletePresignedUploadResponse {
  fileId: string;
  storageUrl: string;
}
```

## Coltorapps Form Schema (Normalized)

```typescript
interface FormSchema {
  pages: Page[];
  settings: {
    isMultiPage: boolean;
    progressBar: boolean;
    saveProgress: boolean;
    analytics: boolean;
  };
}

interface Page {
  id: string;
  title: string;
  description?: string;
  fields: Field[];
}

interface Field {
  id: string;
  type: 'TEXT' | 'EMAIL' | 'NUMBER' | 'SELECT' | 'RADIO' | 'CHECKBOX' | 'TEXTAREA' | 'FILE' | 'DATE' | 'PHONE' | 'SIGNATURE' | 'RATING';
  label: string;
  required: boolean;
  placeholder?: string;
  defaultValue?: any;
  rules?: ValidationRule[];
  options?: { label: string; value: string }[]; // For select/radio/checkbox
  accept?: string[];             // For file uploads
  maxSize?: number;              // Bytes for file uploads
}

interface ValidationRule {
  type: 'REQUIRED' | 'EMAIL' | 'MIN_LENGTH' | 'MAX_LENGTH' | 'PATTERN' | 'CUSTOM';
  value?: any;
  message: string;
}
```

---

## Implementation Status Tracker

| Component | Agent | Status | Subtasks |
|-----------|-------|--------|----------|
| Prisma Schema | 01 | PENDING | Create models, migrations, indices |
| Form Builder (Coltorapps) | 02 | PENDING | Builder UI, autosave, publish |
| Page Designer (GrapesJS) | 03 | PENDING | Page layout, form slot, preview |
| Public Runtime | 04 | PENDING | Load form, submit, OTP flow |
| Presigned Files | 05 | PENDING | Init, upload, complete, storage |
| Submissions Admin | 06 | PENDING | List, detail, export CSV/JSON |
| Email + Webhooks | 07 | PENDING | Resend, templates, delivery engine |
| Drafts & Resume | 08 | PENDING | Save, load, token generation |

---

**Last Updated**: 2026-01-26
**Orchestrator**: Ready for agent coordination
