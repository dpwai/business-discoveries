# Form Preview Page - Admin Documentation

## Overview

The Form Preview Page is a comprehensive tool for administrators to test and validate forms before publishing. It provides multiple device viewports, responsive testing, theme switching, and a validation checklist.

**Route:** `/dpwai/[tenant_snake]/forms/[formId]/preview`

## Features

### 1. Responsive Device Preview

**Available Devices:**
- **Mobile:** iPhone 12 (375×812px)
- **Tablet:** iPad (768×1024px)
- **Desktop:** Standard Desktop (1024×768px)

**How it works:**
- Click device buttons in the toolbar to switch viewports
- Frame automatically resizes to device dimensions
- Each device preset includes realistic dimensions for testing responsive behavior
- Currently selected device is highlighted with blue background

### 2. Zoom Controls

**Range:** 50% - 200% (increments of 10%)

**Controls:**
- **Zoom Out Button:** Decreases by 10% (disabled at 50%)
- **Zoom Slider:** Drag to set any value between 50-200%
- **Zoom In Button:** Increases by 10% (disabled at 200%)

**Display:**
- Current zoom percentage shown in toolbar
- Frame dimensions updated in real-time
- Size displayed as: "Zoom: 100% | Tamanho: 375×812px"

**Use Cases:**
- Test form at different scales
- Verify legibility at extreme zoom levels
- Check responsive behavior at various sizes

### 3. Theme Switching

**Available Themes:**
- **Light Mode:** Clean, bright interface (default)
- **Dark Mode:** Dark gray (gray-900) background

**Behavior:**
- Click theme button to toggle between modes
- All components update instantly (sidebars, frame, header, footer)
- Theme preference passed to iframe via URL parameter: `?theme=light` or `?theme=dark`
- Form inside iframe respects theme parameter

**Use Cases:**
- Verify form styling in both light and dark modes
- Check text contrast and readability
- Test color-dependent UI elements

### 4. Preview Iframe

**Characteristics:**
- Displays public form via `/f/[publicId]` endpoint
- Sandboxed for security with appropriate permissions
- Responsive container that adjusts to device selection
- Centered in viewing area with padding
- Shows frame border and shadow for clarity

**Sandbox Attributes:**
```
allow-same-origin allow-scripts allow-forms
allow-popups allow-top-navigation-by-user-activation
```

**Frame Info Display:**
Shows:
- Device name and dimensions
- Current zoom level
- Actual pixel size of frame
- Theme setting
- Direct URL to form

### 5. Validation Checklist

**7 Critical Checklist Items:**

1. ✓ **Form renderiza sem erros**
   - Checks if form loads without JavaScript errors
   - No console errors visible

2. ✓ **Todos os campos visíveis**
   - All form fields display properly
   - No overlapping or hidden elements
   - Proper spacing and alignment

3. ✓ **Identity block visível**
   - Identity verification section displays
   - If enabled in form settings

4. ✓ **Buttons funcionam (em mobile)**
   - Submit, Cancel, Back buttons are clickable
   - Buttons are properly sized for mobile (tap-able area ≥ 44px)

5. ✓ **Mensagens de erro aparecem**
   - Validation errors display correctly
   - Error styling is visible
   - Error messages are clear

6. ✓ **Submit funciona**
   - Form submission processes
   - No errors on submit
   - API endpoint responding

7. ✓ **Success message aparece**
   - Confirmation message shows after successful submission
   - Message is visible and readable
   - Success state indicates completion

**Checklist Interaction:**
- Click any item to toggle completed state
- Completed items show green checkmark and strikethrough
- Uncompleted items show empty circle
- Progress bar updates in real-time
- Displays: "3 de 7 itens (43%)"

### 6. Notes & Observations

**Features:**
- Free-form textarea for documenting issues
- Placeholder text guides users on what to note
- Notes include: problems, suggestions, observations
- Automatic save to browser localStorage

**How to Use:**
1. Type observations while testing form
2. Click "Salvar Notas" to save
3. Success message confirms save ("Notas salvas com sucesso!")
4. Notes persist even after page refresh (same form)
5. Click "Limpar Tudo" to reset everything

**Storage:**
- Notes stored in localStorage with key: `form-preview-{formId}`
- Data includes: checklist state, notes, timestamp
- Each form has separate storage

### 7. Open in New Tab

**Functionality:**
- Opens form in full-screen new browser tab
- URL: `/f/[publicId]?theme={light|dark}`
- Theme parameter matches current preview setting
- Allows testing form without preview UI constraints

**Use Cases:**
- Test form in actual production view
- Share preview with team members
- Test form submission flow without toolbar
- Debug form rendering in isolated environment

## User Workflow

### Quick Test (5 minutes)

1. Navigate to form preview
2. Wait for form to load
3. Review in Mobile view
4. Review in Desktop view
5. Toggle Dark mode
6. Mark critical checklist items complete
7. Save notes if issues found

### Comprehensive Test (15-20 minutes)

1. Load preview page
2. **Mobile Testing:**
   - Set to Mobile device
   - Test at 100% zoom (normal)
   - Test at 150% zoom (accessibility)
   - Verify all buttons clickable
   - Test form submission
   - Mark mobile checklist items

3. **Tablet Testing:**
   - Switch to Tablet device
   - Review layout and spacing
   - Verify responsive behavior

4. **Desktop Testing:**
   - Switch to Desktop device
   - Test at multiple zoom levels (75%, 100%, 125%)
   - Verify full layout

5. **Theme Testing:**
   - Toggle dark mode
   - Verify all text readable
   - Check color contrast
   - Test both light and dark

6. **Validation:**
   - Complete checklist items as you test
   - Add detailed notes about any issues
   - Screenshot issues if possible
   - Save notes

7. **Final Check:**
   - Open in new tab for full-screen test
   - Verify complete form flow
   - Test success message
   - Return to preview, mark as ready

## Technical Details

### Components

#### PreviewFrame.tsx
- Renders responsive iframe
- Handles device sizing
- Displays frame dimensions
- Manages zoom scaling

#### PreviewToolbar.tsx
- Device selection buttons
- Zoom controls with slider
- Theme toggle
- Open in new tab button
- Displays public form ID

#### PreviewChecklist.tsx
- 7-item checklist with toggle
- Progress bar visualization
- Notes textarea
- Save/Clear buttons
- localStorage persistence

#### page.tsx (Main)
- Page layout and header
- Form data fetching from API
- State management
- Authentication check
- Error handling

### API Integration

**Endpoint:** `GET /api/agro/{tenant}/forms/{formId}`

**Headers:**
```javascript
{
  Authorization: `Bearer ${accessToken}`
}
```

**Response:**
```json
{
  "id": "form-uuid",
  "name": "Form Name",
  "publicId": "public-form-id",
  "status": "PUBLISHED|DRAFT",
  "currentVersion": 1,
  "currentSchemaJson": { ... }
}
```

### localStorage Schema

**Key:** `form-preview-{formId}`

**Value:**
```json
{
  "checklist": [
    { "id": "renders", "label": "...", "checked": true },
    // ... 7 items total
  ],
  "notes": "User-entered notes text",
  "savedAt": "2024-01-26T10:30:00.000Z"
}
```

### Responsive Breakpoints

**Page Layout:**
- **Desktop (≥1024px):** 3-column grid (1-2-1)
  - Left sidebar: 1/4 (Toolbar)
  - Center: 2/4 (Frame)
  - Right sidebar: 1/4 (Checklist)

- **Tablet/Mobile (<1024px):** Single column
  - Toolbar above frame
  - Frame full width
  - Checklist below frame

### Dark Mode Support

All components include dark mode variants:
```
- bg-gray-50 dark:bg-gray-900
- text-gray-900 dark:text-gray-100
- border-gray-200 dark:border-gray-700
```

## Testing Guidelines

### Before Publishing a Form

Use this checklist to validate:

1. **Functionality**
   - [ ] All form fields display and work
   - [ ] Validation messages appear correctly
   - [ ] Form can be submitted
   - [ ] Success confirmation displays
   - [ ] No console errors

2. **Mobile Responsiveness**
   - [ ] Form fits on 375px width
   - [ ] Buttons are 44px+ (tap-able)
   - [ ] Text is readable without zoom
   - [ ] No horizontal scroll needed
   - [ ] Touch interactions work

3. **Accessibility**
   - [ ] Text contrast is sufficient
   - [ ] Form works in dark mode
   - [ ] Labels are associated with fields
   - [ ] Error messages are clear
   - [ ] Navigation is logical

4. **Visual Quality**
   - [ ] Spacing and alignment correct
   - [ ] Colors look good in both themes
   - [ ] Icons are visible and clear
   - [ ] No overlap or cutting off
   - [ ] Professional appearance

5. **Cross-Browser**
   - [ ] Test in Chrome
   - [ ] Test in Safari
   - [ ] Test in Firefox
   - [ ] Test in Mobile Safari (iOS)
   - [ ] Test in Chrome Mobile

### Test Scenarios

**Scenario 1: New User on Mobile**
- Open form on iPhone 12 (375×812)
- Zoom to 120% (accessibility test)
- Verify all fields visible without scrolling
- Complete and submit form

**Scenario 2: Accessibility Testing**
- Use dark mode
- Set zoom to 150%
- Check text contrast
- Verify color indicators have text labels

**Scenario 3: Error State**
- Leave required field empty
- Try to submit
- Verify error message appears clearly
- Fix and resubmit successfully

**Scenario 4: Large Dataset**
- If form has many fields, scroll through
- Verify no elements are cut off
- Check performance (no lag)

## Keyboard Shortcuts (Future Enhancement)

*Planned for future implementation:*
- `D` - Toggle between device types
- `T` - Toggle theme
- `+` / `-` - Zoom in/out
- `R` - Reset zoom to 100%
- `E` - Open in new tab

## Troubleshooting

### Form not loading in preview
- **Issue:** Iframe shows blank or error
- **Solution:**
  1. Check form publicId is correct
  2. Verify form is published (status = PUBLISHED)
  3. Check `/f/[publicId]` endpoint is accessible
  4. Clear browser cache

### Zoom not working
- **Issue:** Zoom slider appears but doesn't change size
- **Solution:**
  1. Refresh page
  2. Check browser console for errors
  3. Verify device is selected
  4. Try different zoom level

### Notes not saving
- **Issue:** "Salvar Notas" doesn't work
- **Solution:**
  1. Check localStorage is enabled in browser
  2. Verify not in private/incognito mode
  3. Check localStorage isn't full (clear old data)
  4. Try different browser

### Theme toggle not working
- **Issue:** Dark mode button doesn't change appearance
- **Solution:**
  1. Refresh page
  2. Check CSS is loaded properly
  3. Check browser supports CSS variables
  4. Look for console errors

### Can't access preview page
- **Issue:** 404 or redirected to login
- **Solution:**
  1. Verify you're logged in
  2. Verify URL format: `/dpwai/[tenant]/forms/[formId]/preview`
  3. Check form exists and you have permission
  4. Check access token is valid

## Best Practices

1. **Test Early and Often**
   - Preview after making any field changes
   - Don't wait until form is "done"

2. **Use All Devices**
   - Always test mobile view (most users)
   - Test tablet for responsive gaps
   - Test desktop for large screen layout

3. **Test Both Themes**
   - Many users use dark mode
   - Verify contrast in both

4. **Check Mobile Specifically**
   - Mobile is priority (most traffic)
   - Test actual devices if possible
   - Use 44px+ button sizes

5. **Document Issues**
   - Use notes for every issue found
   - Be specific ("Button not visible at 150% zoom on mobile")
   - Include steps to reproduce

6. **Test Submission**
   - Always test full form submission
   - Check success message
   - Verify no errors in browser console

7. **Accessibility First**
   - Test with zoom (150%)
   - Test with dark mode
   - Verify error messages are clear
   - Check color contrast

## Performance Notes

- Preview page uses client-side rendering (CSR)
- Iframe loads form independently
- localStorage is fast and local
- No server round-trips for checklist/notes
- Frame dimensions calculated instantly

## Security Considerations

- **Authentication:** All requests require valid JWT token
- **Authorization:** User must have access to tenant and form
- **iframe Sandbox:** Restricted permissions prevent malicious scripts
- **localStorage:** Data stored locally, not sent to server
- **Public Form:** Form in iframe is publicly available (that's the point)

## Future Enhancements

Planned features:
- [ ] Screenshot tool to capture form state
- [ ] Side-by-side comparison of two device sizes
- [ ] Form validation report
- [ ] Response preview (show sample submission)
- [ ] Device rotation (portrait/landscape toggle)
- [ ] Performance metrics (load time, render time)
- [ ] Accessibility audit integration
- [ ] Browser compatibility checker
- [ ] Export test report as PDF
- [ ] Share preview link with team

## Support & Feedback

For issues or feature requests:
1. Document the issue in preview notes
2. Take screenshot if possible
3. Include browser and device information
4. Report in team/support channel

## Version History

**v1.0.0** (2026-01-26)
- Initial release
- 3 device presets (Mobile, Tablet, Desktop)
- Zoom controls (50-200%)
- Dark/Light theme toggle
- 7-item validation checklist
- Notes with localStorage persistence
- Open in new tab functionality
- Responsive layout (3-column desktop, 1-column mobile)

---

**Last Updated:** 2026-01-26
**Status:** Production Ready
**Maintained By:** Engineering Team
