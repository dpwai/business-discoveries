# 🚀 UNIVERSAL DPWAI PROMPT - Use for ANY Task

**Copy this entire prompt and use for ANY future Claude/Agent work on DPWAI**

---

## YOU ARE WORKING ON DPWAI AGRO

A **multi-tenant business automation platform** with:
- ✅ JWT-based authentication
- ✅ Multi-tenant data isolation
- ✅ Dark mode UI (slate-950)
- ✅ Portuguese (pt-BR) + English i18n
- ✅ Responsive design (mobile-first)
- ✅ PostgreSQL + Prisma ORM
- ✅ Next.js 16 + TypeScript

---

## CRITICAL RULES (ABSOLUTE - NO EXCEPTIONS)

### 1. NEXT.JS 16 ROUTE SIGNATURES
Every route handler with `[brackets]` MUST use Promise:

```typescript
// ❌ WRONG (DO NOT DO THIS)
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { id } = params;  // ❌ ERROR - params is a Promise
}

// ✅ RIGHT (ALWAYS DO THIS)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;  // ✅ CORRECT - await the Promise
}
```

**Affects All Files**: `/app/api/agro/[tenant]/` and any route with `[dynamic]` segments
**Check List**: 40+ files need this pattern

---

### 2. AUTHENTICATION VERIFICATION

```typescript
// ❌ WRONG - Don't extract token manually
const token = request.headers.get('Authorization')?.replace('Bearer ', '');
const decoded = await verifyAuth(token);

// ✅ RIGHT - Pass entire request to verifyAuth
const auth = await verifyAuth(request);

if (!auth.authenticated) {
  return NextResponse.json(
    createErrorResponse('auth.invalid_token', 401),
    { status: 401 }
  );
}

// Use the returned auth context
console.log(auth.userId, auth.tenantId, auth.email);
```

**Function Signature**:
```typescript
import { verifyAuth } from '@/lib/auth';

async function verifyAuth(
  request: NextRequest,
  expectedTenant?: string  // Optional tenant verification
): Promise<{
  authenticated: boolean;
  userId?: string;
  email?: string;
  tenantId?: string;
  token?: string;
}>
```

---

### 3. ERROR CODES - MUST BE DEFINED

Before using ANY error code in `createErrorResponse()`:

1. **Add to ErrorCode union** in `/lib/errors/normalizer.ts`:
```typescript
export type ErrorCode =
  | 'existing.codes...'
  | 'your.new_error_code';  // ✅ ADD HERE FIRST
```

2. **Add i18n mapping** in same file:
```typescript
export const ERROR_CODE_TO_I18N_KEY: Record<ErrorCode, string> = {
  // ... existing mappings ...
  'your.new_error_code': 'errors.your.new_error_code',  // ✅ AND HERE
};
```

3. **Then use it**:
```typescript
return NextResponse.json(
  createErrorResponse('your.new_error_code', 400),  // ✅ NOW YOU CAN USE IT
  { status: 400 }
);
```

**Common Codes Already Defined**:
- `auth.invalid_token`, `auth.forbidden`, `auth.missing_token`, `auth.no_access`
- `error.not_found`, `error.server_error`, `error.expired`
- `validation.field_required`, `validation.passwords_dont_match`
- `user.email_already_exists`
- `password.reset_failed`, `password.reset_token_invalid`

---

### 4. MULTI-TENANT ISOLATION

Every query that touches user data MUST filter by tenantId:

```typescript
// ❌ WRONG - Gets data from other tenants!
const users = await prisma.user.findMany({
  where: { /* no tenantId filter */ }
});

// ✅ RIGHT - Only gets this tenant's data
const users = await prisma.membership.findMany({
  where: {
    tenantId: auth.tenantId,  // ✅ FILTER BY TENANT
  },
});

// For nested relations:
const dashboards = await prisma.dashboard.findMany({
  where: {
    tenantId: auth.tenantId,  // ✅ ALWAYS FILTER
    archived: false,
  },
});
```

**Database Rules**:
- Every table with business data has `tenantId` field
- All WHERE clauses MUST include `tenantId: auth.tenantId`
- Foreign keys are composite: `[userId, tenantId]` for user data
- Never allow cross-tenant data access

---

### 5. INTERNATIONALIZATION (i18n)

**NEVER hardcode text in Portuguese or English:**

```typescript
// ❌ WRONG
const message = "Usuário não encontrado";  // Hardcoded Portuguese
const label = "Dashboard";                  // Hardcoded English

// ✅ RIGHT - Use i18n everywhere
const message = t('errors.user.not_found');
const label = t('dashboard.title');
```

**Where text appears**:
- API error messages → Use `createErrorResponse('code')`
- UI labels → Use `t()` hook from i18n
- Form placeholders → Use i18n
- Validation messages → Use error codes with i18n

**All Labels Need**:
- Portuguese translation (pt-BR)
- English translation fallback
- Entry in `/lib/i18n/translations.ts`

---

### 6. DATABASE SCHEMA RULES

**Multi-Tenant Model**:
```prisma
model Dashboard {
  id            String   @id @default(uuid())
  tenantId      String   // ✅ ALWAYS HAVE THIS
  name          String
  description   String?
  embedUrl      String?  // ✅ Can be optional (Json?)
  archived      Boolean  @default(false)
  createdById   String

  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  tenant        Tenant   @relation(fields: [tenantId], references: [id], onDelete: Cascade)

  @@index([tenantId])  // ✅ Index for performance
}

model Membership {
  userId    String
  tenantId  String
  role      String     // OWNER, ADMIN, USER

  user      User       @relation(fields: [userId], references: [id])
  tenant    Tenant     @relation(fields: [tenantId], references: [id])

  @@id([userId, tenantId])  // ✅ Composite key for users
}
```

**Field Rules**:
- `Int?` or `String?` for optional
- `Json?` for flexible data (NOT `null`, use `undefined`)
- Always add `createdAt` and `updatedAt` timestamps
- Always `@@index([tenantId])` on large tables
- Timestamps: `@default(now())` and `@updatedAt`

---

### 7. PRISMA JSON FIELDS

When you have a `Json?` field:

```typescript
// ❌ WRONG - Can't set null on Json fields
await prisma.delivery.update({
  where: { id: deliveryId },
  data: {
    responseBody: null,  // ❌ Type error
  },
});

// ✅ RIGHT - Use undefined instead
await prisma.delivery.update({
  where: { id: deliveryId },
  data: {
    responseBody: undefined,  // ✅ Correct way to clear
  },
});
```

---

## STANDARD API RESPONSE FORMAT

```typescript
// Success Response
return NextResponse.json({
  data: { /* actual data */ },
  statusCode: 200,
});

// Error Response (use createErrorResponse)
return NextResponse.json(
  createErrorResponse('error.code', 400),
  { status: 400 }
);

// Error Response includes:
// {
//   "error": "Error message",
//   "code": "error.code",
//   "i18nKey": "errors.error.code",
//   "statusCode": 400
// }
```

---

## COMPLETE ROUTE HANDLER TEMPLATE

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { verifyAuth } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { createErrorResponse } from '@/lib/errors/normalizer';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    // 1. Verify authentication
    const auth = await verifyAuth(request);
    if (!auth.authenticated) {
      return NextResponse.json(
        createErrorResponse('auth.invalid_token', 401),
        { status: 401 }
      );
    }

    // 2. Await and extract params
    const { tenant: tenantSlug, id } = await params;

    // 3. Verify tenant access
    const tenantRecord = await prisma.tenant.findUnique({
      where: { snake: tenantSlug },
    });

    if (!tenantRecord || tenantRecord.id !== auth.tenantId) {
      return NextResponse.json(
        createErrorResponse('auth.forbidden', 403),
        { status: 403 }
      );
    }

    // 4. Validate request body
    const body = await request.json();
    if (!body.name) {
      return NextResponse.json(
        createErrorResponse('validation.field_required', 400),
        { status: 400 }
      );
    }

    // 5. Check resource ownership
    const resource = await prisma.dashboard.findFirst({
      where: {
        id,
        tenantId: auth.tenantId,  // ✅ Filter by tenant
      },
    });

    if (!resource) {
      return NextResponse.json(
        createErrorResponse('error.not_found', 404),
        { status: 404 }
      );
    }

    // 6. Update/process
    const updated = await prisma.dashboard.update({
      where: { id },
      data: { name: body.name },
    });

    // 7. Return success
    return NextResponse.json({
      data: updated,
      statusCode: 200,
    });

  } catch (error) {
    console.error('[API] Error:', error);
    return NextResponse.json(
      createErrorResponse('error.server_error', 500),
      { status: 500 }
    );
  }
}
```

---

## TESTING CHECKLIST

Before every commit:

```bash
# 1. Build must pass
npm run build                    # ✅ Should have 0 errors

# 2. Type checking
npm run build 2>&1 | grep error  # ✅ Should be empty

# 3. (Optional) Run tests
npm run test:e2e                 # ✅ Tests should pass

# 4. Local testing
npm run dev                      # Start dev server
# Manual test the feature:
# - Verify auth works
# - Verify data filtering by tenant
# - Verify error messages show
# - Verify mobile responsive
```

---

## COMMON MISTAKES TO AVOID

| Mistake | Fix |
|---------|-----|
| `{ params }` without Promise | Wrap in `Promise<{...}>` |
| `verifyAuth(token)` | Pass entire `request` |
| `verifyAuth(req, tenant)` | Only takes 1 param: `request` |
| Missing tenantId in WHERE | Add `tenantId: auth.tenantId` |
| Hardcoded "Usuário" text | Use `t('key')` or error code |
| `null` on Json field | Use `undefined` instead |
| No error code definition | Add to `ErrorCode` type first |
| No auth check on API | Add `verifyAuth` before processing |
| Accessing `params` directly | Always `await params` first |
| Mixing English/Portuguese | Use i18n consistently |

---

## FILE STRUCTURE

```
/app
  /api
    /auth/                  # Authentication routes
    /dashboards/            # Dashboard CRUD
    /users/                 # User management
    /agro/[tenant]/         # All tenant-specific APIs
      /account/             # User account
      /audit-logs/          # Audit trail
      /forms/               # Forms (if implemented)

/lib
  /auth/
    index.ts                # verifyAuth() function
  /errors/
    normalizer.ts           # ErrorCode + i18n mapping
  /i18n/
    translations.ts         # All i18n keys (EN + PT)
  /prisma/
    (auto-generated)

/prisma
  schema.prisma             # Database models
  migrations/               # Migration files
```

---

## QUICK REFERENCE: ERROR CODES

**Already Defined** - Safe to use:
- `auth.invalid_token`, `auth.forbidden`, `auth.missing_token`
- `auth.no_access`, `auth.user_not_found`, `auth.invalid_credentials`
- `error.not_found`, `error.server_error`, `error.expired`
- `validation.field_required`, `validation.passwords_dont_match`
- `user.email_already_exists`
- `password.reset_failed`, `password.reset_token_invalid`

**If you need a new code**:
1. Open `/lib/errors/normalizer.ts`
2. Add to `ErrorCode` union
3. Add to `ERROR_CODE_TO_I18N_KEY` mapping
4. Then use in your code

---

## BEFORE YOU START CODING

1. ✅ Read `/DPWAI_HARDENING_KNOWLEDGE_BASE.md`
2. ✅ Copy this prompt into your implementation
3. ✅ Check all 7 critical rules above
4. ✅ Review the route handler template
5. ✅ Look up error codes you need
6. ✅ Plan database schema with tenantId
7. ✅ Then write code

---

## FOR QUESTIONS

**See Full Reference**:
→ `/DPWAI_HARDENING_KNOWLEDGE_BASE.md`

**For Security Issues**:
→ `/dpwaiagro/docs/SECURITY-AUDIT-REPORT.md`

**For Testing**:
→ `/dpwaiagro/TESTING-README.md`

**For Mobile**:
→ `/dpwaiagro/MOBILE_QA_RESULTS.md`

---

**Status**: ✅ **READY TO USE**
**Updated**: Jan 26, 2026
**Version**: 1.0 - Complete

**USE THIS PROMPT FOR ANY FUTURE WORK ON DPWAI**
