'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
export default function Home() {
  const router = useRouter();
  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      const tenant = localStorage.getItem('tenant');
      if (tenant) {
        try {
          const tenantData = JSON.parse(tenant);
          router.push(`/dpwai/${tenantData.snake}/welcome`);
        } catch (e) {
          router.push('/dpwai/login');
        }
      } else {
        router.push('/dpwai/login');
      }
    } else {
      router.push('/dpwai/login');
    }
  }, [router]);
  return null;
}
