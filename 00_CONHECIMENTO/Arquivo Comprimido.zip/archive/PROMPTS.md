# 🎯 QUICK PROMPTS - COPY & PASTE TO CLAUDE

## PROMPT 1: Login UX + Header Fixes (URGENTE)

```
YOU ARE WORKING ON DPI – BUSINESS AUTOMATION PLATFORM.
TASK: Fix login UX, remove English text, fix header behavior NOW.

CONTEXT:
* Default language: Portuguese (pt-BR)
* Theme: dark mode
* Login is FIRST screen, NO EXCEPTIONS
* Commit small, objective. No new features.

DO THIS:

1. LOGIN SCREEN (100% PORTUGUESE)
   Replace ALL English strings:
   - "Email or username" → "E-mail ou usuário"
   - "Password" → "Senha"
   - "Forgot your password?" → "Esqueci minha senha"
   - "Sign in" → "Entrar"
   - "Signing in..." → "Entrando..."
   - ALL validations, errors, placeholders → PORTUGUESE

2. REMOVE HEADER FROM LOGIN
   - NO menu sanduíche on /login
   - NO avatar on /login
   - NO navigation on /login
   - Login = clean, centered, focused

   HOW:
   if (pathname === '/login') return <LoginPageWithoutHeader />
   else return <LoginPageWithHeader />

3. FIX LOGIN REDIRECT FLOW
   - /login → authenticate → /welcome (CLEAN)
   - No header flickering during auth
   - No menu appearing before login completes

4. HEADER AFTER LOGIN (CORRECT PATTERN)
   Layout (left to right):
   ☰ Menu (LEFT) → Username → (space) → Avatar (RIGHT)

5. VALIDATION CHECKLIST
   [ ] All login text = Portuguese
   [ ] No English anywhere (idle, loading, error)
   [ ] Login has NO header
   [ ] No flickering sanduíche
   [ ] After login: header appears
   [ ] Only ONE menu sanduíche
   [ ] Username visible
   [ ] Avatar top-right corner
   [ ] Clean redirect to /welcome
   [ ] Build passes
   [ ] Tests pass (if exist)

STOP CONDITION: All items ✓, build passes, npm run dev shows clean login flow.
```

---

## PROMPT 2: Global String Audit (NEXT)

```
TASK: Find and document ALL hardcoded English strings.

RUN THIS:
grep -r "Email\|Password\|Loading\|Error\|Success\|Signin\|Logout\|Welcome" \
  app --include="*.tsx" --include="*.ts" | grep -v node_modules | grep -v ".next"

DOCUMENT FOR EACH:
- File: app/...page.tsx
- Line: 42
- Current: "Loading..."
- Portuguese: "Carregando..."

OUTPUT: Create STRINGS-AUDIT.csv with 3 columns:
File | Line | English | Portuguese

Use /knowledge/01-setup-local/I18N-SETUP.md as reference for translation keys.
```

---

## PROMPT 3: Responsive Mobile Header (FOLLOW-UP)

```
TASK: Make header responsive for mobile.

REQUIREMENTS:
- Mobile (< 640px): Sanduíche LEFT, username hidden, avatar RIGHT
- Tablet (640px-1024px): Full header visible
- Desktop (> 1024px): Full header with spacing

TEST ON:
- iPhone 12 (390px)
- iPad (768px)
- Desktop (1920px)

COMPONENT: app/components/layout/Header.tsx (or wherever header lives)

STRUCTURE:
<header className="flex justify-between items-center p-4">
  {/* LEFT: Menu sanduíche */}
  <button className="md:hidden">☰</button>

  {/* CENTER: Username (hidden on mobile) */}
  <span className="hidden md:inline">{userName}</span>

  {/* RIGHT: Avatar */}
  <img className="w-8 h-8 rounded-full" />
</header>
```

---

## PROMPT 4: Remove Temporary Files (CLEANUP)

```
TASK: Remove temporary/backup files from root.

FILES TO DELETE:
- app/layout-new.tsx
- app/layout-updated.tsx
- app/page-final.tsx
- middleware-new.ts
- middleware-fixed.ts
- middleware-auth.ts

RUN:
rm app/layout-new.tsx app/layout-updated.tsx app/page-final.tsx
rm middleware-new.ts middleware-fixed.ts middleware-auth.ts
git add -A && git commit -m "chore: remove temporary backup files"
```

---

## HOW TO USE

1. Copy one prompt entirely
2. Paste into Claude.com or Claude Code
3. Wait for completion
4. Validate against checklist
5. Commit with clear message
6. Move to next prompt

**ORDER:**
1. PROMPT 1 (Login + Header) ← DO THIS FIRST
2. PROMPT 4 (Cleanup) ← Quick win
3. PROMPT 2 (String Audit) ← Documentation
4. PROMPT 3 (Responsive) ← Polish

---

**Last Updated:** 2026-01-25
**Status:** ✅ Ready to copy & paste
