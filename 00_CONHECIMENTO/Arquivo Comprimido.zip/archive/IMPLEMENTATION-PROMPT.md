# 🚀 COPY & PASTE THIS PROMPT TO CLAUDE

---

```
YOU ARE A SENIOR FULL-STACK ENGINEER. IMPLEMENT EMAIL + OTP SYSTEM FOR DPWAI (MULTI-TENANT).
A DETAILED PLAN HAS BEEN CREATED AT: knowledge/09-otp-email-system/OTP-EMAIL-SYSTEM-PLAN.md

YOUR TASK: IMPLEMENT COMMIT 1 - DATABASE SCHEMA

START WITH THE DATABASE LAYER. DO NOT SKIP THIS.

WHAT TO DO:

1. Read the plan (it's comprehensive, don't wing it)
2. Create Prisma migration for:
   - Enhanced OtpCode model (add fields: tenantId, userId, codeHash, verifiedAt, verificationToken, metadata)
   - New EmailVerification model
   - New AuditLog model (enhanced)
   - Update ShareLinkSession (add authMethod, otpVerifiedAt fields)
   - Create OtpType enum: EMAIL_VERIFICATION, PHONE_VERIFICATION, GUEST_FORM_ACCESS, ACCOUNT_RECOVERY, SENSITIVE_ACTION

3. Run migration: npx prisma migrate dev --name add_otp_email_system

4. Verify database changes with: npx prisma db push

5. Update schema.prisma to match plan specifications exactly

CONSTRAINTS:
- Follow existing project patterns (Prisma, TypeScript)
- Portuguese field names where applicable (created_at → createdAt per project convention)
- Use @index for critical queries
- Add @relation annotations for foreign keys
- No breaking changes to existing tables (only ADD fields, never DELETE/RENAME)

DELIVERABLE:
- Prisma migration file in prisma/migrations/
- Updated schema.prisma
- No TypeScript errors: npm run build succeeds
- New models compile without errors

NEXT: After this commit, we implement the OTP utilities layer.

---

GIT COMMIT MESSAGE:
db: add OTP + email verification tables (Commit 1/10)

Implement database layer for email + OTP system:
- Enhanced OtpCode model with secure fields (codeHash, metadata, tenantId, userId)
- New EmailVerification model for email confirmation workflow
- New AuditLog model for security event tracking
- Updated ShareLinkSession for OTP-based guest access
- Added OtpType enum for type-safe OTP purposes
- All tables include proper indexes for query performance
- Relationships established for multi-tenant isolation

Migration: ✅ Created and deployed
Database: ✅ Ready for OTP utilities layer

Co-Authored-By: Claude Haiku 4.5 <noreply@anthropic.com>
```

---

## HOW TO USE

1. Copy the prompt above (everything inside the ``` blocks)
2. Paste into Claude.com or Claude Code
3. Wait for completion
4. Verify database works: `npm run build` passes
5. Come back here for next prompt

---

## FULL IMPLEMENTATION SEQUENCE

| Commit | Task | Depends On | Status |
|--------|------|-----------|--------|
| 1 | Database schema | - | ← **START HERE** |
| 2 | OTP utilities | Commit 1 | Waiting |
| 3 | API endpoints | Commit 2 | Waiting |
| 4 | Email verification API | Commit 3 | Waiting |
| 5 | Frontend components | Commit 4 | Waiting |
| 6 | Share Link OTP | Commit 5 | Waiting |
| 7 | i18n + error codes | Commit 6 | Waiting |
| 8 | Testing suite | All above | Waiting |
| 9 | Security audit | Commit 8 | Waiting |
| 10 | Performance optimization | Commit 9 | Waiting |

---

**Plan:** ✅ Complete at `/knowledge/09-otp-email-system/OTP-EMAIL-SYSTEM-PLAN.md`

**Next prompt:** Will be generated after Commit 1 succeeds
