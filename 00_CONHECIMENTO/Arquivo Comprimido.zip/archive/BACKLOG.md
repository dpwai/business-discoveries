# 🎯 DPWAI Backlog - Prioritized Issues

**Last Updated:** 2026-01-25
**Total Issues:** 12 (P0: 5, P1: 5, P2: 2)

---

## 🔴 P0 - Bloqueadores (Corrigir Agora)

### P0-1: Idioma Misturado (EN/PT) Após Selecionar Propriedade

**Impacto:** Alto - Confunde usuário final, experience inconsistente

**Descrição:**
Após login e seleção de propriedade, algumas telas/componentes ficam em inglês enquanto outras em português. Settings, My Account, menus, botões e labels ficam inconsistentes.

**Root Cause:**
- Strings hardcoded em componentes React (não passam por LanguageContext)
- i18n não está configurado em todas as rotas
- Property selection não recarrega translations

**Passos de Reprodução:**
1. Login com `admin@dpwai.com` / `Admin@123456`
2. Selecione propriedade "Fazenda Demo"
3. Navegue: Configurações → Minha Conta → Settings (menu)
4. Observar: Labels em EN enquanto página principal em PT

**Correção Necessária:**
- [ ] Auditar todos componentes em `/app/dpwai/[tenant_snake]/` e remover strings hardcoded
- [ ] Garantir que TODAS as strings vêm de `translations` ou `useLanguage()`
- [ ] Testar pt-BR como default em todas as rotas
- [ ] Verificar se mudança de propriedade recarrega translations

**Critério de Aceite:**
- ✅ 100% das telas após login em pt-BR
- ✅ Todos os menus, headers, botões, placeholders em português
- ✅ Sem strings em inglês visíveis no app
- ✅ Empty states em português
- ✅ Tooltips e alt-text em português

**Arquivo para revisar:**
- `lib/i18n/translations.ts` - adicionar strings faltantes
- `lib/i18n/useLanguage.ts` - garantir hook está sendo usado
- `app/dpwai/[tenant_snake]/layout.tsx` - verificar LanguageProvider

**Estimativa:** 2-3h
**Responsável:** Frontend

---

### P0-2: Dois Menus Sanduíche + Sanduíche Não Abre Menu

**Impacto:** Alto - Confusão visual, menu não funciona

**Descrição:**
Header tem 2 botões sanduíche (hamburger) ou o botão existe mas não abre/fecha o drawer do menu lateral corretamente.

**Root Cause:**
- Possivelmente 2 instâncias do componente Header
- onClick handler não está ligado ao estado correto do sidebar
- Layout duplicado ou condicional quebrado

**Passos de Reprodução:**
1. Login e entrar em `/dpwai/fazenda-demo/welcome` ou qualquer rota
2. Observar header (mobile + desktop)
3. Clicar no sanduíche
4. Comportamento esperado: drawer abre/fecha à esquerda
5. Comportamento real: nada acontece ou comportamento inconsistente

**Correção Necessária:**
- [ ] Verificar `/app/dpwai/[tenant_snake]/layout.tsx` - contar quantas instâncias de `Menu` button
- [ ] Garantir um único botão sanduíche no header
- [ ] Ligar `onClick` ao estado `isDrawerOpen` do layout
- [ ] Remover duplicatas ou código condicional quebrado

**Critério de Aceite:**
- ✅ Existe apenas 1 botão sanduíche no header
- ✅ Clicando abre/fecha menu lateral sempre
- ✅ Sem duplicação visual ou de funcionalidade
- ✅ Funciona em mobile e desktop

**Arquivo para revisar:**
- `app/dpwai/[tenant_snake]/layout.tsx` - seção header

**Estimativa:** 1h
**Responsável:** Frontend

---

### P0-3: "Propriedade Atual" No Lugar Errado

**Impacto:** Alto - Perda de contexto, confunde qual farm está ativo

**Descrição:**
O nome da propriedade selecionada (ex: "Fazenda Demo") não está visível no header ou está em posição confusa. Usuário não sabe qual propriedade está ativa.

**Root Cause:**
- PropertyContext implementado mas header não mostra corretamente
- Layout não renderiza propriedade selecionada
- Posicionamento no header não é proeminente

**Passos de Reprodução:**
1. Login
2. Observe o header
3. Não consigo identificar claramente qual propriedade está ativa
4. Esperado: "Fazenda Demo" em destaque no topo do header

**Correção Necessária:**
- [ ] Renderizar `selectedProperty.name` no header (PropertyContext)
- [ ] Posicionar ao lado do ícone/sanduíche
- [ ] Fazer loading skeleton enquanto carrega
- [ ] Testar em todas as páginas (forms, dashboards, users, etc)

**Critério de Aceite:**
- ✅ Propriedade selecionada visível no header de TODAS as páginas
- ✅ Posição: próximo ao sanduíche ou logo após
- ✅ Tamanho/fonte: destaca-se (não é um label pequeno perdido)
- ✅ Persiste ao navegar entre páginas
- ✅ Atualiza em tempo real ao trocar propriedade

**Arquivo para revisar:**
- `app/dpwai/[tenant_snake]/layout.tsx` - section "Property + User greeting"

**Estimativa:** 1-2h
**Responsável:** Frontend

---

### P0-4: Lista de Propriedades Não Mostra "Demo Farm"

**Impacto:** Alto - Usuário não consegue trocar propriedade

**Descrição:**
O selector/dropdown de propriedades não exibe a lista completa. "Demo Farm" ou outras propriedades não aparecem, mesmo que o usuário tenha permissão.

**Root Cause:**
- TenantSwitcher não está carregando todas as propriedades
- Filtro incorreto por user/role
- API não retorna lista completa

**Passos de Reprodução:**
1. Login
2. Procure por dropdown/selector de propriedade
3. Tente expandir a lista
4. Observar: "Demo Farm" não aparece ou lista está vazia

**Correção Necessária:**
- [ ] Revisar `/api/auth/me/tenants` - garantir que retorna TODAS as propriedades do user
- [ ] Verificar TenantSwitcher - está carregando corretamente?
- [ ] Implementar separação clara:
  - Current property (selecionada agora)
  - All available properties (lista completa)
- [ ] Adicionar fallback se lista vazia

**Critério de Aceite:**
- ✅ "Demo Farm" aparece na lista de propriedades disponíveis
- ✅ Dropdown mostra TODAS as propriedades que user tem acesso
- ✅ Seleção de nova propriedade funciona sem erro
- ✅ Após trocar propriedade: dados/menus/embeds mudam (sem bug)
- ✅ Sem duplicatas na lista

**Arquivo para revisar:**
- `app/dpwai/[tenant_snake]/tenant-switcher.tsx`
- `app/api/auth/me/tenants` (se existe) ou `app/api/auth/switch-tenant`

**Estimativa:** 2-3h
**Responsável:** Frontend + Backend

---

### P0-5: Painéis: Looker Não Embeda Na Página, Mas "Open Report" Abre

**Impacto:** Alto - Funcionalidade principal não renderiza

**Descrição:**
Na página de Painéis (Dashboards), o embed do Looker fica branco ou não renderiza. Porém, clicando em "Open Report" abre o dashboard em nova aba.

**Root Cause:**
- URL de embed diferente da URL de viewing
- Iframe está sendo renderizado mas com URL errada
- CSP/X-Frame-Options bloqueando embed
- Estado de loading/erro não está correto

**Passos de Reprodução:**
1. Login e vá para `/dpwai/fazenda-demo/dashboards`
2. Procure pelo embed do Looker
3. Observar: tela em branco ou "Open Report" link visível mas iframe vazio
4. Clicar em "Open Report" → abre na nova aba (funciona)

**Correção Necessária:**
- [ ] Verificar se `LookerEmbed` está recebendo `embedUrl` correto
- [ ] Usar `/embed/reporting/...` e NÃO `/reporting/...`
- [ ] Testar se relatório tem "Enable embedding" ligado no Looker Studio
- [ ] Implementar fallback visual se embed falhar
- [ ] Checar CSP headers - permitir `lookerstudio.google.com`

**Critério de Aceite:**
- ✅ Embed renderiza no container de "Painéis"
- ✅ Dashboard visível na página (não branco)
- ✅ Sem depender de "Open Report" para ver conteúdo
- ✅ Se falhar (CSP), fallback mostra com botão "Open Report"
- ✅ Mobile responsive (não cortado)

**Arquivo para revisar:**
- `components/LookerEmbed.tsx`
- `app/dpwai/[tenant_snake]/dashboards/page.tsx` - onde embed é renderizado
- `next.config.ts` - verificar headers CSP

**Estimativa:** 2-3h
**Responsável:** Frontend + DevOps

---

## 🟡 P1 - Muito Importante (UX e Clareza)

### P1-1: Chat: Menu Recolhido Com Lista de Chats

**Impacto:** Médio - Chat meio incompleto sem sidebar

**Descrição:**
Ralph Chat não tem sidebar com lista de conversas. Precisa adicionar drawer colapsível com:
- Lista de chats
- Search de chats
- Botão "New Chat"
- Opções: rename, delete/archive

**Correção Necessária:**
- [ ] Criar componente ChatListDrawer
- [ ] Adicionar ao layout da página Ralph Chat
- [ ] State: `isDrawerOpen` (default closed)
- [ ] Expandir/collapse ao clicar ícone
- [ ] Listar chats com `GET /api/ralph/chats`
- [ ] Implementar CRUD (create, delete, rename)

**Critério de Aceite:**
- ✅ Drawer recolhido por default
- ✅ Expandir mostra lista de chats
- ✅ Search funciona
- ✅ "New Chat" cria conversa nova
- ✅ Rename/delete funcionam com confirmação
- ✅ Clique em chat muda conteúdo à direita

**Estimativa:** 4-5h
**Responsável:** Frontend

---

### P1-2: Ícones do Menu Esquerdo Muito Pequenos No Web

**Impacto:** Médio - Usabilidade ruim no desktop

**Descrição:**
Sidebar icons (Home, Dashboards, Forms, etc) ficam pequenos demais para clicar confortavelmente no desktop.

**Correção Necessária:**
- [ ] Aumentar tamanho de ícones em desktop (24px → 28-32px)
- [ ] Aumentar hit-area (min-height 44px)
- [ ] Ajustar padding/spacing por breakpoint
- [ ] Testar em diferentes resoluções

**Critério de Aceite:**
- ✅ Ícones legíveis em desktop/tablet/mobile
- ✅ Hit-area mínima 44x44px
- ✅ Sem cortes ou overflow
- ✅ Hover effects visíveis

**Estimativa:** 1-2h
**Responsável:** Frontend

---

### P1-3: Forms: "Constraint" É Termo Errado

**Impacto:** Médio - Usuário confuso com jargão técnico

**Descrição:**
Na tela de Forms Builder, o termo "constraint" não faz sentido para usuário final. Deveria ser "Regras" ou "Validações" com UI clara.

**Correção Necessária:**
- [ ] Renomear "constraint" → "Regra de Validação" ou "Validação"
- [ ] Implementar UI com opções claras:
  - Obrigatório (required)
  - Mínimo/Máximo (min/max)
  - Regex (pattern)
  - Lista de valores permitidos (enum)
  - Dependência de campo (conditional)
- [ ] Adicionar tooltips explicativos
- [ ] Traduzir para pt-BR

**Critério de Aceite:**
- ✅ Nenhum termo "constraint" visível ao usuário
- ✅ UI mostra claramente qual tipo de validação
- ✅ Usuário consegue configurar sem documentação
- ✅ Todas as labels em português

**Estimativa:** 3-4h
**Responsável:** Frontend + UX

---

### P1-4: Usuários: Botão Ativar/Desativar Confuso

**Impacto:** Médio - Ação crítica sem feedback claro

**Descrição:**
Botão de ativar/desativar usuário usa ícone ambíguo (ex: X ou check) sem estado visual claro. Usuário não sabe se usuário está ativo ou não.

**Correção Necessária:**
- [ ] Substituir ícone por switch ou pill status
- [ ] Mostrar claramente: "Ativo" (verde) vs "Inativo" (cinza)
- [ ] Adicionar tooltip ao hover
- [ ] Dar feedback ao clicar (toast/modal confirmação)

**Critério de Aceite:**
- ✅ Estado claro em 1 segundo (ativo/inativo)
- ✅ Mudança de estado com confirmação
- ✅ Toast confirma ação ("Usuário desativado")
- ✅ Visual consistente com tema dark

**Estimativa:** 2h
**Responsável:** Frontend

---

### P1-5: Usuários: Editar Deveria Permitir Mudar Role

**Impacto:** Médio - Admin não consegue mudar permissões

**Descrição:**
Ao editar usuário, não há campo para mudar role/permissões (Admin, Proprietário, Usuário). Só é possível mudar nome/email.

**Correção Necessária:**
- [ ] Adicionar campo "Role" no modal de edição
- [ ] Opções: Admin, Proprietário, Usuário
- [ ] Salvar com `PUT /api/users/{id}` incluindo role
- [ ] Dar feedback (toast)
- [ ] Validar: user não pode remover a si mesmo como admin

**Critério de Aceite:**
- ✅ Campo Role visível no modal de edição
- ✅ Mudar role + salvar funciona
- ✅ Toast confirma ("Role atualizado")
- ✅ Permissões refletem na hora (se user já logado)
- ✅ Validação: admin não pode remover próprio acesso

**Estimativa:** 2-3h
**Responsável:** Frontend + Backend

---

## 🟢 P2 - Polimento e Consistência

### P2-1: Minha Conta: Tema Claro/Escuro Não Funciona + Labels em Inglês

**Impacto:** Baixo - Preferência de usuário não persiste

**Descrição:**
Toggle de tema claro/escuro em "Minha Conta" não funciona. Além disso, labels estão em inglês.

**Correção Necessária:**
- [ ] Implementar persistência de tema em localStorage
- [ ] Aplicar tema em TODAS as rotas (não só uma)
- [ ] Traduzir labels para português
- [ ] Testar que tema persiste no reload

**Critério de Aceite:**
- ✅ Toggle tema funciona
- ✅ Tema persiste no reload
- ✅ Aplicado globalmente (todas as páginas)
- ✅ Labels em português
- ✅ Layout não quebra com mudança

**Estimativa:** 2h
**Responsável:** Frontend

---

### P2-2: Configurações/Organização: Nomenclatura Confusa

**Impacto:** Baixo - Texto confuso em página admin

**Descrição:**
Página de Configurações/Organization mostra "Organization ID" e "Organization Display Name" em inglês e sem contexto. Usuário não entende a diferença.

**Correção Necessária:**
- [ ] Renomear:
  - "Organization ID" → "ID da Organização (hash)" - read-only + copy button
  - "Organization Display Name" → "Nome da Organização" - editável
- [ ] Mover "trocar organização" para lugar óbvio
- [ ] Traduzir para português
- [ ] Adicionar ajuda (ícone ? com tooltip)

**Critério de Aceite:**
- ✅ ID da Org: read-only com copy button
- ✅ Nome da Org: editável e persiste
- ✅ Todos os labels em português
- ✅ Usuário entende sem documentação
- ✅ Mudança de nome reflete na hora

**Estimativa:** 1-2h
**Responsável:** Frontend + UX

---

## 📊 Resumo

| Prioridade | Qtd | Tempo Est. |
|-----------|-----|-----------|
| P0 (Crítico) | 5 | 8-14h |
| P1 (Importante) | 5 | 13-17h |
| P2 (Polimento) | 2 | 3-4h |
| **TOTAL** | **12** | **24-35h** |

---

## 🚀 Recomendação de Sprint

**Fase 1 (AGORA - P0):** 1-2 sprints
- P0-1 (Idioma)
- P0-2 (Menu Sanduíche)
- P0-3 (Propriedade no Header)
- P0-4 (Lista Propriedades)
- P0-5 (Looker Embed)

**Fase 2 (Próximo Sprint - P1):**
- P1-1 (Chat Sidebar)
- P1-2 (Menu Icons)
- P1-3 (Forms Constraints)
- P1-4 (User Status)
- P1-5 (User Role Edit)

**Fase 3 (Refinamento - P2):**
- P2-1 (Theme Toggle)
- P2-2 (Organization Settings)

---

**Last Updated:** 2026-01-25
**Format:** GitHub Issues compatible (copy/paste title + descrição + aceite)
