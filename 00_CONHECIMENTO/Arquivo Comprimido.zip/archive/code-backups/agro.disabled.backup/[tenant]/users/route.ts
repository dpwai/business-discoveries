import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcrypt';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

type RequestParams = { params: Promise<{ tenant: string }> };

function mapMembershipUser(membership: any) {
  const user = membership.user;
  return {
    id: user.id,
    email: user.email,
    username: user.username,
    firstName: user.firstName,
    lastName: user.lastName,
    phone: user.phone,
    status: user.status,
    isAdmin: membership.isAdmin,
    isOwner: membership.isOwner,
    createdAt: user.createdAt,
  };
}

async function resolveTenantAndActor(authUserId: string, tenantSnake: string) {
  const tenant = await prisma.tenant.findUnique({ where: { snake: tenantSnake } });
  if (!tenant) return { error: 'Tenant not found' as const };

  const actorMembership = await prisma.membership.findUnique({
    where: {
      userId_tenantId: {
        userId: authUserId,
        tenantId: tenant.id,
      },
    },
  });

  if (!actorMembership) return { error: 'Sem acesso a este tenant' as const };

  if (!actorMembership.isAdmin && !actorMembership.isOwner) {
    return { error: 'Permissão negada' as const };
  }

  return { tenant, actorMembership } as const;
}

export async function GET(req: NextRequest, { params }: RequestParams) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated || !auth.userId) return sendUnauthorized();

    const { tenant } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const resolved = await resolveTenantAndActor(auth.userId, tenantSnake);
    if ('error' in resolved) {
      const status = resolved.error === 'Tenant not found' ? 404 : 403;
      return NextResponse.json({ error: resolved.error }, { status });
    }

    const memberships = await prisma.membership.findMany({
      where: { tenantId: resolved.tenant.id },
      include: { user: true },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(memberships.map(mapMembershipUser));
  } catch (error) {
    console.error('Users GET error:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}

export async function POST(req: NextRequest, { params }: RequestParams) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated || !auth.userId) return sendUnauthorized();

    const { tenant } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const resolved = await resolveTenantAndActor(auth.userId, tenantSnake);
    if ('error' in resolved) {
      const status = resolved.error === 'Tenant not found' ? 404 : 403;
      return NextResponse.json({ error: resolved.error }, { status });
    }

    const body = await req.json();
    const { firstName, lastName, email, username, phone, password, isAdmin } = body as {
      firstName?: string;
      lastName?: string;
      email: string;
      username?: string;
      phone?: string;
      password?: string;
      isAdmin?: boolean;
    };

    if (!email) {
      return NextResponse.json({ error: 'Email é obrigatório' }, { status: 400 });
    }

    const normalizedEmail = email.toLowerCase();
    const normalizedUsername = (username || normalizedEmail.split('@')[0]).toLowerCase();
    const safePassword = password || `Temp@${Math.random().toString(36).slice(2, 8)}`;

    const passwordHash = await bcrypt.hash(safePassword, 10);

    const newUser = await prisma.user.create({
      data: {
        email: normalizedEmail,
        username: normalizedUsername,
        firstName: firstName || null,
        lastName: lastName || null,
        phone: phone || null,
        phoneNormalized: phone ? phone.replace(/\D/g, '') : null,
        passwordHash,
        status: 'ACTIVE',
      },
    });

    const membership = await prisma.membership.create({
      data: {
        userId: newUser.id,
        tenantId: resolved.tenant.id,
        isAdmin: Boolean(isAdmin),
        isOwner: false,
        customPermissions: {},
      },
      include: { user: true },
    });

    return NextResponse.json({
      user: mapMembershipUser(membership),
      temporaryPassword: password ? undefined : safePassword,
    }, { status: 201 });
  } catch (error: any) {
    console.error('Users POST error:', error);
    if (error.code === 'P2002') {
      return NextResponse.json({ error: 'Email ou usuário já existe' }, { status: 409 });
    }
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}
