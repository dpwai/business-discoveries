import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { sendUserInviteEmail } from '@/lib/email/resend';
import { generateSecureToken } from '@/lib/auth/token-hash';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const { tenant } = await params;
    const body = await request.json();
    const { email, role = 'FILLER' } = body;

    // Get authorization header and extract user ID
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Validate email
    if (!email || typeof email !== 'string' || !email.includes('@')) {
      return NextResponse.json(
        { error: 'Valid email is required' },
        { status: 400 }
      );
    }

    // Validate role
    if (!['ADMIN', 'FILLER'].includes(role)) {
      return NextResponse.json(
        { error: 'Invalid role. Must be ADMIN or FILLER' },
        { status: 400 }
      );
    }

    // Find tenant
    const tenantData = await prisma.tenant.findFirst({
      where: {
        OR: [
          { id: tenant },
          { snake: tenant }
        ]
      }
    });

    if (!tenantData) {
      return NextResponse.json(
        { error: 'Tenant not found' },
        { status: 404 }
      );
    }

    // Check if user already exists
    let user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() }
    });

    if (!user) {
      // Create new user with temporary password
      const tempToken = generateSecureToken(12);
      user = await prisma.user.create({
        data: {
          email: email.toLowerCase(),
          username: email.split('@')[0],
          passwordHash: '', // Will be set on first login
          status: 'INVITED',
          inviteToken: tempToken,
          inviteExpiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        }
      });
    }

    // Create membership
    const membership = await prisma.membership.create({
      data: {
        userId: user.id,
        tenantId: tenantData.id,
        isAdmin: role === 'ADMIN',
      }
    });

    // Send invite email
    const inviteLink = `${process.env.NEXT_PUBLIC_APP_URL}/login?email=${encodeURIComponent(email)}&tenant=${tenantData.snake}`;
    const emailResult = await sendUserInviteEmail(
      email,
      tenantData.name,
      role === 'ADMIN' ? 'Administrador' : 'Usuário',
      inviteLink
    );

    console.log(`[USER-INVITE] ✅ Invitation sent to ${email} for ${tenantData.name}. MessageId: ${emailResult.messageId}`);

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        status: user.status,
      },
      membership: {
        id: membership.id,
        role: membership.isAdmin ? 'ADMIN' : 'FILLER',
      },
      emailSent: emailResult.success,
    }, { status: 201 });

  } catch (error) {
    console.error('[USER-INVITE] Error:', error);
    return NextResponse.json(
      { error: 'Failed to send invitation' },
      { status: 500 }
    );
  }
}
