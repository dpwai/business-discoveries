import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

type RequestParams = { params: Promise<{ tenant: string; userId: string }> };

const VALID_STATUS = ['ACTIVE', 'DISABLED', 'INVITED'];

export async function PATCH(req: NextRequest, { params }: RequestParams) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated || !auth.userId) return sendUnauthorized();

    const { tenant, userId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({ where: { snake: tenantSnake } });
    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const actorMembership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId,
          tenantId: tenantData.id,
        },
      },
    });

    if (!actorMembership || (!actorMembership.isAdmin && !actorMembership.isOwner)) {
      return NextResponse.json({ error: 'Permissão negada' }, { status: 403 });
    }

    const targetMembership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId,
          tenantId: tenantData.id,
        },
      },
      include: { user: true },
    });

    if (!targetMembership) {
      return NextResponse.json({ error: 'Usuário não encontrado' }, { status: 404 });
    }

    if (targetMembership.isOwner && !actorMembership.isOwner) {
      return NextResponse.json({ error: 'Owner não pode ser alterado' }, { status: 403 });
    }

    const body = await req.json();
    const { status, isAdmin } = body as { status?: string; isAdmin?: boolean };

    const userUpdates: any = {};
    const membershipUpdates: any = {};

    if (status !== undefined) {
      if (!VALID_STATUS.includes(status)) {
        return NextResponse.json({ error: 'Status inválido' }, { status: 400 });
      }
      userUpdates.status = status;
    }

    if (isAdmin !== undefined) {
      membershipUpdates.isAdmin = Boolean(isAdmin);
    }

    if (!Object.keys(userUpdates).length && !Object.keys(membershipUpdates).length) {
      return NextResponse.json({ error: 'Nenhuma alteração enviada' }, { status: 400 });
    }

    if (Object.keys(userUpdates).length) {
      await prisma.user.update({ where: { id: userId }, data: userUpdates });
    }

    const updatedMembership = await prisma.membership.update({
      where: {
        userId_tenantId: {
          userId,
          tenantId: tenantData.id,
        },
      },
      data: membershipUpdates,
      include: { user: true },
    });

    return NextResponse.json({
      id: updatedMembership.user.id,
      email: updatedMembership.user.email,
      username: updatedMembership.user.username,
      firstName: updatedMembership.user.firstName,
      lastName: updatedMembership.user.lastName,
      phone: updatedMembership.user.phone,
      status: updatedMembership.user.status,
      isAdmin: updatedMembership.isAdmin,
      isOwner: updatedMembership.isOwner,
      createdAt: updatedMembership.user.createdAt,
    });
  } catch (error) {
    console.error('Users PATCH error:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}
