// GET: Count and list submissions/records for a tenant
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    // Find tenant
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // Get all records (submissions) for this tenant
    const submissions = await prisma.record.findMany({
      where: {
        tenantId: tenantData.id,
        isArchived: false,
      },
      select: {
        id: true,
        formId: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(submissions);
  } catch (error) {
    console.error('GET /submissions error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
