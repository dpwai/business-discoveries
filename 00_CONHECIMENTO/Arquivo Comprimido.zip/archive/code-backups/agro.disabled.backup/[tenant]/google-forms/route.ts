import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// GET - List all forms for tenant
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const { tenant } = await params;
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || 'DRAFT,PUBLISHED'; // Filter by status
    const search = searchParams.get('search') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    // Get tenant first
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const statusArray = status.split(',');
    const skip = (page - 1) * limit;

    // Query forms
    const forms = await prisma.googleForm.findMany({
      where: {
        tenantId: tenantData.id,
        status: { in: statusArray },
        ...(search && {
          OR: [{ title: { contains: search, mode: 'insensitive' } }],
        }),
      },
      skip,
      take: limit,
      orderBy: { updatedAt: 'desc' },
    });

    // Count total for pagination
    const total = await prisma.googleForm.count({
      where: {
        tenantId: tenantData.id,
        status: { in: statusArray },
        ...(search && {
          OR: [{ title: { contains: search, mode: 'insensitive' } }],
        }),
      },
    });

    // Add submission count
    const formsWithCount = await Promise.all(
      forms.map(async (form) => {
        const submissionCount = await prisma.googleFormSubmission.count({
          where: { formId: form.id },
        });
        return { ...form, submissionCount };
      })
    );

    return NextResponse.json({
      forms: formsWithCount,
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('[FORMS:GET] Error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch forms' },
      { status: 500 }
    );
  }
}

// POST - Create new form (draft)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const { tenant } = await params;
    const body = await request.json();
    const { title = 'Novo Formulário' } = body;

    // Get tenant
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Create form with default schema
    const form = await prisma.googleForm.create({
      data: {
        tenantId: tenantData.id,
        title,
        description: '',
        status: 'DRAFT',
        schemaJson: {
          questions: [],
          title,
          description: '',
        },
      },
    });

    return NextResponse.json(form, { status: 201 });
  } catch (error) {
    console.error('[FORMS:POST] Error:', error);
    return NextResponse.json(
      { error: 'Failed to create form' },
      { status: 500 }
    );
  }
}
