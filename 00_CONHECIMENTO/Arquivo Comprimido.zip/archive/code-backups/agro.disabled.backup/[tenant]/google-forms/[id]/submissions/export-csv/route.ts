import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// GET - Export submissions as CSV
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const form = await prisma.googleForm.findFirst({
      where: { id, tenantId: tenantData.id },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    const submissions = await prisma.googleFormSubmission.findMany({
      where: {
        formId: id,
        tenantId: tenantData.id,
      },
      orderBy: { submittedAt: 'asc' },
    });

    const schema = form.schemaJson as Record<string, any>;
    const questions = (schema && Array.isArray(schema.questions)) ? schema.questions : [];

    // Build CSV header: submission_id, submitted_at, ...question_labels
    const headers = [
      'submission_id',
      'submitted_at',
      ...questions.map((q: any) => q.label || q.id),
    ];

    // Build CSV rows
    const rows = submissions.map((submission) => [
      submission.id,
      submission.submittedAt.toISOString(),
      ...questions.map((q: any) => {
        const answer = (submission.answersJson as any)[q.id];
        if (Array.isArray(answer)) {
          return answer.join(';');
        }
        return answer || '';
      }),
    ]);

    // Build CSV string
    const csvContent = [
      headers.join(','),
      ...rows.map((row) =>
        row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')
      ),
    ].join('\n');

    return new Response(csvContent, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="submissions-${form.title}.csv"`,
      },
    });
  } catch (error) {
    console.error('[CSV:EXPORT] Error:', error);
    return NextResponse.json(
      { error: 'Failed to export CSV' },
      { status: 500 }
    );
  }
}
