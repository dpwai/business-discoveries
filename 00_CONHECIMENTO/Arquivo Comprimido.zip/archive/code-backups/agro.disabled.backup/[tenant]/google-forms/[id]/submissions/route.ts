import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// GET - List submissions for form
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    const search = searchParams.get('search') || '';

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const form = await prisma.googleForm.findFirst({
      where: { id, tenantId: tenantData.id },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    const skip = (page - 1) * limit;

    const submissions = await prisma.googleFormSubmission.findMany({
      where: {
        formId: id,
        tenantId: tenantData.id,
      },
      skip,
      take: limit,
      orderBy: { submittedAt: 'desc' },
      include: {
        files: true,
      },
    });

    const total = await prisma.googleFormSubmission.count({
      where: {
        formId: id,
        tenantId: tenantData.id,
      },
    });

    return NextResponse.json({
      submissions,
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('[SUBMISSIONS:GET] Error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch submissions' },
      { status: 500 }
    );
  }
}

// PATCH - Update single submission
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;
    const body = await request.json();
    const { submissionId, answersJson } = body;

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const submission = await prisma.googleFormSubmission.findFirst({
      where: {
        id: submissionId,
        formId: id,
        tenantId: tenantData.id,
      },
    });

    if (!submission) {
      return NextResponse.json(
        { error: 'Submission not found' },
        { status: 404 }
      );
    }

    const updated = await prisma.googleFormSubmission.update({
      where: { id: submissionId },
      data: {
        answersJson: answersJson || submission.answersJson,
        updatedAt: new Date(),
      },
      include: { files: true },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error('[SUBMISSION:PATCH] Error:', error);
    return NextResponse.json(
      { error: 'Failed to update submission' },
      { status: 500 }
    );
  }
}

// DELETE - Delete submission
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;
    const body = await request.json();
    const { submissionId } = body;

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const submission = await prisma.googleFormSubmission.findFirst({
      where: {
        id: submissionId,
        formId: id,
        tenantId: tenantData.id,
      },
    });

    if (!submission) {
      return NextResponse.json(
        { error: 'Submission not found' },
        { status: 404 }
      );
    }

    // Delete will cascade to files
    await prisma.googleFormSubmission.delete({
      where: { id: submissionId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('[SUBMISSION:DELETE] Error:', error);
    return NextResponse.json(
      { error: 'Failed to delete submission' },
      { status: 500 }
    );
  }
}
