import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// PATCH - Batch update submissions
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;
    const body = await request.json();
    const { submissionIds, updates } = body;

    if (!Array.isArray(submissionIds) || submissionIds.length === 0) {
      return NextResponse.json(
        { error: 'No submissions to update' },
        { status: 400 }
      );
    }

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify all submissions belong to this form and tenant
    const submissions = await prisma.googleFormSubmission.findMany({
      where: {
        id: { in: submissionIds },
        formId: id,
        tenantId: tenantData.id,
      },
    });

    if (submissions.length !== submissionIds.length) {
      return NextResponse.json(
        { error: 'Some submissions not found' },
        { status: 404 }
      );
    }

    // Update all submissions
    const updated = await Promise.all(
      submissionIds.map((submissionId: string) =>
        prisma.googleFormSubmission.update({
          where: { id: submissionId },
          data: {
            answersJson: updates,
            updatedAt: new Date(),
          },
          include: { files: true },
        })
      )
    );

    return NextResponse.json({ updated });
  } catch (error) {
    console.error('[BATCH:PATCH] Error:', error);
    return NextResponse.json(
      { error: 'Failed to batch update' },
      { status: 500 }
    );
  }
}
