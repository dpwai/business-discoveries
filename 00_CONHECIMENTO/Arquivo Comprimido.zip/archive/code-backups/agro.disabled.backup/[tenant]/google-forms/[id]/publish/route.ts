import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { nanoid } from 'nanoid';

// POST - Publish form (generate public slug)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const form = await prisma.googleForm.findFirst({
      where: { id, tenantId: tenantData.id },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Generate unique slug if not already published
    let publicSlug = form.publicSlug;
    if (!publicSlug) {
      publicSlug = `${form.title.toLowerCase().replace(/\s+/g, '-')}-${nanoid(8)}`;

      // Ensure uniqueness
      let existingSlug = await prisma.googleForm.findUnique({
        where: { publicSlug },
      });

      let attempt = 0;
      while (existingSlug && attempt < 5) {
        publicSlug = `${form.title.toLowerCase().replace(/\s+/g, '-')}-${nanoid(8)}`;
        existingSlug = await prisma.googleForm.findUnique({
          where: { publicSlug },
        });
        attempt++;
      }
    }

    const published = await prisma.googleForm.update({
      where: { id },
      data: {
        status: 'PUBLISHED',
        publicSlug,
        publishedAt: new Date(),
      },
    });

    return NextResponse.json({
      ...published,
      publicUrl: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/f/${publicSlug}`,
    });
  } catch (error) {
    console.error('[FORM:PUBLISH] Error:', error);
    return NextResponse.json(
      { error: 'Failed to publish form' },
      { status: 500 }
    );
  }
}
