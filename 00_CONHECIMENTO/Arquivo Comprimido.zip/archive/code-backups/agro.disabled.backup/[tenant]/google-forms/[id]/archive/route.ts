import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// POST - Archive form
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const form = await prisma.googleForm.findFirst({
      where: { id, tenantId: tenantData.id },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    const archived = await prisma.googleForm.update({
      where: { id },
      data: {
        status: 'ARCHIVED',
      },
    });

    return NextResponse.json(archived);
  } catch (error) {
    console.error('[FORM:ARCHIVE] Error:', error);
    return NextResponse.json(
      { error: 'Failed to archive form' },
      { status: 500 }
    );
  }
}
