import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// POST - Import submissions from CSV
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }

    const csvText = await file.text();
    const lines = csvText.trim().split('\n');

    if (lines.length < 2) {
      return NextResponse.json(
        { error: 'CSV file is empty' },
        { status: 400 }
      );
    }

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const form = await prisma.googleForm.findFirst({
      where: { id, tenantId: tenantData.id },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Parse CSV header
    const headerLine = lines[0];
    const headers = headerLine.split(',').map((h) => h.replace(/^"|"$/g, ''));

    const schema = form.schemaJson as Record<string, any>;
    const questions = (schema && Array.isArray(schema.questions)) ? schema.questions : [];
    const questionMap = new Map(questions.map((q: Record<string, any>) => [q.label || q.id, q.id]));

    let updatedCount = 0;
    let errorCount = 0;
    const errors: string[] = [];

    // Process each data row
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      try {
        // Simple CSV parsing (handle quoted fields)
        const values: string[] = [];
        let current = '';
        let inQuotes = false;

        for (let j = 0; j < line.length; j++) {
          const char = line[j];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            values.push(current.replace(/^"|"$/g, ''));
            current = '';
          } else {
            current += char;
          }
        }
        values.push(current.replace(/^"|"$/g, ''));

        const submissionId = values[0] || '';

        if (!submissionId) {
          errors.push(`Row ${i + 1}: Missing submission_id`);
          errorCount++;
          continue;
        }

        // Check if submission exists
        const submission = await prisma.googleFormSubmission.findFirst({
          where: {
            id: submissionId,
            formId: id,
            tenantId: tenantData.id,
          },
        });

        if (!submission) {
          errors.push(`Row ${i + 1}: Submission ${submissionId} not found`);
          errorCount++;
          continue;
        }

        // Build answers object from CSV row
        const answersJson: Record<string, any> = {};
        for (let colIndex = 2; colIndex < headers.length && colIndex < values.length; colIndex++) {
          const questionLabel = headers[colIndex];
          const questionId = questionMap.get(questionLabel);
          if (questionId) {
            const value = values[colIndex] || '';
            // Handle semicolon-separated multiple values
            answersJson[questionId] = value.includes(';') ? value.split(';') : value;
          }
        }

        // Update submission
        await prisma.googleFormSubmission.update({
          where: { id: submissionId },
          data: {
            answersJson,
            updatedAt: new Date(),
          },
        });

        updatedCount++;
      } catch (rowError) {
        errorCount++;
        errors.push(`Row ${i + 1}: ${rowError instanceof Error ? rowError.message : 'Unknown error'}`);
      }
    }

    return NextResponse.json({
      success: true,
      updatedCount,
      errorCount,
      errors: errors.slice(0, 10), // Return first 10 errors
      totalErrors: errors.length,
    });
  } catch (error) {
    console.error('[CSV:IMPORT] Error:', error);
    return NextResponse.json(
      { error: 'Failed to import CSV' },
      { status: 500 }
    );
  }
}
