import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// GET - Get single form
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const form = await prisma.googleForm.findFirst({
      where: { id, tenantId: tenantData.id },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    return NextResponse.json(form);
  } catch (error) {
    console.error('[FORM:GET] Error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch form' },
      { status: 500 }
    );
  }
}

// PATCH - Update form
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;
    const body = await request.json();
    const { title, description, schemaJson } = body;

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const form = await prisma.googleForm.findFirst({
      where: { id, tenantId: tenantData.id },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    const updated = await prisma.googleForm.update({
      where: { id },
      data: {
        ...(title !== undefined && { title }),
        ...(description !== undefined && { description }),
        ...(schemaJson !== undefined && { schemaJson }),
        updatedAt: new Date(),
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error('[FORM:PATCH] Error:', error);
    return NextResponse.json(
      { error: 'Failed to update form' },
      { status: 500 }
    );
  }
}

// DELETE - Delete form and submissions
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string; id: string }> }
) {
  try {
    const { tenant, id } = await params;

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenant },
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const form = await prisma.googleForm.findFirst({
      where: { id, tenantId: tenantData.id },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Delete will cascade to submissions and files
    await prisma.googleForm.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('[FORM:DELETE] Error:', error);
    return NextResponse.json(
      { error: 'Failed to delete form' },
      { status: 500 }
    );
  }
}
