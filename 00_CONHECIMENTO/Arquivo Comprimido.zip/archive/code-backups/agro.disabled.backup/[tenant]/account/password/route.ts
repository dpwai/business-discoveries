import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcrypt';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated || !auth.userId) {
      return sendUnauthorized();
    }

    const { tenant } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({ where: { snake: tenantSnake } });
    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId,
          tenantId: tenantData.id,
        },
      },
      include: { user: true },
    });

    if (!membership) {
      return NextResponse.json({ error: 'Sem acesso a este tenant' }, { status: 403 });
    }

    const body = await req.json();
    const { currentPassword, newPassword } = body as { currentPassword?: string; newPassword?: string };

    if (!currentPassword || !newPassword) {
      return NextResponse.json({ error: 'Senha atual e nova são obrigatórias' }, { status: 400 });
    }

    if (newPassword.length < 8) {
      return NextResponse.json({ error: 'Nova senha deve ter ao menos 8 caracteres' }, { status: 400 });
    }

    const matches = await bcrypt.compare(currentPassword, membership.user.passwordHash);
    if (!matches) {
      return NextResponse.json({ error: 'Senha atual incorreta' }, { status: 401 });
    }

    const newHash = await bcrypt.hash(newPassword, 10);

    await prisma.user.update({
      where: { id: membership.userId },
      data: { passwordHash: newHash },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Change password error:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}
