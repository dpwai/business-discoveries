import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { language } = body;

    if (!['pt', 'en'].includes(language)) {
      return NextResponse.json(
        { error: 'Invalid language. Must be pt or en' },
        { status: 400 }
      );
    }

    // In a real implementation, you would extract user ID from JWT
    // For now, this is a placeholder
    return NextResponse.json({
      success: true,
      language,
      message: 'Language preference updated successfully'
    });

  } catch (error) {
    console.error('[LANGUAGE-PREFERENCE] Error:', error);
    return NextResponse.json(
      { error: 'Failed to update language preference' },
      { status: 500 }
    );
  }
}
