import { NextRequest, NextResponse } from 'next/server';

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { type, dashboardId, formId } = body;

    // Validate type
    if (!['dashboard', 'hopechat', 'form', 'decide-later'].includes(type)) {
      return NextResponse.json(
        { error: 'Invalid preference type' },
        { status: 400 }
      );
    }

    // In production, this would save to database
    // For now, preferences are stored in localStorage on the client
    console.log('[PREFERENCE] User preference saved:', { type, dashboardId, formId });

    return NextResponse.json({
      success: true,
      preference: { type, dashboardId, formId },
      message: 'Preference saved successfully'
    });

  } catch (error) {
    console.error('[PREFERENCE] Error:', error);
    return NextResponse.json(
      { error: 'Failed to save preference' },
      { status: 500 }
    );
  }
}
