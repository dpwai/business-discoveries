import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated || !auth.userId) {
      return sendUnauthorized();
    }

    const { tenant } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({ where: { snake: tenantSnake } });
    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId,
          tenantId: tenantData.id,
        },
      },
      include: { user: true },
    });

    if (!membership) {
      return NextResponse.json({ error: 'Sem acesso a este tenant' }, { status: 403 });
    }

    const user = membership.user;

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        photoUrl: user.photoUrl,
        status: user.status,
      },
      membership: {
        isOwner: membership.isOwner,
        isAdmin: membership.isAdmin,
      },
      tenant: {
        id: tenantData.id,
        name: tenantData.name,
        snake: tenantData.snake,
      },
    });
  } catch (error) {
    console.error('Account GET error:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated || !auth.userId) {
      return sendUnauthorized();
    }

    const { tenant } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({ where: { snake: tenantSnake } });
    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId,
          tenantId: tenantData.id,
        },
      },
      include: { user: true },
    });

    if (!membership) {
      return NextResponse.json({ error: 'Sem acesso a este tenant' }, { status: 403 });
    }

    const body = await req.json();
    const { firstName, lastName, phone, photoUrl, email } = body as {
      firstName?: string;
      lastName?: string;
      phone?: string;
      photoUrl?: string;
      email?: string;
    };

    const data: any = {};

    if (firstName !== undefined) data.firstName = firstName || null;
    if (lastName !== undefined) data.lastName = lastName || null;
    if (phone !== undefined) {
      data.phone = phone || null;
      data.phoneNormalized = phone ? phone.replace(/\D/g, '') : null;
    }
    if (photoUrl !== undefined) data.photoUrl = photoUrl || null;
    if (email !== undefined) {
      data.email = email.toLowerCase();
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ error: 'Nenhuma alteração enviada' }, { status: 400 });
    }

    const updatedUser = await prisma.user.update({
      where: { id: auth.userId },
      data,
    });

    return NextResponse.json({
      user: {
        id: updatedUser.id,
        email: updatedUser.email,
        username: updatedUser.username,
        firstName: updatedUser.firstName,
        lastName: updatedUser.lastName,
        phone: updatedUser.phone,
        photoUrl: updatedUser.photoUrl,
        status: updatedUser.status,
      },
      membership: {
        isOwner: membership.isOwner,
        isAdmin: membership.isAdmin,
      },
      tenant: {
        id: tenantData.id,
        name: tenantData.name,
        snake: tenantData.snake,
      },
    });
  } catch (error: any) {
    console.error('Account PUT error:', error);
    if (error.code === 'P2002') {
      return NextResponse.json({ error: 'Email ou usuário já em uso' }, { status: 409 });
    }
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}
