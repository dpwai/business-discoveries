// GET: List forms | POST: Create form
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant } = await params;

    // Decode tenant snake case
    const tenantSnake = tenant.replace(/-/g, '_');

    // Find tenant
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // List active forms
    const forms = await prisma.form.findMany({
      where: {
        tenantId: tenantData.id,
        status: 'ACTIVE'
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(forms);
  } catch (error) {
    console.error('GET /forms error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // RBAC: require forms.create (owner/admin or customPermissions)
    const actorMembership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!actorMembership) {
      return sendUnauthorized();
    }

    const perms = (actorMembership.customPermissions as any) || {};
    const canCreate = actorMembership.isOwner || actorMembership.isAdmin || perms['forms.create'] === true;
    if (!canCreate) {
      return NextResponse.json({ error: 'Not allowed' }, { status: 403 });
    }

    const body = await req.json();
    const { name, type } = body;

    if (!name) {
      return NextResponse.json(
        { error: 'Name is required' },
        { status: 400 }
      );
    }

    // Create form with initial empty schema
    const form = await prisma.form.create({
      data: {
        tenantId: tenantData.id,
        name,
        type: type || 'DATA_ONLY',
        status: 'ACTIVE',
        currentSchemaJson: { fields: [] },
        currentVersion: 1
      }
    });

    // Create first version
    await prisma.formVersion.create({
      data: {
        formId: form.id,
        version: 1,
        schemaJson: { fields: [] }
      }
    });

    return NextResponse.json(form, { status: 201 });
  } catch (error) {
    console.error('POST /forms error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
