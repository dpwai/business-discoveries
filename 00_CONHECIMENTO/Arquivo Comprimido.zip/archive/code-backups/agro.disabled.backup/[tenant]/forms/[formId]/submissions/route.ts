// GET: List submissions with filtering and pagination
// POST: Export submissions as CSV or JSON
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    // Verify tenant exists
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // Verify form exists and belongs to tenant
    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Parse query parameters
    const url = new URL(req.url);
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1'));
    const pageSize = Math.min(100, parseInt(url.searchParams.get('pageSize') || '25'));
    const status = url.searchParams.get('status') as 'SUBMITTED' | 'SPAM' | null;
    const search = url.searchParams.get('search') || '';
    const dateFrom = url.searchParams.get('dateFrom') ? new Date(url.searchParams.get('dateFrom')!) : null;
    const dateTo = url.searchParams.get('dateTo') ? new Date(url.searchParams.get('dateTo')!) : null;
    const sortBy = url.searchParams.get('sortBy') || 'submittedAt';
    const sortOrder = url.searchParams.get('sortOrder') as 'asc' | 'desc' | null || 'desc';

    // Build filters
    const filters: any = {
      formVersionId: form.currentSchemaJson ? {} : undefined
    };

    // Get all form versions for this form to filter by
    const formVersions = await prisma.formVersion.findMany({
      where: { formId: form.id },
      select: { id: true }
    });

    if (formVersions.length === 0) {
      // No submissions possible yet
      return NextResponse.json({
        submissions: [],
        total: 0,
        pageSize,
        currentPage: page
      });
    }

    const versionIds = formVersions.map(v => v.id);

    // Get submissions matching criteria
    const skip = (page - 1) * pageSize;

    const where: any = {
      formVersion: {
        formId: form.id
      }
    };

    if (status) {
      where.status = status;
    }

    if (search) {
      where.OR = [
        { submitterEmail: { contains: search, mode: 'insensitive' } },
        { 'identity.firstName': { contains: search, mode: 'insensitive' } },
        { 'identity.lastName': { contains: search, mode: 'insensitive' } }
      ];
    }

    if (dateFrom || dateTo) {
      where.submittedAt = {};
      if (dateFrom) where.submittedAt.gte = dateFrom;
      if (dateTo) {
        // Set to end of day
        const endOfDay = new Date(dateTo);
        endOfDay.setHours(23, 59, 59, 999);
        where.submittedAt.lte = endOfDay;
      }
    }

    // Query submissions
    const [submissions, total] = await Promise.all([
      prisma.formSubmission.findMany({
        where,
        select: {
          id: true,
          submitterEmail: true,
          submittedAt: true,
          status: true,
          identity: true,
          webhookDelivered: true,
          webhookDeliveredAt: true
        },
        orderBy: {
          [sortBy === 'email' ? 'submitterEmail' : sortBy === 'status' ? 'status' : 'submittedAt']: sortOrder
        },
        skip,
        take: pageSize
      }),
      prisma.formSubmission.count({ where })
    ]);

    return NextResponse.json({
      submissions: submissions.map(sub => ({
        id: sub.id,
        submitterEmail: sub.submitterEmail,
        submittedAt: sub.submittedAt,
        status: sub.status || 'SUBMITTED',
        submitterName: sub.identity ? `${sub.identity.firstName || ''} ${sub.identity.lastName || ''}`.trim() : null,
        webhookDelivered: sub.webhookDelivered,
        webhookDeliveredAt: sub.webhookDeliveredAt
      })),
      total,
      pageSize,
      currentPage: page
    });
  } catch (error) {
    console.error('GET /submissions error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    // Verify tenant exists
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // Verify form exists
    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    const { format = 'CSV', fields = [], dateFrom, dateTo } = await req.json();

    // Validate format
    if (!['CSV', 'JSON'].includes(format)) {
      return NextResponse.json({ error: 'Invalid format' }, { status: 400 });
    }

    // Get form versions
    const formVersions = await prisma.formVersion.findMany({
      where: { formId: form.id },
      select: { id: true }
    });

    if (formVersions.length === 0) {
      return NextResponse.json({ error: 'No form versions found' }, { status: 400 });
    }

    // Build filters
    const where: any = {
      formVersion: { formId: form.id }
    };

    if (dateFrom || dateTo) {
      where.submittedAt = {};
      if (dateFrom) where.submittedAt.gte = new Date(dateFrom);
      if (dateTo) {
        const endOfDay = new Date(dateTo);
        endOfDay.setHours(23, 59, 59, 999);
        where.submittedAt.lte = endOfDay;
      }
    }

    // Get all submissions for export
    const submissions = await prisma.formSubmission.findMany({
      where,
      include: {
        formVersion: {
          select: { schemaJson: true }
        }
      },
      orderBy: { submittedAt: 'desc' }
    });

    if (submissions.length === 0) {
      return NextResponse.json({ error: 'No submissions to export' }, { status: 400 });
    }

    // Parse form schema to get field labels
    const latestVersion = submissions[0].formVersion;
    const schema = latestVersion.schemaJson as any;
    const fieldLabels: Record<string, string> = {};

    if (schema && schema.fields) {
      for (const field of schema.fields) {
        fieldLabels[field.id] = field.label || field.id;
      }
    }

    let content: string;
    let filename: string;
    let mimeType: string;

    if (format === 'CSV') {
      // Generate CSV
      const headers = ['Submitted At', 'Email', 'Name', 'Status'];

      // Add dynamic field columns
      const dynamicFields = fields.length > 0 ? fields : Object.keys(fieldLabels);
      headers.push(...dynamicFields.map(f => fieldLabels[f] || f));

      const rows = submissions.map(sub => {
        const identity = sub.identity as any || {};
        const row = [
          new Date(sub.submittedAt).toLocaleString('pt-BR'),
          sub.submitterEmail || '',
          `${identity.firstName || ''} ${identity.lastName || ''}`.trim(),
          sub.status || 'SUBMITTED'
        ];

        // Add field values
        const data = sub.data as any || {};
        for (const field of dynamicFields) {
          row.push(String(data[field] || ''));
        }

        return row.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',');
      });

      content = [headers.map(h => `"${h}"`).join(','), ...rows].join('\n');
      filename = `submissions_${Date.now()}.csv`;
      mimeType = 'text/csv';
    } else {
      // Generate JSON
      const json = submissions.map(sub => {
        const data = sub.data as any || {};
        const identity = sub.identity as any || {};

        const result: any = {
          submissionId: sub.id,
          submittedAt: sub.submittedAt,
          submitterEmail: sub.submitterEmail,
          submitterName: `${identity.firstName || ''} ${identity.lastName || ''}`.trim(),
          status: sub.status || 'SUBMITTED',
          data: {}
        };

        // Add field values
        const fieldsToExport = fields.length > 0 ? fields : Object.keys(fieldLabels);
        for (const field of fieldsToExport) {
          result.data[fieldLabels[field] || field] = data[field] || null;
        }

        return result;
      });

      content = JSON.stringify(json, null, 2);
      filename = `submissions_${Date.now()}.json`;
      mimeType = 'application/json';
    }

    // Return downloadable blob
    const blob = new Blob([content], { type: mimeType });
    const arrayBuffer = await blob.arrayBuffer();

    return new NextResponse(arrayBuffer, {
      status: 200,
      headers: {
        'Content-Type': mimeType,
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': arrayBuffer.byteLength.toString()
      }
    });
  } catch (error) {
    console.error('POST /submissions error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
