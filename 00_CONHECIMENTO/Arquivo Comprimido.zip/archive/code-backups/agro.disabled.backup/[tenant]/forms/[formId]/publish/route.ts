// POST: Publish form (mark as PUBLISHED)
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId } = await params;

    // Decode tenant snake case
    const tenantSnake = tenant.replace(/-/g, '_');

    // Find tenant
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // Find form
    const form = await prisma.form.findUnique({
      where: { id: formId },
      include: {
        versions: {
          orderBy: { versionNumber: 'desc' },
          take: 1
        }
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Verify form belongs to this tenant
    if (form.tenantId !== tenantData.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    const body = await req.json();
    const { schema } = body;

    // Update form status to PUBLISHED
    const updatedForm = await prisma.form.update({
      where: { id: formId },
      data: {
        status: 'PUBLISHED',
        currentSchemaJson: schema || form.currentSchemaJson,
      },
      include: {
        versions: {
          orderBy: { version: 'desc' }
        }
      }
    });

    return NextResponse.json({
      ...updatedForm,
      message: 'Form published successfully',
      publicUrl: `https://app.dpwai.com.br/f/${form.id}`
    });
  } catch (error) {
    console.error('POST /forms/{formId}/publish error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
