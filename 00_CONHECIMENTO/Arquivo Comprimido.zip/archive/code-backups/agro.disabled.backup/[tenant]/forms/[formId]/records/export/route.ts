import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

function toCsvRow(values: any[]): string {
  return values.map(v => {
    if (v === null || v === undefined) return '';
    const s = typeof v === 'string' ? v : JSON.stringify(v);
    const escaped = s.replace(/"/g, '""');
    return `"${escaped}"`;
  }).join(',');
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated) return sendUnauthorized();

    const { tenant, formId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({ where: { snake: tenantSnake } });
    if (!tenantData) return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });

    // RBAC: records.export_all
    const membership = await prisma.membership.findUnique({ where: { userId_tenantId: { userId: auth.userId as string, tenantId: tenantData.id } } });
    if (!membership) return sendUnauthorized();
    const perms = (membership.customPermissions as any) || {};
    const canExport = membership.isOwner || membership.isAdmin || perms['records.export_all'] === true;
    if (!canExport) return NextResponse.json({ error: 'Not allowed' }, { status: 403 });

    const form = await prisma.form.findFirst({ where: { id: formId, tenantId: tenantData.id } });
    if (!form) return NextResponse.json({ error: 'Form not found' }, { status: 404 });

    const includeInactive = new URL(req.url).searchParams.get('includeInactive') === 'true';
    const schema = (form.currentSchemaJson as any) || { fields: [] };
    const activeFields = (schema.fields || []).filter((f: any) => includeInactive ? true : f.active !== false);

    const records = await prisma.record.findMany({ where: { formId: form.id, tenantId: tenantData.id }, orderBy: { createdAt: 'asc' } });

    const header = toCsvRow(activeFields.map((f: any) => f.label || f.id));
    const rows: string[] = [header];
    for (const r of records) {
      const rowValues = activeFields.map((f: any) => (r.data as any)[f.id]);
      rows.push(toCsvRow(rowValues));
    }

    const csv = rows.join('\n');
    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="form_${form.id}_export.csv"`,
      },
    });
  } catch (error) {
    console.error('GET /records/export error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
