// GET: List records | POST: Create new record
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // Verify form ownership
    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Get paginated records
    const url = new URL(req.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '50');
    const skip = (page - 1) * limit;

    const [records, total] = await Promise.all([
      prisma.record.findMany({
        where: {
          formId: form.id,
          isArchived: false
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      prisma.record.count({
        where: {
          formId: form.id,
          isArchived: false
        }
      })
    ]);

    return NextResponse.json({
      records,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('GET /records error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // RBAC: require records.create (owner/admin or customPermissions)
    const actorMembership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!actorMembership) {
      return sendUnauthorized();
    }

    const perms = (actorMembership.customPermissions as any) || {};
    const canCreateRecord = actorMembership.isOwner || actorMembership.isAdmin || perms['records.create'] === true;
    if (!canCreateRecord) {
      return NextResponse.json({ error: 'Not allowed' }, { status: 403 });
    }

    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    const body = await req.json();
    const { data } = body;

    if (!data) {
      return NextResponse.json({ error: 'Data is required' }, { status: 400 });
    }

    // Create record
    const record = await prisma.record.create({
      data: {
        tenantId: tenantData.id,
        formId: form.id,
        formVersionId: form.id,
        data,
        isArchived: false
      }
    });

    return NextResponse.json(record, { status: 201 });
  } catch (error) {
    console.error('POST /records error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
