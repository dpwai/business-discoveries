// GET: Get single submission detail
// DELETE: Delete submission
// PATCH: Update submission (mark as spam, etc)
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string; submissionId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId, submissionId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    // Verify tenant exists
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // Verify form exists
    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Get submission with all details
    const submission = await prisma.formSubmission.findFirst({
      where: {
        id: submissionId,
        formVersion: {
          formId: form.id
        }
      },
      include: {
        formVersion: {
          select: {
            schemaJson: true
          }
        }
      }
    });

    if (!submission) {
      return NextResponse.json({ error: 'Submission not found' }, { status: 404 });
    }

    // Build response with form field labels
    const schema = submission.formVersion.schemaJson as any;
    const fieldLabels: Record<string, string> = {};

    if (schema && schema.fields) {
      for (const field of schema.fields) {
        fieldLabels[field.id] = field.label || field.id;
      }
    }

    // Transform data with labels
    const data = submission.data as any || {};
    const displayData: Record<string, any> = {};

    for (const [fieldId, value] of Object.entries(data)) {
      displayData[fieldLabels[fieldId] || fieldId] = value;
    }

    const identity = submission.identity as any || {};

    // Get webhook delivery status
    let webhookStatus = {
      delivered: submission.webhookDelivered,
      deliveredAt: submission.webhookDeliveredAt,
      attempts: 0,
      lastAttempt: null as Date | null
    };

    // Check for webhook deliveries (if they exist)
    // Note: WebhookDelivery model may not exist yet, but we structure the response for it
    try {
      // Try to find webhook deliveries for this submission
      // This assumes a WebhookDelivery model exists
      const deliveries = await (prisma as any).webhookDelivery?.findMany({
        where: { submissionId },
        orderBy: { sentAt: 'desc' }
      });

      if (deliveries && deliveries.length > 0) {
        webhookStatus.attempts = deliveries.length;
        webhookStatus.lastAttempt = deliveries[0].sentAt;
        const delivered = deliveries.find((d: any) => d.deliveredAt !== null);
        if (delivered) {
          webhookStatus.delivered = true;
          webhookStatus.deliveredAt = delivered.deliveredAt;
        }
      }
    } catch (e) {
      // Model doesn't exist yet, that's fine
    }

    return NextResponse.json({
      id: submission.id,
      formId: form.id,
      submittedAt: submission.submittedAt,
      data: displayData,
      identity: {
        firstName: identity.firstName,
        lastName: identity.lastName,
        email: identity.email,
        phone: identity.phone
      },
      submitterEmail: submission.submitterEmail,
      submitterIP: submission.submitterIP,
      userAgent: submission.userAgent,
      status: submission.status || 'SUBMITTED',
      webhookStatus,
      files: [] // Files will be handled separately if FormFile model is added
    });
  } catch (error) {
    console.error('GET /submission detail error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string; submissionId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId, submissionId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    // Verify tenant exists
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // Verify form exists
    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Verify submission exists
    const submission = await prisma.formSubmission.findFirst({
      where: {
        id: submissionId,
        formVersion: {
          formId: form.id
        }
      }
    });

    if (!submission) {
      return NextResponse.json({ error: 'Submission not found' }, { status: 404 });
    }

    // Delete submission
    await prisma.formSubmission.delete({
      where: { id: submissionId }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /submission error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string; submissionId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId, submissionId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    // Verify tenant exists
    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // Verify form exists
    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Verify submission exists
    const submission = await prisma.formSubmission.findFirst({
      where: {
        id: submissionId,
        formVersion: {
          formId: form.id
        }
      }
    });

    if (!submission) {
      return NextResponse.json({ error: 'Submission not found' }, { status: 404 });
    }

    const { status } = await req.json();

    // Validate status
    if (!['SUBMITTED', 'SPAM'].includes(status)) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 });
    }

    // Update submission
    const updated = await prisma.formSubmission.update({
      where: { id: submissionId },
      data: { status }
    });

    return NextResponse.json({
      id: updated.id,
      status: updated.status
    });
  } catch (error) {
    console.error('PATCH /submission error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
