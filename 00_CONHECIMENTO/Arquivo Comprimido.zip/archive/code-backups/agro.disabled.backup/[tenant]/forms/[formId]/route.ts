// GET: Form by ID | PUT: Update schema (save builder changes)
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      },
      include: {
        versions: {
          orderBy: { version: 'desc' },
          take: 5 // Last 5 versions
        }
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    return NextResponse.json(form);
  } catch (error) {
    console.error('GET /forms/[id] error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // RBAC: require forms.edit (owner/admin or customPermissions)
    const actorMembership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!actorMembership) {
      return sendUnauthorized();
    }

    const perms = (actorMembership.customPermissions as any) || {};
    const canEdit = actorMembership.isOwner || actorMembership.isAdmin || perms['forms.edit'] === true;
    if (!canEdit) {
      return NextResponse.json({ error: 'Not allowed' }, { status: 403 });
    }

    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    const body = await req.json();
    const { schema, name, autosave } = body;

    if (!schema) {
      return NextResponse.json(
        { error: 'Schema is required' },
        { status: 400 }
      );
    }

    // Handle both old and new schema formats
    // Old format: { fields: [...] }
    // New format: { pages: [...], settings: {...} }
    const isNewFormat = schema.pages && Array.isArray(schema.pages);

    if (!isNewFormat && (!schema.fields || !Array.isArray(schema.fields))) {
      return NextResponse.json(
        { error: 'Schema must contain a fields array or pages array' },
        { status: 400 }
      );
    }

    // If autosave is true, don't create a new version - just update the form
    if (autosave) {
      const updated = await prisma.form.update({
        where: { id: form.id },
        data: {
          currentSchemaJson: schema,
          ...(name && { name })
        },
        include: {
          versions: {
            orderBy: { version: 'desc' },
            take: 1
          }
        }
      });

      return NextResponse.json({
        ...updated,
        autosaved: true,
        versionCreated: false
      });
    }

    // For regular saves, create a new version
    const newVersion = form.currentVersion + 1;

    // Save new version
    await prisma.formVersion.create({
      data: {
        formId: form.id,
        version: newVersion,
        schemaJson: schema
      }
    });

    // Update form
    const updated = await prisma.form.update({
      where: { id: form.id },
      data: {
        currentSchemaJson: schema,
        currentVersion: newVersion,
        ...(name && { name })
      },
      include: {
        versions: {
          orderBy: { version: 'desc' },
          take: 1
        }
      }
    });

    return NextResponse.json({
      ...updated,
      versionCreated: true,
      newVersion
    });
  } catch (error: any) {
    console.error('PUT /forms/[id] error:', error);
    const errorMsg = error?.message || 'Internal server error';
    return NextResponse.json(
      { error: 'Failed to update form', details: errorMsg },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    // Verify authentication
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Verify user is a member of this tenant
    const membership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!membership) {
      return sendUnauthorized();
    }

    // RBAC: require forms.archive (owner/admin or customPermissions)
    const actorMembership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!actorMembership) {
      return sendUnauthorized();
    }

    const perms = (actorMembership.customPermissions as any) || {};
    const canArchive = actorMembership.isOwner || actorMembership.isAdmin || perms['forms.archive'] === true;
    if (!canArchive) {
      return NextResponse.json({ error: 'Not allowed' }, { status: 403 });
    }

    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Archive instead of delete
    await prisma.form.update({
      where: { id: form.id },
      data: { status: 'ARCHIVED' }
    });

    return NextResponse.json({ message: 'Form archived' });
  } catch (error) {
    console.error('DELETE /forms/[id] error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string }> }
) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated) {
      return sendUnauthorized();
    }

    const { tenant, formId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({
      where: { snake: tenantSnake }
    });

    if (!tenantData) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // RBAC: require forms.archive to unarchive too (manage status)
    const actorMembership = await prisma.membership.findUnique({
      where: {
        userId_tenantId: {
          userId: auth.userId as string,
          tenantId: tenantData.id,
        },
      },
    });

    if (!actorMembership) {
      return sendUnauthorized();
    }

    const perms = (actorMembership.customPermissions as any) || {};
    const canManageStatus = actorMembership.isOwner || actorMembership.isAdmin || perms['forms.archive'] === true;
    if (!canManageStatus) {
      return NextResponse.json({ error: 'Not allowed' }, { status: 403 });
    }

    const form = await prisma.form.findFirst({
      where: {
        id: formId,
        tenantId: tenantData.id
      }
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    const body = await req.json();
    const { status } = body as { status?: 'ACTIVE' | 'ARCHIVED' };
    if (!status || (status !== 'ACTIVE' && status !== 'ARCHIVED')) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 });
    }

    const updated = await prisma.form.update({ where: { id: form.id }, data: { status } });
    return NextResponse.json(updated);
  } catch (error) {
    console.error('PATCH /forms/[id] error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
