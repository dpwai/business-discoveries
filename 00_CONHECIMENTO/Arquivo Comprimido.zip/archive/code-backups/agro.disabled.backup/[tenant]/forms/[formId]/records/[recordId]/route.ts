import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

function validateValue(type: string, required: boolean, constraints: any, value: any): string | null {
  if (required && (value === null || value === undefined || value === '')) return 'Campo obrigatório';
  if (value === null || value === undefined || value === '') return null;

  switch (type) {
    case 'TEXT': {
      if (typeof value !== 'string') return 'Deve ser texto';
      const min = constraints?.minLength;
      const max = constraints?.maxLength;
      if (min && value.length < min) return `Mínimo ${min} caracteres`;
      if (max && value.length > max) return `Máximo ${max} caracteres`;
      return null;
    }
    case 'NUMBER': {
      const num = typeof value === 'number' ? value : Number(value);
      if (Number.isNaN(num)) return 'Deve ser número';
      const min = constraints?.min;
      const max = constraints?.max;
      const decimals = constraints?.decimals;
      if (min !== undefined && num < min) return `Mínimo ${min}`;
      if (max !== undefined && num > max) return `Máximo ${max}`;
      if (decimals !== undefined) {
        const parts = String(num).split('.')
        if (parts[1] && parts[1].length > decimals) return `Máximo ${decimals} casas decimais`;
      }
      return null;
    }
    case 'BOOLEAN': {
      if (typeof value !== 'boolean') return 'Deve ser boolean';
      return null;
    }
    case 'DATE': {
      const d = new Date(value);
      if (isNaN(d.getTime())) return 'Data inválida';
      // Simple bounds check if provided
      const minDate = constraints?.minDate ? new Date(constraints.minDate) : null;
      const maxDate = constraints?.maxDate ? new Date(constraints.maxDate) : null;
      if (minDate && d < minDate) return `Data mínima ${constraints.minDate}`;
      if (maxDate && d > maxDate) return `Data máxima ${constraints.maxDate}`;
      return null;
    }
    case 'TIME': {
      // Expect HH:MM (24h)
      if (!/^\d{2}:\d{2}$/.test(String(value))) return 'Hora inválida';
      return null;
    }
    case 'DROPDOWN': {
      const opts = constraints?.options || [];
      if (!opts.includes(value)) return 'Valor fora das opções';
      return null;
    }
    case 'MULTISELECT': {
      const opts = constraints?.options || [];
      const maxSelections = constraints?.maxSelections;
      if (!Array.isArray(value)) return 'Deve ser lista';
      for (const v of value) if (!opts.includes(v)) return 'Valor fora das opções';
      if (maxSelections && value.length > maxSelections) return `Máximo ${maxSelections} seleções`;
      return null;
    }
    default:
      return null;
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string; formId: string; recordId: string }> }
) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated) return sendUnauthorized();

    const { tenant, formId, recordId } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({ where: { snake: tenantSnake } });
    if (!tenantData) return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });

    // RBAC: records.edit
    const membership = await prisma.membership.findUnique({
      where: { userId_tenantId: { userId: auth.userId as string, tenantId: tenantData.id } },
    });
    if (!membership) return sendUnauthorized();
    const perms = (membership.customPermissions as any) || {};
    const canEdit = membership.isOwner || membership.isAdmin || perms['records.edit'] === true;
    if (!canEdit) return NextResponse.json({ error: 'Not allowed' }, { status: 403 });

    const form = await prisma.form.findFirst({ where: { id: formId, tenantId: tenantData.id } });
    if (!form) return NextResponse.json({ error: 'Form not found' }, { status: 404 });

    const record = await prisma.record.findFirst({ where: { id: recordId, formId: form.id, tenantId: tenantData.id, isArchived: false } });
    if (!record) return NextResponse.json({ error: 'Record not found' }, { status: 404 });

    const body = await req.json();
    const { changes } = body as { changes: Record<string, any> };
    if (!changes || typeof changes !== 'object') return NextResponse.json({ error: 'Invalid changes' }, { status: 400 });

    const schema = (form.currentSchemaJson as any) || { fields: [] };
    const fieldsById: Record<string, any> = {};
    for (const f of schema.fields || []) fieldsById[f.id] = f;

    const errors: Record<string, string> = {};
    for (const key of Object.keys(changes)) {
      const field = fieldsById[key];
      if (!field || field.active === false) {
        errors[key] = 'Campo desconhecido ou inativo';
        continue;
      }
      const err = validateValue(field.type, field.required, field.constraints, changes[key]);
      if (err) errors[key] = err;
    }

    if (Object.keys(errors).length > 0) {
      return NextResponse.json({ error: 'Validation failed', fieldErrors: errors }, { status: 400 });
    }

    const newData = { ...(record.data as any), ...changes };

    // Create RecordVersion and RecordChange entries
    const latestVersionCount = await prisma.recordVersion.count({ where: { recordId: record.id } });
    const nextVersion = latestVersionCount + 1;
    const recordVersion = await prisma.recordVersion.create({
      data: {
        recordId: record.id,
        version: nextVersion,
        snapshotJson: newData,
        changedBy: auth.userId as string,
        changeType: 'EDIT',
      },
    });

    for (const key of Object.keys(changes)) {
      await prisma.recordChange.create({
        data: {
          recordId: record.id,
          recordVersionId: recordVersion.id,
          fieldId: key,
          oldValueJson: (record.data as any)[key],
          newValueJson: changes[key],
          changedBy: auth.userId as string,
        },
      });
    }

    const updated = await prisma.record.update({
      where: { id: record.id },
      data: { data: newData, updatedById: auth.userId as string },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error('PATCH /records/[recordId] error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
