/**
 * Form Builder API Routes
 *
 * Handles form CRUD operations with automatic versioning.
 * - GET: Fetch form with all versions
 * - POST: Create new form
 * - PUT: Update form (creates new version automatically)
 * - DELETE: Delete form (soft delete)
 */

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { addMissingFieldIds } from '@/lib/formEngine/fieldIds';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const { tenant } = await params;
    const { searchParams } = new URL(request.url);
    const formId = searchParams.get('formId');

    if (!formId) {
      // List all forms for tenant
      const forms = await prisma.form.findMany({
        where: {
          tenant: {
            snake: tenant,
          },
          status: 'ACTIVE',
        },
        include: {
          versions: {
            where: { isActive: true },
            take: 1,
            orderBy: { version: 'desc' },
          },
        },
      });

      return NextResponse.json(forms);
    }

    // Get single form with versions
    const form = await prisma.form.findUnique({
      where: { id: formId },
      include: {
        versions: {
          orderBy: { version: 'desc' },
        },
      },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Verify tenant access
    if (form.tenantId !== tenant) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    return NextResponse.json(form);
  } catch (error) {
    console.error('Error fetching form:', error);
    return NextResponse.json(
      { error: 'Failed to fetch form' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const { tenant: tenantSnake } = await params;
    const body = await request.json();
    const { title, description, schema } = body;

    if (!title) {
      return NextResponse.json(
        { error: 'Title is required' },
        { status: 400 }
      );
    }

    // Get tenant ID from tenant snake
    const tenant = await prisma.tenant.findUnique({
      where: { snake: tenantSnake },
    });

    if (!tenant) {
      return NextResponse.json(
        { error: 'Tenant not found' },
        { status: 404 }
      );
    }

    // Ensure schema has field IDs
    const schemaWithIds = addMissingFieldIds(schema || {});

    // Create form with initial version
    const form = await prisma.form.create({
      data: {
        tenantId: tenant.id,
        name: title,
        status: 'ACTIVE',
        currentVersion: 1,
        currentSchemaJson: schemaWithIds,
        versions: {
          create: {
            version: 1,
            schemaJson: schemaWithIds,
          },
        },
      },
      include: {
        versions: true,
      },
    });

    return NextResponse.json(form, { status: 201 });
  } catch (error) {
    console.error('Error creating form:', error);
    return NextResponse.json(
      { error: 'Failed to create form' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const { tenant: tenantSnake } = await params;
    const body = await request.json();
    const { formId, title, description, schema } = body;

    if (!formId) {
      return NextResponse.json(
        { error: 'formId is required' },
        { status: 400 }
      );
    }

    // Get tenant ID
    const tenant = await prisma.tenant.findUnique({
      where: { snake: tenantSnake },
    });

    if (!tenant) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Get current form
    const form = await prisma.form.findUnique({
      where: { id: formId },
      include: {
        versions: {
          orderBy: { version: 'desc' },
          take: 1,
        },
      },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Verify tenant access
    if (form.tenantId !== tenant.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    // Ensure schema has field IDs
    const schemaWithIds = addMissingFieldIds(schema || {});

    // Check if schema changed (determines if we need a new version)
    const currentVersion = form.versions[0];
    const schemaChanged =
      JSON.stringify(currentVersion?.schemaJson) !==
      JSON.stringify(schemaWithIds);

    const nextVersion = schemaChanged ? form.currentVersion + 1 : form.currentVersion;

    // Create new version if schema changed
    if (schemaChanged) {
      await prisma.formVersion.create({
        data: {
          formId,
          version: nextVersion,
          schemaJson: schemaWithIds,
        },
      });
    }

    // Update form
    const updatedForm = await prisma.form.update({
      where: { id: formId },
      data: {
        name: title || form.name,
        currentVersion: nextVersion,
        currentSchemaJson: schemaWithIds,
      },
      include: {
        versions: {
          orderBy: { version: 'desc' },
        },
      },
    });

    return NextResponse.json({
      ...updatedForm,
      versionCreated: schemaChanged,
      newVersion: nextVersion,
    });
  } catch (error) {
    console.error('Error updating form:', error);
    return NextResponse.json(
      { error: 'Failed to update form' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const { tenant: tenantSnake } = await params;
    const body = await request.json();
    const { formId } = body;

    if (!formId) {
      return NextResponse.json(
        { error: 'formId is required' },
        { status: 400 }
      );
    }

    // Get tenant ID
    const tenant = await prisma.tenant.findUnique({
      where: { snake: tenantSnake },
    });

    if (!tenant) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Get form
    const form = await prisma.form.findUnique({
      where: { id: formId },
    });

    if (!form) {
      return NextResponse.json({ error: 'Form not found' }, { status: 404 });
    }

    // Verify tenant access
    if (form.tenantId !== tenant.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    // Soft delete
    const deleted = await prisma.form.update({
      where: { id: formId },
      data: { status: 'DELETED' },
    });

    return NextResponse.json({
      message: 'Form deleted',
      form: deleted,
    });
  } catch (error) {
    console.error('Error deleting form:', error);
    return NextResponse.json(
      { error: 'Failed to delete form' },
      { status: 500 }
    );
  }
}
