import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyAuth, sendUnauthorized } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  try {
    const auth = verifyAuth(req);
    if (!auth.authenticated) return sendUnauthorized();

    const { tenant } = await params;
    const tenantSnake = tenant.replace(/-/g, '_');

    const tenantData = await prisma.tenant.findUnique({ where: { snake: tenantSnake } });
    if (!tenantData) return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });

    const membership = await prisma.membership.findUnique({
      where: { userId_tenantId: { userId: auth.userId as string, tenantId: tenantData.id } },
    });
    if (!membership) return sendUnauthorized();

    const perms = (membership.customPermissions as any) || {};
    const allow = (key: string) => membership.isOwner || membership.isAdmin || perms[key] === true;

    return NextResponse.json({
      forms: {
        create: allow('forms.create'),
        edit: allow('forms.edit'),
        archive: allow('forms.archive'),
      },
      records: {
        create: allow('records.create'),
        edit: allow('records.edit'),
        archive: allow('records.archive'),
        export_all: allow('records.export_all'),
      },
      role: {
        isOwner: membership.isOwner,
        isAdmin: membership.isAdmin,
      }
    });
  } catch (error) {
    console.error('GET /forms/permissions error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
