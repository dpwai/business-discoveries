'use client';

import { useState, useEffect, useCallback } from 'react';
import { useFormPrefill } from './useFormPrefill';
import { useDraftAutosave } from './useDraftAutosave';
import {
  checkLoggedInUser,
  clearUserIdentity,
  clearDraftFromLocalStorage,
  saveDraftToLocalStorage,
  FormDraftData,
  PrefillConfig,
  UserIdentity,
} from './prefill';

/**
 * Comprehensive hook combining prefill + autosave functionality
 * Use this in form components for complete identity and draft management
 */

export interface UseFormWithPrefillConfig extends PrefillConfig {
  formId: string;
  autoSaveInterval?: number;
  onPrefilled?: (data: FormDraftData, identity: UserIdentity | null) => void;
  onError?: (error: Error) => void;
}

export interface UseFormWithPrefillReturn {
  // Prefill state
  prefilled: FormDraftData;
  readOnlyFields: Set<string>;
  userIdentity: UserIdentity | null;
  isDraft: boolean;
  isLoading: boolean;

  // Autosave state
  lastSaved: number | null;
  isSaving: boolean;

  // Form data management
  formData: FormDraftData;
  updateFormData: (data: Partial<FormDraftData>) => void;
  clearFormData: () => void;

  // User management
  logout: () => void;
  switchUser: () => void;

  // Manual operations
  manualSave: () => Promise<void>;
  submitForm: (submitData?: FormDraftData) => FormDraftData;
}

export function useFormWithPrefill(
  config: UseFormWithPrefillConfig
): UseFormWithPrefillReturn {
  const { formId, autoSaveInterval = 5000, onPrefilled, onError, ...prefillConfig } =
    config;

  // Prefill hook
  const prefill = useFormPrefill(formId, prefillConfig);

  // Autosave hook
  const autosave = useDraftAutosave({
    formId,
    interval: autoSaveInterval,
    onError,
  });

  // Local form data state
  const [formData, setFormData] = useState<FormDraftData>({});

  // Initialize form data with prefill
  useEffect(() => {
    if (!prefill.isLoading) {
      const initialData = { ...prefill.prefilled };
      setFormData(initialData);

      // Trigger user callback if provided
      if (onPrefilled) {
        onPrefilled(initialData, prefill.userIdentity);
      }
    }
  }, [prefill.isLoading, prefill.prefilled, prefill.userIdentity, onPrefilled]);

  // Auto-save form data
  useEffect(() => {
    if (!prefill.isLoading && Object.keys(formData).length > 0) {
      autosave._updateData(formData);
    }
  }, [formData, prefill.isLoading, autosave]);

  const updateFormData = useCallback((data: Partial<FormDraftData>) => {
    setFormData((prev) => ({ ...prev, ...data }));
  }, []);

  const clearFormData = useCallback(() => {
    setFormData({});
    autosave.clearDraft();
  }, [autosave]);

  const logout = useCallback(() => {
    clearUserIdentity();
    clearFormData();
    prefill.clearPrefill();
    window.location.reload();
  }, [clearFormData, prefill]);

  const switchUser = useCallback(() => {
    logout();
  }, [logout]);

  const manualSave = useCallback(async () => {
    await autosave.manualSave(formData);
  }, [formData, autosave]);

  const submitForm = useCallback(
    (submitData?: FormDraftData): FormDraftData => {
      const finalData = submitData || formData;

      // Clear draft on successful submit
      clearDraftFromLocalStorage(formId);
      clearFormData();

      return finalData;
    },
    [formData, formId, clearFormData]
  );

  return {
    // Prefill
    prefilled: prefill.prefilled,
    readOnlyFields: prefill.readOnlyFields,
    userIdentity: prefill.userIdentity,
    isDraft: prefill.isDraft,
    isLoading: prefill.isLoading,

    // Autosave
    lastSaved: autosave.lastSaved,
    isSaving: autosave.isSaving,

    // Form data
    formData,
    updateFormData,
    clearFormData,

    // User management
    logout,
    switchUser,

    // Operations
    manualSave,
    submitForm,
  };
}
