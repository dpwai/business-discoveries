/**
 * Rate Limiter Monitoring and Debugging Utilities
 */

import { globalRateLimiter } from "./index";

export interface RateLimitSnapshot {
  timestamp: Date;
  totalKeys: number;
  estimatedMemoryMb: number;
  topLimitedKeys: Array<{
    key: string;
    requestsInWindow: number;
    resetAt: Date;
  }>;
}

export interface RateLimitMetrics {
  totalChecks: number;
  allowedRequests: number;
  blockedRequests: number;
  blockRatePercent: number;
  averageResponseTimeMs: number;
}

class RateLimitMonitor {
  private metrics: RateLimitMetrics = {
    totalChecks: 0,
    allowedRequests: 0,
    blockedRequests: 0,
    blockRatePercent: 0,
    averageResponseTimeMs: 0,
  };

  private responseTimes: number[] = [];
  private maxResponseTimeSamples = 1000;

  /**
   * Record a rate limit check
   */
  recordCheck(allowed: boolean, responseTimeMs: number): void {
    this.metrics.totalChecks++;

    if (allowed) {
      this.metrics.allowedRequests++;
    } else {
      this.metrics.blockedRequests++;
    }

    // Track response time (keep only recent samples)
    this.responseTimes.push(responseTimeMs);
    if (this.responseTimes.length > this.maxResponseTimeSamples) {
      this.responseTimes.shift();
    }

    // Update average
    const totalTime = this.responseTimes.reduce((a, b) => a + b, 0);
    this.metrics.averageResponseTimeMs = totalTime / this.responseTimes.length;

    // Update block rate
    if (this.metrics.totalChecks > 0) {
      this.metrics.blockRatePercent =
        (this.metrics.blockedRequests / this.metrics.totalChecks) * 100;
    }
  }

  /**
   * Get current metrics
   */
  getMetrics(): RateLimitMetrics {
    return { ...this.metrics };
  }

  /**
   * Reset metrics
   */
  resetMetrics(): void {
    this.metrics = {
      totalChecks: 0,
      allowedRequests: 0,
      blockedRequests: 0,
      blockRatePercent: 0,
      averageResponseTimeMs: 0,
    };
    this.responseTimes = [];
  }

  /**
   * Get a snapshot of current rate limiter state
   */
  getSnapshot(): RateLimitSnapshot {
    const storeSize = globalRateLimiter.getSize();

    // Estimate memory usage (rough estimate)
    // Each entry: key (avg 50 bytes) + timestamps array (avg 10 items * 8 bytes)
    const estimatedBytesPerEntry = 50 + 10 * 8;
    const estimatedMemoryBytes = storeSize * estimatedBytesPerEntry;
    const estimatedMemoryMb = estimatedMemoryBytes / (1024 * 1024);

    return {
      timestamp: new Date(),
      totalKeys: storeSize,
      estimatedMemoryMb,
      topLimitedKeys: [], // Would need access to internal store to populate
    };
  }

  /**
   * Print human-readable metrics report
   */
  printMetricsReport(): string {
    const metrics = this.getMetrics();
    const snapshot = this.getSnapshot();

    const report = `
╔════════════════════════════════════════════════════════════════╗
║           RATE LIMITER MONITORING REPORT                       ║
╠════════════════════════════════════════════════════════════════╣
║ Timestamp:                ${snapshot.timestamp.toISOString()}
║ Active Rate Limit Keys:   ${snapshot.totalKeys}
║ Estimated Memory Usage:   ${snapshot.estimatedMemoryMb.toFixed(2)} MB
╠════════════════════════════════════════════════════════════════╣
║ METRICS:
║   Total Checks:           ${metrics.totalChecks.toLocaleString()}
║   Allowed Requests:       ${metrics.allowedRequests.toLocaleString()} (${((metrics.allowedRequests / metrics.totalChecks) * 100).toFixed(2)}%)
║   Blocked Requests:       ${metrics.blockedRequests.toLocaleString()} (${metrics.blockRatePercent.toFixed(2)}%)
║   Avg Response Time:      ${metrics.averageResponseTimeMs.toFixed(3)} ms
╚════════════════════════════════════════════════════════════════╝
    `;

    return report;
  }

  /**
   * Check if rate limiter is healthy
   */
  healthCheck(): {
    healthy: boolean;
    warnings: string[];
  } {
    const warnings: string[] = [];
    const snapshot = this.getSnapshot();
    const metrics = this.getMetrics();

    // Warning: High block rate
    if (metrics.blockRatePercent > 50) {
      warnings.push(
        `⚠️ High block rate: ${metrics.blockRatePercent.toFixed(2)}% of requests are being blocked`
      );
    }

    // Warning: High memory usage
    if (snapshot.estimatedMemoryMb > 100) {
      warnings.push(
        `⚠️ High memory usage: ${snapshot.estimatedMemoryMb.toFixed(2)} MB (consider increasing cleanup frequency)`
      );
    }

    // Warning: High response time
    if (metrics.averageResponseTimeMs > 1) {
      warnings.push(
        `⚠️ High response time: ${metrics.averageResponseTimeMs.toFixed(3)} ms per check`
      );
    }

    // Warning: Many active keys
    if (snapshot.totalKeys > 10000) {
      warnings.push(
        `⚠️ Many active rate limit keys: ${snapshot.totalKeys} (consider Redis for distributed setup)`
      );
    }

    return {
      healthy: warnings.length === 0,
      warnings,
    };
  }
}

// Export singleton monitor instance
export const rateLimitMonitor = new RateLimitMonitor();

/**
 * Middleware to automatically record metrics
 */
export function createMonitoringMiddleware() {
  return (key: string, maxRequests: number, windowMs: number, allowed: boolean) => {
    const start = Date.now();
    const responseTime = Date.now() - start;
    rateLimitMonitor.recordCheck(allowed, responseTime);
  };
}

/**
 * Get formatted health report
 */
export function getHealthReport(): string {
  const health = rateLimitMonitor.healthCheck();
  const metricsReport = rateLimitMonitor.printMetricsReport();

  let healthReport = metricsReport;

  if (!health.healthy) {
    healthReport += "\n⚠️ WARNINGS:\n";
    health.warnings.forEach((warning) => {
      healthReport += `  ${warning}\n`;
    });
  } else {
    healthReport += "\n✅ All systems healthy\n";
  }

  return healthReport;
}

/**
 * Utility: Simulate load for testing
 */
export function simulateLoad(
  numberOfKeys: number = 100,
  requestsPerKey: number = 10
): { duration: number; results: boolean[] } {
  const start = Date.now();
  const results: boolean[] = [];

  for (let i = 0; i < numberOfKeys; i++) {
    const key = `load-test:key-${i}`;
    for (let j = 0; j < requestsPerKey; j++) {
      const result = globalRateLimiter.checkLimit(key, 5, 60000);
      results.push(result.allowed);
    }
  }

  const duration = Date.now() - start;
  return { duration, results };
}
