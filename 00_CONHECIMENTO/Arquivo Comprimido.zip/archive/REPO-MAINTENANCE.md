# Repository Maintenance Guide

**Version**: 1.0
**Date**: January 26, 2026
**Purpose**: Keep the DPWAI repository clean and organized

---

## Quick Reference

### The Golden Rules
1. **All documentation** → `/knowledge/XX-topic/` (never root, except CLAUDE.md)
2. **All scripts** → `/scripts/XX-category/` (never scattered elsewhere)
3. **Application code** → `/dpwaiagro/` (the main app)
4. **Old/unused** → `/knowledge/archive/` (delete immediately if not needed)

### Directory Structure
```
/Users/balzer/dpwai-app2/
├── CLAUDE.md                    (ONLY root .md file - primary guide)
├── README.md                    (Repository entry point)
├── DPWAI_HARDENING_KNOWLEDGE_BASE.md (CRITICAL - keep accessible)
├── dpwaiagro/                   (Next.js application)
├── knowledge/                   (All documentation)
│   ├── 00-overview/             (Platform fundamentals)
│   ├── 01-setup-local/          (Development setup)
│   ├── 02-frontend/             (UI/UX development)
│   ├── 03-backend/              (API & business logic)
│   ├── 04-env-vars/             (Configuration)
│   ├── 05-ci-cd/                (Deployment pipeline)
│   ├── 06-deploy/               (Production deployment)
│   ├── 07-troubleshooting/      (QA & debugging)
│   ├── 08-forms/                (Forms system)
│   ├── 08-security/             (Security documentation)
│   ├── 08-super-admin/          (Admin features)
│   ├── 09-otp-email-system/     (Authentication)
│   ├── 10-implementation-guide/ (Implementation examples)
│   └── archive/                 (Old/obsolete docs)
├── scripts/                     (All automation)
│   ├── db/                      (Database scripts)
│   ├── deploy/                  (Deployment automation)
│   ├── dev/                     (Development utilities)
│   ├── tools/                   (Utility scripts)
│   └── archive/                 (Old scripts)
├── .git/                        (Version control)
└── .github/                     (GitHub configuration)
```

---

## Creating New Documentation

### Step 1: Choose the Right Category

| Goal | Category | Example |
|------|----------|---------|
| New developer setup | `01-setup-local/` | `DOCKER-SETUP.md` |
| Frontend component | `02-frontend/` | `BUTTON-COMPONENT.md` |
| API endpoint | `03-backend/` | `USER-ENDPOINTS.md` |
| Environment variable | `04-env-vars/` | `STRIPE-API.md` |
| Feature implementation | `10-implementation-guide/` | `PAYMENT-SYSTEM.md` |
| Bug fix/workaround | `07-troubleshooting/bug-fixes/` | `MODAL-Z-INDEX-FIX.md` |
| Security concern | `08-security/` | `SQL-INJECTION-AUDIT.md` |
| Project history | `07-troubleshooting/project-history/` | `PHASE-6-SUMMARY.md` |

### Step 2: Create the File

```bash
# Navigate to the right category
cd /Users/balzer/dpwai-app2/knowledge/02-frontend/

# Create your file
touch MY-NEW-COMPONENT.md

# Add content following naming convention:
# Format: TOPIC-SUBTOPIC.md
# Example: BUTTON-COMPONENT.md, DROPDOWN-MENU.md
```

### Step 3: Update INDEX.md

Edit `/Users/balzer/dpwai-app2/knowledge/INDEX.md`:

1. Find the appropriate section
2. Add your new file to the list with a brief description
3. Save the file

Example:
```markdown
### 🎨 [02-frontend/](./02-frontend/) - Frontend Development

- **[BUTTON-COMPONENT.md](./02-frontend/BUTTON-COMPONENT.md)** - Button component usage and customization
- **[MY-NEW-COMPONENT.md](./02-frontend/MY-NEW-COMPONENT.md)** - Description of new component
```

### Step 4: Link from Related Files

Update other documentation files that reference your new content:

```bash
# Search for files that should reference your new doc
grep -r "related topic" /Users/balzer/dpwai-app2/knowledge/

# Add link: [Description](../path/to/MY-NEW-COMPONENT.md)
```

### Step 5: Verify Links

Run link checker (if available):
```bash
# Future enhancement: add link checker script
npm run check:links
```

---

## Creating New Scripts

### Step 1: Choose the Category

| Purpose | Category | Example |
|---------|----------|---------|
| Database migration | `db/` | `migrate-users.ts` |
| Deployment automation | `deploy/` | `deploy-production.sh` |
| Local development | `dev/` | `reset-db.sh` |
| Utility/tool | `tools/` | `generate-token.ts` |
| Testing | `tools/` | `run-tests.sh` |

### Step 2: Create the Script

```bash
# Navigate to the right category
cd /Users/balzer/dpwai-app2/scripts/db/

# Create your script
touch my-new-migration.ts

# Add a clear header comment
```

### Step 3: Add Documentation

Create a `.md` file in the same directory:

```bash
touch my-new-migration.md
```

Contents:
```markdown
# My New Migration

**Purpose**: Brief description

**Usage**:
\`\`\`bash
npm run ts-node scripts/db/my-new-migration.ts
\`\`\`

**Details**:
- What does it do
- Prerequisites
- Expected output
```

### Step 4: Update `/scripts/README.md`

Add your script to the reference:

```markdown
### Database Scripts
- `my-new-migration.ts` - Brief description ([docs](./db/my-new-migration.md))
```

---

## Organizing Existing Documentation

### Moving a File to the Right Category

```bash
# Example: Moving WEBHOOK-SYSTEM-IMPLEMENTATION.md to implementation guide

# 1. Copy to correct location
cp /Users/balzer/dpwai-app2/WEBHOOK-SYSTEM-IMPLEMENTATION.md \
   /Users/balzer/dpwai-app2/knowledge/10-implementation-guide/WEBHOOK-SYSTEM.md

# 2. Verify content is correct
cat /Users/balzer/dpwai-app2/knowledge/10-implementation-guide/WEBHOOK-SYSTEM.md

# 3. Update INDEX.md with new location
# Add to 10-implementation-guide section

# 4. Find and update all references
grep -r "WEBHOOK-SYSTEM-IMPLEMENTATION" /Users/balzer/dpwai-app2/knowledge/
grep -r "WEBHOOK-SYSTEM-IMPLEMENTATION" /Users/balzer/dpwai-app2/CLAUDE.md

# 5. Update those references to point to new location

# 6. Delete original file
rm /Users/balzer/dpwai-app2/WEBHOOK-SYSTEM-IMPLEMENTATION.md

# 7. Git commit
git add -A
git commit -m "docs: reorganize webhook documentation to implementation guide"
```

### Archiving Obsolete Documentation

```bash
# 1. Move to archive
mv /Users/balzer/dpwai-app2/knowledge/my-old-file.md \
   /Users/balzer/dpwai-app2/knowledge/archive/my-old-file.md

# 2. Update INDEX.md to note it's archived

# 3. Git commit
git add -A
git commit -m "docs: archive obsolete documentation"
```

### Deleting Unnecessary Files

```bash
# Only delete if you're SURE it's not needed

# 1. Search for references
grep -r "filename-to-delete" /Users/balzer/dpwai-app2/

# 2. Delete
rm /Users/balzer/dpwai-app2/knowledge/filename-to-delete.md

# 3. Git commit
git add -A
git commit -m "docs: remove obsolete documentation"
```

---

## File Naming Conventions

### Documentation Files

**Format**: `TOPIC-SUBTOPIC.md`

**Examples**:
```
Good:
✅ QUICK-START.md
✅ MOBILE-PATTERNS.md
✅ ERROR-HANDLING-GUIDE.md
✅ DEPLOYMENT-CHECKLIST.md

Avoid:
❌ quick-start.md (should be CAPS)
❌ QuickStart.md (should be kebab-case)
❌ quick_start.md (should be kebab-case, not snake)
❌ QUICKSTART.md (should have hyphen for readability)
```

### Script Files

**Format**: `kebab-case.sh` or `kebab-case.ts`

**Examples**:
```
Good:
✅ deploy-production.sh
✅ reset-demo-user.ts
✅ migrate-users.ts

Avoid:
❌ DeployProduction.sh (should be kebab-case)
❌ deploy_production.sh (should use hyphen)
❌ deployproduction.sh (hard to read)
```

---

## Link Management

### How to Reference Files

**In README files**:
```markdown
See: [My Document](./00-overview/MY-DOCUMENT.md)
See: [Nested Doc](./00-overview/subdir/NESTED-DOC.md)
```

**In knowledge files (same level)**:
```markdown
[Related Doc](./RELATED-DOC.md)
```

**In knowledge files (different level)**:
```markdown
[Frontend Guide](../02-frontend/COMPONENT-LIBRARY.md)
[Setup Instructions](../01-setup-local/QUICK-START.md)
```

**From root CLAUDE.md**:
```markdown
[Knowledge Index](knowledge/INDEX.md)
[Frontend Guide](knowledge/02-frontend/COMPONENT-LIBRARY.md)
```

### Testing Links

**Manual Check**:
1. Open the markdown file
2. Follow each link to verify it works
3. Check that link text is descriptive

**Search for Broken Patterns**:
```bash
# Find broken relative paths
grep -r "\[.*\](.*FILE-THAT-DOESNT-EXIST" /Users/balzer/dpwai-app2/knowledge/

# Find hardcoded absolute paths (should use relative)
grep -r "\/Users\/balzer" /Users/balzer/dpwai-app2/knowledge/
```

---

## Quality Assurance Checklist

### Before Committing Documentation

- [ ] File is in correct `/knowledge/XX-topic/` directory
- [ ] File follows naming convention (CAPS-KEBAB-CASE.md)
- [ ] File has clear, descriptive heading (H1 or H2)
- [ ] File has table of contents (if >3 sections)
- [ ] All links are relative paths (not absolute)
- [ ] All links are verified to work
- [ ] File is added to INDEX.md
- [ ] Related files are updated with references
- [ ] Spelling and grammar checked
- [ ] Code examples are correct
- [ ] Commands are tested (if applicable)

### Before Committing Scripts

- [ ] Script is in correct `/scripts/XX-category/` directory
- [ ] Script has clear header comment
- [ ] Script is documented in category README
- [ ] Corresponding `.md` documentation exists
- [ ] Script has error handling
- [ ] Script is tested to work
- [ ] Script uses relative paths where needed
- [ ] Script has proper permissions (executable if needed)

### Git Workflow

```bash
# 1. Make changes to documentation/scripts
nano /Users/balzer/dpwai-app2/knowledge/02-frontend/NEW-GUIDE.md

# 2. Stage changes
git add /Users/balzer/dpwai-app2/knowledge/02-frontend/NEW-GUIDE.md
git add /Users/balzer/dpwai-app2/knowledge/INDEX.md

# 3. Verify what's staged
git status

# 4. Commit with clear message
git commit -m "docs: add new frontend guide for component patterns"

# 5. Verify commit
git log -1 --stat

# 6. Push to remote
git push origin main
```

---

## Common Maintenance Tasks

### Task: Update Index When Adding New Category

```bash
# 1. Create new directory
mkdir -p /Users/balzer/dpwai-app2/knowledge/XX-newcategory/

# 2. Add README.md
touch /Users/balzer/dpwai-app2/knowledge/XX-newcategory/README.md

# 3. Edit INDEX.md
nano /Users/balzer/dpwai-app2/knowledge/INDEX.md

# Add section:
### 🎯 [XX-newcategory/](./XX-newcategory/) - Category Description
- **[README.md](./XX-newcategory/README.md)** - Overview

# 4. Commit
git add -A
git commit -m "docs: add new documentation category (XX-newcategory)"
```

### Task: Clean Up Root Directory

```bash
# 1. List files that should move
ls -1 /Users/balzer/dpwai-app2/*.md | grep -v "CLAUDE\|README\|DPWAI_HARDENING"

# 2. Move each one
for file in /Users/balzer/dpwai-app2/OLD-FILE-*.md; do
  mv "$file" /Users/balzer/dpwai-app2/knowledge/07-troubleshooting/project-history/
done

# 3. Update INDEX.md with new locations

# 4. Commit
git add -A
git commit -m "docs: reorganize miscellaneous docs to project history"
```

### Task: Verify All Links Work

```bash
# Create a simple link checker script at /scripts/tools/check-links.sh
cat > /Users/balzer/dpwai-app2/scripts/tools/check-links.sh << 'EOF'
#!/bin/bash
# Find all markdown links and verify files exist

cd /Users/balzer/dpwai-app2/knowledge

for file in $(find . -name "*.md"); do
  echo "Checking: $file"
  grep -o "\[.*\](.*\.md)" "$file" | while read line; do
    link=$(echo "$line" | sed 's/.*(\(.*\))/\1/')
    if [ ! -f "$link" ]; then
      echo "  ❌ BROKEN: $link"
    fi
  done
done
EOF

chmod +x /Users/balzer/dpwai-app2/scripts/tools/check-links.sh
./scripts/tools/check-links.sh
```

---

## Repository Hygiene Checklist

### Daily
- [ ] Delete obsolete files immediately
- [ ] Don't create random `.md` files in root
- [ ] All new scripts go to `/scripts/XX-category/`

### Weekly
- [ ] Check for orphaned files (not linked from anywhere)
- [ ] Update INDEX.md if docs were added
- [ ] Verify no `.txt` or `.log` files left in root

### Monthly
- [ ] Full repository cleanliness audit
- [ ] Archive outdated project documentation
- [ ] Update MAINTENANCE.md if processes change
- [ ] Brief team on organization standards

---

## Troubleshooting

### "Where should I put this documentation?"

Use this decision tree:

```
Is it about setting up the local environment?
  → YES: /knowledge/01-setup-local/
  → NO: Continue

Is it about frontend/UI development?
  → YES: /knowledge/02-frontend/
  → NO: Continue

Is it about backend/API development?
  → YES: /knowledge/03-backend/
  → NO: Continue

Is it a bug fix or QA procedure?
  → YES: /knowledge/07-troubleshooting/bug-fixes/
  → NO: Continue

Is it an implementation example or how-to?
  → YES: /knowledge/10-implementation-guide/
  → NO: Continue

Is it historical/archived content?
  → YES: /knowledge/archive/
  → NO: Use closest category or create new category
```

### "I accidentally created a file in the root"

```bash
# 1. Move it to the right place
mv /Users/balzer/dpwai-app2/MY-FILE.md \
   /Users/balzer/dpwai-app2/knowledge/XX-category/MY-FILE.md

# 2. Update any references that pointed to root

# 3. Commit
git add -A
git commit -m "fix: move documentation to appropriate category"
```

### "I can't remember the directory structure"

```bash
# Quick print of structure
tree /Users/balzer/dpwai-app2/knowledge/ -L 1

# Or
ls -la /Users/balzer/dpwai-app2/knowledge/
```

---

## Standards for All Team Members

### Documentation Standards
1. All `.md` files in `/knowledge/XX-topic/` directories
2. Naming: `TOPIC-SUBTOPIC.md` (all caps, hyphens between words)
3. Always update INDEX.md when adding new docs
4. Use relative links (no absolute paths)
5. Test all links before committing

### Script Standards
1. All scripts in `/scripts/XX-category/` directories
2. Naming: `script-name.sh` or `script-name.ts` (lowercase, hyphens)
3. Include clear header comments
4. Create accompanying `.md` documentation
5. Test scripts before committing

### Root Directory Standards
1. Only CLAUDE.md, README.md, and DPWAI_HARDENING_KNOWLEDGE_BASE.md
2. Never create new .md files in root
3. If you need a root file, discuss in PR first
4. Keep .gitignore updated to prevent commits of unwanted files

---

## Automation Opportunities (Future)

These could be automated with scripts:

1. **Link Checker** - Verify all documentation links work
2. **Duplicate Finder** - Find identical content in different files
3. **Orphan Finder** - Find documentation not linked from INDEX.md
4. **Naming Validator** - Ensure consistent naming conventions
5. **Size Analyzer** - Flag documentation files that are too large
6. **Dead Link Remover** - Find and report broken references

---

## Summary

**Keep It Simple**:
1. Documentation → `/knowledge/`
2. Scripts → `/scripts/`
3. Application → `/dpwaiagro/`
4. Root → Only CLAUDE.md, README.md, DPWAI_HARDENING_KNOWLEDGE_BASE.md
5. Old stuff → `/knowledge/archive/`

**When In Doubt**:
- Check INDEX.md for similar documents
- Look at existing file structure
- Ask: "Would future developers understand where this belongs?"

**Remember**:
- Future you will be grateful for good organization
- Teammates will find documentation faster
- Repository stays professional and maintainable

---

**Last Updated**: 2026-01-26
**Maintained By**: Development Team
**Status**: ✅ Active
