# 🔐 Token Validation Guide

## Quick Start

Test all tokens before deploying:

```bash
cd dpwaiagro
npm run test:tokens
```

---

## What Gets Validated

### ✅ DATABASE_URL
- **Checks:** Presence, valid PostgreSQL format
- **Example:** `postgresql://user:pass@host:5432/dbname`
- **Critical:** YES (blocks deploy if missing)

### ✅ JWT_SECRET
- **Checks:** Presence, minimum 32 characters
- **Example:** `your-very-long-random-secret-key-here-at-least-32-chars`
- **Critical:** YES (blocks deploy if missing/too short)

### ✅ NEXT_PUBLIC_APP_URL
- **Checks:** Presence, valid URL format (http/https)
- **Warns:** If using Vercel temp domain in production
- **Example:** `https://app.dpwai.com.br`
- **Critical:** YES (blocks deploy if missing)

### ✅ RESEND_API_KEY
- **Checks:** Presence, valid format (starts with `re_`)
- **Tests:** Can reach Resend API
- **Example:** `re_xxxxxxxxxxxxxxxxxxxx`
- **Critical:** YES (blocks deploy if missing)

### ✅ EMAIL_FROM
- **Checks:** Valid email format (optional, has default)
- **Default:** `DPWAI <noreply@dpwai.com.br>`
- **Example:** `My Company <noreply@company.com>`
- **Critical:** NO (uses default if missing)

---

## Local Testing

### 1. Before Committing

Make sure all required tokens are in your `.env.local`:

```bash
# .env.local
DATABASE_URL=postgresql://user:pass@localhost:5432/dpwai
JWT_SECRET=your-very-long-random-secret-at-least-32-characters
NEXT_PUBLIC_APP_URL=http://localhost:3000
RESEND_API_KEY=re_xxxxxxxxxxxxxxxxxxxx
EMAIL_FROM=Your Company <noreply@yourcompany.com>
```

Then test:

```bash
cd dpwaiagro
npm run test:tokens
```

Expected output:
```
✅ Valid format (localhost)
✅ Valid length (64 chars)
✅ Valid URL (http://localhost:3000)
✅ Valid format
✅ Custom value (Your Company <noreply@yourcompany.com>)
✅ API is reachable

📊 SUMMARY
  ✅ Passed: 6
  ⚠️  Warnings: 0
  ❌ Failed: 0

✅ ALL TOKENS VALID - Ready to deploy!
```

### 2. Common Issues

#### ❌ DATABASE_URL not set
```
❌ Not set in environment
```
**Fix:** Add DATABASE_URL to `.env.local` or GitHub secrets

#### ❌ JWT_SECRET too short
```
⚠️  Too short (16 chars, recommend 32+)
```
**Fix:** Generate a longer secret
```bash
# Generate 64-char random secret
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

#### ❌ NEXT_PUBLIC_APP_URL wrong format
```
❌ Must start with http:// or https://
```
**Fix:** Use full URL
```
NEXT_PUBLIC_APP_URL=https://app.dpwai.com.br
```

#### ❌ RESEND_API_KEY invalid
```
❌ Invalid format (should start with re_)
```
**Fix:** Get fresh key from resend.com dashboard

---

## GitHub Actions Testing

### Before Deploy

The workflow automatically:

1. Runs `npm run test:tokens`
2. Uses secrets from GitHub Actions
3. **Blocks deploy if critical tokens fail**
4. **Warns** if non-critical issues found

### Adding Secrets to GitHub

Go to: `https://github.com/seu-usuario/dpwai-app2/settings/secrets/actions`

Add these 5 secrets:

```
DATABASE_URL        = postgresql://...
JWT_SECRET          = your-secret-here (32+ chars)
NEXT_PUBLIC_APP_URL = https://app.dpwai.com.br
RESEND_API_KEY      = re_xxxxx
EMAIL_FROM          = Your Company <email@domain.com>
```

### Viewing Results

After pushing to `main`:

1. Go to: `github.com/seu-usuario/dpwai-app2/actions`
2. Click the workflow run
3. Scroll to "Validate tokens" step
4. See results

Example output in GitHub Actions:
```
✅ Valid format (database-server)
✅ Valid length (64 chars)
✅ Valid URL (https://app.dpwai.com.br)
✅ Valid format
✅ Using default
✅ API is reachable

✅ ALL TOKENS VALID - Ready to deploy!
```

---

## Production Checklist

Before deploying to production:

- [ ] All 5 tokens configured in Vercel
- [ ] `npm run test:tokens` passes locally
- [ ] GitHub Actions "Validate tokens" step passed
- [ ] Build completed successfully on Vercel
- [ ] Login works end-to-end
- [ ] Password reset email arrives
- [ ] Email has correct NEXT_PUBLIC_APP_URL

---

## Troubleshooting

### Token validation fails but tests pass

Possible causes:
- GitHub secrets not in sync with `.env`
- Secrets added after workflow started (redeploy)
- Network issue reaching Resend API (non-critical)

**Fix:** Redeploy or restart workflow

### Workflow still tries to deploy after token failure

This shouldn't happen - job is configured to fail hard.

**If it does:**
- Check GitHub Actions logs for error
- Verify secrets are properly configured
- Redeploy

### Different behavior local vs CI/CD

Possible causes:
- `.env.local` has different values than GitHub secrets
- `.env` being committed (❌ never do this)
- Environment variables leaking from shell

**Fix:**
- Keep `.env.local` and GitHub secrets in sync
- Never commit `.env`
- Use fresh terminal after changing env vars

---

## Advanced: Extending Validation

To add more token checks:

Edit `/dpwaiagro/scripts/test-tokens.ts`:

```typescript
// Add new validation function
function validateMyToken() {
  const value = process.env.MY_TOKEN;

  if (!value) {
    results.push({
      name: 'MY_TOKEN',
      status: 'fail',
      message: '❌ Not set in environment',
      critical: true, // Block deploy if missing
    });
    return;
  }

  // Add format checks...

  results.push({
    name: 'MY_TOKEN',
    status: 'pass',
    message: '✅ Valid',
    critical: true,
  });
}

// Call in runValidation()
async function runValidation() {
  validateMyToken(); // Add this line
  // ... rest of function
}
```

Then rebuild and test:

```bash
npm run test:tokens
```

---

## Related Files

- **Script:** `/dpwaiagro/scripts/test-tokens.ts`
- **Workflow:** `/.github/workflows/validate.yml`
- **Secrets:** `https://github.com/seu-usuario/dpwai-app2/settings/secrets/actions`
- **Env Reference:** `/knowledge/04-env-vars/ENV-REFERENCE.md`
- **Setup Guide:** `/knowledge/01-setup-local/QUICK-START.md`

---

**Last Updated:** 2026-01-26
