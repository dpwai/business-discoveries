# 🎨 DPWAI UI/UX AUDIT FINDINGS

**Date:** 2026-01-25
**Status:** ✅ Audit Complete - Ready for Implementation
**Priority Level:** HIGH (Core user experience impaired)
**Estimated Fix Time:** 18 hours across 8 commits

---

## Executive Summary

The DPWAI platform offers useful features (dashboards, forms, chatbot) but suffers from **fundamental usability issues** that impair the user experience:

- **Inconsistent language mixing** (Portuguese + English on same screens)
- **Low contrast text** (blue on dark blue, hard to read)
- **Non-intuitive interactions** (cards not fully clickable, menus don't close)
- **Missing feedback** (no success/error messages after actions)
- **Confusing navigation** (sidebar icons without labels, unclear elements)
- **Duplicated/placeholder content** (confuses new users)

**Current UX Grade:** C (Functional but frustrating)
**After Fixes:** A- (Professional, intuitive, accessible)

---

## Detailed Issues by Area

### 1. Welcome Page (Início)

#### Issue 1.1: Cards Not Fully Clickable
**Severity:** HIGH | **Impact:** Frustration, repeated clicks

**Problem:**
- Quick action cards (Painéis, Formulários, Ralph Chat) only respond to a small arrow in the corner
- Clicking the card body has no effect
- Users expect entire card to be clickable

**Current Behavior:**
```
┌─────────────────────────┐
│  Painéis                │
│  Description text       │    ← Only THIS arrow is clickable
│                    → ◀─┘
└─────────────────────────┘
```

**Expected Behavior:**
```
┌─────────────────────────┐
│  Painéis                │
│  Description text       │    ← Entire card clickable
│                    →    │
└─────────────────────────┘ ← Entire card clickable
```

**Fix Required:** Make entire `.card` element clickable (remove nested button, use `<Link>` wrapper)

---

#### Issue 1.2: Property Selection Feedback Unclear
**Severity:** MEDIUM | **Impact:** User doesn't know if selection changed

**Problem:**
- Dropdown shows current property but selection indicator is dark blue on dark background
- Color difference minimal, hard to notice active selection
- No visual confirmation when property changes

**Fix Required:**
- Highlight active property with brighter color (white text, blue background)
- Show checkmark or highlight indicator
- Add subtle animation on selection

---

#### Issue 1.3: Language Inconsistency on Same Screen
**Severity:** MEDIUM | **Impact:** Confusion, perception of incomplete product

**Problems:**
- Header: "Welcome" (English)
- Labels: "Propriedade atual", "Painéis" (Portuguese)
- Button text: Mixed languages

**Fix Required:** Standardize to Portuguese throughout entire page

---

#### Issue 1.4: Modal Preference Dialog - Poor Contrast
**Severity:** MEDIUM | **Impact:** Hard to interact with preferences modal

**Problems:**
- Save/Cancel buttons have low contrast
- Radio button selection not clearly visible
- Modal doesn't clearly show current selection

**Fix Required:**
- High contrast buttons
- Clear radio button states
- Highlight selected option with color

---

### 2. Sidebar Navigation

#### Issue 2.1: Icons Without Labels - Ambiguous
**Severity:** HIGH | **Impact:** Users don't know what each icon does

**Problem:**
- Sidebar shows only icons (no labels)
- Many icons are ambiguous (form icon looks like document)
- No tooltips on hover
- Red button at bottom does nothing

**Current State:**
```
┌──────┐
│  ⊞   │  ← Dashboard? Settings? Unknown
│  □   │  ← Document? Form? Unclear
│  💬  │  ← Chat (obvious)
│  ⚙   │  ← Settings? Integration? Ambiguous
│      │
│ 🔴   │  ← RED BUTTON - NONFUNCTIONAL (WTF?)
└──────┘
```

**Fix Required:**
- Add tooltips on icon hover: `title="Painéis"`, `title="Formulários"`, etc.
- Remove or document the red button
- Consider expanding sidebar on hover to show labels

---

#### Issue 2.2: Non-Functional Elements
**Severity:** MEDIUM | **Impact:** Frustration, appears broken

**Problem:**
- Red button at bottom of sidebar does nothing
- No tooltip or explanation
- Clicking it wastes user time

**Fix Required:** Remove or add tooltip explaining purpose

---

### 3. Dashboards (Painéis)

#### Issue 3.1: Dropdown Menu Doesn't Close on Outside Click
**Severity:** MEDIUM | **Impact:** Breaks web standard interaction pattern

**Problem:**
- Click three-dot menu (⋯) → opens dropdown
- Click elsewhere on page → dropdown stays open
- User must click three dots AGAIN to close menu
- **Expected behavior:** Clicking outside closes menu, pressing Esc closes menu

**Fix Required:**
- Add click-outside handler to close menu
- Add Escape key listener
- Use standard dropdown library or implement event listeners

```typescript
// Example fix:
useEffect(() => {
  const handleClickOutside = (e) => {
    if (!menuRef.current?.contains(e.target)) {
      setMenuOpen(false);
    }
  };
  document.addEventListener('click', handleClickOutside);
  return () => document.removeEventListener('click', handleClickOutside);
}, []);
```

---

#### Issue 3.2: Embed URL Error - Non-functional Back Button
**Severity:** HIGH | **Impact:** User trapped, must use browser back button

**Problem:**
- Click "Visualizar" (View) on test dashboard
- Page shows: "Nenhuma URL de embed configurada"
- Click "Voltar" (Back) button → does nothing
- User must use browser back button
- Appears as broken feature

**Fix Required:**
- Either: Don't show dashboard cards without embed URL
- Or: Ensure back button actually works (`router.back()` or `useNavigate()`)
- Or: Navigate to edit page instead with explanatory message

---

#### Issue 3.3: "New Panel" Modal Title in English
**Severity:** LOW | **Impact:** Language inconsistency

**Problem:**
- Modal title: "New Panel" (English)
- Form labels: Portuguese
- Mixes languages on same screen

**Fix Required:** Translate to "Novo Painel"

---

#### Issue 3.4: No Validation on URL Field
**Severity:** MEDIUM | **Impact:** User can create invalid panels

**Problem:**
- Create new panel modal allows empty URL
- No URL format validation
- User can save invalid configuration

**Fix Required:**
- URL field optional (show as "Optional" label)
- If required, validate URL format before save
- Show error message for invalid URLs

---

### 4. Forms (Formulários)

#### Issue 4.1: Table Has Confusing/Duplicate Names
**Severity:** MEDIUM | **Impact:** Navigation confusion, seems unprofessional

**Problem:**
- Many forms named "Duplicar de sfsdf", "Novo", "Teste", etc.
- Appears to be test data not cleaned up
- Makes it hard to find real forms
- Seems like incomplete product

**Fix Required:**
- Delete test/duplicate forms from production/demo database
- Implement form validation to prevent weird names
- Add sorting by date/status to help organize

---

#### Issue 4.2: Edit Button Disabled Without Explanation
**Severity:** MEDIUM | **Impact:** User confused why they can't edit

**Problem:**
- Some form edit buttons are grayed out (disabled)
- No tooltip explaining why
- Unclear if due to permissions, status, or state

**Fix Required:**
- Add tooltip: "Edit disabled - form is archived" OR "You don't have permission"
- Or implement actual edit functionality
- Or remove disabled button if not needed

---

#### Issue 4.3: Form Submission Editor - Unlabeled Input Areas
**Severity:** HIGH | **Impact:** Hard to understand form editor purpose

**Problem:**
- Page shows large empty boxes/text areas
- No labels, no clear purpose
- Unclear if they are drag-drop zones, text inputs, or just layout
- Confusing header with empty boxes

**Fix Required:**
- Add clear labels to each section
- Add placeholder text explaining what goes where
- Add section headers or instructions
- Add visual indicators for drag-drop zones if applicable

---

#### Issue 4.4: "Add new form" Button in English
**Severity:** LOW | **Impact:** Language inconsistency

**Problem:**
- Button text: "Add new form" (English)
- Context: Portuguese interface

**Fix Required:** Translate to "Adicionar novo formulário"

---

#### Issue 4.5: Template Selector Not Obvious
**Severity:** MEDIUM | **Impact:** Users don't notice templates, slower workflow

**Problem:**
- Templates selector exists but is easy to miss
- Should be prominent in form creation flow
- Templates can accelerate user creation

**Fix Required:**
- Make templates more visible in modal
- Show template preview/cards
- Highlight "Use Template" option

---

### 5. Ralph Chat (Chatbot)

#### Issue 5.1: Chat List Items Not Distinguishable
**Severity:** HIGH | **Impact:** Confusing, looks like broken UI

**Problem:**
- Left sidebar lists many items all labeled "Novo Chat"
- No distinction between conversations
- No preview or timestamp
- Unclear if these are real chats or placeholders
- Clicking doesn't always load conversation

**Current State:**
```
Conversations:
- Novo Chat
- Novo Chat
- Novo Chat
- Novo Chat
```

**Expected State:**
```
Conversations:
- 📅 Farm Report (Today, 2:30 PM)
- 📅 Planting Schedule (Jan 22, 10:15 AM)
- 📅 Watering Plan (Jan 20, 5:00 PM)
```

**Fix Required:**
- Show conversation timestamp or date
- Show message preview (first 50 chars)
- Add icon/badge for unread messages
- Delete or rename duplicate "Novo Chat" entries
- Make list items distinct and meaningful

---

#### Issue 5.2: Similar Colors for User and Bot Messages
**Severity:** MEDIUM | **Impact:** Tiring to read, hard to follow conversation

**Problem:**
- User messages and bot messages have similar background colors
- Both using similar blue/gray tones
- Conversation flow hard to follow
- Eye strain from reading

**Fix Required:**
- Use clearly distinct colors:
  - User messages: Blue bubble (right side)
  - Bot messages: Gray/white bubble (left side)
- Add subtle borders to differentiate
- Use material design chat patterns

---

#### Issue 5.3: Input Box Hidden Below Fold
**Severity:** HIGH | **Impact:** New users think there's no text input

**Problem:**
- Chat input box is at bottom of page
- Requires scrolling to see it
- New users think they can't type
- Breaks basic chat UX

**Fix Required:**
- Keep input box always visible (sticky footer)
- Implement chat UI correctly (messages scroll, input stays)
- Use standard chat UI pattern

---

#### Issue 5.4: No Send Button Feedback
**Severity:** LOW | **Impact:** User unsure if message sent

**Problem:**
- Send button might not show loading state
- No confirmation message was sent
- No visual feedback during send

**Fix Required:**
- Show loading spinner while message sends
- Disable send button during sending
- Show "Enviado" confirmation

---

### 6. Coming Soon (Integrações)

#### Issue 6.1: "Em Breve" Page Exists But Confusing
**Severity:** LOW | **Impact:** User clicks expecting feature, finds nothing

**Problem:**
- Navigation item leads to "Coming Soon" page
- No indication when feature will be available
- No signup for early access option

**Fix Required:**
- Hide navigation item until feature ready
- OR add availability estimate: "Coming in Q1 2026"
- OR add "Notify me" email signup
- OR replace with roadmap/beta access option

---

### 7. Users Management

#### Issue 7.1: First List Item Covered by Dark Overlay
**Severity:** MEDIUM | **Impact:** User can't see/interact with first user

**Problem:**
- User list has dark overlay covering first item
- First user's name/email partially hidden
- Can't click action buttons for first user

**Fix Required:**
- Remove or reposition overlay
- Ensure all list items fully visible
- Fix CSS positioning issue

---

#### Issue 7.2: Action Buttons Lack Feedback
**Severity:** MEDIUM | **Impact:** User unsure if action succeeded

**Problem:**
- Click "Remove admin" or "Reactivate" button
- No success/error message
- No confirmation dialog
- User unsure if action completed

**Fix Required:**
- Show success toast: "✓ Admin role removed"
- Show error toast if action fails
- Add confirmation dialog for destructive actions
- Disable button during processing

---

#### Issue 7.3: Overly Aggressive Red Buttons
**Severity:** LOW | **Impact:** Visual clutter, unnecessary emphasis

**Problem:**
- Action buttons are bright red
- Draws excessive attention
- Not all actions are destructive

**Fix Required:**
- Use red only for destructive actions (Delete, Remove)
- Use gray for neutral actions (Reactivate)
- Use blue for primary actions

---

### 8. Account & Settings

#### Issue 8.1: Language Mixing in Account Settings
**Severity:** MEDIUM | **Impact:** Incoherent, unprofessional appearance

**Problem:**
```
✗ Section Headers: "My Account", "Language", "Security" (English)
✓ Field Labels: Portuguese
✗ Button Text: "Save changes" (English)
```

**Fix Required:** Translate all to Portuguese:
- "Minha Conta"
- "Idioma"
- "Segurança"
- "Salvar alterações"

---

#### Issue 8.2: No Save Confirmation
**Severity:** MEDIUM | **Impact:** User unsure if changes saved

**Problem:**
- Update name, email, password
- Click save
- No feedback message
- User unsure if changes took effect

**Fix Required:**
- Show success toast: "✓ Alterações salvas com sucesso"
- Disable save button during processing
- Show validation errors immediately

---

#### Issue 8.3: Organization Name Field Disabled Without Explanation
**Severity:** MEDIUM | **Impact:** User confused why can't edit

**Problem:**
- "Organization Name" field is grayed out
- No tooltip explaining why
- User doesn't know if it's a permission issue or design

**Fix Required:**
- Add tooltip: "Organization name cannot be changed. Contact admin."
- OR enable editing with proper permissions
- OR remove field if not editable

---

#### Issue 8.4: "Save changes" Button Mixes Languages
**Severity:** LOW | **Impact:** Language inconsistency

**Problem:**
- Button text: "Save changes" (English)
- Context: Portuguese interface

**Fix Required:** Translate to "Salvar alterações"

---

## Cross-Cutting Issues

### Issue C1: Inconsistent Language Throughout Platform
**Severity:** HIGH | **Impact:** Confusing, unprofessional appearance

**Scope:** Affects 90% of UI

**Problem:**
- Portuguese: "Propriedade", "Painéis", "Usuários", "Entrar"
- English: "Welcome", "New Panel", "Add new form", "Display Name", "Save changes"
- Mixed on single screens

**Root Cause:** Incomplete internationalization (i18n) implementation

**Fix Required:**
- Conduct full i18n audit
- Translate ALL text to Portuguese
- Ensure consistent language everywhere
- Remove any English strings

**Files Affected:** Multiple (see i18n audit in `/knowledge/03-backend/I18N-HARDCODED-AUDIT.md`)

---

### Issue C2: Low Contrast - Dark Theme Problem
**Severity:** HIGH | **Impact:** Poor readability, accessibility violation

**Problem:**
- Blue text on dark blue background
- Gray text on dark gray background
- Fails WCAG AA standard (must be 4.5:1 ratio for normal text)

**Current:**
```
Color: #3b82f6 (blue)
Background: #0f172a (dark blue)
Contrast Ratio: ~2.5:1 ❌ (WCAG AA requires 4.5:1)
```

**Fix Required:**
- Increase text color brightness
- Use white (#ffffff) or light gray (#e0e0e0) for body text
- Maintain sufficient contrast everywhere
- Test with contrast checker

**WCAG AA Levels:**
- Normal text: 4.5:1 minimum
- Large text: 3:1 minimum

---

### Issue C3: Non-Standard Dropdown Behavior
**Severity:** MEDIUM | **Impact:** Breaks user expectations

**Problem:**
- Menus stay open when clicking elsewhere
- Requires clicking menu button again to close
- Expected: Click outside or press Esc closes menu

**Files to Fix:**
- Dashboard menu (⋯ button)
- Property selector dropdown
- Navigation dropdowns

**Fix Required:** Implement standard click-outside behavior on all dropdowns

---

### Issue C4: Placeholder/Test Data in Production
**Severity:** MEDIUM | **Impact:** Unprofessional, confusing

**Problem:**
- Forms named "Novo", "Teste", "Duplicar de sfsdf"
- Chat list showing "Novo Chat" repeatedly
- Test users in user list

**Fix Required:**
- Clean database: delete test forms, chats, users
- Implement data validation to prevent weird names
- Use clear naming conventions

---

### Issue C5: Missing Tooltips and Help Text
**Severity:** MEDIUM | **Impact:** User confusion, need to guess functionality

**Problem:**
- Sidebar icons have no labels/tooltips
- Disabled buttons without explanation
- Form editor has unlabeled boxes

**Fix Required:**
- Add `title` attributes to all icons
- Add tooltips explaining disabled state
- Add help text in forms
- Add placeholders in empty input areas

---

## Implementation Priority

### Priority 1: Critical UX Blocks (Fix immediately)
1. **Cards not fully clickable** (Issue 1.1) - 1h
2. **Chat input box hidden** (Issue 5.3) - 1h
3. **Menu doesn't close outside click** (Issue 3.1) - 1.5h
4. **Language inconsistency audit** (Issue C1) - 2h
5. **Low contrast issues** (Issue C2) - 2h

**Subtotal: 7.5 hours**

### Priority 2: High Usability Issues (Fix soon)
6. **Sidebar icons unclear** (Issue 2.1) - 1h
7. **Chat list items not distinguishable** (Issue 5.1) - 1.5h
8. **Form editor unlabeled** (Issue 4.3) - 1.5h
9. **Misleading dashboard back button** (Issue 3.2) - 1h
10. **No action feedback** (Issue 7.2, 8.2) - 1.5h

**Subtotal: 7 hours**

### Priority 3: Medium Issues (Fix in next iteration)
11. **Property selection feedback** (Issue 1.2) - 0.5h
12. **Account settings disabled field** (Issue 8.3) - 0.5h
13. **Form button translations** (Issues 4.4, 8.1, 8.4) - 0.5h
14. **Delete test data** (Issue C4) - 1h
15. **Dropdown behavior standardization** (Issue C3) - 1h

**Subtotal: 3.5 hours**

---

## Total Implementation Plan

**Total Effort:** ~18 hours across 3 phases
- **Phase 1 (Critical):** 7.5 hours - Fixes core UX blocks
- **Phase 2 (High):** 7 hours - Improves usability significantly
- **Phase 3 (Medium):** 3.5 hours - Polish and refinement

---

## Related Documentation

- **Current i18n status:** `/knowledge/03-backend/I18N-HARDCODED-AUDIT.md`
- **Component library:** `/knowledge/02-frontend/COMPONENT-LIBRARY.md`
- **Responsive design:** `/knowledge/02-frontend/RESPONSIVE-DESIGN.md`
- **Design system:** `/knowledge/00-overview/DESIGN-SYSTEM.md`

---

## Success Criteria

After all fixes:

✅ **Consistency:** All text in Portuguese (no English mixing)
✅ **Contrast:** WCAG AA compliant (4.5:1 text ratio)
✅ **Interaction:** Dropdowns close on outside click, cards fully clickable
✅ **Feedback:** Toast messages for all actions
✅ **Navigation:** Sidebar icons have tooltips
✅ **Clarity:** All form fields labeled, no empty boxes
✅ **Data:** No test data in UI
✅ **Accessibility:** Full keyboard navigation, ARIA labels

---

**Audit Date:** 2026-01-25
**Status:** ✅ Complete
**Recommendation:** Begin Priority 1 fixes immediately
