# DPWAIAGRO - Sistema de Gestão Agrícola

Sistema completo de gestão para o agronegócio baseado no TailAdmin.

## 🚀 Tecnologias

- **Next.js 15** - Framework React para produção
- **TypeScript** - Tipagem estática
- **Tailwind CSS v4** - Framework CSS utility-first
- **ApexCharts** - Biblioteca de gráficos
- **FullCalendar** - Calendário interativo
- **Flatpickr** - Seletor de datas
- **React Dropzone** - Upload de arquivos

## 📁 Estrutura do Projeto

```
dpwaiagro/
├── app/
│   ├── (admin)/                 # Páginas administrativas com layout
│   │   ├── layout.tsx          # Layout com sidebar e header
│   │   ├── page.tsx            # Dashboard principal
│   │   ├── products/           # Gestão de produtos
│   │   ├── calendar/           # Calendário
│   │   └── settings/           # Configurações
│   ├── (full-width-pages)/     # Páginas sem sidebar
│   │   ├── (auth)/             # Páginas de autenticação
│   │   │   └── signin/
│   │   └── (error-pages)/      # Páginas de erro
│   │       ├── 404/
│   │       └── 500/
│   ├── layout.tsx              # Layout raiz
│   ├── page.tsx                # Página inicial
│   └── globals.css             # Estilos globais
├── components/
│   ├── ui/                     # Componentes de UI
│   │   ├── Button.tsx
│   │   └── Card.tsx
│   ├── form/                   # Componentes de formulário
│   │   ├── Input.tsx
│   │   ├── Select.tsx
│   │   ├── Textarea.tsx
│   │   ├── Checkbox.tsx
│   │   ├── Switcher.tsx
│   │   └── FileUpload.tsx
│   ├── common/                 # Componentes comuns
│   │   ├── Loading.tsx
│   │   ├── CardDataStats.tsx
│   │   ├── Breadcrumb.tsx
│   │   ├── Alert.tsx
│   │   └── Modal.tsx
│   ├── charts/                 # Componentes de gráficos
│   │   ├── ChartOne.tsx
│   │   └── ChartTwo.tsx
│   ├── tables/                 # Componentes de tabelas
│   │   └── Table.tsx
│   ├── calendar/               # Componentes de calendário
│   │   └── Calendar.tsx
│   └── auth/                   # Componentes de autenticação
│       └── SignIn.tsx
├── layout/                     # Componentes de layout
│   ├── AppHeader.tsx
│   ├── AppSidebar.tsx
│   └── Backdrop.tsx
├── context/                    # Context API
│   ├── SidebarContext.tsx
│   └── ThemeContext.tsx
├── public/
│   └── images/
│       └── icon/
├── next.config.ts              # Configuração Next.js
├── tailwind.config.ts          # Configuração Tailwind
├── postcss.config.js           # Configuração PostCSS
├── prettier.config.js          # Configuração Prettier
├── eslint.config.mjs           # Configuração ESLint
├── jsvectormap.d.ts           # Tipos JsVectorMap
└── svg.d.ts                   # Tipos SVG
```

## 🎨 Recursos

### Componentes UI
- ✅ Botões com variantes (primary, secondary, danger, success, warning)
- ✅ Cards responsivos
- ✅ Alertas informativos
- ✅ Modais personalizáveis
- ✅ Loading states

### Formulários
- ✅ Inputs com validação
- ✅ Selects customizados
- ✅ Textareas
- ✅ Checkboxes
- ✅ Switches/Toggles
- ✅ Upload de arquivos com drag & drop

### Visualização de Dados
- ✅ Gráficos de área (ApexCharts)
- ✅ Gráficos de pizza (ApexCharts)
- ✅ Tabelas responsivas
- ✅ Cards de estatísticas

### Layout
- ✅ Sidebar responsiva
- ✅ Header com busca e notificações
- ✅ Dark mode
- ✅ Breadcrumbs

### Páginas
- ✅ Dashboard com estatísticas
- ✅ Gestão de produtos
- ✅ Calendário interativo
- ✅ Configurações de perfil
- ✅ Páginas de autenticação
- ✅ Páginas de erro (404, 500)

## 🛠️ Instalação

```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev

# Build para produção
npm run build

# Rodar em produção
npm start
```

## 📦 Dependências Principais

- `next` - Framework React
- `react` & `react-dom` - Biblioteca React
- `typescript` - Suporte TypeScript
- `tailwindcss` - Framework CSS
- `apexcharts` & `react-apexcharts` - Gráficos
- `@fullcalendar/*` - Calendário
- `flatpickr` - Date picker
- `react-dropzone` - Upload de arquivos
- `@svgr/webpack` - Importação de SVGs como componentes

## 🎯 Próximos Passos

- Integração com backend/API
- Autenticação completa
- CRUD de produtos
- Gestão de usuários
- Relatórios e exportações
- Internacionalização (i18n)

## 📄 Licença

Este projeto é privado e de propriedade da DPWAI.
