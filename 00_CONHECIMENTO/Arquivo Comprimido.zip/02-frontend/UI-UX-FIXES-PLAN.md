# 🎨 UI/UX FIXES IMPLEMENTATION PLAN

**Start Date:** 2026-01-25
**Total Duration:** ~18 hours
**Risk Level:** LOW - UI/UX fixes, no backend changes
**Status:** Ready for implementation

---

## Overview

This plan fixes 15 core UX issues that impact user experience. Work is organized into 3 phases prioritized by severity.

---

## PHASE 1: CRITICAL UX BLOCKS (7.5 hours)

These fixes address fundamental interaction issues that prevent normal usage.

### Commit 1.1: Make Cards Fully Clickable (1 hour)

**Files to modify:**
- `/dpwaiagro/app/dpwai/[tenant_snake]/welcome/page.tsx`
- `/dpwaiagro/app/dpwai/[tenant_snake]/dashboards/page.tsx`

**Current problematic pattern:**
```tsx
<div className="card">
  <h3>Painéis</h3>
  <p>Description</p>
  <button onClick={() => router.push('/dashboards')}>
    →  {/* Only this arrow is clickable */}
  </button>
</div>
```

**Fix to:**
```tsx
<Link href="/dashboards" className="block card hover:opacity-80 transition">
  <h3>Painéis</h3>
  <p>Description</p>
  <div className="text-right">→</div>
</Link>
```

**Changes:**
- Remove nested button
- Wrap entire card in `<Link>`
- Add `.block` to make link full-size
- Add hover effect for feedback
- Test by clicking card body (should navigate)

**Validation:**
```bash
# Test in browser:
# Click anywhere on card → should navigate
# No console errors
# Hover shows pointer cursor
```

---

### Commit 1.2: Fix Chat Input Box (Always Visible) (1 hour)

**File:** `/dpwaiagro/app/dpwai/[tenant_snake]/chat/page.tsx` (or Chat component)

**Current problematic structure:**
```tsx
<div className="flex flex-col h-screen">
  <ChatMessages messages={messages} />  {/* Scrolls with messages */}
  <ChatInput onSend={handleSend} />      {/* Hidden below fold */}
</div>
```

**Fix to:**
```tsx
<div className="flex flex-col h-screen">
  {/* Messages with flex-grow so they scroll, input stays at bottom */}
  <div className="flex-grow overflow-y-auto">
    <ChatMessages messages={messages} />
  </div>

  {/* Input always visible - sticky footer */}
  <div className="sticky bottom-0 bg-slate-950 border-t border-slate-800 p-4">
    <ChatInput onSend={handleSend} />
  </div>
</div>
```

**Changes:**
- Use `flex-grow` on messages container
- Add `overflow-y-auto` so messages scroll independently
- Make input area `sticky bottom-0`
- Add border/spacing for visual separation
- Ensure input always visible on any screen size

**Validation:**
```bash
# Test:
# 1. Load chat page
# 2. See input box immediately (no scrolling needed)
# 3. Type message - input visible while typing
# 4. Send message - input still visible
# 5. New message appears above - scroll not needed for input
```

---

### Commit 1.3: Fix Dropdown Menu Behavior (1.5 hours)

**Files to modify:**
- `/dpwaiagro/app/dpwai/[tenant_snake]/dashboards/page.tsx` (dashboard menu)
- `/dpwaiagro/components/**/DropdownMenu.tsx` (if it exists)
- Any component with menu/dropdown pattern

**Current problematic pattern:**
```tsx
<button onClick={() => setMenuOpen(!menuOpen)}>⋯</button>
{menuOpen && (
  <div className="dropdown-menu">
    <a>Edit</a>
    <a>Delete</a>
  </div>
)}
```

**Fix to:**
```tsx
const menuRef = useRef(null);

// Close menu on outside click
useEffect(() => {
  const handleClickOutside = (event) => {
    if (menuRef.current && !menuRef.current.contains(event.target)) {
      setMenuOpen(false);
    }
  };

  if (menuOpen) {
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }
}, [menuOpen]);

// Close menu on Escape key
useEffect(() => {
  const handleEscKey = (event) => {
    if (event.key === 'Escape' && menuOpen) {
      setMenuOpen(false);
    }
  };

  if (menuOpen) {
    document.addEventListener('keydown', handleEscKey);
    return () => document.removeEventListener('keydown', handleEscKey);
  }
}, [menuOpen]);

return (
  <div ref={menuRef} className="relative">
    <button
      onClick={() => setMenuOpen(!menuOpen)}
      className="p-2 hover:bg-slate-800 rounded"
    >
      ⋯
    </button>
    {menuOpen && (
      <div className="absolute right-0 mt-1 w-40 bg-slate-900 rounded shadow-lg z-50">
        <a className="block px-4 py-2 hover:bg-slate-800">Edit</a>
        <a className="block px-4 py-2 hover:bg-slate-800">Delete</a>
      </div>
    )}
  </div>
);
```

**Changes:**
- Add `useRef` to track menu element
- Add `mousedown` event listener for click-outside
- Add `keydown` listener for Escape key
- Store listener cleanup functions
- Properly position menu (absolute, right-0)

**Validation:**
```bash
# Test:
# 1. Click menu button (⋯) → opens
# 2. Click elsewhere on page → closes ✓
# 3. Click menu button again → opens
# 4. Press Escape → closes ✓
# 5. Click menu item → closes and executes action ✓
```

---

### Commit 1.4: Language Audit & First Pass Translation (2 hours)

**Scope:** Identify and translate all English strings to Portuguese

**Files to search:**
```bash
# Find all hardcoded English strings:
grep -r "Welcome\|Add new\|Save changes\|Display Name\|New Panel\|Edit\|Delete" \
  /dpwaiagro/app \
  /dpwaiagro/components \
  /dpwaiagro/lib
```

**Common translations needed:**
| English | Portuguese |
|---------|------------|
| Welcome | Bem-vindo |
| Add new form | Adicionar novo formulário |
| Save changes | Salvar alterações |
| Display Name | Nome de Exibição |
| New Panel | Novo Painel |
| Permissions | Permissões |
| Organization | Organização |
| Security | Segurança |
| Language | Idioma |
| My Account | Minha Conta |
| Edit | Editar |
| Delete | Remover |
| Cancel | Cancelar |
| Confirm | Confirmar |

**Changes:**
1. Search codebase for hardcoded English strings
2. Replace with Portuguese equivalents
3. Use translation function if `i18n` exists
4. Update all component text
5. Update all button labels
6. Update all placeholders

**Implementation approach:**
- Use find-and-replace in VS Code for common terms
- Verify each change manually
- Check for context (e.g., "Delete" might be "Remover" or "Excluir")

**Validation:**
```bash
# After changes:
npm run build  # Must pass
# Manual inspection: Visit each page, verify no English text visible
```

---

### Commit 1.5: Fix Text Contrast (Dark Theme) (2 hours)

**Problem:** Blue text on dark blue background is unreadable

**Current colors (example):**
```
Text: #3b82f6 (blue)
Background: #0f172a (dark blue)
Contrast: 2.5:1 ❌
```

**Required contrast:**
```
WCAG AA: 4.5:1 minimum for normal text
WCAG AAA: 7:1 for enhanced contrast
```

**Files to audit:**
- Tailwind color config: `tailwind.config.ts`
- CSS files with color definitions
- Component styles using `text-blue-*` on dark backgrounds

**Fix approach:**

1. **Change text color for readability:**
   ```tsx
   // Current: text-blue-500 (too dark)
   // Change to: text-blue-300 or text-white

   <div className="text-white">Body text</div>  {/* White on dark blue */}
   <div className="text-slate-200">Secondary text</div>  {/* Light gray */}
   <div className="text-slate-400">Tertiary text</div>  {/* Medium gray */}
   ```

2. **Test contrast ratio:**
   - Use WebAIM contrast checker: https://webaim.org/resources/contrastchecker/
   - Verify each text/background combination
   - Update colors until 4.5:1 minimum

3. **Files to check and fix:**
   - All `.text-blue-*` classes on dark backgrounds
   - All `.text-gray-*` that might be too dark
   - Input field labels
   - Button text
   - Link colors

**Validation:**
```bash
# Manual testing:
npm run dev
# Visit each page
# Check readability of all text
# Use browser DevTools color picker to verify ratios
```

---

## PHASE 2: HIGH USABILITY ISSUES (7 hours)

### Commit 2.1: Add Sidebar Icon Tooltips (1 hour)

**File:** `/dpwaiagro/components/Sidebar.tsx` (or similar)

**Current:**
```tsx
<div className="sidebar">
  <IconButton icon={dashboardIcon} />
  <IconButton icon={formIcon} />
  <IconButton icon={chatIcon} />
  <IconButton icon={settingsIcon} />
</div>
```

**Fix to:**
```tsx
<div className="sidebar">
  <div className="group relative">
    <IconButton icon={dashboardIcon} />
    <span className="absolute left-16 bg-slate-800 text-white text-sm rounded px-2 py-1
                     opacity-0 group-hover:opacity-100 transition whitespace-nowrap">
      Painéis
    </span>
  </div>

  <div className="group relative">
    <IconButton icon={formIcon} />
    <span className="absolute left-16 bg-slate-800 text-white text-sm rounded px-2 py-1
                     opacity-0 group-hover:opacity-100 transition whitespace-nowrap">
      Formulários
    </span>
  </div>

  {/* ... other icons ... */}
</div>
```

**Alternative (simpler) - use title attribute:**
```tsx
<IconButton
  icon={dashboardIcon}
  title="Painéis"
  className="hover:cursor-help"
/>
```

**Changes:**
- Add hover tooltip to each icon
- Show label on mouse hover
- Clearly identify what each icon does

---

### Commit 2.2: Make Chat List Items Distinguishable (1.5 hours)

**File:** `/dpwaiagro/app/dpwai/[tenant_snake]/chat/page.tsx` (chat list component)

**Current problematic state:**
```
Conversations:
- Novo Chat
- Novo Chat
- Novo Chat
```

**Fix to:**
```tsx
{conversations.map((conv) => (
  <div
    key={conv.id}
    className="p-3 border-b border-slate-800 hover:bg-slate-900 cursor-pointer"
    onClick={() => selectConversation(conv.id)}
  >
    {/* Date/time */}
    <div className="text-xs text-slate-400 mb-1">
      {formatDate(conv.updatedAt)}
    </div>

    {/* First message preview */}
    <div className="text-sm text-white truncate">
      {conv.messages[0]?.content || 'Conversação vazia'}
    </div>

    {/* Unread badge */}
    {conv.unreadCount > 0 && (
      <span className="inline-block bg-blue-600 text-white text-xs rounded-full
                       w-5 h-5 flex items-center justify-center mt-1">
        {conv.unreadCount}
      </span>
    )}
  </div>
))}
```

**Changes:**
- Show conversation date/timestamp
- Show first message preview (50 chars)
- Add unread count badge
- Remove or rename duplicate "Novo Chat" items
- Make each item visually distinct

---

### Commit 2.3: Label Form Editor Fields (1.5 hours)

**File:** `/dpwaiagro/app/dpwai/[tenant_snake]/forms/[id]/edit/page.tsx` (form editor)

**Current problematic state:**
```
[Large empty box]
[Large empty box]
[Large empty box]
```

**Fix to:**
```tsx
<div className="space-y-6">
  {/* Question title */}
  <div>
    <label className="block text-sm font-medium mb-2">Título da Pergunta</label>
    <input
      type="text"
      placeholder="Ex: Qual é seu nome?"
      className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded"
    />
  </div>

  {/* Question type */}
  <div>
    <label className="block text-sm font-medium mb-2">Tipo de Pergunta</label>
    <select className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded">
      <option>Texto curto</option>
      <option>Parágrafo</option>
      <option>Múltipla escolha</option>
      <option>Checkboxes</option>
    </select>
  </div>

  {/* Field for options (if applicable) */}
  <div>
    <label className="block text-sm font-medium mb-2">Opções</label>
    <div className="space-y-2">
      {options.map((opt, idx) => (
        <input
          key={idx}
          type="text"
          placeholder="Opção"
          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded"
        />
      ))}
      <button onClick={addOption}>+ Adicionar opção</button>
    </div>
  </div>

  {/* Help text for drag/drop if applicable */}
  <div className="p-3 bg-slate-900 border border-slate-700 rounded text-sm">
    💡 Arraste e solte as perguntas para reordenar
  </div>
</div>
```

**Changes:**
- Add clear labels above each input
- Add placeholder text showing examples
- Add section headers
- Explain drag-drop functionality
- Group related fields
- Add helper text and icons

---

### Commit 2.4: Dashboard Visualization Fix (1 hour)

**File:** `/dpwaiagro/app/dpwai/[tenant_snake]/dashboards/[id]/page.tsx` (dashboard view)

**Current problematic behavior:**
- Click "Visualizar" → page shows error "Nenhuma URL de embed configurada"
- Click "Voltar" button → doesn't work
- User must use browser back button

**Fix approach:**

**Option A - Prevent navigation to empty dashboards:**
```tsx
<button
  onClick={() => {
    if (!dashboard.embedUrl) {
      toast.error('Configure uma URL de embed primeiro');
      return;
    }
    router.push(`/dashboards/${dashboard.id}/view`);
  }}
  disabled={!dashboard.embedUrl}
  className="disabled:opacity-50 disabled:cursor-not-allowed"
>
  Visualizar
</button>
```

**Option B - Fix the back button:**
```tsx
{/* In dashboard view page */}
<button
  onClick={() => router.back()}
  className="mb-4 px-4 py-2 bg-slate-800 rounded hover:bg-slate-700"
>
  ← Voltar
</button>

{/* Or use Link */}
<Link href="/dashboards" className="mb-4 px-4 py-2 bg-slate-800 rounded">
  ← Voltar
</Link>
```

**Better approach:**
```tsx
{/* Dashboard view page with check */}
export default function DashboardViewPage() {
  if (!dashboard?.embedUrl) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold mb-4">Nenhuma URL configurada</h2>
        <p className="text-slate-400 mb-6">
          Configure uma URL de embed para visualizar este painel.
        </p>
        <Link
          href="/dashboards"
          className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
        >
          ← Voltar aos Painéis
        </Link>
      </div>
    );
  }

  return (
    <div>
      <Link href="/dashboards">← Voltar</Link>
      <iframe src={dashboard.embedUrl} className="w-full h-screen" />
    </div>
  );
}
```

---

### Commit 2.5: Add Action Feedback (Toast Messages) (1.5 hours)

**Scope:** Add success/error feedback for all actions

**Files to modify:**
- Dashboard: Delete/Edit actions
- Forms: Edit/Delete/Archive actions
- Users: Remove/Reactivate actions
- Settings: Save changes actions

**Pattern to implement:**

```tsx
import toast from '@/lib/toast';  // Or use react-hot-toast, react-toastify, etc.

export async function handleDeleteDashboard(id: string) {
  try {
    const response = await fetch(`/api/dashboards/${id}`, { method: 'DELETE' });

    if (!response.ok) throw new Error('Failed to delete');

    toast.success('✓ Painel removido com sucesso');
    router.refresh();  // Refresh list
  } catch (error) {
    toast.error('✗ Erro ao remover painel: ' + error.message);
  }
}

export async function handleSaveSettings(data) {
  try {
    // Show loading state
    const button = document.querySelector('[data-action="save"]');
    button.disabled = true;
    button.textContent = 'Salvando...';

    const response = await fetch('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(data)
    });

    if (!response.ok) throw new Error('Failed to save');

    toast.success('✓ Alterações salvas com sucesso');
    button.textContent = 'Salvar alterações';
    button.disabled = false;
  } catch (error) {
    toast.error('Erro ao salvar: ' + error.message);
    button.textContent = 'Salvar alterações';
    button.disabled = false;
  }
}
```

**Toast library setup:**
- If using `react-hot-toast`:
  ```bash
  npm install react-hot-toast
  ```

  ```tsx
  // app.tsx
  import { Toaster } from 'react-hot-toast';

  export default function RootLayout() {
    return (
      <html>
        <body>
          <Toaster position="bottom-right" />
          {children}
        </body>
      </html>
    );
  }
  ```

**Changes:**
- Add toast notification on success
- Add toast notification on error
- Show loading state during processing
- Disable button while processing
- Display actual error messages

---

## PHASE 3: MEDIUM ISSUES & POLISH (3.5 hours)

### Commit 3.1: Property Selection Feedback (0.5 hour)

**File:** `/dpwaiagro/app/dpwai/[tenant_snake]/welcome/page.tsx` (property selector)

**Current:**
```tsx
<select className="bg-slate-800 text-blue-500">
  <option>Farm A (not obvious it's selected)</option>
  <option>Farm B</option>
</select>
```

**Fix to:**
```tsx
<select className="bg-slate-800 text-white border-2 border-blue-600">
  <option>Farm A ✓</option>
  <option>Farm B</option>
</select>
```

**Changes:**
- Use white text (better contrast)
- Highlight with blue border
- Add checkmark to active option
- Test selection change is obvious

---

### Commit 3.2: Disabled Fields Tooltip (0.5 hour)

**Files:** Account settings, Organization settings

**Current:**
```tsx
<input disabled value={organizationName} />
```

**Fix to:**
```tsx
<div className="group relative">
  <input
    disabled
    value={organizationName}
    className="opacity-50"
    title="O nome da organização não pode ser alterado. Contate o administrador."
  />
  <span className="absolute bottom-full left-0 bg-slate-800 text-white text-xs
                   rounded px-2 py-1 opacity-0 group-hover:opacity-100 transition">
    Não pode ser alterado
  </span>
</div>
```

**Changes:**
- Add title attribute explaining why disabled
- Add visual tooltip on hover
- Reduce opacity to show it's disabled

---

### Commit 3.3: Button Text Translations (0.5 hour)

**Files:** Multiple (search for these exact strings)

**Translations:**
```
"Save changes" → "Salvar alterações"
"Add new form" → "Adicionar novo formulário"
"New Panel" → "Novo Painel"
"Cancel" → "Cancelar"
"Delete" → "Remover"
"Edit" → "Editar"
"Add option" → "Adicionar opção"
```

**Implementation:**
- Find and replace in codebase
- Verify context
- Test UI doesn't break with longer Portuguese text

---

### Commit 3.4: Clean Up Test Data (1 hour)

**Database cleanup:**

1. **Delete test forms:**
   ```sql
   DELETE FROM forms
   WHERE name LIKE 'Novo%'
   OR name LIKE 'Duplicar%'
   OR name LIKE 'Teste%';
   ```

2. **Delete test chats:**
   ```sql
   DELETE FROM chats
   WHERE name = 'Novo Chat'
   AND message_count = 0;
   ```

3. **Delete test users:**
   ```sql
   DELETE FROM users
   WHERE email LIKE 'test%'
   OR email LIKE 'demo%';
   ```

4. **Manual cleanup:**
   - Log in to app
   - Rename or delete duplicate items
   - Verify clean state

---

### Commit 3.5: Standardize Dropdown Behavior (1 hour)

**Apply to all dropdowns in codebase:**
- Property selector
- Form type selector
- User role selector
- Any menu component

**Standard pattern:**
```tsx
// All dropdowns should use this pattern
const [open, setOpen] = useState(false);
const ref = useRef(null);

useEffect(() => {
  const handleClickOutside = (e) => {
    if (ref.current && !ref.current.contains(e.target)) setOpen(false);
  };

  if (open) {
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }
}, [open]);

// Escape key
useEffect(() => {
  const handleEsc = (e) => {
    if (e.key === 'Escape') setOpen(false);
  };

  if (open) {
    document.addEventListener('keydown', handleEsc);
    return () => document.removeEventListener('keydown', handleEsc);
  }
}, [open]);

// Render...
```

---

## ✅ VALIDATION CHECKLIST

After all 8 commits:

- [ ] All cards fully clickable (welcome, dashboards)
- [ ] Chat input always visible (no scrolling needed)
- [ ] Dropdowns close on outside click
- [ ] Dropdowns close on Escape key
- [ ] All text in Portuguese (no English visible)
- [ ] Text contrast ≥4.5:1 (WCAG AA)
- [ ] Sidebar icons have hover tooltips
- [ ] Chat list shows timestamps and previews
- [ ] Form editor fields clearly labeled
- [ ] Dashboard "Nenhuma URL" case handled properly
- [ ] All actions show toast feedback
- [ ] Property selection shows clear feedback
- [ ] Disabled fields have explanatory tooltip
- [ ] All buttons translated to Portuguese
- [ ] No test data visible in UI
- [ ] All dropdowns behave consistently
- [ ] `npm run build` passes with no errors
- [ ] No console errors in DevTools
- [ ] Manual testing: All pages work end-to-end

---

## Testing Strategy

### Manual Testing
1. Test each page/feature mentioned in audit
2. Click all buttons and menus
3. Verify feedback messages appear
4. Test on desktop (1920x1080) and mobile (375x667)
5. Check keyboard navigation (Tab, Enter, Escape)

### Accessibility Testing
- [ ] Color contrast verified (WebAIM checker)
- [ ] All inputs have labels
- [ ] All images have alt text
- [ ] Focus indicators visible
- [ ] Keyboard navigation complete

### Build Verification
```bash
npm run build
# Must pass with no errors
```

---

## Rollout Strategy

1. **Stage 1:** Deploy Commits 1.1-1.5 (Phase 1 - Critical)
   - Test in staging
   - Get user feedback
   - Fix any regressions

2. **Stage 2:** Deploy Commits 2.1-2.5 (Phase 2 - High)
   - Continue staging tests
   - Ensure dropdown behavior consistent
   - Verify toast messages working

3. **Stage 3:** Deploy Commits 3.1-3.5 (Phase 3 - Polish)
   - Final testing
   - Clean database
   - Deploy to production

---

## Success Metrics

- ✅ Zero "This feels broken" feedback from users
- ✅ No confusion about clickable areas
- ✅ All text readable and in Portuguese
- ✅ Keyboard navigation working
- ✅ Mobile-friendly interaction patterns
- ✅ Actions provide clear feedback
- ✅ WCAG AA accessibility compliance

---

**Status:** Ready for implementation
**Start:** Copy prompt from `/dpwaiagro/UI-UX-FIXES-PROMPT.md`
