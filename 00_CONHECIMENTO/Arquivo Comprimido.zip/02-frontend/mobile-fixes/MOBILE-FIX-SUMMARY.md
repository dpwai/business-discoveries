# Mobile UI/UX Fixes - Summary

## ✅ COMPLETED: Phase 1 - I18N Audit

### Fixed Hardcoded English Strings
- ✅ `automated-entries/page.tsx` - "Integrations in progress" → `t('automated.coming-soon')`
- ✅ `users/page.tsx` - "Owner"/"Admin"/"User" badges → `t('users.owner')` / `t('users.admin')` / `t('users.user')`
- ✅ `components/users/UserCard.tsx` - Same role badge fixes
- ✅ `lib/i18n/translations.ts` - Added 'automated' namespace + fixed PT translations

### Translations Updated
- Added keys: `automated.coming-soon`, `automated.setting-up`, `automated.contact-support`
- Fixed PT translations: Changed "Owner" → "Proprietário", "Admin" → "Administrador"
- All UI now consistent Portuguese (PT-BR) when locale is pt

### Files Modified
1. `lib/i18n/translations.ts` - Added automated keys, fixed role translations
2. `app/dpwai/[tenant_snake]/automated-entries/page.tsx` - Now uses i18n
3. `app/dpwai/[tenant_snake]/users/page.tsx` - Role badges use i18n
4. `components/users/UserCard.tsx` - Role labels use i18n

### Commit
- `feat(i18n): Standardize Portuguese UI strings and fix hardcoded English`

---

## ⏳ IN PROGRESS: Phase 2-5 (Mobile Layout & Polish)

### Remaining Work

#### Phase 2: Forms Mobile Layout
- [ ] Update `forms/page.tsx` to be mobile-responsive
- [ ] Update `forms/[formId]/page.tsx` header to be responsive
- [ ] Update `FormBuilder` component for mobile (hide columns on small screens)
- [ ] Add sticky bottom action bar with Save button for mobile

#### Phase 3: Upload Widget
- [ ] Check `components/form/FileUpload.tsx` for mobile issues
- [ ] Ensure layout doesn't overflow on mobile
- [ ] Add error handling and retry logic

#### Phase 4: Users Modal Mobile
- [ ] Verify modal scrolling on small viewports (360-430px)
- [ ] Ensure buttons stay reachable (44px minimum)

#### Phase 5: Mobile Polish
- [ ] Fix footer centering in layout.tsx
- [ ] Fix sidebar collapse behavior
- [ ] Add global CSS guards for mobile overflow
- [ ] Verify all tap targets >= 44px

---

## Architecture Notes

### Components Using i18n
All components now using `useLanguage()` hook:
- `automated-entries/page.tsx`
- `users/page.tsx`
- `components/users/UserCard.tsx`

### Dark Theme Status
- ✅ `automated-entries/page.tsx` - Updated to dark (slate-950/slate-900)
- ⏳ `forms/page.tsx` - Still using light theme (white/gray-50)
- ⏳ `forms/[formId]/page.tsx` - Still using light theme
- ⏳ `FormBuilder` - Still using light theme

### Mobile Responsive Status
- ✅ `users/page.tsx` - Has responsive layout (table on desktop, cards on mobile)
- ⏳ `FormBuilder` - Using 3-column grid (breaks on mobile)
- ⏳ `forms/page.tsx` - Using grid layout (might be OK)

---

## QA Checklist (Mobile - iPhone 360-430px)

### Phase 1 (I18N) ✅
- [x] Automated-entries shows Portuguese text ("Em Breve", not "Coming Soon")
- [x] Users page shows Portuguese role labels ("Proprietário", "Administrador", "Usuário")
- [x] UserCard shows Portuguese text

### Phase 2 (Forms) - TODO
- [ ] Forms list loads without horizontal scroll
- [ ] Create form modal works on mobile
- [ ] Form editor opens without breaking layout
- [ ] Save button always visible and tappable (44px+)

### Phase 3 (Upload) - TODO
- [ ] File upload widget fits on 360px viewport
- [ ] Long filenames wrap (don't overflow)
- [ ] File list scrolls internally if needed
- [ ] Remove file button tappable

### Phase 4 (Users Modal) - TODO
- [ ] Users create modal scrolls on small screens
- [ ] All input fields visible without horizontal scroll
- [ ] Save/Cancel buttons always reachable

### Phase 5 (Polish) - TODO
- [ ] Footer centered on mobile/desktop
- [ ] Sidebar collapse doesn't break icon sizing
- [ ] No horizontal scrolling on any screen
- [ ] All buttons/links >= 44px touch targets

---

## Technical Decisions

### I18N Implementation
- Used existing `useLanguage()` hook
- Added to `useLanguage()` import in affected components
- All hardcoded English strings replaced with `t()` calls
- PT translations verified and fixed in `translations.ts`

### Dark Theme Updates
- Using slate colors (slate-950, slate-900, slate-800, slate-400, slate-500)
- Consistent with existing dark theme pattern in codebase
- Proper contrast for readability

### Responsive Patterns Used
- Existing `hidden md:block` pattern for desktop/mobile views
- `glass-card` component for styled cards
- Tailwind responsive classes (md:, lg:, etc.)

---

## Known Issues to Address

1. **FormBuilder 3-column layout** - Needs responsive mode for mobile
2. **Forms page light theme** - Should be dark theme like the rest
3. **Forms editor header** - Title input might push buttons on narrow screens
4. **No "Submit" button** - User task mentioned "Submit" button missing (need to clarify)

---

## References

- i18n keys: `/lib/i18n/translations.ts`
- User component pattern: `/components/users/UserCard.tsx`
- Dark theme colors: Check `tailwind.config.ts` for design tokens

