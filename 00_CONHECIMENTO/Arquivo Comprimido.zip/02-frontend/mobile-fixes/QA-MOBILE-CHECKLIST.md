# Mobile QA Checklist - DPWAI Agro

**Last Updated**: 25 January 2026
**Tested Viewports**: iPhone 12 (390px), iPhone SE (375px), Small Android (360px)

---

## 🧪 QA Test Cases

### Test 1: Navigation & I18N (Portuguese)
**Objective**: Verify all UI strings are in Portuguese, no English leaks

**Steps**:
1. Open app in Portuguese locale
2. Navigate to: Forms → Automated-Entries → Users → Dashboards
3. Check sidebar menu labels
4. Open any modal (create form, create user)

**Expected Results**:
- ✅ All menu items in Portuguese
- ✅ "Entradas Automatizadas" (not "Automated Inputs")
- ✅ Users page shows "Proprietário", "Administrador", "Usuário" (not Owner, Admin, User)
- ✅ Role badges use Portuguese labels
- ✅ No English strings visible

**Pass/Fail**: ___

---

### Test 2: Forms List - Mobile Layout (iPhone 360-390px)
**Objective**: Forms list is readable and usable on small screens

**Steps**:
1. Navigate to Forms page
2. Inspect viewport: Should be 360-390px wide
3. Scroll vertically (no horizontal scroll!)
4. Try creating a form:
   - Click "Novo Formulário" button
   - Modal should be centered and scrollable
   - Input fields should be readable
   - Save/Cancel buttons should be tappable

**Expected Results**:
- ✅ No horizontal scroll
- ✅ Forms list shows 1 column on mobile
- ✅ Cards have proper padding
- ✅ "Novo Formulário" button full-width or sticky
- ✅ Create modal fits screen
- ✅ Buttons >= 44px height
- ✅ Input fields have focus ring

**Pass/Fail**: ___

---

### Test 3: Dark Theme Consistency
**Objective**: All screens use dark theme colors consistently

**Steps**:
1. Navigate through all screens:
   - Forms list
   - Forms editor
   - Users list
   - Automated-Entries
   - Dashboards
   - Account/Settings
2. Check for any white/light gray backgrounds
3. Check text contrast

**Expected Results**:
- ✅ All backgrounds slate-900 or slate-950
- ✅ All text white or slate-200/slate-400
- ✅ No white cards unless intentional
- ✅ All inputs have dark backgrounds (slate-800)
- ✅ Focus states visible (green/blue ring)
- ✅ Text contrast >= 4.5:1 (AA standard)

**Pass/Fail**: ___

---

### Test 4: Forms Editor - Mobile
**Objective**: Form builder is usable on mobile (or shows helpful message)

**Steps**:
1. Create a form or open existing form
2. On mobile viewport (360-390px):
   - Click form name (should be editable)
   - Try adding a field (if UI available)
   - Scroll the form builder
   - Look for Save button

**Expected Results**:
- ✅ Form name is readable
- ✅ No horizontal scrolling
- ✅ If form builder is complex, it shows helpful message on mobile
- ✅ Save button is visible and tappable (44px+)
- ✅ Scrolling works smoothly

**Pass/Fail**: ___

---

### Test 5: Users Modal - Mobile
**Objective**: Users create/edit modal is usable on small screens

**Steps**:
1. Navigate to Users page
2. Click "Novo Usuário" button
3. On mobile (360-390px):
   - Modal should appear centered
   - Scroll through all fields:
     - Nome
     - Sobrenome
     - Email
     - Telefone
     - Senha inicial
     - Checkbox "Tornar administrador"
   - Buttons (Cancel, Save) should be visible and tappable

**Expected Results**:
- ✅ Modal centered and readable
- ✅ All fields visible when scrolled
- ✅ No fields cut off or hidden
- ✅ Buttons >= 44px height
- ✅ No horizontal scrolling
- ✅ Input fields have good focus states
- ✅ Save button disabled if required fields empty

**Pass/Fail**: ___

---

### Test 6: Tap Targets & Accessibility
**Objective**: All interactive elements are >= 44px

**Steps**:
1. Using browser dev tools, check these elements on mobile:
   - Buttons in headers
   - Buttons in modals
   - Icons with click handlers
   - Links in sidebars
2. Use Inspector → Elements panel to measure
3. Try tapping with thumb (harder than mouse)

**Expected Results**:
- ✅ All buttons/links >= 44px in both dimensions
- ✅ Proper spacing between clickable areas
- ✅ No overlapping tap targets
- ✅ Cursor changes to pointer on hover
- ✅ Focus states visible

**Pass/Fail**: ___

---

### Test 7: Form Submission (Upload Widget if exists)
**Objective**: File upload works on mobile

**Steps**:
1. If form has file upload field:
   - On mobile, click file input
   - System should show file picker
   - Select a file
   - File should show in preview
   - Should be able to remove file
   - Submit button should be accessible

**Expected Results**:
- ✅ File picker opens
- ✅ Selected file shows with name (wraps if long)
- ✅ Remove button is tappable
- ✅ No layout breaks
- ✅ Form still scrollable

**Pass/Fail**: ___

---

### Test 8: Footer Alignment
**Objective**: Footer is centered on all screen sizes

**Steps**:
1. Open any page with footer
2. On mobile (360px): Check footer alignment
3. On tablet (768px): Check footer alignment
4. On desktop (1024px): Check footer alignment
5. Scroll page and check footer stays aligned

**Expected Results**:
- ✅ Footer content centered
- ✅ No horizontal scroll due to footer
- ✅ Footer aligned left/center/right consistently
- ✅ Footer links are tappable (44px+)

**Pass/Fail**: ___

---

### Test 9: Sidebar Collapse (Mobile)
**Objective**: Sidebar doesn't interfere with content on mobile

**Steps**:
1. On mobile, click hamburger menu (if exists)
2. Sidebar should open overlay or drawer
3. Content should be readable
4. Close sidebar
5. Try clicking a sidebar link

**Expected Results**:
- ✅ Sidebar opens without pushing content
- ✅ Close button is accessible
- ✅ Clicking link navigates
- ✅ Icons remain readable (not too small)
- ✅ No overflow or clipping

**Pass/Fail**: ___

---

### Test 10: No Horizontal Scrolling (Critical!)
**Objective**: App works without horizontal scrolling at 360px width

**Steps**:
1. Set viewport to 360px width
2. Visit each screen:
   - Forms list
   - Create form modal
   - Users list
   - Automated-Entries
   - Dashboards
3. Inspect with Developer Tools
4. Try scrolling horizontally (shouldn't be possible)

**Expected Results**:
- ✅ No horizontal scroll bars
- ✅ Content fits within viewport
- ✅ Text wraps appropriately
- ✅ Buttons stack or shrink properly
- ✅ No overflow:hidden hiding content

**Pass/Fail**: ___

---

## 📋 Test Scenarios

### Scenario A: New User Creates First Form
1. Log in
2. Navigate to Forms
3. Click "Novo Formulário"
4. Fill in form name: "Pesquisa de Satisfação"
5. Select type: "Apenas Dados"
6. Click Criar
7. Form should be created and added to list

**Acceptance**: ✅ Form created successfully on mobile

---

### Scenario B: User Changes Language
1. Navigate to Account/Settings
2. Find Language selector
3. Switch to English
4. All UI should switch to English
5. Switch back to Portuguese
6. All UI should be Portuguese

**Acceptance**: ✅ Language switching works on mobile

---

### Scenario C: User Opens Complex Modal
1. Open Users page
2. Click "Novo Usuário"
3. On mobile, modal should:
   - Be scrollable internally
   - Show all fields when scrolled
   - Buttons accessible
   - No fields cut off

**Acceptance**: ✅ Modal fully functional on mobile

---

## 🔧 DevTools Tests (Optional)

### Lighthouse Mobile Audit
1. Open DevTools → Lighthouse
2. Run Mobile audit
3. Check metrics:
   - Performance > 80
   - Accessibility > 80
   - Best Practices > 80

### Viewport Testing
1. DevTools → Device Emulation
2. Test these devices:
   - iPhone SE (375px)
   - iPhone 12 (390px)
   - iPhone 14 (390px)
   - Pixel 5 (393px)
   - Pixel 6 (412px)

### Responsive Design Mode
1. DevTools → Responsive Design Mode
2. Custom: 360px width
3. Verify no horizontal scroll

---

## ✅ Sign-Off

| Component | Tested By | Date | Pass/Fail | Notes |
|-----------|-----------|------|-----------|-------|
| I18N (Portuguese) | ___ | ___ | ___ | |
| Forms Mobile | ___ | ___ | ___ | |
| Dark Theme | ___ | ___ | ___ | |
| Users Modal | ___ | ___ | ___ | |
| Tap Targets | ___ | ___ | ___ | |
| Footer | ___ | ___ | ___ | |
| Sidebar | ___ | ___ | ___ | |
| No Horizontal Scroll | ___ | ___ | ___ | |
| Upload Widget | ___ | ___ | ___ | |
| Overall UX | ___ | ___ | ___ | |

---

## 📝 Notes

- All tests should be performed on real devices if possible
- Use Safari on iOS for accurate testing
- Check both portrait and landscape orientations
- Test with both light and dark system preferences
- Verify accessibility with VoiceOver (iOS)

---

**Created**: 25 January 2026
**For**: DPWAI Agro Mobile Testing
**Version**: 1.0
