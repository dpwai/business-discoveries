# CI/CD Pipeline Documentation

## Overview

The DPWAI Agro platform uses a continuous integration and deployment pipeline combining **GitHub Actions** for light validation and **Vercel** for automatic deployment and hosting.

## Deployment Flow

```
Developer Push to main
        ↓
GitHub Actions (light validation)
        ↓
Vercel Webhook Trigger
        ↓
Build Process (Prisma generate + Next.js build)
        ↓
Automatic Deployment
        ↓
Production: app.dpwai.com.br
```

### Step-by-Step

1. **Developer Push** → GitHub repository (main branch)
2. **GitHub Actions** → Runs minimal validation checks (if configured)
3. **Vercel Webhook** → Automatically triggered on main branch push
4. **Build Process** →
   - `npx prisma generate` - Generate Prisma client
   - `next build` - Build Next.js application
5. **Production Deploy** → Deployment to `app.dpwai.com.br`
6. **DNS Resolution** → Hostinger CNAME points to Vercel

## GitHub Actions

**Location:** `.github/workflows/`

Currently, the repository has minimal CI/CD validation configured. GitHub Actions could be enhanced with:

- **Linting** - ESLint validation
- **Type Checking** - TypeScript strict mode verification
- **Unit Tests** - Run all unit tests
- **Integration Tests** - End-to-end testing
- **Build Validation** - Ensure build completes without errors

### Current Setup

- Light validation or no validation (configured via Vercel)
- Focus on deployment automation rather than pre-deployment checks

## Vercel Deployment

**Hosting:** Vercel (primary production host)
**Domain:** `app.dpwai.com.br`
**Environment:** Production

See `/knowledge/06-deploy/VERCEL-DEPLOYMENT.md` for detailed Vercel configuration, environment variables, and deployment settings.

### Environment Variables

All sensitive environment variables are set in the **Vercel Dashboard** (never committed to git):

- `DATABASE_URL` - PostgreSQL connection string
- `JWT_SECRET` - Authentication secret
- `RESEND_API_KEY` - Email service API key
- `NEXT_PUBLIC_APP_URL` - Public application URL

See `/knowledge/04-env-vars/ENV-REFERENCE.md` for the complete environment variable reference.

## Build Commands

### Local Build Test

Test that your code builds locally before pushing:

```bash
cd dpwaiagro

# Install dependencies (if not already done)
npm install

# Run local build (same as Vercel)
npm run build

# Or step-by-step:
npx prisma generate  # Generate Prisma client
next build           # Build Next.js application
```

### Vercel Build Process

When deployed to Vercel, the build process runs:

```bash
# Install dependencies (automatic)
npm install

# Build command (configured in Vercel settings)
npm run build

# This internally runs:
# - Next.js TypeScript compilation
# - Prisma client generation
# - Output optimization
```

### Build Optimization

- **Output Directory:** `.next/` (automatically configured)
- **Node Version:** Specified in `.nvmrc` or Vercel settings
- **Build Duration:** ~2-5 minutes typical
- **Cache:** Vercel caches dependencies between builds (faster deployments)

## Monitoring & Logs

### Vercel Dashboard

1. **Build Logs** - View real-time build output
2. **Deployment Status** - Success/failure of each deployment
3. **Analytics** - Performance metrics, request data
4. **Preview URLs** - Temporary URLs for pull request previews (if enabled)

Access: https://vercel.com/dashboards/dpwai

### GitHub Integration

- **Deployment Status** - GitHub shows deployment status on commits
- **Pull Request Previews** - Vercel can create preview deployments for PRs

### Monitoring Production

- **Vercel Monitoring** - Built-in performance monitoring
- **Application Logs** - Available in Vercel dashboard
- **Error Tracking** - Sentry can be integrated for advanced error monitoring

## Troubleshooting

### Build Failures

**Common Issues:**

1. **Prisma Schema Errors**
   - Fix: Verify `dpwaiagro/prisma/schema.prisma` is valid
   - Command: `npx prisma validate`

2. **Missing Environment Variables**
   - Fix: Ensure all required variables are set in Vercel dashboard
   - See: `/knowledge/04-env-vars/ENV-REFERENCE.md`

3. **Type Errors**
   - Fix: Run `npm run build` locally to catch TypeScript errors early
   - Command: `cd dpwaiagro && npm run build`

4. **Node Version Mismatch**
   - Fix: Specify Node version in `.nvmrc` if needed
   - Current: Node 18+ recommended

### Deployment Stuck

1. Check Vercel dashboard for build status
2. Look for error messages in build logs
3. Verify all environment variables are set
4. Try manual redeploy from Vercel dashboard
5. Contact Vercel support if persistent

### Rollback to Previous Version

1. Go to Vercel dashboard
2. Find previous successful deployment
3. Click "Redeploy" on that deployment
4. Or use GitHub to revert commit and push

## Related Documentation

- [Deployment Overview](/knowledge/06-deploy/DEPLOYMENT-OVERVIEW.md) - Complete deployment guide
- [Vercel Deployment](/knowledge/06-deploy/VERCEL-DEPLOYMENT.md) - Detailed Vercel setup
- [Environment Variables](/knowledge/04-env-vars/ENV-REFERENCE.md) - All environment variable reference
- [Deployment Checklist](/knowledge/06-deploy/DEPLOYMENT-CHECKLIST.md) - Pre-launch verification
- [Architecture](/knowledge/00-overview/ARCHITECTURE.md) - System design and tech stack

## Maintenance

### Regular Tasks

- **Monitor builds** - Check Vercel dashboard weekly
- **Review logs** - Check application logs for errors
- **Update dependencies** - Keep Node packages updated
- **Test builds locally** - Before pushing to main

### Future Enhancements

- [ ] Add GitHub Actions for linting and type checking
- [ ] Configure pull request preview deployments
- [ ] Add Sentry for error tracking
- [ ] Setup automated testing in CI pipeline
- [ ] Add performance monitoring alerts

---

**Last Updated:** January 25, 2026
**Status:** ✅ Production Ready
**Next Review:** February 2026
