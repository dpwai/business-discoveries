# 🔌 API Reference

**Complete reference for all API endpoints in DPWAI Agro.**

**Status**: 🟢 Complete
**Last Updated**: 25 January 2026
**Base URL**: http://localhost:3000 (local) or https://app.dpwai.com.br (prod)

---

## Authentication Endpoints

### POST /api/auth/login
**Login with email or username**

Request:
```json
{
  "email": "user@example.com",
  "password": "Teste@123456"
}
```

Response (200 OK):
```json
{
  "accessToken": "eyJhbGci...",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "firstName": "João"
  },
  "tenant": {
    "id": "uuid",
    "name": "Demo Tenant",
    "snake": "demo-tenant"
  }
}
```

Errors:
- 404: User not found
- 401: Invalid password
- 400: Missing email/password

---

### POST /api/auth/logout
**Logout (invalidate session)**

Request:
```bash
Authorization: Bearer <token>
```

Response (200 OK):
```json
{ "success": true }
```

---

### POST /api/auth/forgot-password
**Request password reset**

Request:
```json
{
  "email": "user@example.com"
}
```

Response (200 OK):
```json
{
  "success": true,
  "message": "Email de reset enviado",
  "resetToken": "token-here"
}
```

---

### POST /api/auth/reset-password
**Complete password reset**

Request:
```json
{
  "token": "reset-token",
  "newPassword": "NewPass@123"
}
```

Response (200 OK):
```json
{
  "success": true,
  "message": "Senha atualizada com sucesso"
}
```

Errors:
- 400: Invalid or expired token
- 400: Password too weak

---

### POST /api/auth/switch-tenant
**Switch to different tenant**

Request:
```bash
Authorization: Bearer <token>

Body:
{
  "tenantId": "tenant-uuid"
}
```

Response (200 OK):
```json
{
  "accessToken": "new-token-with-tenant-id",
  "tenant": { ... }
}
```

---

### GET /api/auth/me/tenants
**Get user's available tenants**

Request:
```bash
Authorization: Bearer <token>
```

Response (200 OK):
```json
{
  "tenants": [
    {
      "id": "uuid",
      "name": "Demo Tenant",
      "snake": "demo-tenant",
      "role": "ADMIN"
    }
  ]
}
```

---

## Form Endpoints

### GET /api/agro/[tenant]/forms
**List forms for tenant**

Request:
```bash
Authorization: Bearer <token>
GET /api/agro/demo-tenant/forms?skip=0&take=20
```

Response (200 OK):
```json
{
  "forms": [
    {
      "id": "uuid",
      "name": "Customer Feedback",
      "description": "Collect feedback",
      "status": "ACTIVE",
      "currentVersionId": "version-uuid",
      "createdAt": "2026-01-25T10:00:00Z"
    }
  ],
  "total": 5
}
```

---

### POST /api/agro/[tenant]/forms
**Create new form**

Request:
```bash
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "New Form",
  "description": "Form description",
  "schema": {
    "fields": [
      {
        "id": "field-uuid",
        "type": "SHORT_ANSWER",
        "label": "Name",
        "required": true
      }
    ]
  }
}
```

Response (201 Created):
```json
{
  "id": "form-uuid",
  "name": "New Form",
  "currentVersionId": "version-uuid",
  "createdAt": "2026-01-25T10:00:00Z"
}
```

---

### GET /api/agro/[tenant]/forms/[formId]
**Get single form**

Request:
```bash
Authorization: Bearer <token>
GET /api/agro/demo-tenant/forms/form-uuid
```

Response (200 OK):
```json
{
  "id": "form-uuid",
  "name": "Customer Feedback",
  "schema": { ... },
  "currentVersionId": "version-uuid",
  "FormVersion": [
    {
      "id": "version-uuid",
      "versionNumber": 1,
      "schema": { ... },
      "createdAt": "2026-01-25T10:00:00Z"
    }
  ]
}
```

---

### PUT /api/agro/[tenant]/forms/[formId]
**Update form**

Request:
```bash
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Updated Name",
  "schema": { ... }
}
```

Response (200 OK):
```json
{
  "id": "form-uuid",
  "name": "Updated Name",
  "versionCreated": true,
  "newVersionNumber": 2
}
```

---

### DELETE /api/agro/[tenant]/forms/[formId]
**Delete form (soft delete)**

Request:
```bash
Authorization: Bearer <token>
DELETE /api/agro/demo-tenant/forms/form-uuid
```

Response (200 OK):
```json
{
  "success": true,
  "id": "form-uuid"
}
```

---

## Form Submission Endpoints

### GET /api/agro/[tenant]/forms/[formId]/submissions
**Get form submissions**

Request:
```bash
Authorization: Bearer <token>
GET /api/agro/demo-tenant/forms/form-uuid/submissions?skip=0&take=20
```

Response (200 OK):
```json
{
  "submissions": [
    {
      "id": "submission-uuid",
      "formVersionId": "version-uuid",
      "submittedData": {
        "field-uuid": "User's answer",
        "field-2": "Another answer"
      },
      "submittedAt": "2026-01-25T10:30:00Z",
      "user": {
        "email": "user@example.com",
        "firstName": "João"
      }
    }
  ],
  "total": 45
}
```

---

### POST /api/agro/[tenant]/forms/[formId]/submit
**Submit form (user)**

Request:
```bash
Content-Type: application/json

{
  "formVersionId": "version-uuid",
  "submittedData": {
    "field-uuid": "User's answer",
    "field-2": "Another answer"
  }
}
```

Response (201 Created):
```json
{
  "id": "submission-uuid",
  "success": true,
  "message": "Formulário enviado com sucesso"
}
```

Errors:
- 400: Invalid form data
- 404: Form not found
- 422: Validation failed

---

## Form Builder API

### POST /api/agro/[tenant]/forms/builder
**Form builder operations**

Build forms with live preview, versioning, and field management.

---

## Admin Endpoints

### POST /api/admin/create-test-users
**Create test users (dev only)**

Request:
```bash
Content-Type: application/json

{}
```

Response (200 OK):
```json
{
  "success": true,
  "users": [
    {
      "id": "uuid",
      "email": "joaobalzer@dpwai.com.br",
      "password": "Teste@123456",
      "status": "created"
    },
    {
      "id": "uuid",
      "email": "rodrigo@dpwai.com.br",
      "password": "Teste@123456",
      "status": "created"
    }
  ]
}
```

---

## Error Responses

### 401 Unauthorized
```json
{
  "error": "Unauthorized",
  "message": "Invalid or missing token"
}
```

### 403 Forbidden
```json
{
  "error": "Forbidden",
  "message": "You don't have permission to access this resource"
}
```

### 404 Not Found
```json
{
  "error": "Not Found",
  "message": "Resource not found"
}
```

### 422 Unprocessable Entity
```json
{
  "error": "Validation Error",
  "fields": {
    "email": "Invalid email format",
    "password": "Password too weak"
  }
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal Server Error",
  "message": "Something went wrong"
}
```

---

## Headers & Authentication

### Required Headers
```
Content-Type: application/json        # For all requests
Authorization: Bearer <token>         # For authenticated endpoints
```

### Token Format
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Token Contents (JWT)
```json
{
  "userId": "user-uuid",
  "tenantId": "tenant-uuid",
  "iat": 1674644400,
  "exp": 1674730800
}
```

---

## Rate Limiting

Currently: No rate limiting (planned for future)

---

## Pagination

All list endpoints support:
```
?skip=0       # Offset (default: 0)
?take=20      # Limit (default: 20, max: 100)
```

Response includes:
```json
{
  "items": [...],
  "total": 45,
  "skip": 0,
  "take": 20
}
```

---

## CORS Policy

**Allowed Origins**:
- localhost:3000 (dev)
- app.dpwai.com.br (prod)
- Vercel preview URLs

**Allowed Methods**: GET, POST, PUT, DELETE, OPTIONS

---

## Testing Endpoints

### Using curl
```bash
# Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"joaobalzer@dpwai.com.br","password":"Teste@123456"}'

# Get forms (authenticated)
curl -X GET http://localhost:3000/api/agro/demo-tenant/forms \
  -H "Authorization: Bearer <token>"
```

### Using Postman
1. Set base URL: http://localhost:3000
2. Login and save token to variable
3. Use {{token}} in Authorization header
4. Import provided collection

---

## API Status Codes

| Code | Meaning |
|------|---------|
| 200 | OK - Success |
| 201 | Created - Resource created |
| 400 | Bad Request - Invalid input |
| 401 | Unauthorized - Auth required |
| 403 | Forbidden - No permission |
| 404 | Not Found - Resource missing |
| 422 | Validation - Input validation failed |
| 500 | Server Error - Internal error |

---

**Last Updated**: 25 January 2026
**Maintained By**: Claude Code
**Source**: `/dpwaiagro/app/api/`

