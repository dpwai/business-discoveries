# Internationalization (i18n) Guide

This document explains how to work with translations in the DPWAI Agro application.

## Overview

The application uses a custom i18n system with support for multiple languages (currently English and Portuguese). All UI strings should be translated and managed through the translation system.

### Current Languages
- **English** (`en`) - Default language
- **Portuguese (Brazil)** (`pt`) - Portuguese translation

## Architecture

### Translation System

**Location:** `/lib/i18n/translations.ts`

The translations are stored in a single TypeScript file that exports a `translations` object containing all language keys:

```typescript
export const translations = {
  en: {
    'key.name': 'English text',
    // ...
  },
  pt: {
    'key.name': 'Texto em português',
    // ...
  },
};
```

### Translation Hook

**Location:** `/lib/i18n/useLanguage.ts`

Use the `useLanguage` hook to access translation functions in client components:

```typescript
import { useLanguage } from '@/lib/i18n/useLanguage';

export default function MyComponent() {
  const { t, language, setLanguage } = useLanguage();

  return (
    <div>
      <h1>{t('nav.welcome')}</h1>
      <p>Current language: {language}</p>
    </div>
  );
}
```

### Hook Properties

- `t(key)` - Translate a key to the current language. Falls back to English if Portuguese is unavailable.
- `language` - Current language code ('en' or 'pt')
- `setLanguage(lang)` - Change the current language and persist to localStorage
- `isReady` - Boolean indicating if the component has hydrated (useful for avoiding hydration mismatches)

## Adding New Translations

### Step 1: Define Translation Keys

Edit `/lib/i18n/translations.ts` and add your new keys to both language objects:

```typescript
export const translations = {
  en: {
    // ... existing keys
    'forms.records.saved-success': 'Form saved successfully!',
    'forms.permission-denied': 'Permission denied',
  },
  pt: {
    // ... existing keys
    'forms.records.saved-success': 'Formulário salvo com sucesso!',
    'forms.permission-denied': 'Sem permissão',
  },
};
```

### Step 2: Use Translation in Components

In your React component, import the hook and use the `t()` function:

```typescript
'use client';

import { useLanguage } from '@/lib/i18n/useLanguage';

export default function FormPage() {
  const { t } = useLanguage();

  return (
    <div>
      <h1>{t('forms.title')}</h1>
      <button>{t('forms.create')}</button>
      <p>{t('forms.permission-denied')}</p>
    </div>
  );
}
```

### Translation Key Naming Conventions

Follow these patterns for consistency:

- **Navigation:** `nav.welcome`, `nav.dashboards`
- **Authentication:** `auth.email`, `auth.login`, `auth.reset-password`
- **Dashboard:** `dashboard.title`, `dashboard.create`, `dashboard.delete`
- **Forms:** `forms.title`, `forms.create`, `forms.delete`
- **Errors:** `error.failed-to-load`, `error.invalid-email`
- **UI Labels:** `ui.save`, `ui.cancel`, `ui.delete`
- **Common:** `common.loading`, `common.success`, `common.error`

## Adding a New Language

To add support for a new language (e.g., Spanish):

### Step 1: Update translations.ts

```typescript
export const translations = {
  en: { /* ... */ },
  pt: { /* ... */ },
  es: {
    'nav.welcome': 'Bienvenido',
    'nav.dashboards': 'Paneles',
    // ... add all keys for Spanish
  },
};
```

### Step 2: Update useLanguage.ts

Modify the `Language` type definition:

```typescript
type Language = 'en' | 'pt' | 'es';
```

### Step 3: Update Language Selector

If you have a language selector component, add the new language option:

```typescript
<select value={language} onChange={(e) => setLanguage(e.target.value as Language)}>
  <option value="en">English</option>
  <option value="pt">Português</option>
  <option value="es">Español</option>
</select>
```

## Running the i18n Audit

The project includes an automated audit script to check for translation issues:

```bash
npm run i18n:audit
```

### What the Audit Checks

1. **Missing Translation Keys** - Detects `t('key')` calls where the key is not defined in translations.ts
2. **Hardcoded Strings** - Finds English strings in JSX that should be translated
3. **Orphaned Keys** - Identifies translation keys that are defined but never used in code

### Audit Output

The audit will report:
- Total files scanned
- Number of translation keys defined and used
- Any missing, hardcoded, or orphaned keys
- Exit code 0 if all checks pass, 1 if issues found

Example output:
```
✓ Loaded 395 translation keys
Files Scanned: 124
Translation Keys Defined: 395
Translation Keys Used: 88

✅ All checks passed!
✓ No missing translation keys
✓ No hardcoded English strings detected
✓ No orphaned keys found
```

## Best Practices

### Do's
- Always use the `t()` function for user-facing text
- Keep translation keys descriptive and hierarchical (e.g., `forms.records.delete-error`)
- Add both English and Portuguese translations simultaneously
- Test the audit script before committing: `npm run i18n:audit`
- Use the `isReady` property to avoid hydration mismatches in server-rendered components

### Don'ts
- Don't hardcode English strings in JSX
- Don't forget to add translations for both languages
- Don't use placeholder text as translation keys
- Don't commit code with failing audit checks

## Fallback Behavior

If a translation key is missing or the language is unavailable:

1. First, try to use the current language's translation
2. If not found, fall back to English
3. If English is also missing, return the key itself

Example:
```typescript
const { t } = useLanguage();
t('missing.key') // Returns: 'missing.key'
```

## Persisting Language Preference

The `useLanguage` hook automatically persists the selected language to browser localStorage under the key `language`. This means:

- User's language selection is remembered across sessions
- The hook reads from localStorage on component mount
- Changes to language are immediately persisted

## Common Issues

### Hydration Mismatch

If you see hydration errors, use the `isReady` flag:

```typescript
const { t, isReady } = useLanguage();

if (!isReady) return null; // Don't render until hydrated

return <div>{t('nav.welcome')}</div>;
```

### Missing Keys in Audit

Run the audit to identify all missing keys:

```bash
npm run i18n:audit
```

Then add the missing keys to both language objects in `translations.ts`.

## Current Translation Statistics

**Total Translation Keys:** 395

### Key Breakdown by Category
- Navigation & UI: 125 keys
- Authentication: 45 keys
- Forms & Records: 85 keys
- Dashboards: 35 keys
- Errors & Validation: 75 keys
- User & Account: 30 keys

See `/lib/i18n/translations.ts` for the complete list of all available translation keys.

## Debugging

To debug translation issues:

1. **Check the browser console** - Look for warning messages about missing translations
2. **Run the audit script** - `npm run i18n:audit`
3. **Verify key names** - Ensure the key passed to `t()` exactly matches the key in translations.ts
4. **Check language setting** - Verify the correct language is selected in the useLanguage hook
5. **Test fallback** - If a Portuguese translation is missing, English should be used as fallback

## Files to Know

- `/lib/i18n/translations.ts` - All translation definitions
- `/lib/i18n/useLanguage.ts` - Translation hook
- `/lib/i18n/LanguageContext.tsx` - Language context provider
- `/scripts/i18n-audit.mjs` - Audit script for checking translations
