# 🚨 ERRORS YOU WILL ENCOUNTER - AND HOW TO FIX THEM

**Status**: Jan 26, 2026 - All errors discovered and documented
**Scope**: 38 build errors fixed during hardening sprint

---

## ERROR #1: Route Handler Type Mismatch (38+ FILES)

### What You'll See
```
Type error: Type '{ params: { id: string } }' does not satisfy 
type 'params: Promise<{ id: string }>'.
  Expected Promise type but got direct object.
```

### Where It Happens
- Any file in `/app/api/` with `[dynamic-segments]`
- Examples: `/app/api/agro/[tenant]/...`

### THE FIX (Copy & Paste)
```typescript
// ❌ WRONG (what you probably have)
export async function POST(
  request: NextRequest,
  { params }: { params: { tenant: string } }
) {
  const { tenant } = params;
}

// ✅ RIGHT (fix this)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ tenant: string }> }
) {
  const { tenant } = await params;
}
```

### Automated Fix Script
```bash
find app/api -name "route.ts" -type f | while read file; do
  perl -i -pe 's/\{\s*params\s*\}\s*:\s*\{\s*params\s*:\s*(?!Promise)(\{[^}]+\})\s*\}/{ params }: { params: Promise<$1> }/g' "$file"
done
```

### Files with This Error (40+ total)
All files in: `/app/api/agro/[tenant]/`

---

## ERROR #2: verifyAuth() Wrong Arguments (5+ FILES)

### What You'll See
```
Type error: Argument of type 'string' is not assignable to 
parameter of type 'NextRequest'.
  verifyAuth expects NextRequest, not token string
```

### Common Mistakes
```typescript
// ❌ WRONG #1 - extracting token manually
const token = authHeader.replace('Bearer ', '');
const decoded = await verifyAuth(token);  // ❌ String, not NextRequest

// ❌ WRONG #2 - passing 2 arguments
const auth = await verifyAuth(req, tenant);  // ❌ Only takes 1 param

// ❌ WRONG #3 - wrong variable name
const decoded = await verifyAuth(request);  // ❌ Returns auth, not decoded
if (!decoded) { ... }  // ❌ decoded.userId won't exist
```

### THE FIX (Copy & Paste)
```typescript
// ✅ RIGHT - Always do this
const auth = await verifyAuth(request);

if (!auth.authenticated) {
  return NextResponse.json(
    createErrorResponse('auth.invalid_token', 401),
    { status: 401 }
  );
}

// Use the returned object:
console.log(auth.userId, auth.tenantId, auth.email);
```

### Function Signature (Reference)
```typescript
import { verifyAuth } from '@/lib/auth';

async function verifyAuth(
  request: NextRequest,
  expectedTenant?: string
): Promise<{
  authenticated: boolean;
  userId?: string;
  email?: string;
  tenantId?: string;
  token?: string;
}>
```

---

## ERROR #3: Unknown Error Code (Multiple FILES)

### What You'll See
```
Type error: Argument of type '"error.not_found"' is not assignable 
to parameter of type 'ErrorCode'.
  The code you're using is not in the ErrorCode union type
```

### Common Codes Missing
- `'auth.missing_token'` - not in ErrorCode
- `'error.not_found'` - uses `error.resource_not_found` instead
- `'auth.forbidden'` - not defined
- `'error.expired'` - not defined

### THE FIX (3 Steps)

**Step 1**: Open `/lib/errors/normalizer.ts`

**Step 2**: Add your code to the union:
```typescript
export type ErrorCode =
  // ... existing codes ...
  | 'your.new_error_code';  // ✅ ADD HERE
```

**Step 3**: Add i18n mapping:
```typescript
export const ERROR_CODE_TO_I18N_KEY: Record<ErrorCode, string> = {
  // ... existing mappings ...
  'your.new_error_code': 'errors.your.new_error_code',  // ✅ ADD HERE
};
```

**Step 4**: Then use it:
```typescript
return NextResponse.json(
  createErrorResponse('your.new_error_code', 400),  // ✅ NOW WORKS
  { status: 400 }
);
```

### All Codes That Are Already Defined
```
✅ auth.invalid_credentials
✅ auth.invalid_token
✅ auth.user_not_found
✅ auth.user_disabled
✅ auth.no_tenants
✅ auth.no_access
✅ auth.token_expired
✅ auth.token_invalid_format
✅ error.network_error
✅ error.server_error
✅ error.unknown_error
✅ error.invalid_response
✅ error.resource_not_found
✅ error.access_denied
✅ error.request_failed
✅ error.invalid_request
✅ error.conflict
✅ validation.email_required
✅ validation.email_invalid
✅ validation.password_required
✅ validation.password_too_short
✅ validation.password_weak
✅ validation.passwords_dont_match
✅ validation.name_required
✅ validation.field_required
✅ validation.field_invalid
✅ password.reset_token_expired
✅ password.reset_token_invalid
✅ password.reset_failed
✅ form.failed_to_load
✅ form.failed_to_create
✅ form.failed_to_update
✅ form.failed_to_delete
✅ user.email_already_exists
✅ user.username_already_exists
✅ user.creation_failed
✅ tenant.not_found
✅ tenant.switch_failed
```

### Codes You Might Need to Add
```
⚠️ auth.missing_token - NEED TO ADD
⚠️ auth.forbidden - NEED TO ADD  
⚠️ error.not_found - NEED TO ADD
⚠️ error.expired - NEED TO ADD
```

---

## ERROR #4: Prisma JSON Field Type Error

### What You'll See
```
Type error: Type 'null' is not assignable to type 
'NullableJsonNullValueInput | InputJsonValue | undefined'.
```

### Where It Happens
When updating a field defined as `Json?` in Prisma schema:
```prisma
model WebhookDelivery {
  responseBody  Json?  // ← This field
}
```

### THE FIX
```typescript
// ❌ WRONG - can't set JSON field to null
await prisma.webhookDelivery.update({
  where: { id: deliveryId },
  data: {
    responseBody: null,  // ❌ Type error
  },
});

// ✅ RIGHT - use undefined instead
await prisma.webhookDelivery.update({
  where: { id: deliveryId },
  data: {
    responseBody: undefined,  // ✅ Correct
  },
});
```

### Rule
- For `Json?` fields: use `undefined` not `null`
- For other optional fields: use `null` is fine

---

## ERROR #5: Missing await on params

### What You'll See
```
Type error: Cannot read property 'id' of Promise.
  params is a Promise - you need to await it
```

### THE FIX
```typescript
// ❌ WRONG - params is a Promise, can't access directly
const { id } = params;

// ✅ RIGHT - must await first
const { id } = await params;
```

---

## ERROR #6: No Multi-Tenant Isolation

### What You'll See
No error, but **SECURITY ISSUE**: other tenants can see your data

### THE FIX
Every WHERE clause MUST filter by tenantId:

```typescript
// ❌ WRONG - gets data from other tenants
const users = await prisma.user.findMany({
  where: { /* missing tenantId */ }
});

// ✅ RIGHT - only gets this tenant's data  
const users = await prisma.membership.findMany({
  where: {
    tenantId: auth.tenantId,  // ✅ ALWAYS ADD THIS
  },
});

// ✅ RIGHT - with other filters
const dashboards = await prisma.dashboard.findMany({
  where: {
    tenantId: auth.tenantId,   // ✅ FIRST FILTER
    archived: false,            // ✅ OTHER FILTERS
  },
});
```

---

## ERROR #7: Hardcoded Text (Not i18n)

### What You'll See
Code compiles fine, but text appears in English/Portuguese instead of being translated

### THE FIX
Never hardcode text:

```typescript
// ❌ WRONG - hardcoded Portuguese
const message = "Usuário não encontrado";

// ❌ WRONG - hardcoded English
const label = "Dashboard";

// ✅ RIGHT - use error codes
return NextResponse.json(
  createErrorResponse('user.not_found', 404),  // Maps to translation
  { status: 404 }
);

// ✅ RIGHT - use i18n keys in UI
const Dashboard = () => {
  const { t } = useLanguage();  // Get i18n hook
  return <h1>{t('dashboard.title')}</h1>;
};
```

---

## ERROR #8: No Authentication on Protected Route

### What You'll See
Anyone can access the endpoint without a token (CRITICAL SECURITY)

### THE FIX
Every protected route must verify auth:

```typescript
// ✅ RIGHT - ALWAYS do this first
export async function POST(request: NextRequest) {
  try {
    const auth = await verifyAuth(request);
    if (!auth.authenticated) {
      return NextResponse.json(
        createErrorResponse('auth.invalid_token', 401),
        { status: 401 }
      );
    }
    
    // Rest of your code...
  } catch (error) {
    // ...
  }
}
```

---

## QUICK REFERENCE: Before You Commit

| Check | Fix |
|-------|-----|
| Route has `[params]`? | Use `Promise<{ ... }>` |
| Call verifyAuth()? | Pass `request`, not `token` |
| Use error code? | Define in `ErrorCode` type first |
| Update Json? field? | Use `undefined`, not `null` |
| Access params? | Use `await params` |
| Query user data? | Add `tenantId: auth.tenantId` filter |
| Display text? | Use i18n/error codes, not hardcoded |
| Protected API? | Check `auth.authenticated` first |

---

## HOW TO FIND & FIX ERRORS

### 1. Build Fails
```bash
npm run build 2>&1 | head -50  # See first 50 lines of errors
```

### 2. Fix Known Issues
Use search & replace in your editor:
- Find: `{ params }: { params: `
- Replace with: `{ params }: { params: Promise<`

Then manually:
1. Check for `verifyAuth(token)` → change to `verifyAuth(request)`
2. Check for `createErrorResponse('...')` → ensure code exists in type
3. Check for `params.` → change to `await params.`

### 3. Verify Fix
```bash
npm run build  # Should pass
```

---

**You've seen all 38 errors. They're all documented here. Never panic.**

Reference: `/DPWAI_HARDENING_KNOWLEDGE_BASE.md`
