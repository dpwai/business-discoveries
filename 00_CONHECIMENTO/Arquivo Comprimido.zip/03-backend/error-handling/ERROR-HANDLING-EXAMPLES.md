# Error Handling & i18n Integration Examples

This document provides practical examples of how to use the new error handling system in different scenarios.

## Table of Contents

1. [API Routes](#api-routes)
2. [Client Components](#client-components)
3. [Form Validation](#form-validation)
4. [Common Patterns](#common-patterns)

---

## API Routes

### Example 1: Simple Email Validation

```typescript
// app/api/user/verify-email/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createErrorResponse, validateEmail } from '@/lib/errors/normalizer';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email } = body;

    // Check if email is provided
    if (!email) {
      return NextResponse.json(
        createErrorResponse('validation.email_required', 400),
        { status: 400 }
      );
    }

    // Validate email format
    const emailError = validateEmail(email);
    if (emailError) {
      return NextResponse.json(
        createErrorResponse(emailError, 400),
        { status: 400 }
      );
    }

    // Your business logic...

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Email verification error:', error);
    return NextResponse.json(
      createErrorResponse('error.server_error', 500),
      { status: 500 }
    );
  }
}
```

### Example 2: Complex Validation

```typescript
// app/api/auth/create-account/route.ts
import { NextRequest, NextResponse } from 'next/server';
import {
  createErrorResponse,
  validateEmail,
  validatePasswordStrength,
  validateTenantFormat,
} from '@/lib/errors/normalizer';
import prisma from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, confirmPassword, firstName, lastName, tenantName } = body;

    // Validate all required fields
    if (!email || !password || !confirmPassword || !firstName || !lastName || !tenantName) {
      return NextResponse.json(
        createErrorResponse('validation.field_required', 400),
        { status: 400 }
      );
    }

    // Validate email format
    const emailError = validateEmail(email);
    if (emailError) {
      return NextResponse.json(
        createErrorResponse(emailError, 400),
        { status: 400 }
      );
    }

    // Validate password strength
    const passwordError = validatePasswordStrength(password);
    if (passwordError) {
      return NextResponse.json(
        createErrorResponse(passwordError, 400),
        { status: 400 }
      );
    }

    // Validate passwords match
    if (password !== confirmPassword) {
      return NextResponse.json(
        createErrorResponse('validation.passwords_dont_match', 400),
        { status: 400 }
      );
    }

    // Validate tenant format
    const tenantError = validateTenantFormat(tenantName);
    if (tenantError) {
      return NextResponse.json(
        createErrorResponse(tenantError, 400),
        { status: 400 }
      );
    }

    // Check if email already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (existingUser) {
      return NextResponse.json(
        createErrorResponse('user.email_already_exists', 409),
        { status: 409 }
      );
    }

    // Create user...
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Account creation error:', error);
    return NextResponse.json(
      createErrorResponse('user.creation_failed', 500),
      { status: 500 }
    );
  }
}
```

### Example 3: Using Custom Error Codes

```typescript
// app/api/dashboard/create/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createErrorResponse } from '@/lib/errors/normalizer';

export async function POST(request: NextRequest) {
  try {
    // ... validation ...

    const userId = request.headers.get('x-user-id');

    // Check user access
    if (!userId) {
      return NextResponse.json(
        createErrorResponse('auth.no_access', 403),
        { status: 403 }
      );
    }

    // Business logic...

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Dashboard creation error:', error);
    return NextResponse.json(
      createErrorResponse('error.server_error', 500),
      { status: 500 }
    );
  }
}
```

---

## Client Components

### Example 1: Login Form

```typescript
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useErrorHandler } from '@/lib/errors/useErrorHandler';

export function LoginForm() {
  const router = useRouter();
  const { handleError, handleNetworkError } = useErrorHandler();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Make API call
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      // Handle error responses
      if (!res.ok) {
        const { message } = await handleError(res);
        setError(message);
        setLoading(false);
        return;
      }

      // Parse success response
      const data = await res.json();
      localStorage.setItem('accessToken', data.accessToken);
      router.push('/dashboard');
    } catch (err) {
      // Handle network errors
      const { message } = handleNetworkError(err);
      setError(message);
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      {error && <div className="error-message">{error}</div>}
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email"
        required
      />
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
        required
      />
      <button type="submit" disabled={loading}>
        {loading ? 'Loading...' : 'Sign In'}
      </button>
    </form>
  );
}
```

### Example 2: Sign Up Form with Field-Level Validation

```typescript
'use client';

import { useState } from 'react';
import { useErrorHandler } from '@/lib/errors/useErrorHandler';
import {
  validateEmail,
  validatePasswordStrength,
  validateTenantFormat,
} from '@/lib/errors/normalizer';

interface FieldErrors {
  email?: string;
  password?: string;
  tenantName?: string;
}

export function SignUpForm() {
  const { handleError, handleNetworkError, translate } = useErrorHandler();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    tenantName: '',
  });
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [loading, setLoading] = useState(false);

  // Validate individual field
  function validateField(name: string, value: string): string | null {
    switch (name) {
      case 'email':
        const emailError = validateEmail(value);
        return emailError ? translate(`errors.validation.${emailError}`) : null;

      case 'password':
        const passwordError = validatePasswordStrength(value);
        return passwordError ? translate(`errors.validation.${passwordError}`) : null;

      case 'tenantName':
        const tenantError = validateTenantFormat(value);
        return tenantError ? translate(`errors.validation.${tenantError}`) : null;

      default:
        return null;
    }
  }

  // Handle field change
  function handleFieldChange(e: React.ChangeEvent<HTMLInputElement>) {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // Validate field
    const error = validateField(name, value);
    setFieldErrors((prev) => ({
      ...prev,
      [name]: error,
    }));
  }

  // Submit form
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/auth/create-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!res.ok) {
        const { message } = await handleError(res);
        // Show general error or field-specific error
        alert(message);
        setLoading(false);
        return;
      }

      const data = await res.json();
      // Handle success...
    } catch (err) {
      const { message } = handleNetworkError(err);
      alert(message);
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <input
          name="email"
          type="email"
          value={formData.email}
          onChange={handleFieldChange}
          placeholder="Email"
          required
        />
        {fieldErrors.email && <span className="error">{fieldErrors.email}</span>}
      </div>

      <div>
        <input
          name="password"
          type="password"
          value={formData.password}
          onChange={handleFieldChange}
          placeholder="Password (min 8 chars, uppercase, lowercase, numbers)"
          required
        />
        {fieldErrors.password && <span className="error">{fieldErrors.password}</span>}
      </div>

      <div>
        <input
          name="confirmPassword"
          type="password"
          value={formData.confirmPassword}
          onChange={handleFieldChange}
          placeholder="Confirm Password"
          required
        />
        {formData.password !== formData.confirmPassword && (
          <span className="error">{translate('errors.validation.passwords_dont_match')}</span>
        )}
      </div>

      <div>
        <input
          name="firstName"
          type="text"
          value={formData.firstName}
          onChange={(e) => setFormData((prev) => ({ ...prev, firstName: e.target.value }))}
          placeholder="First Name"
          required
        />
      </div>

      <div>
        <input
          name="lastName"
          type="text"
          value={formData.lastName}
          onChange={(e) => setFormData((prev) => ({ ...prev, lastName: e.target.value }))}
          placeholder="Last Name"
          required
        />
      </div>

      <div>
        <input
          name="tenantName"
          type="text"
          value={formData.tenantName}
          onChange={handleFieldChange}
          placeholder="Organization Name (snake_case)"
          required
        />
        {fieldErrors.tenantName && <span className="error">{fieldErrors.tenantName}</span>}
      </div>

      <button type="submit" disabled={loading || Object.values(fieldErrors).some(Boolean)}>
        {loading ? 'Creating Account...' : 'Sign Up'}
      </button>
    </form>
  );
}
```

### Example 3: Reset Password Form

```typescript
'use client';

import { useState } from 'react';
import { useErrorHandler } from '@/lib/errors/useErrorHandler';
import { validatePasswordStrength } from '@/lib/errors/normalizer';

interface FieldErrors {
  password?: string;
  confirmPassword?: string;
}

export function ResetPasswordForm({ token }: { token: string }) {
  const { handleError, handleNetworkError, translate } = useErrorHandler();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  function validatePasswords() {
    const errors: FieldErrors = {};

    // Validate password strength
    const passwordError = validatePasswordStrength(password);
    if (passwordError) {
      errors.password = translate(`errors.validation.${passwordError}`);
    }

    // Check if passwords match
    if (password && confirmPassword && password !== confirmPassword) {
      errors.confirmPassword = translate('errors.validation.passwords_dont_match');
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!validatePasswords()) {
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          password,
          confirmPassword,
        }),
      });

      if (!res.ok) {
        const { message } = await handleError(res);
        alert(message);
        setLoading(false);
        return;
      }

      setSuccess(true);
      setTimeout(() => {
        window.location.href = '/login';
      }, 2000);
    } catch (err) {
      const { message } = handleNetworkError(err);
      alert(message);
      setLoading(false);
    }
  }

  if (success) {
    return <div className="success">{translate('auth.password-reset-successful')}</div>;
  }

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="New Password"
          required
        />
        {fieldErrors.password && <span className="error">{fieldErrors.password}</span>}
      </div>

      <div>
        <input
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          placeholder="Confirm Password"
          required
        />
        {fieldErrors.confirmPassword && <span className="error">{fieldErrors.confirmPassword}</span>}
      </div>

      <button type="submit" disabled={loading}>
        {loading ? 'Resetting...' : 'Reset Password'}
      </button>
    </form>
  );
}
```

---

## Form Validation

### Example: Custom Hook for Form Validation

```typescript
// lib/hooks/useFormValidation.ts
import { useCallback } from 'react';
import { useErrorHandler } from '@/lib/errors/useErrorHandler';
import {
  validateEmail,
  validatePasswordStrength,
  validateTenantFormat,
} from '@/lib/errors/normalizer';

type Validator = (value: string) => string | null;

const validators: Record<string, Validator> = {
  email: (value) => {
    if (!value) return 'errors.validation.email_required';
    const error = validateEmail(value);
    return error ? error.replace('validation.', 'errors.validation.') : null;
  },

  password: (value) => {
    if (!value) return 'errors.validation.password_required';
    const error = validatePasswordStrength(value);
    return error ? error.replace('validation.', 'errors.validation.') : null;
  },

  tenant: (value) => {
    if (!value) return 'errors.validation.field_required';
    const error = validateTenantFormat(value);
    return error ? error.replace('validation.', 'errors.validation.') : null;
  },

  required: (value) => {
    return value ? null : 'errors.validation.field_required';
  },
};

export function useFormValidation() {
  const { translate } = useErrorHandler();

  const validateField = useCallback(
    (fieldName: string, value: string): string | null => {
      const validator = validators[fieldName];
      if (!validator) return null;

      const error = validator(value);
      return error ? translate(error) : null;
    },
    [translate]
  );

  const validateForm = useCallback(
    (formData: Record<string, string>, schema: Record<string, string>): Record<string, string> => {
      const errors: Record<string, string> = {};

      for (const [field, validatorName] of Object.entries(schema)) {
        const error = validateField(field, formData[field]);
        if (error) {
          errors[field] = error;
        }
      }

      return errors;
    },
    [validateField]
  );

  return { validateField, validateForm };
}

// Usage in component:
/*
const { validateField, validateForm } = useFormValidation();

// Validate single field
const emailError = validateField('email', email);

// Validate entire form
const errors = validateForm(
  { email, password, tenantName },
  { email: 'email', password: 'password', tenantName: 'tenant' }
);
*/
```

---

## Common Patterns

### Pattern 1: Error Toast Notification

```typescript
'use client';

import { useErrorHandler } from '@/lib/errors/useErrorHandler';
import { useToast } from '@/components/ui/useToast'; // Your toast component

export function FormWithErrorToast() {
  const { handleError, handleNetworkError } = useErrorHandler();
  const { showToast } = useToast();

  async function submitForm() {
    try {
      const res = await fetch('/api/form', { method: 'POST' });

      if (!res.ok) {
        const { message } = await handleError(res);
        showToast({ type: 'error', message });
        return;
      }

      const data = await res.json();
      showToast({ type: 'success', message: 'Form submitted successfully!' });
    } catch (err) {
      const { message } = handleNetworkError(err);
      showToast({ type: 'error', message });
    }
  }

  return <button onClick={submitForm}>Submit</button>;
}
```

### Pattern 2: Retry with Exponential Backoff

```typescript
'use client';

import { useErrorHandler } from '@/lib/errors/useErrorHandler';

export function withRetry(fn: () => Promise<Response>, maxRetries = 3) {
  return async function retriedFn() {
    const { handleNetworkError } = useErrorHandler();
    let lastError = null;

    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        return await fn();
      } catch (err) {
        lastError = err;

        // Only retry on network errors
        if (!(err instanceof TypeError && err.message.includes('fetch'))) {
          throw err;
        }

        // Wait before retry with exponential backoff
        const delay = Math.pow(2, attempt) * 1000;
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }

    throw lastError;
  };
}

// Usage:
/*
const res = await withRetry(() => fetch('/api/user'));
*/
```

### Pattern 3: Centralized Error Handling Service

```typescript
// lib/services/errorService.ts
import { normalizeError, NormalizedError } from '@/lib/errors/normalizer';

class ErrorService {
  private errors: Map<string, NormalizedError> = new Map();

  log(error: unknown, context?: string): string {
    const normalized = normalizeError(error);
    const key = `${context}-${Date.now()}`;

    this.errors.set(key, normalized);
    console.error(`[${context}]`, normalized);

    return key;
  }

  getError(key: string): NormalizedError | undefined {
    return this.errors.get(key);
  }

  clearErrors(): void {
    this.errors.clear();
  }
}

export const errorService = new ErrorService();

// Usage in API route:
/*
try {
  // ...
} catch (error) {
  const errorKey = errorService.log(error, 'login');
  return NextResponse.json(
    createErrorResponse('error.server_error', 500),
    { status: 500, headers: { 'x-error-key': errorKey } }
  );
}
*/
```

---

## Testing Error Responses

```bash
# Test invalid email
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "invalid", "password": "Test@1234"}'

# Response:
# {"code": "validation.email_invalid", "i18nKey": "errors.validation.email_invalid"}

# Test weak password
curl -X POST http://localhost:3000/api/auth/reset-password \
  -H "Content-Type: application/json" \
  -d '{"token": "xyz", "password": "weak", "confirmPassword": "weak"}'

# Response:
# {"code": "validation.password_too_short", "i18nKey": "errors.validation.password_too_short"}

# Test invalid tenant format
curl -X POST http://localhost:3000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email": "test@test.com", "password": "Test@1234", "name": "User", "tenant": "Invalid-Tenant"}'

# Response:
# {"code": "validation.tenant_invalid_format", "i18nKey": "errors.validation.tenant_invalid_format"}
```

These examples demonstrate the flexibility and robustness of the error handling system for various real-world scenarios.
