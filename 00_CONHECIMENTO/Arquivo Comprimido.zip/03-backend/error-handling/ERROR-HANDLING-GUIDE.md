# Phase 5: Error Handling & Validation i18n Guide

## Overview

This document describes the comprehensive error handling and internationalization (i18n) system for Portuguese (pt-BR) implemented in the application.

## Architecture

### 1. Error Normalizer (`lib/errors/normalizer.ts`)

The error normalizer provides a unified system for mapping error codes to i18n keys:

- **ErrorCode**: Type-safe error codes for validation, auth, common, password, form, and user/tenant errors
- **NormalizedError**: Standard error object with code, i18nKey, message (for logging), and statusCode
- **Helper Functions**:
  - `normalizeError()`: Convert any error to normalized format
  - `createErrorResponse()`: Create API response with error code and i18nKey only (never expose raw messages)
  - `validatePasswordStrength()`: Check password meets security requirements
  - `validateEmail()`: Validate email format
  - `validateTenantFormat()`: Validate tenant name format (snake_case)

### 2. Error Handler Hook (`lib/errors/useErrorHandler.ts`)

Client-side hook for handling and translating errors:

```typescript
const { translate, handleError, handleNetworkError, getErrorMessage, processError } = useErrorHandler();

// Handle API error response
const { message } = await handleError(response);

// Handle network errors
const { message } = handleNetworkError(error);

// Get message for error code
const message = getErrorMessage('validation.field_required');
```

### 3. API Error Response Format

All API routes return error codes, not messages:

```typescript
// WRONG - Exposes raw message (NEVER do this)
return NextResponse.json({ error: 'Email inválido' }, { status: 400 });

// CORRECT - Uses error code
import { createErrorResponse } from '@/lib/errors/normalizer';
return NextResponse.json(createErrorResponse('validation.email_invalid', 400), { status: 400 });

// Response format:
{
  "code": "validation.email_invalid",
  "i18nKey": "errors.validation.email_invalid"
}
```

### 4. Translations (`lib/i18n/translations.ts`)

Organized by category:

- `errors.validation.*` - Validation errors (email_required, password_weak, etc)
- `errors.auth.*` - Authentication errors (invalid_credentials, user_disabled, etc)
- `errors.common.*` - Common errors (network_error, server_error, etc)
- `errors.password.*` - Password reset errors
- `errors.form.*` - Form operation errors
- `errors.user.*` / `errors.tenant.*` - User and tenant errors

All keys have both English and Portuguese translations.

## Implementation Examples

### API Route with Error Codes

```typescript
// app/api/auth/login/route.ts
import { createErrorResponse, validateEmail } from '@/lib/errors/normalizer';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json(
        createErrorResponse('validation.field_required', 400),
        { status: 400 }
      );
    }

    // Validate email format
    const emailError = validateEmail(email);
    if (emailError) {
      return NextResponse.json(
        createErrorResponse(emailError, 400),
        { status: 400 }
      );
    }

    // Your business logic...

    return NextResponse.json({ /* success response */ });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      createErrorResponse('error.server_error', 500),
      { status: 500 }
    );
  }
}
```

### Client Component with Error Handler

```typescript
'use client';

import { useState } from 'react';
import { useErrorHandler } from '@/lib/errors/useErrorHandler';

export function LoginForm() {
  const [error, setError] = useState('');
  const { handleError, handleNetworkError } = useErrorHandler();

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      if (!res.ok) {
        // This converts the error code to a localized message
        const { message } = await handleError(res);
        setError(message); // Already in user's language!
        return;
      }

      const data = await res.json();
      // Handle success...
    } catch (err) {
      // Handle network errors
      const { message } = handleNetworkError(err);
      setError(message);
    }
  }

  return (
    <form onSubmit={handleLogin}>
      {error && <div className="error">{error}</div>}
      {/* Form fields... */}
    </form>
  );
}
```

## Updated API Routes

The following routes have been updated with error code responses:

1. **POST /api/auth/login**
   - validation.field_required (missing fields)
   - validation.email_invalid (invalid email format)
   - auth.invalid_credentials (wrong password)
   - auth.user_not_found (user doesn't exist)
   - auth.user_disabled (account disabled)
   - auth.no_tenants (user has no organizations)
   - error.server_error (internal error)

2. **POST /api/auth/reset-password**
   - validation.field_required (missing fields)
   - validation.passwords_dont_match (passwords don't match)
   - validation.password_too_short (password too short)
   - validation.password_weak (password lacks required complexity)
   - password.reset_token_invalid (invalid/expired token)
   - password.reset_failed (reset failed)

3. **POST /api/auth/signup**
   - validation.field_required (missing fields)
   - validation.email_invalid (invalid email)
   - validation.password_weak (password too weak)
   - validation.tenant_invalid_format (invalid tenant format)

4. **POST /api/auth/switch-tenant**
   - auth.invalid_token (invalid/missing token)
   - validation.field_required (missing tenantId)
   - auth.no_access (user doesn't have access to tenant)
   - error.server_error (internal error)

## Security Best Practices

1. **Never expose raw error messages to the client**
   - API returns error codes and i18n keys only
   - Messages are composed on the client in the user's language
   - Sensitive details are logged on the server only

2. **Validation happens at multiple levels**
   - Client-side: Quick user feedback
   - API validation: Business logic enforcement
   - Error codes: Consistent across the app

3. **Error logging**
   - Server logs full error details
   - Client shows only localized messages
   - Error codes allow tracking without exposing sensitive info

## Translation Keys Reference

### Validation Errors (English)
- `errors.validation.email_required` → Email is required
- `errors.validation.email_invalid` → Please enter a valid email address
- `errors.validation.password_required` → Password is required
- `errors.validation.password_too_short` → Password must be at least 8 characters
- `errors.validation.password_weak` → Password must contain uppercase, lowercase, and numbers
- `errors.validation.passwords_dont_match` → Passwords do not match
- `errors.validation.name_required` → Name is required
- `errors.validation.field_required` → This field is required
- `errors.validation.field_invalid` → This field is invalid
- `errors.validation.tenant_invalid_format` → Tenant name must contain only lowercase letters, numbers, and underscores

### Validation Errors (Portuguese)
- `errors.validation.email_required` → Email é obrigatório
- `errors.validation.email_invalid` → Por favor, digite um email válido
- `errors.validation.password_required` → Senha é obrigatória
- `errors.validation.password_too_short` → A senha deve ter pelo menos 8 caracteres
- `errors.validation.password_weak` → A senha deve conter maiúsculas, minúsculas e números
- `errors.validation.passwords_dont_match` → As senhas não conferem
- `errors.validation.name_required` → Nome é obrigatório
- `errors.validation.field_required` → Este campo é obrigatório
- `errors.validation.field_invalid` → Este campo é inválido
- `errors.validation.tenant_invalid_format` → Nome do tenant deve conter apenas letras minúsculas, números e underscore

### Auth Errors (English)
- `errors.auth.invalid_credentials` → Invalid email or password
- `errors.auth.user_not_found` → User not found
- `errors.auth.user_disabled` → User account is disabled
- `errors.auth.no_tenants` → User has no organizations
- `errors.auth.no_access` → You do not have access
- `errors.auth.invalid_token` → Invalid token
- `errors.auth.token_expired` → Token has expired
- `errors.auth.token_invalid_format` → Token format is invalid

### Auth Errors (Portuguese)
- `errors.auth.invalid_credentials` → Email ou senha inválida
- `errors.auth.user_not_found` → Usuário não encontrado
- `errors.auth.user_disabled` → Conta de usuário está desativada
- `errors.auth.no_tenants` → Usuário não possui organizações
- `errors.auth.no_access` → Você não tem acesso
- `errors.auth.invalid_token` → Token inválido
- `errors.auth.token_expired` → Token expirou
- `errors.auth.token_invalid_format` → Formato do token é inválido

### Common Errors (English & Portuguese)
- `errors.common.network_error` → Network error. Please check your connection / Erro de rede. Por favor, verifique sua conexão
- `errors.common.server_error` → Server error. Please try again later / Erro do servidor. Por favor, tente novamente mais tarde
- `errors.common.unknown_error` → An unknown error occurred / Um erro desconhecido ocorreu
- `errors.common.invalid_response` → Invalid response from server / Resposta inválida do servidor
- `errors.common.resource_not_found` → Resource not found / Recurso não encontrado
- `errors.common.access_denied` → Access denied / Acesso negado
- `errors.common.request_failed` → Request failed / Falha na requisição
- `errors.common.invalid_request` → Invalid request / Requisição inválida
- `errors.common.conflict` → Resource conflict / Conflito de recurso

### Password Errors (English & Portuguese)
- `errors.password.reset_token_expired` → Password reset link has expired / Link de reset de senha expirou
- `errors.password.reset_token_invalid` → Password reset link is invalid / Link de reset de senha é inválido
- `errors.password.reset_failed` → Failed to reset password / Falha ao resetar senha

### Form Errors (English & Portuguese)
- `errors.form.failed_to_load` → Failed to load form / Falha ao carregar formulário
- `errors.form.failed_to_create` → Failed to create form / Falha ao criar formulário
- `errors.form.failed_to_update` → Failed to update form / Falha ao atualizar formulário
- `errors.form.failed_to_delete` → Failed to delete form / Falha ao deletar formulário

### User/Tenant Errors (English & Portuguese)
- `errors.user.email_already_exists` → Email already exists / Email já existe
- `errors.user.username_already_exists` → Username already exists / Usuário já existe
- `errors.user.creation_failed` → Failed to create user / Falha ao criar usuário
- `errors.tenant.not_found` → Organization not found / Organização não encontrada
- `errors.tenant.switch_failed` → Failed to switch organization / Falha ao alternar organização
- `errors.tenant.invalid_format` → Organization name format is invalid / Formato do nome da organização é inválido

## Testing Error Handling

### Test 1: Login with Invalid Email

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "invalid-email", "password": "Test@1234"}'

# Expected Response (400):
{
  "code": "validation.email_invalid",
  "i18nKey": "errors.validation.email_invalid"
}

# Client displays (English):
# "Please enter a valid email address"

# Client displays (Portuguese):
# "Por favor, digite um email válido"
```

### Test 2: Login with Weak Password

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@dpwai.com", "password": "weak"}'

# Expected Response (400):
{
  "code": "validation.password_too_short",
  "i18nKey": "errors.validation.password_too_short"
}
```

### Test 3: Invalid Credentials

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@dpwai.com", "password": "WrongPassword123"}'

# Expected Response (401):
{
  "code": "auth.invalid_credentials",
  "i18nKey": "errors.auth.invalid_credentials"
}
```

## Files Modified

1. **Created:**
   - `/lib/errors/normalizer.ts` - Error code mapping and validation
   - `/lib/errors/useErrorHandler.ts` - Client-side error handler hook
   - `ERROR_HANDLING_GUIDE.md` - This guide

2. **Updated:**
   - `/app/api/auth/login/route.ts` - Use error codes
   - `/app/api/auth/signup/route.ts` - Use error codes and validation
   - `/app/api/auth/reset-password/route.ts` - Use error codes
   - `/app/api/auth/switch-tenant/route.ts` - Use error codes
   - `/lib/i18n/translations.ts` - Added error message translations (pt-BR & en)
   - `/app/login/page.tsx` - Integrated error handler

## Next Steps

1. Update remaining API routes to use error codes
2. Integrate error handler into other forms (forgot-password, reset-password, signup)
3. Add error toast/notification components
4. Consider adding error tracking/logging service
5. Create validation error display components for forms

## Important Notes

- All error codes are type-safe with TypeScript
- Error messages are never exposed in API responses
- Both English and Portuguese translations are complete
- Password validation enforces minimum 8 characters + uppercase + lowercase + numbers
- Email validation is RFC 5322 compliant
- Tenant format validation ensures snake_case format
