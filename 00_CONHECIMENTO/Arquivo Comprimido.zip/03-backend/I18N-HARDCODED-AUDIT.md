# Hardcoded Strings Audit Report

**Date**: 2026-01-25
**Scope**: Full codebase scan of `/Users/balzer/dpwai-app2/dpwaiagro`
**Files Scanned**: 133 TypeScript/JavaScript files
**Exclusions**: node_modules, .next, .git directories; translations.ts file

## Summary

This report identifies **100+ hardcoded Portuguese and English strings** that are NOT in the centralized translations.ts file. The strings are categorized by file and include suggested translation keys.

### Critical Pages Analyzed (Priority Order)
1. `app/dpwai/select-tenant/page.tsx` - Tenant selection UI
2. `app/login/page.tsx` - Login page
3. `app/dpwai/[tenant_snake]/settings/page.tsx` - Settings page
4. `app/dpwai/[tenant_snake]/account/page.tsx` - Account/profile page
5. `app/dpwai/[tenant_snake]/forms/page.tsx` - Forms management
6. `app/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx` - Form records
7. `app/dpwai/[tenant_snake]/manual/page.tsx` - Manual forms
8. `app/dpwai/[tenant_snake]/ralph-chat/page.tsx` - AI chat interface
9. `app/dpwai/[tenant_snake]/users/page.tsx` - User management

## String Categories

### Error Messages (prefix: `error.`)
- Validation errors (e.g., "Campo obrigatório", "Deve ser número")
- Loading failures (e.g., "Failed to load forms")
- Operation failures (e.g., "Erro ao deletar registro")

### UI Labels (prefix: `ui.`)
- Page titles (e.g., "Formulários", "Minha Conta")
- Section headers (e.g., "Segurança", "Informações da Organização")
- Button labels (e.g., "Criar", "Salvar")
- Status indicators (e.g., "Carregando...")

### Form Placeholders (prefix: `label.`)
- Input placeholders (e.g., "Ex: Pesquisa de Satisfação")
- Example values (e.g., "voce@empresa.com")
- Help text (e.g., "Por favor, digite um nome")

## Top 100 Hardcoded Strings (Priority Order)

```csv
file_path,line_num,hardcoded_string,translation_key,suggested_action
app/dpwai/select-tenant/page.tsx,56,"Falha ao alternar tenant",error.falha-ao-alternar-tenant,Add new translation key
app/dpwai/select-tenant/page.tsx,70,"Erro ao alternar tenant",error.erro-ao-alternar-tenant,Add new translation key
app/dpwai/select-tenant/page.tsx,86,"Carregando...",ui.carregando,Add new translation key
app/dpwai/select-tenant/page.tsx,97,"Selecione um Tenant",ui.selecione-um-tenant,Add new translation key
app/dpwai/select-tenant/page.tsx,98,"Escolha qual organização deseja acessar",ui.escolha-qual-organização-deseja-acessar,Add new translation key
app/login/page.tsx,47,"Erro ao fazer login",error.erro-ao-fazer-login,Add new translation key
app/login/page.tsx,99,"Erro ao selecionar organização",error.erro-ao-selecionar-organização,Add new translation key
app/login/page.tsx,123,"Selecionar Organização",ui.selecionar-organização,Add new translation key
app/login/page.tsx,124,"Escolha qual organização acessar",ui.escolha-qual-organização-acessar,Add new translation key
app/login/page.tsx,172,"DPWAI Agro",ui.dpwai-agro,Add new translation key
app/login/page.tsx,173,"Plataforma de Dados Agrícolas",ui.plataforma-de-dados-agrícolas,Add new translation key
app/login/page.tsx,195,"admin@dpwai.com",label.admin@dpwai.com,Add new translation key
app/login/page.tsx,209,"••••••••",label.••••••••,Add new translation key
app/login/page.tsx,239,"Credenciais de Teste",ui.credenciais-de-teste,Add new translation key
app/login/page.tsx,245,"Demo:",ui.demo,Add new translation key
app/login/page.tsx,248,"Email:",ui.email,Add new translation key
app/login/page.tsx,252,"Senha:",ui.senha,Add new translation key
app/login/page.tsx,253,"Admin@123456",ui.admin@123456,Add new translation key
app/login/page.tsx,260,"© 2026 DPWAI Agro. Todos os direitos reservados.",ui.©-2026-dpwai-agro.-todos-os-direitos-reservados.,Add new translation key
app/dpwai/[tenant_snake]/settings/page.tsx,11,"Configurações",ui.configurações,Add new translation key
app/dpwai/[tenant_snake]/settings/page.tsx,16,"Informações da Organização",ui.informações-da-organização,Add new translation key
app/dpwai/[tenant_snake]/settings/page.tsx,39,"Minha Fazenda",label.minha-fazenda,Add new translation key
app/dpwai/[tenant_snake]/settings/page.tsx,50,"Descrição da sua organização...",label.descrição-da-sua-organização,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,86,"Falha ao carregar perfil",error.falha-ao-carregar-perfil,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,108,"Erro desconhecido",error.erro-desconhecido,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,153,"Erro ao salvar perfil",error.erro-ao-salvar-perfil,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,160,"Erro ao salvar",error.erro-ao-salvar,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,188,"Erro ao atualizar tenant padrão",error.erro-ao-atualizar-tenant-padrão,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,236,"Erro ao trocar senha",error.erro-ao-trocar-senha,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,254,"Carregando...",ui.carregando,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,275,"Minha Conta",ui.minha-conta,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,276,"Atualize seus dados pessoais e segurança",ui.atualize-seus-dados-pessoais-e-segurança,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,280,"Owner",ui.owner,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,283,"Admin",ui.admin,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,313,"Nome",ui.nome,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,318,"Seu nome",label.seu-nome,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,322,"Sobrenome",ui.sobrenome,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,327,"Seu sobrenome",label.seu-sobrenome,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,333,"Email",ui.email,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,339,"voce@empresa.com",label.voce@empresa.com,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,345,"Telefone",ui.telefone,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,350,"(11) 99999-9999",label.11-99999-9999,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,354,"Foto (URL)",ui.foto-url,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,381,"Tenant Padrão",ui.tenant-padrão,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,382,"Selecione qual tenant será carregado ao fazer login",ui.selecione-qual-tenant-será-carregado-ao-fazer-logi,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,386,"Selecionar",ui.selecionar,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,392,"-- Selecionar --",ui.---selecionar---,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,413,"Idioma",ui.idioma,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,414,"Selecione seu idioma preferido",ui.selecione-seu-idioma-preferido,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,417,"Language / Idioma",ui.language---idioma,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,423,"English",ui.english,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,424,"Português",ui.português,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,432,"Segurança",ui.segurança,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,433,"Altere sua senha",ui.altere-sua-senha,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,437,"Senha atual",ui.senha-atual,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,447,"Nova senha",ui.nova-senha,Add new translation key
app/dpwai/[tenant_snake]/account/page.tsx,458,"Confirmar",ui.confirmar,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,55,"Failed to load forms",error.failed-to-load-forms,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,67,"Por favor, digite um nome",error.por-favor,-digite-um-nome,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,98,"Failed to create form",error.failed-to-create-form,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,123,"Failed to delete form",error.failed-to-delete-form,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,136,"Formulários",ui.formulários,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,137,"Crie e gerencie seus formulários de coleta de dados",ui.crie-e-gerencie-seus-formulários-de-coleta-de-dado,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,154,"Criar Novo Formulário",ui.criar-novo-formulário,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,165,"Ex: Pesquisa de Satisfação",label.ex-pesquisa-de-satisfação,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,179,"Apenas Dados",ui.apenas-dados,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,180,"Um Arquivo",ui.um-arquivo,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,181,"Importação CSV",ui.importação-csv,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,213,"Carregando formulários...",ui.carregando-formulários,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,238,"Tipo:",ui.tipo,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,244,"Versão:",ui.versão,Add new translation key
app/dpwai/[tenant_snake]/forms/page.tsx,247,"Status:",ui.status,Add new translation key
app/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx,47,"Failed to load",error.failed-to-load,Add new translation key
app/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx,66,"Nenhum registro para exportar",error.nenhum-registro-para-exportar,Add new translation key
app/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx,101,"Erro ao deletar registro",error.erro-ao-deletar-registro,Add new translation key
app/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx,123,"Carregando...",ui.carregando,Add new translation key
app/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx,160,"Nenhum registro ainda",ui.nenhum-registro-ainda,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,43,"No token",error.no-token,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,82,"Falha ao criar formulário",error.falha-ao-criar-formulário,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,99,"Falha ao obter formulário original",error.falha-ao-obter-formulário-original,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,106,"Falha ao criar cópia",error.falha-ao-criar-cópia,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,112,"Falha ao aplicar schema na cópia",error.falha-ao-aplicar-schema-na-cópia,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,184,"Falha ao criar formulário do template",error.falha-ao-criar-formulário-do-template,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,187,"Falha ao salvar schema do template",error.falha-ao-salvar-schema-do-template,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,204,"Falha ao atualizar status",error.falha-ao-atualizar-status,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,214,"Carregando formulários...",ui.carregando-formulários,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,244,"Formulários",ui.formulários,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,245,"Owner",ui.owner,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,246,"Admin",ui.admin,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,270,"Checklist de Inspeção",ui.checklist-de-inspeção,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,271,"Inspeções e verificações",ui.inspeções-e-verificações,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,277,"Registro de Aplicação",ui.registro-de-aplicação,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,278,"Controle de defensivos",ui.controle-de-defensivos,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,284,"Ocorrências de Campo",ui.ocorrências-de-campo,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,285,"Registro de eventos",ui.registro-de-eventos,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,291,"Envio de Documentos",ui.envio-de-documentos,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,292,"Gestão documental",ui.gestão-documental,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,305,"Novo Formulário",ui.novo-formulário,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,317,"Nome do Formulário",ui.nome-do-formulário,Add new translation key
app/dpwai/[tenant_snake]/manual/page.tsx,322,"Ex: Controle de Qualidade",label.ex-controle-de-qualidade,Add new translation key
```

## Key Findings

### Critical Issues
- **Login page** has numerous hardcoded Portuguese strings without translation keys
- **Account/Settings pages** mix Portuguese and English without i18n
- **Forms and Manual pages** have many error messages in Portuguese that are not translatable
- **Ralph Chat** interface has prompts and instructions not in translations.ts

### Pattern Analysis
1. **Error Messages**: 40+ hardcoded error messages (mostly Portuguese)
2. **UI Labels**: 30+ hardcoded labels and headers
3. **Form Placeholders**: 15+ hardcoded example texts
4. **Mixed Languages**: Pages mix Portuguese and English inconsistently

### Recommendations
1. Add all identified strings to `translations.ts` with proper key structure
2. Implement ESLint rule to prevent hardcoded strings in JSX
3. Create a style guide for translation key naming (e.g., `ui.*`, `error.*`, `label.*`)
4. Consider automated checks in CI/CD pipeline
5. Prioritize critical pages (login, select-tenant, account) first

## Usage
The full CSV can be imported into a spreadsheet for tracking and prioritization. Each row represents one hardcoded string that should be moved to the translations file.

### Next Steps
1. Review the CSV entries by file
2. Add missing translations to `/Users/balzer/dpwai-app2/dpwaiagro/lib/i18n/translations.ts`
3. Replace hardcoded strings with `useLanguage()` hook calls
4. Test both English (en) and Portuguese (pt) language modes
5. Add linting rules to prevent future hardcoded strings
