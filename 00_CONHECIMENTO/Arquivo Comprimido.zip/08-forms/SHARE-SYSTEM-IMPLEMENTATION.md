# Sistema de Compartilhamento Avançado de Formulários

**Status:** ✅ Implementado
**Data:** 2026-01-26
**Versão:** 1.0

## 📋 Visão Geral

Sistema completo de compartilhamento de formulários com suporte para:
- **Short Links**: Links curtos (8 caracteres) com rastreamento de cliques
- **QR Codes**: Código QR escaneável gerado dinamicamente
- **WhatsApp**: Integração com WhatsApp Web
- **Email**: Envio de formulários via email para múltiplos destinatários
- **Copy to Clipboard**: Copiar link com feedback visual

---

## 🏗️ Arquitetura

### 1. Banco de Dados (Prisma)

```prisma
model PublicShortLink {
  id            String   @id @default(uuid())
  tenantId      String
  formId        String
  shortCode     String   @unique
  targetPublicId String
  expiresAt     DateTime?
  clickCount    Int      @default(0)
  lastClickAt   DateTime?
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  @@unique([tenantId, formId, shortCode])
  @@index([shortCode])
  @@index([tenantId])
  @@index([formId])
  @@index([createdAt])
}
```

**Campos:**
- `shortCode`: Código único de 8 caracteres (ex: "A1B2C3D4")
- `targetPublicId`: ID do formulário público que será acessado
- `clickCount`: Total de cliques no link
- `lastClickAt`: Timestamp do último clique
- `expiresAt`: Data de expiração (opcional)

---

## 🔌 APIs REST

### 1. POST `/api/agro/[tenant]/forms/[formId]/short-links`

**Criar novo short link**

```bash
curl -X POST http://localhost:3000/api/agro/demo/forms/form1/short-links \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "targetPublicId": "public-form-xyz",
    "expiresAt": "2026-02-26T00:00:00Z"
  }'
```

**Response:**
```json
{
  "id": "uuid",
  "shortCode": "A1B2C3D4",
  "shortUrl": "http://localhost:3000/s/A1B2C3D4",
  "targetPublicId": "public-form-xyz",
  "expiresAt": "2026-02-26T00:00:00Z",
  "createdAt": "2026-01-26T00:00:00Z"
}
```

### 2. GET `/api/agro/[tenant]/forms/[formId]/short-links`

**Listar todos os short links de um formulário**

```bash
curl http://localhost:3000/api/agro/demo/forms/form1/short-links \
  -H "Authorization: Bearer <token>"
```

**Response:**
```json
{
  "shortLinks": [
    {
      "id": "uuid",
      "shortCode": "A1B2C3D4",
      "shortUrl": "http://localhost:3000/s/A1B2C3D4",
      "targetPublicId": "public-form-xyz",
      "expiresAt": null,
      "clickCount": 42,
      "lastClickAt": "2026-01-26T10:30:00Z",
      "createdAt": "2026-01-26T00:00:00Z"
    }
  ],
  "total": 1
}
```

### 3. DELETE `/api/agro/[tenant]/forms/[formId]/short-links/[shortCode]`

**Deletar um short link**

```bash
curl -X DELETE http://localhost:3000/api/agro/demo/forms/form1/short-links/A1B2C3D4 \
  -H "Authorization: Bearer <token>"
```

**Response:**
```json
{
  "message": "Short link deleted successfully",
  "shortCode": "A1B2C3D4"
}
```

### 4. GET `/api/public/short-links/[shortCode]`

**Rota pública de redirecionamento (sem autenticação)**

```bash
# Redireciona automaticamente para /f/[publicId]
curl -L http://localhost:3000/s/A1B2C3D4
```

**Behavior:**
- Incrementa `clickCount`
- Atualiza `lastClickAt`
- Retorna HTTP 302 Redirect para `/f/[publicId]`
- Se expirado, retorna HTTP 410 Gone
- Se não encontrado, retorna HTTP 404 Not Found

---

## 🎨 Componentes Frontend

### ShareModal Component

**Localização:** `/dpwaiagro/components/forms/ShareModal.tsx`

```tsx
<ShareModal
  isOpen={isOpen}
  onClose={() => setIsOpen(false)}
  formId="form-1"
  formName="Pesquisa de Satisfação"
  publicUrl="/f/public-form-xyz"
  tenantSlug="demo"
  onShareSuccess={() => console.log('Shared!')}
/>
```

**Features:**
- Exibe URL completa com botão copy
- Gera short link sob demanda
- Exibe QR code escaneável
- Botão de compartilhamento via WhatsApp
- Botão de compartilhamento via Email
- Lista todos os short links existentes com opção de deletar
- Feedback visual "Copiado!" após copy

### Share Page

**Localização:** `/dpwaiagro/app/dpwai/[tenant_snake]/forms/[formId]/share/page.tsx`

Página dedicada para envio de formulários via email:
- Input de múltiplos emails (separados por vírgula, ponto-e-vírgula ou quebra de linha)
- Campo de assunto customizável
- Campo de mensagem opcional
- Validação de emails
- Feedback de sucesso/erro

---

## 📱 Utilitários

### short-link.ts

**Localização:** `/dpwaiagro/lib/forms/short-link.ts`

```typescript
// Gerar código curto único
const shortCode = generateShortCode(); // "A1B2C3D4"

// Validar código
isValidShortCode("A1B2C3D4"); // true
isValidShortCode("invalid"); // false

// Construir URL
const url = buildShortLinkUrl("A1B2C3D4");
// http://localhost:3000/s/A1B2C3D4
```

---

## 🔐 Segurança

### Autenticação
- ✅ Todas as APIs de criação/listagem/deleção requerem JWT
- ✅ Verificação de tenant access
- ✅ Verificação de formId ownership

### Rota Pública
- ✅ `/api/public/short-links/[shortCode]` não requer autenticação
- ✅ Validação de expiração
- ✅ Tracking anônimo de cliques

### Validações
- ✅ Emails validados antes de envio
- ✅ Short code validado com regex
- ✅ Tenant e formId verificados

---

## 📊 Rastreamento

### Click Analytics
Cada clique em um short link é registrado:
- `clickCount`: Total de cliques
- `lastClickAt`: Timestamp do último clique

Para analytics mais detalhados, considere criar uma tabela adicional:

```prisma
model PublicShortLinkClick {
  id           String   @id @default(uuid())
  shortLinkId  String
  ipAddress    String?
  userAgent    String?
  referer      String?
  createdAt    DateTime @default(now())

  @@index([shortLinkId])
  @@index([createdAt])
}
```

---

## 🧪 Testes

### Testar Geração de Short Link

```bash
# 1. Get auth token
TOKEN=$(curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@dpwai.com","password":"Admin@123456"}' \
  | jq -r .accessToken)

# 2. Create short link
RESPONSE=$(curl -X POST http://localhost:3000/api/agro/demo/forms/form1/short-links \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"targetPublicId":"public-form-xyz"}')

SHORT_CODE=$(echo $RESPONSE | jq -r .shortCode)
echo "Created short link: $SHORT_CODE"

# 3. Test redirect (should get 302)
curl -I http://localhost:3000/s/$SHORT_CODE

# 4. Verify click was tracked
curl http://localhost:3000/api/agro/demo/forms/form1/short-links \
  -H "Authorization: Bearer $TOKEN" \
  | jq '.shortLinks[0].clickCount'
```

### Testar QR Code

1. Abrir modal ShareModal
2. Clicar "Gerar Link Curto"
3. Verificar que QR code é exibido
4. Baixar QR code (PNG)
5. Scannear com câmera/leitor QR
6. Verificar que redireciona corretamente

### Testar WhatsApp

1. Gerar short link
2. Clicar botão WhatsApp
3. Verificar que abre wa.me com link pré-preenchido
4. Verificar que mensagem contém nome do formulário

### Testar Copy to Clipboard

1. Clicar botão "Copiar Link"
2. Verificar feedback "Copiado!" aparece
3. Colar em editor de texto (Ctrl+V / Cmd+V)
4. Verificar que URL está correta

---

## 🔄 Fluxo de Uso

### 1. Admin cria short link

```
Admin → Página de Formulário
  → Clica botão "Compartilhar"
  → Modal ShareModal abre
  → Clica "Gerar Link Curto"
  → API cria PublicShortLink
  → QR code gerado
  → Short link exibido
```

### 2. Admin compartilha via WhatsApp

```
Admin → Modal ShareModal
  → Clica botão WhatsApp
  → Abre wa.me com link pré-preenchido
  → Envia para contatos
  → Contatos recebem link curto
```

### 3. Usuário acessa via short link

```
Usuário → Clica link curto (s/A1B2C3D4)
  → GET /api/public/short-links/A1B2C3D4
  → API incrementa clickCount
  → API retorna 302 Redirect
  → Browser redireciona para /f/[publicId]
  → Formulário público é exibido
```

### 4. Admin envia via Email

```
Admin → Página /forms/[formId]/share
  → Digita emails
  → Clica "Enviar Emails"
  → API envia emails via Resend
  → Cada email contém link curto
  → Cada destinatário pode acessar
```

---

## 🚀 Próximas Melhorias

### Phase 2
- [ ] Analytics dashboard com gráficos de cliques
- [ ] Compartilhamento via SMS (Twilio)
- [ ] Agendamento de envios de email
- [ ] Templates de email customizáveis
- [ ] Preview de email antes de enviar

### Phase 3
- [ ] Campanha de compartilhamento (rastreamento)
- [ ] A/B testing de links
- [ ] Rate limiting por IP
- [ ] Segurança: hCaptcha para formulários públicos
- [ ] Expiração automática de links antigos

---

## 📚 Referências

- **Rota Pública:** `/s/[shortCode]`
- **Modal:** `ShareModal.tsx`
- **Página Share:** `/forms/[formId]/share/page.tsx`
- **API Docs:** `/api/agro/[tenant]/forms/[formId]/short-links`
- **Tradução:** `translations['pt-BR'].form.share*`

---

## ✅ Checklist de Implementação

- [x] Modelo PublicShortLink criado no Prisma
- [x] Migração de banco de dados
- [x] API POST para criar short link
- [x] API GET para listar short links
- [x] API DELETE para deletar short link
- [x] API pública de redirecionamento (GET /api/public/short-links/[shortCode])
- [x] Componente ShareModal com QR code
- [x] Página de compartilhamento por email
- [x] Rota pública /s/[shortCode]
- [x] Utilitários de short link
- [x] Traduções (pt-BR)
- [x] Documentação completa
- [ ] Testes E2E
- [ ] Testes de unidade
- [ ] Deploy em produção

---

## 🐛 Troubleshooting

### QR Code não gera
- Verificar se `qrcode` está instalado: `npm list qrcode`
- Verificar console do browser para erros
- Tentar atualizar página

### WhatsApp não abre
- Verificar se está em mobile ou web
- Desktop: abrir wa.web.com
- Mobile: abrir WhatsApp app

### Email não enviado
- Verificar RESEND_API_KEY está configurada
- Verificar logs da API
- Verificar inbox de spam

### Short link não redireciona
- Verificar se short code existe: GET /api/agro/[tenant]/forms/[formId]/short-links
- Verificar se targetPublicId é válido
- Verificar se link não expirou

---

**Last Updated:** 2026-01-26
**Maintainer:** Claude Code Agent
**Version:** 1.0
