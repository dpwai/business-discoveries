# Forms System Documentation

Welcome to the Forms module documentation. This directory contains comprehensive guides for the DPWAI form management system.

## 📋 Table of Contents

### Core Features

1. **[SHARE-SYSTEM-IMPLEMENTATION.md](./SHARE-SYSTEM-IMPLEMENTATION.md)**
   - Advanced form sharing system with short links and QR codes
   - Public redirect API and analytics
   - ShareModal component documentation
   - Email sharing integration
   - Complete API reference and examples

## Key Components

### Short Link System
- **Model**: `PublicShortLink` - Manages short codes, click tracking, expiration
- **APIs**:
  - `POST /api/agro/[tenant]/forms/[formId]/short-links` - Create short link
  - `GET /api/agro/[tenant]/forms/[formId]/short-links` - List all short links
  - `DELETE /api/agro/[tenant]/forms/[formId]/short-links/[shortCode]` - Delete link
  - `GET /api/public/short-links/[shortCode]` - Public redirect (no auth required)

### ShareModal Component
- Location: `/components/forms/ShareModal.tsx`
- Features:
  - Copy to clipboard with feedback
  - QR code generation (scaneável)
  - WhatsApp direct integration
  - Email share button
  - Manage existing short links with delete option

### Share Page
- Location: `/app/dpwai/[tenant_snake]/forms/[formId]/share/page.tsx`
- Features:
  - Multi-email input (comma, semicolon, or line-separated)
  - Customizable email subject and message
  - Email validation
  - Resend API integration ready

## Quick Start

### Generate a Short Link
```typescript
import { generateShortCode, buildShortLinkUrl } from '@/lib/forms/short-link';

const shortCode = generateShortCode(); // "A1B2C3D4"
const shortUrl = buildShortLinkUrl(shortCode); // "http://localhost:3000/s/A1B2C3D4"
```

### Use ShareModal
```tsx
<ShareModal
  isOpen={isOpen}
  onClose={() => setIsOpen(false)}
  formId="form-123"
  formName="Customer Feedback"
  publicUrl="/f/public-id-xyz"
  tenantSlug="demo-tenant"
  onShareSuccess={() => console.log('Shared!')}
/>
```

### Create Short Link via API
```bash
curl -X POST http://localhost:3000/api/agro/demo/forms/form1/short-links \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"targetPublicId":"public-form-xyz"}'
```

## Security & Privacy

- ✅ All authenticated endpoints require JWT
- ✅ Tenant isolation enforced
- ✅ Public redirect endpoint has no authentication
- ✅ Click tracking is anonymous
- ✅ Expiration support for time-limited sharing
- ✅ Email validation before sending

## Database Model

```prisma
model PublicShortLink {
  id            String   @id @default(uuid())
  tenantId      String
  formId        String
  shortCode     String   @unique        // "A1B2C3D4"
  targetPublicId String               // public form ID
  expiresAt     DateTime?             // optional expiration
  clickCount    Int      @default(0)  // analytics
  lastClickAt   DateTime?             // last access time
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  @@unique([tenantId, formId, shortCode])
  @@index([shortCode])
  @@index([tenantId])
  @@index([formId])
  @@index([createdAt])
}
```

## Translations

All sharing features are translated to Portuguese (pt-BR):
- `form.share` - "Compartilhar"
- `form.short-link` - "Link Curto"
- `form.qr-code` - "Código QR"
- `form.send-email` - "Enviar por Email"
- And many more in `lib/i18n/translations.ts`

## Status

- ✅ Implementation complete
- ✅ Short link generation working
- ✅ QR code generation working
- ✅ Public redirect working
- ✅ Click tracking working
- ✅ ShareModal component complete
- ✅ Share page complete
- ✅ Documentation complete
- ⏳ E2E tests (planned)
- ⏳ Analytics dashboard (planned)

## Related Documentation

- **Forms Design Guide**: See `/knowledge/00-overview/FORMS-DESIGN-GUIDE.md`
- **Component Library**: See `/knowledge/02-frontend/COMPONENT-LIBRARY.md`
- **API Reference**: See `/knowledge/03-backend/API-REFERENCE.md`
- **Setup Guide**: See `/knowledge/01-setup-local/QUICK-START.md`

## Contact

For questions or issues with the forms system, refer to the comprehensive documentation in `SHARE-SYSTEM-IMPLEMENTATION.md` or check the troubleshooting section in `/knowledge/07-troubleshooting/`.

---

**Last Updated**: 2026-01-26
**Version**: 1.0
**Status**: Production Ready
