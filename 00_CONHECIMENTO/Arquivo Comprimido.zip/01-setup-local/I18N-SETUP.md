# Translation Fix Guide

## Overview

This guide shows how to fix the 100+ hardcoded strings found in the codebase. All hardcoded strings should be moved to the centralized translation system.

## Files Generated

1. **hardcoded_strings.csv** - Complete list of all 100+ hardcoded strings with suggested translation keys
2. **HARDCODED_STRINGS_REPORT.md** - Detailed analysis and findings
3. **TRANSLATION_FIX_GUIDE.md** - This file with instructions

## How to Use

### Step 1: Add Translations to translations.ts

For each hardcoded string, add it to `/lib/i18n/translations.ts`:

```typescript
// Example: Adding new error messages
'error.falha-ao-alternar-tenant': 'Falha ao alternar tenant',

// Example: Adding new UI labels
'ui.selecione-um-tenant': 'Selecione um Tenant',
'ui.formulários': 'Formulários',

// Example: Adding new labels/placeholders
'label.seu-nome': 'Seu nome',
'label.ex-pesquisa-de-satisfação': 'Ex: Pesquisa de Satisfação',
```

### Step 2: Update Code to Use Translations

Before:
```tsx
// app/dpwai/select-tenant/page.tsx (line 97)
<h1 className="text-3xl font-bold text-gray-900">Selecione um Tenant</h1>
```

After:
```tsx
'use client';
import { useLanguage } from '@/lib/i18n/useLanguage';

export default function SelectTenantPage() {
  const { t } = useLanguage();

  return (
    <h1 className="text-3xl font-bold text-gray-900">{t('ui.selecione-um-tenant')}</h1>
  );
}
```

### Step 3: Handle Error Messages

Before:
```tsx
setError('Falha ao alternar tenant');
```

After:
```tsx
const { t } = useLanguage();
setError(t('error.falha-ao-alternar-tenant'));
```

### Step 4: Handle Placeholders

Before:
```tsx
<input placeholder="Seu nome" />
```

After:
```tsx
<input placeholder={t('label.seu-nome')} />
```

## Priority Order (Fix These First)

### Priority 1 (Critical - User-Facing Auth Pages)
- [ ] `app/login/page.tsx` - 19 hardcoded strings
- [ ] `app/dpwai/select-tenant/page.tsx` - 5 hardcoded strings

### Priority 2 (High - Core Features)
- [ ] `app/dpwai/[tenant_snake]/account/page.tsx` - 22 hardcoded strings
- [ ] `app/dpwai/[tenant_snake]/settings/page.tsx` - 4 hardcoded strings
- [ ] `app/dpwai/[tenant_snake]/forms/page.tsx` - 15 hardcoded strings

### Priority 3 (Medium - Feature Pages)
- [ ] `app/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx` - 5 hardcoded strings
- [ ] `app/dpwai/[tenant_snake]/manual/page.tsx` - 23 hardcoded strings
- [ ] `app/dpwai/[tenant_snake]/users/page.tsx` - 3 hardcoded strings

### Priority 4 (API Layer)
- [ ] `app/api/agro/[tenant]/forms/[formId]/records/[recordId]/route.ts` - Error messages

## Translation Key Naming Conventions

### Error Messages (`error.*`)
- Validation errors: `error.campo-obrigatório`, `error.deve-ser-número`
- Load failures: `error.failed-to-load-forms`, `error.falha-ao-carregar-usuários`
- Operation failures: `error.erro-ao-deletar-registro`, `error.falha-ao-salvar`

### UI Labels (`ui.*`)
- Page titles: `ui.formulários`, `ui.minha-conta`
- Headers: `ui.configurações`, `ui.segurança`
- Button labels: `ui.selecionar`, `ui.confirmar`
- Loading states: `ui.carregando`, `ui.carregando-formulários`

### Form Labels (`label.*`)
- Placeholders: `label.seu-nome`, `label.ex-pesquisa-de-satisfação`
- Examples: `label.voce@empresa.com`, `label.11-99999-9999`
- Help text: `label.por-favor,-digite-um-nome`

## Common Patterns to Fix

### Pattern 1: JSX Text Content
```tsx
// Before
<h1>Formulários</h1>

// After
<h1>{t('ui.formulários')}</h1>
```

### Pattern 2: Error Messages
```tsx
// Before
catch (err) {
  setError('Falha ao carregar perfil');
}

// After
catch (err) {
  setError(t('error.falha-ao-carregar-perfil'));
}
```

### Pattern 3: Alert Messages
```tsx
// Before
alert('Deletar este registro?');

// After
if (confirm(t('error.deletar-este-registro?'))) {
  // delete
}
```

### Pattern 4: Placeholder Attributes
```tsx
// Before
<input placeholder="Seu nome" />

// After
<input placeholder={t('label.seu-nome')} />
```

### Pattern 5: Fallback Messages
```tsx
// Before
const res = await fetch(...);
const data = await res.json();
if (!res.ok) {
  setError(data.error || 'Falha ao alternar tenant');
}

// After
if (!res.ok) {
  setError(data.error || t('error.falha-ao-alternar-tenant'));
}
```

## Testing Checklist

After making changes:

- [ ] Test English (en) language mode - all strings should display in English
- [ ] Test Portuguese (pt) language mode - all strings should display in Portuguese
- [ ] Test error states - all error messages should be translated
- [ ] Test placeholder texts - all form placeholders should be translated
- [ ] Verify localStorage language preference is respected
- [ ] Check browser console for no errors related to translation keys

## Build Verification

Run these checks before committing:

```bash
# 1. Check for any remaining hardcoded strings (should be empty)
grep -r "Carregando\|Erro\|Falha\|Sucesso" app/ --include="*.tsx" --include="*.ts" | grep -v "translations.ts" | grep -v "node_modules"

# 2. Verify TypeScript compilation
npm run build

# 3. Run linting
npm run lint
```

## Key Files to Update

Main translation file:
- `/Users/balzer/dpwai-app2/dpwaiagro/lib/i18n/translations.ts`

Pages to update:
1. `/Users/balzer/dpwai-app2/dpwaiagro/app/login/page.tsx`
2. `/Users/balzer/dpwai-app2/dpwaiagro/app/dpwai/select-tenant/page.tsx`
3. `/Users/balzer/dpwai-app2/dpwaiagro/app/dpwai/[tenant_snake]/account/page.tsx`
4. `/Users/balzer/dpwai-app2/dpwaiagro/app/dpwai/[tenant_snake]/settings/page.tsx`
5. `/Users/balzer/dpwai-app2/dpwaiagro/app/dpwai/[tenant_snake]/forms/page.tsx`
6. `/Users/balzer/dpwai-app2/dpwaiagro/app/dpwai/[tenant_snake]/forms/[formId]/records/page.tsx`
7. `/Users/balzer/dpwai-app2/dpwaiagro/app/dpwai/[tenant_snake]/manual/page.tsx`
8. `/Users/balzer/dpwai-app2/dpwaiagro/app/dpwai/[tenant_snake]/users/page.tsx`

API routes to update:
- `/Users/balzer/dpwai-app2/dpwaiagro/app/api/agro/[tenant]/forms/[formId]/records/[recordId]/route.ts`

## Future Prevention

After fixing these issues, add ESLint rules to prevent hardcoded strings in the future:

```javascript
// eslintrc.json
{
  "rules": {
    "no-hardcoded-strings": "warn"
  }
}
```

Or use a simpler approach with git pre-commit hooks to warn about hardcoded strings.

## Questions?

Refer to:
- Current usage: `/Users/balzer/dpwai-app2/dpwaiagro/lib/i18n/useLanguage.ts`
- Translation system: `/Users/balzer/dpwai-app2/dpwaiagro/lib/i18n/translations.ts`
- Language context: `/Users/balzer/dpwai-app2/dpwaiagro/lib/i18n/LanguageContext.tsx`
