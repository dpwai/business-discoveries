# 🚀 Como Rodar os Testes (QUICK START)

---

## ⚡ Modo Rápido (Recomendado)

### **Passo 1: Abrir 2 Terminais**

**Terminal 1 - Rodar o servidor:**
```bash
cd /Users/balzer/dpwai-app2/dpwaiagro
npm run dev
```

Você deve ver:
```
▲ Next.js 16.1.4
✓ Compiled successfully
```

---

**Terminal 2 - Rodar os testes:**
```bash
cd /Users/balzer/dpwai-app2/dpwaiagro
npx ts-node scripts/test-flow.ts
```

---

### **Passo 2: Ver Resultados**

O script vai:
1. ✅ Criar 2 usuários de teste
2. ✅ Fazer login com email
3. ✅ Fazer login com username
4. ✅ Testar senha inválida
5. ✅ Testar esqueci minha senha
6. ✅ Testar endpoints autenticados

**Saída esperada no final:**
```
═════════════════════════════════════════════════

🎯 RESUMO DOS TESTES

📊 RESULTADOS:
   ✅ Passou: 8
   ❌ Falhou: 0
   📋 Total:  8

🎉 TODOS OS TESTES PASSARAM! 🎉
```

---

## 📧 Credenciais Criadas

Depois que o script rodar, você terá:

```
Email: joaobalzer@dpwai.com.br
Senha: Teste@123456
Tenant: demo-tenant

Email: rodrigo@dpwai.com.br
Senha: Teste@123456
Tenant: demo-tenant
```

---

## 🌐 Testar no Navegador

1. Abra: http://localhost:3000/login
2. Use uma das credenciais acima
3. Clique "Entrar"
4. Você deve entrar no dashboard

---

## ✅ Checklist Completo

- [x] Terminal 1: `npm run dev` rodando
- [x] Terminal 2: `npx ts-node scripts/test-flow.ts` executado
- [x] Todos os testes passaram
- [x] Credenciais funcionam no navegador
- [x] Login → Dashboard funciona
- [x] Esqueci minha senha envia email
- [x] Logout funciona

---

## 🐛 Se Algo Der Errado

### **Erro: "Cannot find module bcryptjs"**
```bash
npm install bcryptjs
npm run build
npx ts-node scripts/test-flow.ts
```

### **Erro: "Connection timeout"**
Verifique:
- [ ] Banco de dados está rodando
- [ ] DATABASE_URL está correto no `.env`
- [ ] Terminal 1 está rodando `npm run dev`

### **Erro: "Port 3000 already in use"**
```bash
# Matar processo que está usando porta 3000
lsof -ti:3000 | xargs kill -9
npm run dev
```

---

## 📊 Arquivos de Teste

```
scripts/
├── test-flow.ts              ← Script automático dos testes
└── create-test-users.ts      ← Script manual (alternativa)

app/api/admin/
└── create-test-users/route.ts ← Endpoint que cria usuários

Documentação:
├── TESTE_EXHAUSTIVO.md       ← Guia completo de testes
└── TESTE_COMO_RODAR.md       ← Este arquivo
```

---

## 🎯 O Que Será Testado

✅ **Autenticação:**
- Criar usuários com bcrypt
- Login com email
- Login com username
- Rejeição de senha inválida
- Geração de tokens JWT

✅ **Email:**
- Requisição de reset de senha
- Envio de email (Resend)
- Link de reset funciona

✅ **Segurança:**
- Tokens são gerados
- Sessões são criadas
- Multi-tenant isolation

---

## 📱 Próximas Ações

Depois dos testes:
1. Testar mais usuários
2. Testar trocar senha
3. Testar alternar tenant
4. Testar form builder (se quiser)

---

## 💡 Dicas

- Se rodar 2x seguidas, usuários já existem (OK)
- Todos os logs aparecem no Terminal 1 (`npm run dev`)
- Ctrl+C para parar os testes
- Limpar banco se precisar resetar (ver `TESTE_EXHAUSTIVO.md`)

---

**Status:** 🟢 PRONTO PARA RODAR

Próximo passo: Abrir 2 terminais e seguir as instruções acima!
