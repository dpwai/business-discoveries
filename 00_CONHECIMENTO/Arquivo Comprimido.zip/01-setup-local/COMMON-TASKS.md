# 🎯 Common Development Tasks

**How to accomplish frequent tasks during development.**

**Status**: 🟢 Quick Reference
**Last Updated**: 25 January 2026

---

## 📁 Project Navigation

```bash
# Go to app directory
cd dpwaiagro

# Check what scripts are available
npm run        # Lists all available scripts

# View current branch
git status
```

---

## 🚀 Starting Development

```bash
# 1. Start dev server
npm run dev

# Opens on http://localhost:3000

# 2. In another terminal, watch for type errors
npx tsc --watch

# 3. Or run tests
npm run test
```

---

## 🗄️ Database Operations

### View Database in UI
```bash
npx prisma studio
# Opens http://localhost:5555
# Browse all tables, data, relationships
```

### Create Migration
```bash
# After editing schema.prisma:
npx prisma migrate dev --name <migration_name>

# Example:
npx prisma migrate dev --name add_user_phone_field
```

### Run Pending Migrations
```bash
npx prisma migrate deploy
```

### Reset Database (DEV ONLY!)
```bash
npx prisma migrate reset
# ⚠️ WARNING: Deletes all data!
# Only use in local development
```

### Seed Database
```bash
npm run prisma:seed
# Runs seed.ts, populates test data
```

---

## 👥 Test Users

### Create Test Users
```bash
# Option 1: API endpoint
curl -X POST http://localhost:3000/api/admin/create-test-users

# Option 2: TypeScript script
npx ts-node scripts/tools/create-test-users.ts
```

**Created Users**:
- Email: joaobalzer@dpwai.com.br
- Email: rodrigo@dpwai.com.br
- Password: Teste@123456
- Tenant: demo-tenant

---

## 🧪 Testing

### Run All Tests
```bash
npm run test
```

### Run Specific Test
```bash
npm run test -- path/to/test.ts
```

### Automated Test Suite
```bash
# Full auth + email + database testing
npx ts-node scripts/tools/test-flow.ts
```

---

## 🔍 Debugging

### Check TypeScript Errors
```bash
npx tsc --noEmit
```

### View Build Output Size
```bash
npm run build
# Check .next/static/ for bundle sizes
```

### Browser DevTools
```
F12 or right-click → Inspect
- Console tab: JavaScript errors
- Network tab: API calls
- Application tab: localStorage, cookies
```

### VS Code Debugging
Create `.vscode/launch.json`:
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Next.js",
      "type": "node",
      "runtimeExecutable": "npm",
      "runtimeArgs": ["run", "dev"],
      "console": "integratedTerminal"
    }
  ]
}
```

---

## 📝 Making Changes

### Create New Page
```
1. Create /dpwaiagro/app/dpwai/[tenant_snake]/newpage/page.tsx
2. Add layout.tsx if needed
3. Run npm run dev
4. Visit http://localhost:3000/dpwai/demo-tenant/newpage
```

### Create New API Route
```
1. Create /dpwaiagro/app/api/path/route.ts
2. Export functions: export async function GET() { }
3. Test with curl or Postman
4. Add to documentation
```

### Add Translation
```
1. Edit /dpwaiagro/lib/i18n/translations.ts
2. Add key to both pt and en objects
3. Use: translations[language].category.key
```

### Change Design Tokens
```
1. Edit /dpwaiagro/tailwind.config.ts
2. OR edit /dpwaiagro/app/globals.css
3. Restart dev server
4. Changes apply globally
```

---

## 🔗 API Testing

### Using curl
```bash
# Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"Teste@123456"}'

# Get response with token
# { "accessToken": "eyJh...", "user": {...} }
```

### Using token
```bash
# Store token
TOKEN="eyJh..."

# Make authenticated request
curl -X GET http://localhost:3000/api/auth/me/tenants \
  -H "Authorization: Bearer $TOKEN"
```

### Using Postman/Insomnia
1. Import collection
2. Set base URL: http://localhost:3000
3. Login endpoint stores token automatically
4. Subsequent requests use token

---

## 🔐 Password Reset Testing

### Request Reset
```bash
curl -X POST http://localhost:3000/api/auth/forgot-password \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com"}'
```

### Check Console
- Terminal running `npm run dev` shows email content
- Look for reset link with token
- Visit link: http://localhost:3000/reset-password?token=...

### Reset Password
```bash
curl -X POST http://localhost:3000/api/auth/reset-password \
  -H "Content-Type: application/json" \
  -d '{"token":"...","newPassword":"NewPass@123"}'
```

---

## 📦 Dependencies

### Add Package
```bash
npm install package-name
# Or with version:
npm install package-name@1.2.3
```

### Remove Package
```bash
npm uninstall package-name
```

### Update Packages
```bash
# Check outdated
npm outdated

# Update all
npm update

# Update specific
npm install package-name@latest
```

### List Installed
```bash
npm list
```

---

## 🔄 Git Workflow

### Check Status
```bash
git status
```

### Create Branch
```bash
git checkout -b feature/my-feature
```

### Stage Changes
```bash
git add file.ts
# Or all:
git add .
```

### Commit
```bash
git commit -m "feat: add new feature

Description of changes.

Co-Authored-By: Claude Haiku 4.5 <noreply@anthropic.com>"
```

### Push
```bash
git push origin feature/my-feature
```

### Create PR
```bash
# Via GitHub CLI:
gh pr create --title "Add new feature" --body "Description"
```

---

## 🚢 Deployment

### Deploy to Vercel
```bash
# Simply push to main:
git push origin main

# Vercel auto-deploys
# Check: https://vercel.com/dashboard
```

### Check Deployment Logs
```bash
# Via CLI:
vercel logs

# Or in dashboard:
# https://vercel.com/projects/dpwai-agro
```

---

## 🐛 Troubleshooting

### Build Fails
```bash
# Clear cache
rm -rf .next node_modules
npm install
npm run build
```

### Port 3000 in Use
```bash
# Find what's using it:
lsof -i :3000

# Kill the process:
lsof -ti:3000 | xargs kill -9
```

### Database Connection Error
```bash
# Check:
1. DATABASE_URL in .env is correct
2. Database is running
3. Network access enabled

# Test connection:
npx prisma db execute --file test.sql
```

### TypeScript Errors
```bash
# Regenerate Prisma types:
npm run prisma:generate

# Check all errors:
npx tsc --noEmit
```

---

**Quick Links**: 
- Setup: `/knowledge/01-setup-local/QUICK-START.md`
- Scripts: `/scripts/README.md`
- API Routes: See `/dpwaiagro/app/api/`

