# ✅ CHECKLIST - SETUP COMPLETO

Marca enquanto você vai fazendo:

---

## 📋 FASE 1: PREPARAÇÃO (5 MIN)

### Terminal - Gerar JWT_SECRET

- [ ] Abri terminal
- [ ] Rodei: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
- [ ] Copiei o resultado (64 caracteres)
- [ ] **Guardei em nota segura** ← IMPORTANTE!

**Resultado:**
```
[COLE O RESULTADO AQUI]
```

---

## 🏗️ FASE 2: CRIAR BANCO (5 MIN)

### Neon.tech - PostgreSQL

- [ ] Abri https://console.neon.tech
- [ ] Fiz login com GitHub
- [ ] Cliquei "Create a project"
- [ ] Deixei padrão (PostgreSQL / us-east-1)
- [ ] Cliquei "Create"
- [ ] Aguardei terminar (leva ~1 min)
- [ ] Cliquei "Connection string"
- [ ] Copiei a string inteira (com `sslmode=require`)
- [ ] **Guardei em nota segura** ← IMPORTANTE!

**Connection String:**
```
[COLE AQUI]
```

---

## 📧 FASE 3: CRIAR API KEY EMAIL (2 MIN)

### Resend.com - Email Service

- [ ] Abri https://resend.com/api-keys
- [ ] Fiz login (ou criei conta)
- [ ] Cliquei "Create API Key"
- [ ] Digitei nome "dpwai"
- [ ] Cliquei "Create"
- [ ] Copiei a chave (começa com `re_`)
- [ ] **Guardei em nota segura** ← IMPORTANTE!

**API Key:**
```
[COLE AQUI]
```

---

## 🚀 FASE 4: ADICIONAR NA VERCEL (5 MIN)

### Vercel - Environment Variables

**Abri:** https://vercel.com → Projeto "dpwai-app2" → Settings → Environment Variables

#### Variável 1: DATABASE_URL
- [ ] Cliquei "Add New"
- [ ] Campo "Variável": `DATABASE_URL`
- [ ] Campo "Valor": [COLE A CONNECTION STRING DO NEON]
- [ ] Marcaram: ✓ Production  ✓ Preview  ✓ Development
- [ ] Cliquei "Save"

#### Variável 2: JWT_SECRET
- [ ] Cliquei "Add New"
- [ ] Campo "Variável": `JWT_SECRET`
- [ ] Campo "Valor": [COLE O RESULTADO DO TERMINAL]
- [ ] Marcaram: ✓ Production  ✓ Preview  ✓ Development
- [ ] Cliquei "Save"

#### Variável 3: NEXT_PUBLIC_APP_URL
- [ ] Cliquei "Add New"
- [ ] Campo "Variável": `NEXT_PUBLIC_APP_URL`
- [ ] Campo "Valor": `https://app.dpwai.com.br`
- [ ] Marcaram: ✓ Production  ✓ Preview  ✓ Development
- [ ] Cliquei "Save"

#### Variável 4: RESEND_API_KEY
- [ ] Cliquei "Add New"
- [ ] Campo "Variável": `RESEND_API_KEY`
- [ ] Campo "Valor": [COLE A API KEY DO RESEND]
- [ ] Marcaram: ✓ Production  ✓ Preview  ✓ Development
- [ ] Cliquei "Save"

#### Variável 5: EMAIL_FROM
- [ ] Cliquei "Add New"
- [ ] Campo "Variável": `EMAIL_FROM`
- [ ] Campo "Valor": `DPWAI Agro <noreply@dpwai.com.br>`
- [ ] Marcaram: ✓ Production  ✓ Preview  ✓ Development
- [ ] Cliquei "Save"

---

## 🔄 FASE 5: REDEPLOY (3 MIN)

### Vercel - Redeploy

- [ ] Fui pra aba "Deployments" (topo da Vercel)
- [ ] Achei o deploy mais recente
- [ ] Cliquei os 3 pontinhos (...) do lado dele
- [ ] Cliquei "Redeploy"
- [ ] **Aguardei ficar verde** (2-3 minutos)

**Status:** [ ] Verde ✓ ou [ ] Vermelho ✗

Se vermelho:
- [ ] Cliquei no deploy pra ver logs
- [ ] Procurei por erro
- [ ] Chequei se variável foi adicionada corretamente

---

## 🧪 FASE 6: TESTAR (2 MIN)

### Teste 1: Login Funciona?

- [ ] Abri https://app.dpwai.com.br/login
- [ ] Digitei email + senha
- [ ] Cliquei login

**Resultado:** [ ] Entrei ✓ ou [ ] Erro ✗

Se erro:
- [ ] Checquei DATABASE_URL
- [ ] Checquei JWT_SECRET
- [ ] Fiz redeploy de novo

### Teste 2: Email Funciona?

- [ ] Abri https://app.dpwai.com.br/forgot-password
- [ ] Digitei um email
- [ ] Cliquei "Reset Password"
- [ ] **Aguardei ~10 segundos**
- [ ] Chequei inbox (ou spam)

**Resultado:** [ ] Email chegou ✓ ou [ ] Não chegou ✗

Se não chegou:
- [ ] Checquei RESEND_API_KEY
- [ ] Checquei NEXT_PUBLIC_APP_URL (tem https://?)
- [ ] Fiz redeploy de novo

### Teste 3: Link do Email Está Correto?

- [ ] Abri o email recebido
- [ ] Cliquei no link de reset
- [ ] Chequei se a URL começa com `https://app.dpwai.com.br`

**Resultado:** [ ] URL correta ✓ ou [ ] URL errada ✗

Se URL errada:
- [ ] Chequei NEXT_PUBLIC_APP_URL na Vercel
- [ ] Fiz redeploy

---

## 🎉 FASE FINAL: TUDO VERDE?

- [ ] Login funciona
- [ ] Email chega
- [ ] Link do email está correto
- [ ] Build está verde

**SE TODOS MARCADOS = 100% PRONTO! 🚀**

---

## 🆘 PROBLEMAS COMUNS

### ❌ Build ficou vermelho

**Checklist:**
- [ ] DATABASE_URL está preenchida? (não vazia)
- [ ] JWT_SECRET está preenchida? (não vazia)
- [ ] NEXT_PUBLIC_APP_URL está preenchida? (não vazia)
- [ ] RESEND_API_KEY está preenchida? (não vazia)
- [ ] Todas tem os 3 ambientes marcados?

Se tudo ok:
- [ ] Cliquei em "Redeploy" de novo
- [ ] Aguardei build terminar

### ❌ Login não funciona

**Checklist:**
- [ ] Database_URL com `sslmode=require`?
- [ ] JWT_SECRET tem mais de 20 caracteres?
- [ ] Build está verde?

Se tudo ok:
- [ ] Hard refresh browser (Ctrl+F5)
- [ ] Limpar cookies: DevTools → Application → Cookies → Delete all
- [ ] Tentar login de novo

### ❌ Email não chega

**Checklist:**
- [ ] RESEND_API_KEY começa com `re_`?
- [ ] EMAIL_FROM está preenchida?
- [ ] Build está verde?
- [ ] Chequei spam folder?

Se tudo ok:
- [ ] Ir em resend.com → Dashboard → Emails
- [ ] Procurar pelo email ali
- [ ] Ver se tem erro

### ❌ Link do email está quebrado

**Checklist:**
- [ ] NEXT_PUBLIC_APP_URL começa com `https://` (não http)?
- [ ] Termina com `.br` (não tem `/` no final)?
- [ ] Build está verde?

---

## 📝 NOTES

Espaço pra anotar algo importante:

```
[ESPAÇO LIVRE PRA ANOTAS]
```

---

## ✨ SUCESSO!

Quando tudo passar nos testes = App está 100% viva!

**Próximos passos:**
1. Configurar domínio (já fez? Ver HOSTINGER_SETUP.md)
2. Criar primeiros usuários
3. Começar a usar!

---

**Precisa de ajuda?**
- VERCEL_PRONTO.md - Com exemplos
- SETUP_RAPIDO.txt - Visual
- VERCEL_SETUP.md - Detalhado
