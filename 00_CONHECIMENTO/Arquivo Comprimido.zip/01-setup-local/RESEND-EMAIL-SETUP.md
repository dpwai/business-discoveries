# Resend Password Reset Testing Checklist

## Objetivo
Garantir que o Resend está enviando corretamente o email de recuperação de senha no ambiente do MVP, usando `joaobalzer@dpwai.com.br` como email de teste.

---

## Configuração Pré-Requisitos

### 1. Environment Variables
Certifique-se de que as seguintes variáveis estão configuradas no `.env`:

```bash
# Resend Configuration
RESEND_API_KEY=re_xxxxxxxxxxxxx
RESEND_FROM=noreply@dpwai.com.br  # ou seu domínio verificado no Resend

# App Configuration
APP_BASE_URL=http://localhost:3000  # ou seu URL em produção
NODE_ENV=development
```

### 2. Criar usuário de teste (se não existir)

Execute este comando no banco de dados:

```sql
INSERT INTO "User" (id, email, username, "passwordHash", "firstName", "lastName", status)
VALUES (
  'test-user-pwd-reset',
  'joaobalzer@dpwai.com.br',
  'joaobalzer',
  '$2b$10$...', -- bcrypt hash de uma senha qualquer
  'João',
  'Balzer',
  'ACTIVE'
);

-- Adicionar membership ao tenant padrão (ajuste tenant_id conforme necessário)
INSERT INTO "Membership" ("userId", "tenantId", role, "isOwner", "isAdmin")
VALUES ('test-user-pwd-reset', '15a01efb-04bd-4aa7-bb7b-a38bcd45a65c', 'owner', true, true);
```

---

## Teste Manual (Passo a Passo)

### Passo 1: Acessar página de "Esqueceu a Senha"

1. Navegue até: `http://localhost:3000/forgot-password`
2. Você deve ver a página com o formulário de recuperação

**Screenshot esperado:** Página com campo de email e botão "Enviar Instruções"

---

### Passo 2: Submeter email para reset

1. Digite: `joaobalzer@dpwai.com.br`
2. Clique em "Enviar Instruções"
3. Observe a resposta: "Email enviado! Verifique sua caixa de entrada..."

**O que esperar:**
- ✅ Resposta 200 (sem vazar se o email existe ou não)
- ✅ Mensagem genérica de sucesso
- ✅ Email enviado pelo Resend em <1 minuto

---

### Passo 3: Receber e validar email

1. **Abra seu email** (joaobalzer@dpwai.com.br)
2. **Procure por:**
   - Remetente: `noreply@dpwai.com.br`
   - Assunto: `Reset your password` ou `Recuperar Senha`
3. **Valide o conteúdo:**
   - [ ] Saudação personalizada ("Hello, João")
   - [ ] Aviso de expiração (ex: "link expires in 30 minutes")
   - [ ] Botão "Reset Password" ou link clicável
   - [ ] Fallback text: `http://localhost:3000/reset-password?token=...`
   - [ ] Aviso: "If you didn't request this, ignore this email"

**Screenshot esperado:** Email com logo da DPWAI, botão verde, conteúdo profissional

---

### Passo 4: Extrair token da URL

1. **Clique no botão "Reset Password"** no email, ou
2. **Copie o link** do texto fallback
3. **Extraia o token:**
   ```
   http://localhost:3000/reset-password?token=<COPIE_ISTO>
   ```

Exemplo de token:
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

### Passo 5: Acessar página de reset

1. **Clique no link** do email (ou navegue manualmente)
2. **URL será:** `http://localhost:3000/reset-password?token=...`
3. **Página esperada:** Formulário com:
   - Campo "Nova Senha"
   - Campo "Confirmar Senha"
   - Botão "Resetar Senha"
   - Validação: "Mínimo de 8 caracteres"

**Screenshot esperado:** Página limpa com gradiente verde/azul

---

### Passo 6: Definir nova senha

1. Digite nova senha: `NovoPass@123456` (min 8 chars, com maiúscula + número)
2. Confirme: `NovoPass@123456`
3. Clique "Resetar Senha"
4. **Mensagem esperada:** "Sua senha foi resetada com sucesso. Você será redirecionado para o login..."
5. **Aguarde:** ~2 segundos para redirecionar para `/login`

---

### Passo 7: Login com nova senha

1. **URL:** `http://localhost:3000/login`
2. **Credenciais:**
   - Email: `joaobalzer@dpwai.com.br`
   - Senha: `NovoPass@123456` (nova)
3. **Clique "Entrar"**
4. **Esperado:**
   - ✅ Login bem-sucedido
   - ✅ Redireciona para `/dpwai/[tenant]/welcome`
   - ✅ Exibe nome "João" no header

**Screenshot esperado:** Página welcome com avatar e farm selector

---

### Passo 8: Tentar reutilizar token (DEVE FALHAR)

1. **Copie a URL do step 5** (com o token antigo)
2. **Navegue para ela novamente** em nova aba
3. **Esperado:**
   - ❌ Mensagem de erro: "Token inválido ou expirado"
   - ❌ Opção: "Solicitar Novo Link"

**Screenshot esperado:** Página com aviso e botão para novo reset

---

## Verificação de Logs do Backend

### Log esperado para Forgot Password:

```
[PASSWORD_RESET_REQUESTED] {
  "email": "joaobalzer@dpwai.com.br",
  "resend_message_id": "re_msg_1234567890",
  "status": "queued",
  "timestamp": "2026-01-25T10:30:00Z"
}
```

### Log esperado para Reset Password:

```
[PASSWORD_RESET_COMPLETED] {
  "user_id": "ac699638-1a76-459f-bc83-b905079b708d",
  "email": "joaobalzer@dpwai.com.br",
  "timestamp": "2026-01-25T10:32:00Z",
  "token_used": true
}
```

---

## Checklist de Aceite

### Funcionalidade
- [ ] Email chega em <1 minuto via Resend
- [ ] Remetente correto: `noreply@dpwai.com.br`
- [ ] Link no email funciona
- [ ] Link expira após 30-60 minutos
- [ ] Nova senha funciona para login
- [ ] Token é uso único (não reutilizável)

### Segurança
- [ ] Endpoint forgot-password não vaza se email existe
- [ ] Sempre retorna 200 (mesmo email inexistente)
- [ ] Hash do token armazenado no BD (não plain)
- [ ] Token excluído/marcado após uso
- [ ] Senha com bcrypt (10+ rounds)

### UX
- [ ] Página forgot-password é acessível
- [ ] Página reset-password é intuitiva
- [ ] Mensagens de erro claras
- [ ] Redirecionamento automático para login
- [ ] Email é profissional e claro

### Observabilidade
- [ ] Logs registram tentativas
- [ ] Resend message ID está nos logs
- [ ] Falhas de envio estão registradas
- [ ] Sem exposição de senhas ou tokens em logs

---

## Teste Automatizado

```bash
# Passo 1: Executar o script de teste
npm run test:password-reset

# Você será instruído a:
# 1. Ir ao email
# 2. Copiar o token
# 3. Rodar novamente com o token

# Passo 2: Executar com token
npm run test:password-reset -- --token eyJhbGc...
```

---

## Evidências para Documentação

Capture prints de:

1. **Email recebido:**
   - Remetente
   - Assunto
   - Conteúdo
   - Link/Token

2. **Página Reset:**
   - Formulário preenchido
   - Mensagem de sucesso

3. **Logs do Backend:**
   - PASSWORD_RESET_REQUESTED
   - PASSWORD_RESET_COMPLETED
   - Resend message ID

4. **Login Pós-Reset:**
   - Usuário logado com nova senha
   - Página welcome exibindo nome correto

---

## Troubleshooting

### Email não chega
- [ ] Verificar `RESEND_API_KEY` no `.env`
- [ ] Verificar se domínio está verificado no Resend
- [ ] Verificar logs do backend: `RESEND_ERROR` ou `EMAIL_SEND_FAILED`
- [ ] Testar Resend diretamente: `curl https://api.resend.com/send`

### Link expirado rapidinho
- [ ] Verificar expiração no `.env`: `PASSWORD_RESET_TOKEN_EXPIRY=30m` (padrão)
- [ ] Verificar timestamp do BD

### Token não funciona
- [ ] Verificar hash comparação: `crypto.timingSafeEqual()`
- [ ] Verificar se token foi marcado como used
- [ ] Verificar se não há múltiplos tokens para mesmo user

---

## Próximos Passos (Após Aceite)

- [ ] Adicionar rate limiting ao endpoint forgot-password
- [ ] Implementar email de confirmação de reset
- [ ] Adicionar dashboard de "recent resets" para admin
- [ ] Implementar "revoke all tokens" em account settings
- [ ] Testar em produção com domínio verificado

---

**Data do Teste:** _______________
**Responsável:** _______________
**Status Final:** ✅ PASSOU / ❌ FALHOU

