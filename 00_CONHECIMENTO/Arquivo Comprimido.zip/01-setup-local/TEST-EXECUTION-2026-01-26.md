# TEST EXECUTION REPORT - 2026-01-26

**Location:** `/Users/balzer/dpwai-app2/dpwaiagro`  
**Command Executed:** `npm run test 2>&1 | tee test.log`  
**Date:** 2026-01-26  

---

## SUMMARY

### Total Tests Executed: **283**

| Status | Count | Percentage |
|--------|-------|-----------|
| ✅ **PASSED** | **278** | **98.2%** |
| ❌ **FAILED** | **5** | **1.8%** |

### Test Suites

| Status | Count |
|--------|-------|
| ✅ Passed | 10 |
| ❌ Failed | 7 |
| **Total** | **17** |

---

## WHICH TESTS FAILED?

### 5 Tests Failed (Total)

#### 1. `lib/__tests__/email-sending.test.ts` - **4 Failures**
- **Error Type:** TypeError: Cannot set properties of undefined (setting 'send')
- **Cause:** Resend mock setup issue
- **Failed Tests:**
  - sendOtpEmail should be callable without throwing
  - sendOtpEmail should include correct content in HTML
  - sendOtpEmail should use correct from address
  - sendOtpEmail should throw if email sending fails
- **Priority:** 🔴 HIGH

#### 2. `lib/__tests__/otp.test.ts` - **1 Failure**
- **Error Type:** AssertionError
- **Cause:** maskEmail() not masking short emails correctly
- **Failed Test:** Email Masking › handles edge cases
- **Priority:** 🟡 MEDIUM

#### 3. `lib/forms/__tests__/prefill.test.ts` - **1 Suite Failure**
- **Error Type:** ReferenceError: window is not defined
- **Cause:** Jest running with 'node' environment but test needs 'jsdom'
- **Priority:** 🟡 MEDIUM

#### 4. `lib/__tests__/rate-limit-api.test.ts` - **1 Suite Failure**
- **Error Type:** Cannot find module '@/lib/ratelimit'
- **Cause:** Jest moduleNameMapper not configured for '@/' path alias
- **File Status:** ✅ File EXISTS at `/dpwaiagro/lib/ratelimit/index.ts`
- **Priority:** 🔴 HIGH

#### 5. `lib/__tests__/file-upload.test.ts` - **1 Suite Failure**
- **Error Type:** Cannot find module '@/lib/storage'
- **Cause:** Jest moduleNameMapper not configured
- **File Status:** ✅ File EXISTS at `/dpwaiagro/lib/storage/index.ts`
- **Priority:** 🔴 HIGH

#### 6. `lib/__tests__/auth-login.test.ts` - **1 Suite Failure**
- **Error Type:** Cannot find module '@/lib/prisma'
- **Cause:** Jest moduleNameMapper not configured
- **File Status:** ✅ File EXISTS at `/dpwaiagro/lib/prisma.ts`
- **Priority:** 🔴 HIGH

#### 7. `lib/__tests__/abuse-protection.test.ts` - **1 Suite Failure**
- **Error Type:** Cannot find module '@/lib/abuse'
- **Cause:** Jest moduleNameMapper not configured
- **File Status:** ✅ File EXISTS at `/dpwaiagro/lib/abuse/index.ts`
- **Priority:** 🔴 HIGH

---

## PASSING TESTS (278)

### Test Suites Passing (10)

1. ✅ `lib/webhooks/__tests__/webhook-system.test.ts`
2. ✅ `lib/__tests__/draft-utils.test.ts`
3. ✅ `lib/__tests__/auth-tokens.test.ts`
4. ✅ `lib/__tests__/form-preview.test.ts`
5. ✅ `app/api/__tests__/public-forms.integration.test.ts`
6. ✅ `app/api/__tests__/otp.integration.test.ts`
7. ✅ `app/api/__tests__/files.integration.test.ts`
8. ✅ `app/api/__tests__/webhooks.integration.test.ts`
9. ✅ `lib/__tests__/ratelimit.test.ts`
10. ✅ `lib/__tests__/hmac.test.ts`

---

## COVERAGE REPORT

**Target:** 80% (global threshold in jest.config.js)  
**Status:** ⚠️ Coverage verification blocked by failing tests  
**Action:** Will be verified once all tests pass

---

## FILES TO FIX

### Priority 1: jest.config.js (Fixes 4 test suites)
**File:** `/dpwaiagro/jest.config.js`

Add moduleNameMapper:
```javascript
moduleNameMapper: {
  '@/(.*)': '<rootDir>/$1',
}
```

### Priority 2: email-sending.test.ts (Fixes 4 tests)
**File:** `/dpwaiagro/lib/__tests__/email-sending.test.ts`

**Issue:** Resend mock setup - Resend.prototype.emails is undefined

### Priority 3: prefill.test.ts (Fixes 1 test)
**File:** `/dpwaiagro/lib/forms/__tests__/prefill.test.ts`

Add at top of file:
```typescript
/**
 * @jest-environment jsdom
 */
```

### Priority 4: maskEmail() function (Fixes 1 test)
**Issue:** Function not masking emails under certain conditions

---

## DOCUMENTATION GENERATED

- ✅ `/dpwaiagro/TEST-REPORT.md` - Full detailed report
- ✅ `/dpwaiagro/TEST-SUMMARY.txt` - Text summary
- ✅ `/dpwaiagro/TEST-RESULTS-INDEX.md` - Results index
- ✅ `/dpwaiagro/test.log` - Complete test execution log
- ✅ `/knowledge/07-troubleshooting/TEST-EXECUTION-REPORT-2026-01-26.md` - Archived

---

## FILES VERIFIED (All Exist ✅)

- ✓ `/dpwaiagro/lib/ratelimit/index.ts`
- ✓ `/dpwaiagro/lib/storage/index.ts`
- ✓ `/dpwaiagro/lib/prisma.ts`
- ✓ `/dpwaiagro/lib/abuse/index.ts`

---

## GOAL

| Metric | Current | Target |
|--------|---------|--------|
| Tests Passing | 278/283 | 283/283 |
| Success Rate | 98.2% | 100% |
| Failures to Fix | 5 | 0 |
| Estimated Time | - | ~30 minutes |

---

**Status:** 🟡 NEEDS ATTENTION - 5 failures need fixing for 100% pass rate
