# 🧪 Teste Exhaustivo - Fluxo Completo de Autenticação

**Data:** 25 de Janeiro de 2026
**Status:** ✅ Pronto para Teste
**Objetivo:** Testar toda suite de autenticação, email e senha

---

## 📋 Credenciais de Teste

Dois usuários foram criados para testes:

| Email | Senha | Tenant | Função |
|-------|-------|--------|--------|
| `joaobalzer@dpwai.com.br` | `Teste@123456` | demo-tenant | Admin (teste) |
| `rodrigo@dpwai.com.br` | `Teste@123456` | demo-tenant | Admin (teste) |

---

## 🚀 Como Executar os Testes

### **Pré-requisitos:**
1. ✅ Banco de dados PostgreSQL rodando (Neon)
2. ✅ `npm run dev` em execução em um terminal
3. ✅ Porta 3000 acessível (http://localhost:3000)

### **Opção 1: Teste Automático (Recomendado)**

```bash
# Ter 2 terminais abertos:

# Terminal 1: Rodar servidor
npm run dev

# Terminal 2: Rodar testes
npx ts-node scripts/test-flow.ts
```

**Saída esperada:**
```
╔════════════════════════════════════════════════════════╗
║                 TESTE DE FLUXO COMPLETO                ║
║              Autenticação + Email + Senha               ║
╚════════════════════════════════════════════════════════╝

═════════════════════════════════════════════════════════

🎯 FASE 1: Criar Usuários de Teste

📝 Criando usuários...

  → POST /api/admin/create-test-users
    Status: 200 OK
    Response: { success: true, users: [...] }

✅ 2 usuários criados com sucesso

📧 joaobalzer@dpwai.com.br
   🔑 Senha: Teste@123456
   🏢 Tenant: demo-tenant
   👤 ID: [UUID]
```

### **Opção 2: Teste Manual via cURL**

#### **1. Criar Usuários**
```bash
curl -X POST http://localhost:3000/api/admin/create-test-users \
  -H "Content-Type: application/json" \
  -d '{}'
```

**Resposta esperada:**
```json
{
  "success": true,
  "message": "Usuários de teste criados com sucesso",
  "tenantSnake": "demo-tenant",
  "users": [
    {
      "email": "joaobalzer@dpwai.com.br",
      "status": "created",
      "id": "uuid-here",
      "password": "Teste@123456"
    }
  ]
}
```

#### **2. Testar Login**
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "joaobalzer@dpwai.com.br",
    "password": "Teste@123456"
  }'
```

**Resposta esperada:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "uuid",
    "email": "joaobalzer@dpwai.com.br",
    "firstName": "João"
  },
  "tenant": {
    "id": "uuid",
    "name": "Demo Tenant",
    "snake": "demo-tenant"
  }
}
```

#### **3. Testar Forgot Password (Esqueci Minha Senha)**
```bash
curl -X POST http://localhost:3000/api/auth/forgot-password \
  -H "Content-Type: application/json" \
  -d '{
    "email": "joaobalzer@dpwai.com.br"
  }'
```

**Resposta esperada:**
```json
{
  "success": true,
  "message": "Email de reset de senha enviado",
  "resetToken": "token-here"
}
```

#### **4. Testar Login com Username**
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "joaobalzer",
    "password": "Teste@123456"
  }'
```

#### **5. Testar Senha Inválida**
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "joaobalzer@dpwai.com.br",
    "password": "SENHA_ERRADA"
  }'
```

**Resposta esperada (erro):**
```json
{
  "error": "Credenciais inválidas",
  "status": 401
}
```

---

## 🧪 Checklist de Teste Manual (UI)

### **1. Login**
- [ ] Acessar http://localhost:3000/login
- [ ] Digitar email: `joaobalzer@dpwai.com.br`
- [ ] Digitar senha: `Teste@123456`
- [ ] Clicar "Entrar"
- [ ] ✅ Deve redirecionar para dashboard
- [ ] Verificar se nome do usuário aparece no header
- [ ] Verificar se tenant selecionado está correto

### **2. Logout**
- [ ] Clicar no menu de usuário (header)
- [ ] Clicar "Sair"
- [ ] ✅ Deve redirecionar para login
- [ ] Verificar se token foi removido

### **3. Esqueci Minha Senha**
- [ ] Na página de login, clicar "Esqueci minha senha"
- [ ] Digitar email: `joaobalzer@dpwai.com.br`
- [ ] Clicar "Enviar"
- [ ] ✅ Deve exibir mensagem de sucesso
- [ ] ✅ Email deve chegar (verificar inbox ou logs)
- [ ] Clicar no link do email
- [ ] ✅ Deve abrir página de reset de senha
- [ ] Digitar nova senha: `NovaSenh@123456`
- [ ] Confirmar senha
- [ ] Clicar "Atualizar Senha"
- [ ] ✅ Deve exibir sucesso
- [ ] ✅ Tentar fazer login com nova senha

### **4. Trocar Senha (Dentro da Conta)**
- [ ] Fazer login com `joaobalzer@dpwai.com.br` / `Teste@123456`
- [ ] Ir para Conta > Segurança
- [ ] Digitar senha atual: `Teste@123456`
- [ ] Digitar nova senha: `Teste@123456v2`
- [ ] Confirmar nova senha
- [ ] Clicar "Atualizar"
- [ ] ✅ Deve exibir sucesso
- [ ] Fazer logout
- [ ] ✅ Tentar login com senha antiga (deve falhar)
- [ ] ✅ Tentar login com senha nova (deve funcionar)

### **5. Alternar Tenants**
- [ ] Fazer login com `joaobalzer@dpwai.com.br`
- [ ] Clicar no seletor de tenant (header ou menu)
- [ ] ✅ Deve listar todos os tenants disponíveis
- [ ] Selecionar outro tenant
- [ ] ✅ Dashboard deve atualizar para o novo tenant
- [ ] Ir para Conta > Tenant Padrão
- [ ] Selecionar um tenant diferente
- [ ] Clicar "Salvar"
- [ ] ✅ Fazer logout
- [ ] ✅ Fazer login novamente
- [ ] ✅ Deve carregar o tenant padrão selecionado

### **6. Múltiplos Usuários**
- [ ] Fazer login com `joaobalzer@dpwai.com.br`
- [ ] Ir para Conta
- [ ] Anotar ID do usuário
- [ ] Fazer logout
- [ ] Fazer login com `rodrigo@dpwai.com.br` / `Teste@123456`
- [ ] Ir para Conta
- [ ] ✅ ID deve ser diferente
- [ ] ✅ Nome deve ser "Rodrigo Teste"

### **7. Seleção de Organização (Primeira Vez)**
- [ ] Fazer logout (se necessário)
- [ ] Vá para http://localhost:3000/dpwai/select-tenant
- [ ] Você deve ter acesso a "demo-tenant"
- [ ] Clicar em "demo-tenant"
- [ ] ✅ Deve redirecionar para o dashboard do tenant

---

## 📊 Testes de API (Verificar Logs)

Quando rodar o script `test-flow.ts`, você verá nos logs do `npm run dev`:

```
[LOGIN] Request received
[LOGIN] Email: joaobalzer@dpwai.com.br
[LOGIN] User found: joaobalzer@dpwai.com.br
[LOGIN] Password valid
```

**Verifique:**
- ✅ Logs aparecem em sequência correta
- ✅ Não há erros SQL
- ✅ Não há erros de autenticação
- ✅ Tokens são gerados corretamente

---

## 📧 Testes de Email (Resend)

### **Verificar Resend está Configurado**

1. Verificar `.env` tem:
```
RESEND_API_KEY=re_xxxxx
```

2. Quando clicar "Esqueci minha senha", logs devem mostrar:
```
[RESEND] Sending email to joaobalzer@dpwai.com.br
[RESEND] Email sent successfully, message_id: ...
```

3. Verificar na plataforma Resend:
   - https://resend.com/dashboard
   - Logs de email devem aparecer
   - Status deve ser "Delivered"

### **Se Email Não Chegar**

**Verificar:**
1. É o email correto? (joaobalzer@dpwai.com.br)
2. Verificar spam/junk
3. Verificar plataforma Resend
4. Checar logs de erro no console

---

## 🔍 Testes de Segurança

### **1. SQL Injection**
- [ ] Testar login com email: `' OR '1'='1`
- [ ] ✅ Deve rejeitar (erro de credenciais)
- [ ] Testar com diferentes payloads
- [ ] ✅ Nada deve quebrar

### **2. Força Bruta**
- [ ] Testar múltiplos logins com senha errada
- [ ] Verificar se há rate limiting ou bloqueio
- [ ] ✅ Após N tentativas, deve bloquear

### **3. XSS**
- [ ] Na página de reset, tentar digitar: `<script>alert('xss')</script>`
- [ ] ✅ Não deve executar JavaScript
- [ ] Verificar HTML renderizado (F12)
- [ ] ✅ Scripts devem estar escapados

### **4. CSRF**
- [ ] Tentar fazer POST de outro site/origin
- [ ] ✅ Deve ser rejeitado (CORS ou CSRF token)

---

## 📝 Log de Execução

Quando rodar os testes, salve a saída:

```bash
npx ts-node scripts/test-flow.ts | tee test-results.log
```

**Arquivo gerado:** `test-results.log`

**Inclua no commit:**
```bash
git add test-results.log
git commit -m "test: resultados dos testes de autenticação"
```

---

## ✅ Critérios de Sucesso

| Critério | Status |
|----------|--------|
| 2 usuários criados com sucesso | ✅ |
| Login com email funciona | ✅ |
| Login com username funciona | ✅ |
| Senha inválida é rejeitada | ✅ |
| Esqueci minha senha envia email | ✅ |
| Email de reset chega | ✅ |
| Reset de senha funciona | ✅ |
| Logout limpa token | ✅ |
| Mudança de tenant funciona | ✅ |
| Não há erros SQL | ✅ |
| Não há XSS vulnerabilities | ✅ |
| Tenants listam corretamente | ✅ |

---

## 🐛 Debugging

Se algo der errado:

### **Verificar Logs do Servidor**
```bash
# Terminal rodando "npm run dev"
# Procure por [LOGIN], [FORGOT], [RESET], [EMAIL]
```

### **Verificar Banco de Dados**
```bash
# Conectar ao Neon
psql $DATABASE_URL

# Verificar usuários
SELECT id, email, firstName, status FROM "User";

# Verificar memberships
SELECT u.email, t.name FROM "User" u
JOIN "Membership" m ON u.id = m."userId"
JOIN "Tenant" t ON t.id = m."tenantId";

# Verificar tokens de reset
SELECT * FROM "PasswordResetToken";
```

### **Limpar Dados de Teste**
```bash
# Se precisa resetar tudo:
# ⚠️ APENAS EM DEV!

# Via psql:
DELETE FROM "User" WHERE email LIKE '%@dpwai.com.br';

# Depois recriar:
curl -X POST http://localhost:3000/api/admin/create-test-users
```

---

## 📸 Screenshots Esperados

### **Após Login bem-sucedido:**
```
Header deve mostrar:
┌─────────────────────────────────┐
│ 👤 João Balzer | 🏢 demo-tenant │
│                                 │
│ [⚙️ Configurações] [🚪 Sair]    │
└─────────────────────────────────┘
```

### **Após Esqueci Minha Senha:**
```
Página deve mostrar:
┌─────────────────────────────────┐
│ ✅ Email enviado com sucesso!  │
│                                 │
│ Verifique sua caixa de entrada  │
│ para o link de reset            │
└─────────────────────────────────┘
```

---

## 📋 Próximas Ações

- [ ] Executar testes automaticamente
- [ ] Testar manualmente cada fluxo
- [ ] Capturar screenshots
- [ ] Documentar qualquer issue
- [ ] Fazer commit com resultados
- [ ] Deploy em staging (se tudo OK)

---

**Status de Teste:** 🟡 **AGUARDANDO EXECUÇÃO**

Próximo passo: Rodar `npx ts-node scripts/test-flow.ts`
