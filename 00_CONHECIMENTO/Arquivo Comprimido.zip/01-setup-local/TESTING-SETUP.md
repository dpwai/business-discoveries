# 🧪 Responsive Testing Setup Guide

## Overview

This document describes the comprehensive responsive testing setup for the DPWAI App, including Playwright configuration, test execution, and CI/CD integration.

---

## Quick Start

### Run All Responsive Tests

```bash
cd dpwaiagro
npx playwright test tests/responsive-audit.spec.ts
```

### Run Tests in Headed Mode (See Browser)

```bash
npx playwright test tests/responsive-audit.spec.ts --headed
```

### Run Tests for Specific Browser

```bash
# Chromium only
npx playwright test tests/responsive-audit.spec.ts --project=chromium

# Safari only
npx playwright test tests/responsive-audit.spec.ts --project=webkit

# Firefox only
npx playwright test tests/responsive-audit.spec.ts --project=firefox

# Mobile only
npx playwright test tests/responsive-audit.spec.ts --project='Mobile Chrome'
```

### Generate HTML Report

```bash
npx playwright test tests/responsive-audit.spec.ts --reporter=html
npx playwright show-report
```

### Run Single Test

```bash
npx playwright test -g "hamburger menu visible"
```

---

## Installation

### Prerequisites

- Node.js 18.x or higher
- npm or yarn
- Next.js dev server running on http://localhost:3000

### Playwright Already Installed

Playwright is already in `package.json` as a dev dependency:

```json
{
  "devDependencies": {
    "@playwright/test": "^1.58.0",
    "playwright": "^1.58.0"
  }
}
```

### Install Playwright Browsers

```bash
npx playwright install
```

### Verify Installation

```bash
npx playwright --version
```

---

## File Structure

```
dpwaiagro/
├── tests/
│   └── responsive-audit.spec.ts         # Main responsive test suite
├── playwright.config.ts                  # Playwright configuration
├── screenshots/                          # Screenshots from test runs
│   ├── hamburger-iphone-12.png
│   ├── login-chromium-mobile.png
│   └── ...
├── playwright-report/                    # HTML test report (generated)
└── test-results.json                     # JSON test results (generated)
```

---

## Test Suite Overview

### File: `tests/responsive-audit.spec.ts`

**Total Tests:** 40
**Duration:** ~1-2 minutes
**Coverage:**
- 17 viewport sizes
- 3 browser engines
- 13 test categories

### Test Categories

#### 1. Hamburger Menu Tests (16 × 3 browsers = 48 tests)
**Tests that hamburger menu is:**
- Visible on all mobile viewports
- Clickable and accessible
- Properly z-indexed
- Never overlapped
- Works across browsers

```typescript
test(`hamburger menu visible and accessible on iPhone 12`, async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const visibility = await checkElementVisibility(page, '[aria-controls="sidebar"]');
  expect(visibility.visible).toBe(true);
  expect(visibility.inViewport).toBe(true);
  expect(visibility.accessible).toBe(true);
});
```

#### 2. Horizontal Scrolling Tests (13 mobile viewports)
**Ensures no unwanted horizontal scroll on mobile:**
```typescript
test(`no horizontal scrolling on iPhone 12`, async ({ page }) => {
  const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
  expect(scrollWidth).toBeLessThanOrEqual(390); // viewport width
});
```

#### 3. Text Overflow Tests (All viewports)
**Validates text wraps correctly:**
```typescript
test(`text doesn't overflow on iPhone 12`, async ({ page }) => {
  const overflowElements = await page.$$eval('*', (elements) => {
    return elements.filter(el => {
      const scrollWidth = el.scrollWidth;
      const clientWidth = el.clientWidth;
      return scrollWidth > clientWidth;
    });
  });
  expect(overflowElements.length).toBe(0);
});
```

#### 4. Touch Target Tests
**All buttons ≥ 44px (WCAG AAA):**
```typescript
test('touch targets are at least 44px on mobile', async ({ page }) => {
  const buttons = await page.$$('button, [role="button"]');
  for (const button of buttons) {
    const box = await button.boundingBox();
    expect(box.width).toBeGreaterThanOrEqual(44);
    expect(box.height).toBeGreaterThanOrEqual(44);
  }
});
```

#### 5. Viewport Meta Tag Test
**Validates responsive configuration:**
```typescript
test('viewport meta tag is set correctly', async ({ page }) => {
  const viewport = await page.$eval(
    'meta[name="viewport"]',
    (el) => el.getAttribute('content')
  );
  expect(viewport).toContain('width=device-width');
  expect(viewport).toContain('initial-scale=1');
});
```

#### 6. Layout Shift Test
**Ensures Cumulative Layout Shift < 0.1:**
```typescript
test('layout stable on portrait (iPhone 12)', async ({ page }) => {
  const cls = await page.evaluate(() => {
    let clsValue = 0;
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!entry.hadRecentInput) {
          clsValue += entry.value;
        }
      }
    });
    observer.observe({ entryTypes: ['layout-shift'] });
    return new Promise(resolve => setTimeout(() => resolve(clsValue), 3000));
  });
  expect(cls).toBeLessThan(0.1);
});
```

#### 7. Modal Tests
**Verifies modals are closable:**
- ESC key closes modal
- Click outside closes modal
- Focus is properly trapped

#### 8. Image Responsiveness
**Images use max-width: 100%:**
```typescript
test('images are responsive', async ({ page }) => {
  const images = await page.$$('img');
  for (const img of images) {
    const maxWidth = await img.evaluate((el) => {
      return window.getComputedStyle(el).maxWidth;
    });
    expect(maxWidth).not.toBe('none');
  }
});
```

#### 9. Form Input Tests
**All inputs ≥ 44px on mobile:**
```typescript
test('form inputs are properly sized on mobile', async ({ page }) => {
  const inputs = await page.$$('input, textarea, select');
  for (const input of inputs) {
    const box = await input.boundingBox();
    expect(box.height).toBeGreaterThanOrEqual(44);
  }
});
```

#### 10. Safe Area Test (iOS)
**Checks for notch/Dynamic Island compatibility:**
```typescript
test('respects safe-area-inset on iOS', async ({ page }) => {
  const safeAreaUsed = await page.evaluate(() => {
    return window.getComputedStyle(document.body).padding.includes('env');
  }).catch(() => false);
  console.log('Safe area insets used:', safeAreaUsed);
});
```

#### 11. Scrolling Behavior
**Validates smooth scrolling:**
```typescript
test('scrolling behavior is smooth on mobile', async ({ page }) => {
  await page.evaluate(() => {
    window.scrollTo({ top: 100, behavior: 'smooth' });
  });
  const scrollTop = await page.evaluate(() => window.scrollY);
  expect(scrollTop).toBeGreaterThan(0);
});
```

#### 12. Cross-Browser Tests
**Login page responsive on all browsers:**
- Chromium
- Firefox
- WebKit

#### 13. Performance Tests
**FCP < 3 seconds on slow 3G:**
```typescript
test('First Contentful Paint within budget on mobile', async ({ page }) => {
  const metrics = await page.evaluate(() => {
    const perfData = performance.getEntriesByType('paint');
    return perfData.find(entry => entry.name === 'first-contentful-paint')?.startTime;
  });
  expect(metrics).toBeLessThan(3000);
});
```

---

## Viewport Configuration

The test suite includes 17 standard viewport sizes:

```typescript
const VIEWPORTS = {
  // Mobile (0-480px)
  'iPhone SE': { width: 375, height: 667 },
  'iPhone 12': { width: 390, height: 844 },
  'iPhone 13': { width: 390, height: 844 },
  'iPhone 14': { width: 390, height: 844 },
  'iPhone 14 Pro Max': { width: 430, height: 932 },
  'Pixel 7': { width: 412, height: 915 },
  'Galaxy S21': { width: 360, height: 800 },
  'Small Mobile': { width: 320, height: 568 },

  // Tablet (480-1024px)
  'iPad': { width: 768, height: 1024 },
  'iPad Mini': { width: 744, height: 1133 },
  'iPad Air': { width: 820, height: 1180 },

  // Desktop (1024px+)
  'HD': { width: 1280, height: 720 },
  'FHD': { width: 1920, height: 1080 },
  '2K': { width: 2560, height: 1440 },
};
```

---

## Browser Configuration

Tests run on 5 browser configurations:

```typescript
projects: [
  {
    name: 'chromium',
    use: { ...devices['Desktop Chrome'] },
  },
  {
    name: 'firefox',
    use: { ...devices['Desktop Firefox'] },
  },
  {
    name: 'webkit',
    use: { ...devices['Desktop Safari'] },
  },
  {
    name: 'Mobile Chrome',
    use: { ...devices['Pixel 5'] },
  },
  {
    name: 'Mobile Safari',
    use: { ...devices['iPhone 12'] },
  },
];
```

---

## Configuration Files

### `playwright.config.ts`

Key settings:

```typescript
export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,

  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },

  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});
```

**Settings Explained:**
- `fullyParallel`: Run all tests simultaneously
- `retries`: Retry failed tests (2x on CI, 0 locally)
- `workers`: Parallel workers (1 on CI for stability)
- `trace`: Record Playwright traces for debugging
- `screenshot`: Only save on failure to save space
- `video`: Keep video of failures
- `webServer`: Auto-start Next.js dev server

---

## CI/CD Integration

### GitHub Actions Workflow

Add to `.github/workflows/test.yml`:

```yaml
name: Responsive Tests

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  responsive-test:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v3

      - uses: actions/setup-node@v3
        with:
          node-version: 18
          cache: npm
          cache-dependency-path: 'dpwaiagro/package-lock.json'

      - name: Install dependencies
        run: cd dpwaiagro && npm ci

      - name: Install Playwright
        run: cd dpwaiagro && npx playwright install --with-deps

      - name: Run responsive tests
        run: cd dpwaiagro && npm test

      - name: Upload test report
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: playwright-report
          path: dpwaiagro/playwright-report/

      - name: Upload screenshots
        if: failure()
        uses: actions/upload-artifact@v3
        with:
          name: screenshots
          path: dpwaiagro/screenshots/
```

### Running in CI

The workflow will:
1. ✅ Install Node.js 18
2. ✅ Install dependencies
3. ✅ Install Playwright browsers
4. ✅ Run all tests
5. ✅ Upload report on every run
6. ✅ Upload screenshots on failure

---

## Debugging Failed Tests

### Generate Trace

When a test fails, Playwright records a trace:

```bash
npx playwright show-trace trace.zip
```

This opens an interactive viewer showing:
- Screenshots at each step
- Network requests
- Console logs
- DOM state

### Debug Mode

Run tests with debug UI:

```bash
npx playwright test --debug
```

This opens:
- Browser window
- Inspector panel
- Step-through controls
- DOM inspection

### Headed Mode

See browser during test:

```bash
npx playwright test --headed
```

### Slow Motion

Slow down execution (debugging):

```bash
npx playwright test --headed --slow-mo=500
```

500ms delay between actions.

### Verbose Logging

```bash
PW_DEBUG=pw:api npx playwright test
```

---

## Performance Considerations

### Test Execution Time

**Typical Duration:** 1-2 minutes

**Breakdown:**
- Setup & browser launch: ~10 sec
- Per-test execution: ~1-2 sec
- Report generation: ~5 sec

**Parallelization:**
- Default: 4 workers
- CI: 1 worker (for stability)

### Optimization Tips

1. **Use existing server:**
   ```bash
   npm run dev &
   npx playwright test  # Reuses existing server
   ```

2. **Run specific tests:**
   ```bash
   npx playwright test -g "hamburger"
   ```

3. **Disable video capture:**
   ```bash
   npx playwright test --config=playwright.config.ts --no-video
   ```

---

## Maintenance

### Adding New Tests

Add to `tests/responsive-audit.spec.ts`:

```typescript
test('new test name', async ({ page }) => {
  await page.setViewportSize(VIEWPORTS['iPhone 12']);
  await page.goto('http://localhost:3000/new-route');

  // Your test logic
  const element = await page.$('.selector');
  expect(element).toBeTruthy();
});
```

### Adding New Viewports

Update `VIEWPORTS` object:

```typescript
const VIEWPORTS = {
  // ... existing ...
  'Foldable': { width: 512, height: 717 },
};
```

### Updating Selectors

If UI changes, update selectors in tests:

```typescript
// Old
await page.click('[aria-controls="sidebar"]');

// New
await page.click('button.hamburger-menu');
```

---

## Troubleshooting

### Server Not Starting

```bash
# Make sure Next.js dev server is running
npm run dev

# In separate terminal
npx playwright test
```

### Playwright Browsers Missing

```bash
npx playwright install
```

### Tests Timing Out

Increase timeout in config:

```typescript
use: {
  navigationTimeout: 30000,  // 30 seconds
}
```

### Flaky Tests

Add retry logic:

```typescript
test('flaky test', async ({ page }) => {
  for (let i = 0; i < 3; i++) {
    try {
      await page.waitForSelector('.element', { timeout: 5000 });
      break;
    } catch (e) {
      if (i === 2) throw e;
      await page.reload();
    }
  }
});
```

---

## Best Practices

### ✅ Do's

- ✅ Wait for elements before interacting
- ✅ Use semantic selectors (`[aria-controls]`)
- ✅ Test on real viewports (not arbitrary sizes)
- ✅ Include error cases
- ✅ Use data attributes for stable selectors

### ❌ Don'ts

- ❌ Hard-code timeouts
- ❌ Use CSS selectors that change often
- ❌ Test too many things in one test
- ❌ Depend on test execution order
- ❌ Use `page.goto()` without waiting

---

## Resources

- **Playwright Docs:** https://playwright.dev
- **Best Practices:** https://playwright.dev/docs/best-practices
- **Debug Guide:** https://playwright.dev/docs/debug
- **API Reference:** https://playwright.dev/docs/api/class-page

---

## Support

For issues or questions:

1. Check Playwright documentation
2. Review test traces in `playwright-report/`
3. Review recent changes in `RESPONSIVE_AUDIT.md`
4. File issue with browser logs

---

**Last Updated:** January 25, 2026
**Maintained By:** QA Team
