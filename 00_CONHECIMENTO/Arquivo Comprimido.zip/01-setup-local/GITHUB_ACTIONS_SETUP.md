# GitHub Actions + Vercel Deploy Setup

## 📋 O Que Foi Feito

O workflow `.github/workflows/validate.yml` agora faz:

1. ✅ **Build validation** - TypeScript compilation
2. ✅ **Run tests** - npm run test
3. ✅ **Deploy to Vercel** - Automatic production deploy on main branch

---

## 🔧 Configuração Necessária

### 1. Adicione os Secrets no GitHub

Vá em: `https://github.com/seu-usuario/dpwai-app2/settings/secrets/actions`

Clique em "New repository secret" e adicione:

#### Secret 1: `VERCEL_TOKEN`
- **Name:** `VERCEL_TOKEN`
- **Value:** Sua chave Vercel (vck_...)
- Clique "Add secret"

#### Secret 2: `VERCEL_ORG_ID`
- Vá em: https://vercel.com/account/settings
- Copie o **Team ID** (está no início da página)
- **Name:** `VERCEL_ORG_ID`
- **Value:** Cole aqui
- Clique "Add secret"

#### Secret 3: `VERCEL_PROJECT_ID`
- Vá em: https://vercel.com/dashboard
- Clique no seu projeto
- Vá em Settings → General
- Procure por "Project ID"
- **Name:** `VERCEL_PROJECT_ID`
- **Value:** Cole aqui
- Clique "Add secret"

---

## 🚀 Como Funciona

```
git push origin main
    ↓
GitHub Actions dispara
    ↓
1. Valida TypeScript
2. Roda testes
3. Checa código
    ↓
Se tudo passar:
    ↓
Deploy para Vercel (production)
    ↓
✅ App atualizado em app.dpwai.com.br
```

---

## 📊 Monitore o Status

1. Vá em: `github.com/seu-usuario/dpwai-app2/actions`
2. Veja o status de cada push
3. Clique no workflow para ver logs detalhados

---

## 🔐 Segurança

- Secrets são **criptografados** no GitHub
- Não aparecem em logs públicos
- Só o Vercel consegue ler durante o workflow
- Você pode revogar a qualquer momento

---

## ❌ Se Der Erro

### "Vercel build failed"
- Vá em Vercel dashboard → seu projeto → Deployments
- Veja o log completo do build
- Corrija o erro localmente com `npm run build`
- Faça novo commit

### "Tests failed"
- Roda localmente: `cd dpwaiagro && npm run test`
- Vê qual teste falhou
- Corrige e faz novo commit

### "TypeScript errors"
- Roda localmente: `cd dpwaiagro && npx tsc --noEmit`
- Vê os erros
- Corrige e faz novo commit

---

## ✅ Checklist de Confirmação

- [ ] VERCEL_TOKEN adicionado aos secrets
- [ ] VERCEL_ORG_ID adicionado aos secrets
- [ ] VERCEL_PROJECT_ID adicionado aos secrets
- [ ] Fez um commit novo e fez push
- [ ] Verificou em GitHub Actions → viu o workflow rodar
- [ ] Build passou em Vercel

---

**Depois de configurar, todo push para `main` vai fazer deploy automático!** 🚀
