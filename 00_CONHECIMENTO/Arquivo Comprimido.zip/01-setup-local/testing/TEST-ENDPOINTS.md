# 🧪 Como Testar os Endpoints (verificar se tá retornando dados reais)

## Pre-requisitos
1. Ter um token JWT válido (faça login e copie o `accessToken` do localStorage)
2. Conhecer o tenant snake (ex: `default_tenant`)
3. Ter dados no banco (pelo menos um formulário, usuário, registro)

## Testando no Terminal

### 1. Obter o Token
```bash
# Abra a página da app no navegador
# Abra DevTools (F12)
# Vá em Console
# Cole isso:
console.log(localStorage.getItem('accessToken'))
# Copie o token que aparecer
```

### 2. Testar Forms Count
```bash
TOKEN="seu_token_aqui"
TENANT="default_tenant"

curl -X GET "http://localhost:3000/api/agro/${TENANT}/forms" \
  -H "Authorization: Bearer ${TOKEN}"

# Deve retornar array com formulários, ex:
# [
#   { id: "...", name: "Formulário 1", status: "ACTIVE", ... },
#   { id: "...", name: "Formulário 2", status: "ACTIVE", ... }
# ]
```

### 3. Testar Users Count
```bash
curl -X GET "http://localhost:3000/api/agro/${TENANT}/users" \
  -H "Authorization: Bearer ${TOKEN}"

# Deve retornar array com usuários
```

### 4. Testar Submissions (NOVO)
```bash
curl -X GET "http://localhost:3000/api/agro/${TENANT}/submissions" \
  -H "Authorization: Bearer ${TOKEN}"

# Deve retornar array com registros/submissions
```

### 5. Testar Dashboards
```bash
curl -X GET "http://localhost:3000/api/dashboards" \
  -H "Authorization: Bearer ${TOKEN}"

# Deve retornar array com dashboards
```

## Testando no Navegador

### 1. Abra a Home Page
```
http://localhost:3000/dpwai/default_tenant/
```

### 2. Abra DevTools (F12)
- Vá em Network tab
- Procure pelos requests:
  - `forms`
  - `users`
  - `submissions`
  - `dashboards`

### 3. Clique em cada request
- Veja o Status (deve ser 200)
- Veja o Preview ou Response
- Deve estar mostrando um array com dados, não array vazio []

## O Que Significa Cada Resposta

### ✅ Sucesso (Status 200)
```json
[
  { id: "uuid", name: "...", ... },
  { id: "uuid", name: "...", ... }
]
```
→ Significa que há dados reais. Você deve ver números reais na home page

### ❌ Array Vazio (Status 200, mas retorna [])
```json
[]
```
→ Significa que não há dados. A home page vai mostrar 0 (correto)
→ Você precisa criar alguns formulários/usuários/registros

### ❌ Erro 401 Unauthorized
```json
{ "error": "Unauthorized" }
```
→ Significa que o token não é válido ou expirou
→ Faça login novamente e copie um novo token

### ❌ Erro 404 Not Found
```json
{ "error": "..." }
```
→ Significa que o endpoint não existe
→ Verifique se o arquivo route.ts existe

### ❌ Erro 500 Internal Server Error
```json
{ "error": "Internal server error" }
```
→ Significa que algo quebrou no servidor
→ Verifique os logs do servidor

## Checklist Esperado

Se tudo funcionar corretamente, você deve ver:

- [ ] `/api/agro/{tenant}/forms` retorna array (pode ser vazio ou com dados)
- [ ] `/api/agro/{tenant}/users` retorna array (pode ser vazio ou com dados)
- [ ] `/api/agro/{tenant}/submissions` retorna array (pode ser vazio ou com dados)
- [ ] `/api/dashboards` retorna array (pode ser vazio ou com dados)
- [ ] Home page mostra números reais (ou 0 se não tiver dados)
- [ ] Home page mostra "-" enquanto carrega
- [ ] Sem erros no console do navegador

## Se Algo Não Funcionar

1. **Submissões endpoint retorna erro 500**
   - Problema: O endpoint novo pode ter um bug
   - Solução: Verifique os logs do servidor

2. **Users endpoint retorna 403 Forbidden**
   - Problema: Você não é admin/owner do tenant
   - Solução: Verifique permissões do usuário

3. **Forms retorna vazio mas tem formulários no banco**
   - Problema: Os formulários talvez sejam de outro tenant
   - Solução: Verifique qual tenant você está usando

4. **Home page não atualiza os números**
   - Problema: Os endpoints retornam erro (veja Network tab)
   - Solução: Verifique os erros acima

## Command Rápido (Bash)

Se preferir um script bash completo:

```bash
#!/bin/bash

TOKEN=$(grep -o 'accessToken":"[^"]*' ~/.bash_history | tail -1 | cut -d'"' -f2)
TENANT="default_tenant"
BASE_URL="http://localhost:3000"

echo "🧪 Testando endpoints..."
echo ""

echo "1. Forms:"
curl -s -w "\n%{http_code}\n" -X GET "$BASE_URL/api/agro/$TENANT/forms" \
  -H "Authorization: Bearer $TOKEN" | tail -1

echo "2. Users:"
curl -s -w "\n%{http_code}\n" -X GET "$BASE_URL/api/agro/$TENANT/users" \
  -H "Authorization: Bearer $TOKEN" | tail -1

echo "3. Submissions:"
curl -s -w "\n%{http_code}\n" -X GET "$BASE_URL/api/agro/$TENANT/submissions" \
  -H "Authorization: Bearer $TOKEN" | tail -1

echo "4. Dashboards:"
curl -s -w "\n%{http_code}\n" -X GET "$BASE_URL/api/dashboards" \
  -H "Authorization: Bearer $TOKEN" | tail -1
```

---

**Status**: Testes prontos para executar
**Esperado**: Todos os endpoints devem retornar 200 (OK)

