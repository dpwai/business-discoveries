# Webhook System Implementation Guide

## Overview

A complete, production-ready webhook system with automatic retry logic, HMAC signing, and full management UI for the DPWAI Forms platform.

**Status**: ✅ Complete
**Build**: ✅ Passing (Webhook routes compile without errors)
**Database**: ✅ Schema models ready

---

## Architecture

### Database Models

#### Webhook
```prisma
model Webhook {
  id          String   @id @default(uuid())
  formId      String
  tenantId    String
  url         String
  eventTypes  String[]
  secretHash  String
  active      Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  form       Form               @relation(fields: [formId], references: [id], onDelete: Cascade)
  deliveries WebhookDelivery[]

  @@unique([formId, url])
  @@index([formId])
  @@index([tenantId])
  @@index([active])
  @@index([createdAt])
}
```

#### WebhookDelivery
```prisma
model WebhookDelivery {
  id             String                  @id @default(uuid())
  webhookId      String
  submissionId   String
  eventType      String
  status         WebhookDeliveryStatus   @default(PENDING)
  attempt        Int                     @default(0)
  maxAttempts    Int                     @default(8)
  httpStatus     Int?
  requestBody    Json?
  responseBody   Json?
  responseError  String?
  nextRetryAt    DateTime?
  deliveredAt    DateTime?
  createdAt      DateTime                @default(now())
  updatedAt      DateTime                @updatedAt

  webhook    Webhook        @relation(fields: [webhookId], references: [id], onDelete: Cascade)
  submission FormSubmission @relation(fields: [submissionId], references: [id], onDelete: Cascade)

  @@index([webhookId])
  @@index([status])
  @@index([nextRetryAt])
  @@index([createdAt])
  @@index([submissionId])
}

enum WebhookDeliveryStatus {
  PENDING
  DELIVERED
  FAILED
  RETRYING
}
```

### Libraries

#### 1. **hmac.ts** - HMAC-SHA256 Signing
```typescript
// Functions:
- generateSignature(payload, secret): {signature, timestamp}
- verifySignature(payload, secret, signature, timestamp, toleranceMs?): boolean
- hashSecret(secret): string
- generateWebhookSecret(): string
```

**Features**:
- HMAC-SHA256 with timestamp
- Constant-time comparison (prevents timing attacks)
- 5-minute timestamp tolerance (configurable)
- Format: `timestamp.payload` signed with Base64 encoding

#### 2. **retry.ts** - Exponential Backoff
```typescript
// Functions:
- calculateNextRetry(attempt): Date
- shouldRetry(status, attempt, maxAttempts, nextRetryAt?): boolean
- isReadyToRetry(nextRetryAt?, now?): boolean
- formatRetryStatus(attempt, maxAttempts, nextRetryAt?): string
```

**Retry Schedule**:
- Attempt 1: 1 minute
- Attempt 2: 5 minutes
- Attempt 3: 15 minutes
- Attempt 4: 1 hour
- Attempt 5: 6 hours
- Attempt 6: 24 hours
- Attempt 7: 24 hours
- Attempt 8: 24 hours (max)

#### 3. **delivery.ts** - HTTP Delivery & Retry Handler
```typescript
// Functions:
- attemptDelivery(deliveryId, webhookSecret): Promise<DeliveryResult>
- processPendingRetries(): Promise<void>
- cleanupOldDeliveries(retentionDays?): Promise<number>
```

**Features**:
- POST with 5-second timeout
- Automatic retry scheduling
- Detailed response logging
- Handles network errors gracefully

#### 4. **dispatcher.ts** - Webhook Queue & Management
```typescript
// Functions:
- enqueueWebhook(options): Promise<{success, deliveryIds, error?}>
- checkWebhookHealth(webhookId, limit?): Promise<health_stats>
- retryFailedDeliveries(webhookId, webhookSecret): Promise<{retried, failed}>
```

**Features**:
- Automatic webhook discovery for form + event type
- Creates delivery records for all matching webhooks
- Triggers first attempt immediately
- Batches for performance

---

## API Routes

### 1. GET /api/agro/[tenant]/webhooks
List all webhooks for tenant

**Query Parameters**:
- `formId` (optional): Filter by form

**Response**:
```json
{
  "success": true,
  "webhooks": [
    {
      "id": "webhook-123",
      "formId": "form-456",
      "url": "https://example.com/webhook",
      "eventTypes": ["SUBMISSION_CREATED"],
      "active": true,
      "stats": {
        "delivered": 42,
        "failed": 2,
        "retrying": 1,
        "pending": 0
      },
      "createdAt": "2026-01-26T...",
      "updatedAt": "2026-01-26T..."
    }
  ],
  "count": 1
}
```

### 2. POST /api/agro/[tenant]/webhooks
Create webhook

**Body**:
```json
{
  "formId": "form-456",
  "url": "https://example.com/webhook",
  "eventTypes": ["SUBMISSION_CREATED", "SUBMISSION_UPDATED"],
  "secret": "optional-custom-secret" // Omit to auto-generate
}
```

**Response**:
```json
{
  "success": true,
  "webhook": {
    "id": "webhook-123",
    "formId": "form-456",
    "url": "https://example.com/webhook",
    "eventTypes": ["SUBMISSION_CREATED", "SUBMISSION_UPDATED"],
    "active": true,
    "createdAt": "2026-01-26T...",
    "updatedAt": "2026-01-26T..."
  },
  "secret": "abc123def456...",
  "message": "Webhook created successfully. Save the secret in a secure location."
}
```

### 3. PUT /api/agro/[tenant]/webhooks/[webhookId]
Update webhook

**Body** (all optional):
```json
{
  "url": "https://new-url.com/webhook",
  "eventTypes": ["SUBMISSION_CREATED"],
  "active": false
}
```

### 4. DELETE /api/agro/[tenant]/webhooks/[webhookId]
Delete webhook (cascades to deliveries)

### 5. POST /api/agro/[tenant]/webhooks/[webhookId]/test
Send test event

**Body**:
```json
{
  "eventType": "SUBMISSION_CREATED",
  "data": {
    "formId": "form-456",
    "submissionId": "sub-789",
    "timestamp": "2026-01-26T..."
  }
}
```

### 6. GET /api/agro/[tenant]/webhooks/[webhookId]/deliveries
List delivery attempts

**Query Parameters**:
- `page`: Default 1
- `limit`: Default 20, max 100
- `status`: Comma-separated (PENDING,DELIVERED,FAILED,RETRYING)

**Response**:
```json
{
  "success": true,
  "deliveries": [
    {
      "id": "delivery-123",
      "submissionId": "sub-456",
      "eventType": "SUBMISSION_CREATED",
      "status": "DELIVERED",
      "attempt": 1,
      "maxAttempts": 8,
      "httpStatus": 200,
      "deliveredAt": "2026-01-26T...",
      "createdAt": "2026-01-26T...",
      "updatedAt": "2026-01-26T..."
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 142,
    "totalPages": 8,
    "hasMore": true
  }
}
```

### 7. POST /api/agro/[tenant]/webhooks/[webhookId]/deliveries/[deliveryId]/retry
Manually retry failed delivery

**Response**:
```json
{
  "success": true,
  "delivery": {
    "id": "delivery-123",
    "status": "DELIVERED",
    "attempt": 2,
    "httpStatus": 200,
    "deliveredAt": "2026-01-26T..."
  },
  "message": "Delivery successful"
}
```

---

## Webhook Payload Format

All webhook requests are POST with JSON body + HMAC headers.

### Headers
```
Content-Type: application/json
User-Agent: DPWAI-Webhooks/1.0
X-DPWAI-Signature: base64(hmac-sha256)
X-DPWAI-Timestamp: milliseconds-since-epoch
X-DPWAI-Event-Type: SUBMISSION_CREATED
X-DPWAI-Delivery-ID: delivery-123
```

### Body
```json
{
  "id": "delivery-123",
  "webhookId": "webhook-456",
  "eventType": "SUBMISSION_CREATED",
  "submissionId": "sub-789",
  "timestamp": "2026-01-26T...",
  "attempt": 1,
  "data": {
    // Form submission data, custom based on event type
    "formId": "form-456",
    "field_1": "value",
    "field_2": 123
  }
}
```

### HMAC Verification (Node.js)
```javascript
import crypto from 'crypto';

function verifyWebhookSignature(payload, signature, timestamp, secret) {
  const message = `${timestamp}.${JSON.stringify(payload)}`;
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(message)
    .digest('base64');

  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}
```

---

## UI Pages

### 1. /dpwai/[tenant_snake]/webhooks
**Webhook Management Dashboard**

Features:
- List all webhooks with stats
- Create new webhook (modal form)
- Toggle active/inactive status
- Quick actions: View Deliveries, Edit, Delete
- Statistics: delivered, failed, retrying, pending counts
- Status indicators (green for active, gray for inactive)

### 2. /dpwai/[tenant_snake]/webhooks/[webhookId]/deliveries
**Delivery History & Retry**

Features:
- Paginated delivery list (20 per page)
- Filter by status (PENDING, DELIVERED, FAILED, RETRYING)
- Click delivery for detailed view:
  - Request/response bodies
  - Error messages
  - Retry timing
  - HTTP status codes
- Manual retry button for failed deliveries
- Timestamps for all events

---

## Implementation Checklist

### Database
- [x] Webhook model with form + tenant relations
- [x] WebhookDelivery model with status tracking
- [x] Enum for delivery statuses
- [x] Proper indexes for queries
- [x] Cascade delete for webhooks

### Libraries
- [x] HMAC-SHA256 signing/verification
- [x] Exponential backoff retry scheduling
- [x] HTTP delivery with timeout handling
- [x] Error handling & logging
- [x] Webhook dispatcher/enqueuer

### API Routes (7 endpoints)
- [x] GET /api/agro/[tenant]/webhooks
- [x] POST /api/agro/[tenant]/webhooks
- [x] PUT /api/agro/[tenant]/webhooks/[webhookId]
- [x] DELETE /api/agro/[tenant]/webhooks/[webhookId]
- [x] POST /api/agro/[tenant]/webhooks/[webhookId]/test
- [x] GET /api/agro/[tenant]/webhooks/[webhookId]/deliveries
- [x] POST /api/agro/[tenant]/webhooks/[webhookId]/deliveries/[deliveryId]/retry

### UI Pages (2 pages)
- [x] /dpwai/[tenant_snake]/webhooks (management)
- [x] /dpwai/[tenant_snake]/webhooks/[webhookId]/deliveries (history)

### Authentication & Authorization
- [x] JWT verification on all API routes
- [x] Tenant membership check
- [x] Webhook ownership validation

### Error Handling
- [x] Network error handling
- [x] Timeout handling (5s)
- [x] Response validation
- [x] Graceful degradation

### Testing
- [x] Unit tests for HMAC
- [x] Unit tests for retry logic
- [x] Test scenarios for exponential backoff
- [x] Payload structure validation

---

## Usage Example

### 1. Create a Webhook
```bash
curl -X POST http://localhost:3000/api/agro/my-tenant/webhooks \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "formId": "form-123",
    "url": "https://example.com/webhook",
    "eventTypes": ["SUBMISSION_CREATED"]
  }'
```

Response:
```json
{
  "webhook": {
    "id": "webhook-abc123",
    "url": "https://example.com/webhook",
    "active": true
  },
  "secret": "abc123def456789..."
}
```

### 2. Handle Webhook on Your Server
```javascript
app.post('/webhook', (req, res) => {
  const signature = req.headers['x-dpwai-signature'];
  const timestamp = req.headers['x-dpwai-timestamp'];
  const eventType = req.headers['x-dpwai-event-type'];
  const deliveryId = req.headers['x-dpwai-delivery-id'];

  // Verify signature
  const isValid = verifyWebhookSignature(
    req.body,
    signature,
    timestamp,
    process.env.WEBHOOK_SECRET
  );

  if (!isValid) {
    return res.status(401).json({ error: 'Invalid signature' });
  }

  // Process webhook
  console.log(`Processing ${eventType} event (delivery ${deliveryId})`);
  console.log('Form submission:', req.body);

  res.json({ success: true, processed: true });
});
```

### 3. Monitor Deliveries
```bash
curl http://localhost:3000/api/agro/my-tenant/webhooks/webhook-abc123/deliveries \
  -H "Authorization: Bearer $TOKEN" \
  -G --data-urlencode "status=FAILED"
```

### 4. Retry Failed Delivery
```bash
curl -X POST http://localhost:3000/api/agro/my-tenant/webhooks/webhook-abc123/deliveries/delivery-123/retry \
  -H "Authorization: Bearer $TOKEN"
```

---

## File Structure

```
/dpwaiagro/
├── lib/webhooks/
│   ├── hmac.ts              (HMAC signing)
│   ├── retry.ts             (Exponential backoff)
│   ├── delivery.ts          (HTTP delivery + retry)
│   ├── dispatcher.ts        (Queue + management)
│   └── __tests__/
│       └── webhook-system.test.ts
├── app/api/agro/[tenant]/webhooks/
│   ├── route.ts             (GET/POST webhooks)
│   ├── [webhookId]/
│   │   ├── route.ts         (PUT/DELETE webhook)
│   │   ├── test/
│   │   │   └── route.ts     (POST test event)
│   │   └── deliveries/
│   │       ├── route.ts     (GET deliveries)
│   │       └── [deliveryId]/
│   │           └── retry/
│   │               └── route.ts  (POST retry)
└── app/dpwai/[tenant_snake]/webhooks/
    ├── page.tsx             (Webhook management)
    └── [webhookId]/
        └── deliveries/
            └── page.tsx     (Delivery history)
```

---

## Security Considerations

1. **HMAC Signing**: All webhooks signed with SHA256 + timestamp
2. **Constant-Time Comparison**: Prevents timing attacks
3. **Timestamp Validation**: 5-minute tolerance (configurable)
4. **Secret Storage**: Hashed in database, never logged
5. **Tenant Isolation**: Webhooks scoped to tenant + form
6. **JWT Authentication**: All API routes require valid JWT
7. **Rate Limiting**: Can be added at gateway level
8. **Timeout Protection**: 5-second timeout on all deliveries

---

## Monitoring & Maintenance

### Key Metrics
- Total webhooks per tenant
- Delivery success rate
- Average delivery time
- Retry rate
- Failed deliveries requiring manual intervention

### Database Cleanup
```typescript
// Clean up old successful deliveries (after 30 days)
await cleanupOldDeliveries(30);
```

### Manual Retry (Admin)
```typescript
// Retry all failed deliveries for a webhook
await retryFailedDeliveries(webhookId, secret);
```

---

## Future Enhancements

1. **Webhook Templates**: Pre-built webhook types for popular services
2. **Rate Limiting**: Per-webhook rate limits
3. **Signing Algorithms**: Support for RSA, ECDSA
4. **Webhook Certificates**: Validate server certificates
5. **Batch Delivery**: Group multiple submissions
6. **Event Filtering**: Fine-grained event subscriptions
7. **Delivery Analytics**: Dashboard with metrics
8. **Slack/Email Alerts**: Notify on delivery failures
9. **Webhook Replay**: Resend old deliveries
10. **Custom Headers**: User-specified HTTP headers

---

## Support & Troubleshooting

### Webhook not delivering
1. Check webhook is active: `GET /api/agro/[tenant]/webhooks`
2. View delivery attempts: `GET /api/agro/[tenant]/webhooks/[id]/deliveries`
3. Check response/error in delivery details
4. Verify signature verification on your server
5. Check server logs for timeouts (5s limit)

### High retry rate
1. Review server response codes in delivery history
2. Ensure webhook endpoint is accessible
3. Increase timeout if needed (currently 5s)
4. Contact server owner if returning 5xx errors

### Unable to verify signature
1. Confirm you're using exact webhook secret
2. Verify timestamp is current (within 5 minutes)
3. Ensure you're using exact payload body (no reformatting)
4. Check signing algorithm: HMAC-SHA256, Base64 encoding

---

**Last Updated**: 2026-01-26
**Version**: 1.0
**Status**: Production Ready ✅
