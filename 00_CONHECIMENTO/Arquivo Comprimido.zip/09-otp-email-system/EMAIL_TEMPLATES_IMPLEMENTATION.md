# Email Template System - Complete Implementation

## Overview
Comprehensive email template system with GrapesJS visual builder, merge tags, and test email functionality.

## Database Schema

### Enums Added
```prisma
enum EmailTemplateType {
  FORM_LINK_INVITE
  SUBMISSION_CONFIRMATION
  OTP_EMAIL
  CUSTOM
}

enum EmailTemplateState {
  DRAFT
  PUBLISHED
  ARCHIVED
}
```

### Model Added
```prisma
model EmailTemplate {
  id                String                @id @default(uuid())
  tenantId          String
  name              String
  type              EmailTemplateType
  state             EmailTemplateState    @default(DRAFT)
  subjectTemplate   String
  htmlTemplate      String?
  grapesProjectJson Json?
  mergeTags         String[]
  createdAt         DateTime              @default(now())
  updatedAt         DateTime              @updatedAt

  @@index([tenantId])
  @@index([type])
  @@index([state])
  @@index([createdAt])
}
```

**Database Migration**: `/Users/balzer/dpwai-app2/dpwaiagro/prisma/migrations/20260126_add_email_templates/migration.sql`

## API Endpoints

### 1. List & Create Templates
**Route**: `/api/agro/[tenant]/email-templates`

**GET** - List all templates
- Response: `{ success: true, templates: EmailTemplate[] }`

**POST** - Create new template
- Body: `{ name: string, type: EmailTemplateType, subjectTemplate: string }`
- Response: `{ success: true, template: EmailTemplate }`

### 2. Update & Delete Template
**Route**: `/api/agro/[tenant]/email-templates/[templateId]`

**PUT** - Update template (save draft, HTML, GrapesJS project)
- Body: `{ htmlTemplate?: string, grapesProjectJson?: Json, subjectTemplate?: string, mergeTags?: string[] }`
- Response: `{ success: true, template: EmailTemplate }`

**DELETE** - Delete template
- Response: `{ success: true, message: 'Template deleted successfully' }`

### 3. Publish Template
**Route**: `/api/agro/[tenant]/email-templates/[templateId]/publish`

**POST** - Change state from DRAFT to PUBLISHED
- Body: (empty)
- Response: `{ success: true, template: EmailTemplate, message: 'Template published successfully' }`

### 4. Send Test Email
**Route**: `/api/agro/[tenant]/email-templates/[templateId]/send-test`

**POST** - Send test email with sample data
- Body: `{ toEmail: string, variables?: Record<string, string> }`
- Response: `{ success: true, message: 'Test email sent successfully', messageId: string }`

## Merge Tags

### Supported Merge Tags
- `{formName}` - Name of the form
- `{recipientName}` - Name of the recipient
- `{publicLink}` - Public URL of the form
- `{otpCode}` - OTP code for verification
- `{submissionId}` - Unique submission identifier
- `{submissionDate}` - Date the form was submitted

### Usage Example
Subject: `Você recebeu um convite para {formName}`
HTML: `<p>Olá {recipientName},</p> <p><a href="{publicLink}">Abrir Formulário</a></p>`

## Utility Function

**File**: `/Users/balzer/dpwai-app2/dpwaiagro/lib/email/renderTemplate.ts`

### Functions
```typescript
renderTemplate(template: string, variables: RenderVariables): string
// Replaces merge tags with values

renderEmailTemplate(subjectTemplate: string, htmlTemplate: string, variables: RenderVariables): { subject: string, html: string }
// Renders both subject and HTML templates

getSampleVariables(templateType: string): RenderVariables
// Gets default sample data for template preview
```

### Features
- HTML-escapes all variable values to prevent XSS
- Removes unused merge tags
- Provides sample data for each template type

## Frontend Pages

### 1. Templates List Page
**Route**: `/dpwai/[tenant_snake]/email-templates`

**Features**:
- List all templates in table format
- Filter by type (FORM_LINK_INVITE, SUBMISSION_CONFIRMATION, OTP_EMAIL, CUSTOM)
- Filter by state (DRAFT, PUBLISHED, ARCHIVED)
- Actions: Edit, Preview, Delete
- Create new template button
- State indicators with color badges

### 2. Create New Template Page
**Route**: `/dpwai/[tenant_snake]/email-templates/new`

**Features**:
- Template name input
- Template type selector
- Subject template input with merge tag guide
- Form validation
- Redirects to builder on creation
- Merge tags reference guide

### 3. Email Builder Page
**Route**: `/dpwai/[tenant_snake]/email-templates/[templateId]/builder`

**Features**:
- GrapesJS visual email builder (dynamically loaded)
- Save draft button
- Publish button (validates HTML and subject)
- Send test email form with email input
- Shows template state (DRAFT/PUBLISHED)
- Renders HTML + CSS from GrapesJS
- Saves project data and rendered HTML

**GrapesJS Configuration**:
- Plugin: grapesjs-preset-webpage
- No storage manager (manual save)
- Loads existing project data or HTML on init

### 4. Preview Page
**Route**: `/dpwai/[tenant_snake]/email-templates/[templateId]/preview`

**Features**:
- Desktop/Mobile viewport toggle
- Subject preview
- HTML render with merge tag substitution
- Live variable editing
- Sample data based on template type
- Download HTML button
- Shows raw HTML code

## Files Created

### Backend
1. `/app/api/agro/[tenant]/email-templates/route.ts` - List & Create
2. `/app/api/agro/[tenant]/email-templates/[templateId]/route.ts` - Update & Delete
3. `/app/api/agro/[tenant]/email-templates/[templateId]/publish/route.ts` - Publish
4. `/app/api/agro/[tenant]/email-templates/[templateId]/send-test/route.ts` - Send Test
5. `/lib/email/renderTemplate.ts` - Template rendering utility

### Frontend
1. `/app/dpwai/[tenant_snake]/email-templates/page.tsx` - Templates list
2. `/app/dpwai/[tenant_snake]/email-templates/new/page.tsx` - Create template
3. `/app/dpwai/[tenant_snake]/email-templates/[templateId]/builder/page.tsx` - GrapesJS builder
4. `/app/dpwai/[tenant_snake]/email-templates/[templateId]/preview/page.tsx` - Preview

### Database
1. `/prisma/migrations/20260126_add_email_templates/migration.sql` - Database schema

## Authentication & Authorization

All endpoints require authentication via `verifyAuth()`:
- Validates JWT token
- Ensures user has access to tenant
- Validates tenant parameter matches user's tenant

## Error Handling

### Validation Errors (400)
- Missing required fields
- Invalid template type
- Invalid email format
- Incomplete template (no HTML/subject for publishing)

### Not Found Errors (404)
- Template doesn't exist
- Template doesn't belong to tenant

### Server Errors (500)
- Database errors
- Email sending failures
- GrapesJS initialization failures

## Sample Data by Template Type

### FORM_LINK_INVITE
```javascript
{
  formName: "Cadastro de Propriedade",
  publicLink: "https://app.dpwai.com.br/forms/abc123",
  recipientName: "João Silva"
}
```

### SUBMISSION_CONFIRMATION
```javascript
{
  formName: "Cadastro de Propriedade",
  recipientName: "João Silva",
  submissionId: "SUB-001",
  submissionDate: "26/01/2026"
}
```

### OTP_EMAIL
```javascript
{
  otpCode: "123456",
  recipientName: "João Silva"
}
```

## Key Features

1. **Visual Email Builder**: GrapesJS integration for drag-and-drop email design
2. **Merge Tags**: Dynamic content substitution with automatic HTML escaping
3. **Multi-State Workflow**: DRAFT → PUBLISHED → ARCHIVED
4. **Test Email**: Send previews to test addresses before publishing
5. **Preview**: View rendered email with different viewports (desktop/mobile)
6. **Download HTML**: Export completed templates as HTML files
7. **Sample Data**: Auto-populated variables for testing
8. **Type Safety**: Enum-based template types for consistency

## Testing Workflow

1. Create template: `/dpwai/[tenant]/email-templates/new`
2. Edit template: `/dpwai/[tenant]/email-templates/[templateId]/builder`
3. Preview: `/dpwai/[tenant]/email-templates/[templateId]/preview`
4. Send test email: Use "Enviar Teste" button in builder
5. Publish: Click "Publicar" when ready
6. Use in automation: Reference template ID in submission workflows

## Resend Integration

Uses existing `/lib/email/resend.ts` with `sendEmail()` function:
- Supports HTML + Text content
- Uses EMAIL_FROM env var (default: "DPWAI <noreply@dpwai.com.br>")
- Returns message ID and success status

## i18n Considerations

- UI text in Portuguese (pt-BR)
- Merge tags support English variable names (no translation)
- Subject/HTML content is user-provided (no translation)

## Performance Notes

- GrapesJS loaded dynamically (client-side only)
- CSS/JS minified by GrapesJS
- Database queries indexed by tenantId, type, state, createdAt
- No real-time sync (manual save only)

## Deployment Notes

1. Run Prisma migration to create EmailTemplate table
2. Ensure Resend API key is set in environment
3. GrapesJS library will be downloaded on first use
4. CSS imports may need to be added to global styles if needed

## Future Enhancements

1. Template versioning (keep history of changes)
2. Email scheduling (send at specific times)
3. A/B testing (split test subject lines)
4. Analytics (track opens, clicks)
5. Advanced merge tags (conditional content, loops)
6. Template library (pre-built templates)
7. Drag-and-drop merge tags in builder
8. Custom fonts and branding
9. Template locking (prevent modifications)
10. Bulk email sending

---

**Implementation Date**: 2026-01-26
**Status**: Complete - Ready for Testing & Deployment
**Build Status**: Pending fix of unrelated verifyTenantAccess import issue in webhook routes
