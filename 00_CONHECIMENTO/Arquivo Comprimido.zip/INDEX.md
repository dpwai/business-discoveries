# DPWAI Platform - Knowledge Base

**Welcome to the DPWAI documentation hub.** This is your single source of truth for understanding, developing, and deploying the DPWAI agricultural automation platform.

---

## Quick Start by Intent

### "I want to get started developing locally"
→ See: [Local Setup Guide](/01-setup-local/QUICK-START.md)

### "I want to understand how the platform works"
→ See: [How the Repo Works](/00-overview/HOW-THE-REPO-WORKS.md)

### "I want to deploy to production"
→ See: [Deployment Checklist](/06-deploy/DEPLOYMENT-CHECKLIST.md)

### "I'm having a problem and need help"
→ See: [Troubleshooting & QA](/07-troubleshooting/QA-INDEX.md)

### "I want to learn about our design system"
→ See: [Design System](/00-overview/DESIGN-SYSTEM.md)

### "I need to build forms"
→ See: [Forms Design Guide](/00-overview/FORMS-DESIGN-GUIDE.md)

---

## Documentation Structure

### 📋 [00-overview/](./00-overview/) - Platform Fundamentals
Essential knowledge for understanding DPWAI's capabilities and architecture.

- **[PROJECT-OVERVIEW.md](./00-overview/PROJECT-OVERVIEW.md)** - High-level platform description
- **[PLATFORM-CAPABILITY-ANALYSIS.md](./00-overview/PLATFORM-CAPABILITY-ANALYSIS.md)** - What DPWAI can do (features, modules, limitations)
- **[HOW-THE-REPO-WORKS.md](./00-overview/HOW-THE-REPO-WORKS.md)** - Technical architecture and repository structure
- **[TECH-STACK.md](./00-overview/TECH-STACK.md)** - Technology choices and versions
- **[DESIGN-SYSTEM.md](./00-overview/DESIGN-SYSTEM.md)** - UI/UX design guidelines and component patterns
- **[FORMS-DESIGN-GUIDE.md](./00-overview/FORMS-DESIGN-GUIDE.md)** - Form builder documentation and field types
- **[REQUIREMENTS-SUMMARY.md](./00-overview/REQUIREMENTS-SUMMARY.md)** - Feature requirements and specifications
- **[CLAUDE-CONTEXT.md](./00-overview/CLAUDE-CONTEXT.md)** - Design context and decision rationale
- **[FRAMEWORK_READY_FINAL_REPORT.md](./00-overview/FRAMEWORK_READY_FINAL_REPORT.md)** - Final report of the repo-wide organization + framework rollout (Jan 2026)
- **[README.md](./00-overview/README.md)** - Directory guide

---

### 🚀 [01-setup-local/](./01-setup-local/) - Local Development Setup
Everything you need to set up your development environment.

- **[QUICK-START.md](./01-setup-local/QUICK-START.md)** - Five-minute setup guide (START HERE if new)
- **[PREREQUISITES.md](./01-setup-local/PREREQUISITES.md)** - System requirements and dependencies
- **[SETUP-RAPIDO.txt](./01-setup-local/SETUP-RAPIDO.txt)** - Portuguese quick reference
- **[CHEAT-SHEET.txt](./01-setup-local/CHEAT-SHEET.txt)** - Common commands and shortcuts
- **[I18N-SETUP.md](./01-setup-local/I18N-SETUP.md)** - Internationalization (i18n) configuration
- **[RESEND-EMAIL-SETUP.md](./01-setup-local/RESEND-EMAIL-SETUP.md)** - Email service integration
- **[COMMON-TASKS.md](./01-setup-local/COMMON-TASKS.md)** - How to perform everyday development tasks
- **[TESTING-SETUP.md](./01-setup-local/TESTING-SETUP.md)** - Test environment configuration
- **[TEST-SUITE-QUICK.md](./01-setup-local/TEST-SUITE-QUICK.md)** - Running quick test suite
- **[TEST-SUITE-FULL.md](./01-setup-local/TEST-SUITE-FULL.md)** - Running full test suite
- **[TEST-RESULTS-SUMMARY.md](./01-setup-local/TEST-RESULTS-SUMMARY.md)** - Latest test results

---

### 🎨 [02-frontend/](./02-frontend/) - Frontend Development
UI components, styling patterns, and responsive design guidance.

- **[COMPONENT-LIBRARY.md](./02-frontend/COMPONENT-LIBRARY.md)** - Available UI components and usage
- **[DESIGN-SYSTEM.md](./00-overview/DESIGN-SYSTEM.md)** - Design tokens and patterns (see 00-overview)
- **[MOBILE-PATTERNS.md](./02-frontend/MOBILE-PATTERNS.md)** - Responsive and mobile design patterns
- **[RESPONSIVE-DESIGN.md](./02-frontend/RESPONSIVE-DESIGN.md)** - Breakpoints and responsive guidelines
- **[MOBILE-DRAWER-FIX.md](./02-frontend/MOBILE-DRAWER-FIX.md)** - Mobile drawer implementation details
- **[UI-MODERNIZATION.md](./02-frontend/UI-MODERNIZATION.md)** - UI/UX improvements and modernization notes
- **[FORM-PREVIEW-DELIVERABLES.md](./02-frontend/FORM-PREVIEW-DELIVERABLES.md)** - Admin form preview page deliverables (components, page, tests, docs)

**Mobile Fixes & Improvements:**
- **[mobile-fixes/CHANGELOG-MOBILE-FIXES.md](./02-frontend/mobile-fixes/CHANGELOG-MOBILE-FIXES.md)** - Mobile bug fixes changelog
- **[mobile-fixes/MOBILE-FIX-SUMMARY.md](./02-frontend/mobile-fixes/MOBILE-FIX-SUMMARY.md)** - Summary of mobile fixes
- **[mobile-fixes/DEMO-FIXES-ACTUAL.md](./02-frontend/mobile-fixes/DEMO-FIXES-ACTUAL.md)** - Demo implementation details
- **[mobile-fixes/QA-MOBILE-CHECKLIST.md](./02-frontend/mobile-fixes/QA-MOBILE-CHECKLIST.md)** - Mobile QA testing checklist

---

### ⚙️ [03-backend/](./03-backend/) - Backend Development
API endpoints, database structure, and backend logic.

- **[API-REFERENCE.md](./03-backend/API-REFERENCE.md)** - Complete API endpoint documentation
- **[I18N-HARDCODED-AUDIT.md](./03-backend/I18N-HARDCODED-AUDIT.md)** - Hardcoded strings audit and migration status
- **[HARDCODED-STRINGS-AUDIT.csv](./03-backend/HARDCODED-STRINGS-AUDIT.csv)** - CSV audit results for tracking
- **[FILE_UPLOAD_DELIVERABLES.md](./03-backend/FILE_UPLOAD_DELIVERABLES.md)** - File upload system deliverables (APIs, storage, DB, tests, docs)

**Error Handling System:**
- **[error-handling/ERROR-HANDLING-GUIDE.md](./03-backend/error-handling/ERROR-HANDLING-GUIDE.md)** - Comprehensive error handling architecture
- **[error-handling/ERROR-HANDLING-EXAMPLES.md](./03-backend/error-handling/ERROR-HANDLING-EXAMPLES.md)** - Code examples and patterns
- **[error-handling/ERROR-HANDLING-README.md](./03-backend/error-handling/ERROR-HANDLING-README.md)** - Quick start guide
- **[error-handling/ERROR-HANDLING-VERIFICATION.md](./03-backend/error-handling/ERROR-HANDLING-VERIFICATION.md)** - Verification checklist

**Internationalization (i18n):**
- **[i18n/I18N-GUIDE.md](./03-backend/i18n/I18N-GUIDE.md)** - i18n system documentation
- **[i18n/I18N-AUDIT-REPORT.md](./03-backend/i18n/I18N-AUDIT-REPORT.md)** - Phase 7 i18n audit results

---

### 🔧 [04-env-vars/](./04-env-vars/) - Environment Configuration
Environment variables and configuration reference.

- **[ENV-REFERENCE.md](./04-env-vars/ENV-REFERENCE.md)** - All environment variables explained
- **[VERCEL-ENV-SUMMARY.txt](./04-env-vars/VERCEL-ENV-SUMMARY.txt)** - Vercel-specific environment setup

---

### 🎯 [08-forms/](./08-forms/) - Forms System
Advanced form building and sharing features.

- **[README.md](./08-forms/README.md)** - Forms system overview and quick start
- **[SHARE-SYSTEM-IMPLEMENTATION.md](./08-forms/SHARE-SYSTEM-IMPLEMENTATION.md)** - Complete form sharing with short links, QR codes, and email integration

---

### 🔄 [05-ci-cd/](./05-ci-cd/) - CI/CD Pipeline
Continuous integration and deployment documentation.

- **[CI-CD-README.md](./05-ci-cd/CI-CD-README.md)** - GitHub Actions + Vercel deployment flow

---

### 📦 [06-deploy/](./06-deploy/) - Production Deployment
Deployment procedures for different platforms.

- **[DEPLOYMENT-CHECKLIST.md](./06-deploy/DEPLOYMENT-CHECKLIST.md)** - Pre-deployment verification checklist
- **[DEPLOYMENT-OVERVIEW.md](./06-deploy/DEPLOYMENT-OVERVIEW.md)** - Deployment process overview
- **[VERCEL-DEPLOYMENT.md](./06-deploy/VERCEL-DEPLOYMENT.md)** - Deploying to Vercel (recommended)
- **[VERCEL-QUICK-SETUP.md](./06-deploy/VERCEL-QUICK-SETUP.md)** - Quick Vercel setup
- **[VERCEL-QUICK-REFERENCE.md](./06-deploy/VERCEL-QUICK-REFERENCE.md)** - Vercel quick reference
- **[HOSTINGER-DEPLOYMENT.md](./06-deploy/HOSTINGER-DEPLOYMENT.md)** - Alternative: Hostinger deployment

---

### 🆘 [07-troubleshooting/](./07-troubleshooting/) - QA & Troubleshooting
Debugging, testing, and problem-solving guides.

- **[QA-INDEX.md](./07-troubleshooting/QA-INDEX.md)** - QA test index and test cases
- **[QA-SUMMARY.md](./07-troubleshooting/QA-SUMMARY.md)** - QA testing summary
- **[AUDIT-COMPLETION.md](./07-troubleshooting/AUDIT-COMPLETION.md)** - Audit completion status
- **[AUDIT-VERIFICATION.md](./07-troubleshooting/AUDIT-VERIFICATION.md)** - Audit verification details
- **[VERCEL_CACHE_FIX.md](./07-troubleshooting/VERCEL_CACHE_FIX.md)** - How to clear stale Vercel cache when builds fail

**Bug Fixes & Tracking:**
- **[bug-fixes/AUDIT-AND-FIXES.md](./07-troubleshooting/bug-fixes/AUDIT-AND-FIXES.md)** - Comprehensive bug audit and fixes
- **[bug-fixes/AUDIT-EXECUTIVE-SUMMARY.md](./07-troubleshooting/bug-fixes/AUDIT-EXECUTIVE-SUMMARY.md)** - Audit executive summary
- **[bug-fixes/REMAINING-BUGS-ACTION-PLAN.md](./07-troubleshooting/bug-fixes/REMAINING-BUGS-ACTION-PLAN.md)** - Remaining bugs action plan
- **[bug-fixes/BUG-FIX-PLAN.md](./07-troubleshooting/bug-fixes/BUG-FIX-PLAN.md)** - Bug fix planning process
- **[bug-fixes/BUG-REPORT-DEMO-AUDIT.md](./07-troubleshooting/bug-fixes/BUG-REPORT-DEMO-AUDIT.md)** - Demo audit bug report
- **[bug-fixes/DEMO-BUG-FIXES-IMPLEMENTATION.md](./07-troubleshooting/bug-fixes/DEMO-BUG-FIXES-IMPLEMENTATION.md)** - Demo bug fixes implementation

**Critical Fixes:**
- **[critical-fixes/LOGIN-404-FIX.md](./07-troubleshooting/critical-fixes/LOGIN-404-FIX.md)** - Critical login 404 fix documentation
- **[critical-fixes/CRITICAL-FIX-SUMMARY.md](./07-troubleshooting/critical-fixes/CRITICAL-FIX-SUMMARY.md)** - Critical fix summary
- **[critical-fixes/DEPLOYMENT-READY.md](./07-troubleshooting/critical-fixes/DEPLOYMENT-READY.md)** - Deployment readiness verification
- **[critical-fixes/TESTING-LOGIN-FLOW.md](./07-troubleshooting/critical-fixes/TESTING-LOGIN-FLOW.md)** - Manual login flow testing guide

**Project History:**
- **[project-history/FINAL-WORK-SUMMARY.md](./07-troubleshooting/project-history/FINAL-WORK-SUMMARY.md)** - Complete work summary
- **[project-history/PHASE5-COMPLETION-SUMMARY.md](./07-troubleshooting/project-history/PHASE5-COMPLETION-SUMMARY.md)** - Phase 5 completion summary
- **[project-history/PHASE5-INDEX.md](./07-troubleshooting/project-history/PHASE5-INDEX.md)** - Phase 5 documentation index

---

## File Organization Guide

| Directory | Purpose | When to Visit |
|-----------|---------|---------------|
| **00-overview** | Platform fundamentals | When you're new or need to understand "why" decisions were made |
| **01-setup-local** | Local development | When setting up your environment or doing daily development |
| **02-frontend** | UI/UX development | When building or modifying frontend components |
| **03-backend** | API & business logic | When working on server-side code or APIs |
| **04-env-vars** | Configuration | When setting up environment variables or secrets |
| **05-ci-cd** | Build & deployment pipeline | When understanding how code is deployed automatically |
| **06-deploy** | Production deployment | When deploying to staging or production |
| **07-troubleshooting** | QA & debugging | When things break or during testing phases |
| **archive** | Historical references | Legacy backups and old documentation (for reference only) |

---

## Important Notes

### Repository Cleanup (2026-01-27)
- Root trimmed to `dpwaiagro/`, `knowledge/`, `scripts/` and `dpwai_local_audit/` for clarity
- Legacy root docs relocated to [archive/legacy-root-docs/](./archive/legacy-root-docs/)
- dpwaiagro-specific docs/logs moved to [archive/dpwaiagro-docs/](./archive/dpwaiagro-docs/) so the Next.js app folder holds only runtime code + README
- Legacy code/backups parked under [archive/code-backups/](./archive/code-backups/) (includes `root-lib/` and `agro.disabled.backup/`)
- Old helper script filed at `scripts/archive/move_all_md_to_knowledge.sh`

### Repository Reorganization (2026-01-25)
During the reorganization, we consolidated scattered documentation:
- **Moved 22 markdown files** from root and dpwaiagro/ to /knowledge/ subdirectories
- **Deleted 2 obsolete files** (STEP-1-VISUAL-VERIFICATION.txt, REALLY_FIXED.md)
- **Cleaned up 18+ empty directories** (.tmux_ai, .agent, .ralphy, backlog, etc.)
- **Created 9 new subdirectories** for better organization (error-handling, i18n, bug-fixes, critical-fixes, etc.)
- **Created missing 05-ci-cd/** directory with complete documentation

**Result**: All documentation now centralized in /knowledge/ with clear organization by topic and purpose. Professional repository structure achieved.

### Maintenance Guidelines
- Keep files focused on their specific purpose
- Update documentation when code changes
- Delete outdated content immediately
- Cross-reference between files using relative paths
- Use clear headings and table of contents in large files

### How to Contribute
1. Add documentation to the appropriate directory
2. Update this INDEX.md with a brief description
3. Link to the new file from relevant sections
4. Review for accuracy and completeness

---

## Quick Links by Role

**🆕 New Developer**
1. [Quick Start](./01-setup-local/QUICK-START.md) - Get your environment running
2. [How the Repo Works](./00-overview/HOW-THE-REPO-WORKS.md) - Understand the architecture
3. [Common Tasks](./01-setup-local/COMMON-TASKS.md) - Learn daily workflows

**👨‍💼 Project Manager**
1. [Platform Capabilities](./00-overview/PLATFORM-CAPABILITY-ANALYSIS.md) - What we can build
2. [Tech Stack](./00-overview/TECH-STACK.md) - What we're using
3. [Deployment Checklist](./06-deploy/DEPLOYMENT-CHECKLIST.md) - Ready for production?

**🎨 Frontend Developer**
1. [Component Library](./02-frontend/COMPONENT-LIBRARY.md) - Available components
2. [Design System](./00-overview/DESIGN-SYSTEM.md) - Design guidelines
3. [Forms Guide](./00-overview/FORMS-DESIGN-GUIDE.md) - Building forms

**⚙️ Backend Developer**
1. [API Reference](./03-backend/API-REFERENCE.md) - Available endpoints
2. [How the Repo Works](./00-overview/HOW-THE-REPO-WORKS.md) - Database & architecture
3. [I18N Audit](./03-backend/I18N-HARDCODED-AUDIT.md) - Localization status

**🚀 DevOps/Deploy**
1. [Deployment Checklist](./06-deploy/DEPLOYMENT-CHECKLIST.md) - Pre-deploy check
2. [Vercel Deployment](./06-deploy/VERCEL-DEPLOYMENT.md) - Deploy to production
3. [Environment Reference](./04-env-vars/ENV-REFERENCE.md) - Configure environment

**🐛 QA Tester**
1. [QA Index](./07-troubleshooting/QA-INDEX.md) - Test cases
2. [Common Tasks](./01-setup-local/COMMON-TASKS.md) - How to run tests
3. [Troubleshooting](./07-troubleshooting/AUDIT-VERIFICATION.md) - Known issues

---

## Directory Tree

```
knowledge/
├── 00-overview/                          (9 files)
│   ├── README.md
│   ├── PROJECT-OVERVIEW.md
│   ├── PLATFORM-CAPABILITY-ANALYSIS.md
│   ├── HOW-THE-REPO-WORKS.md
│   ├── TECH-STACK.md
│   ├── DESIGN-SYSTEM.md
│   ├── FORMS-DESIGN-GUIDE.md
│   ├── REQUIREMENTS-SUMMARY.md
│   └── CLAUDE-CONTEXT.md
│
├── 01-setup-local/                       (12 files)
│   ├── QUICK-START.md
│   ├── PREREQUISITES.md
│   ├── SETUP-RAPIDO.txt
│   ├── CHEAT-SHEET.txt
│   ├── I18N-SETUP.md
│   ├── RESEND-EMAIL-SETUP.md
│   ├── COMMON-TASKS.md
│   ├── TESTING-SETUP.md
│   ├── TEST-SUITE-QUICK.md
│   ├── TEST-SUITE-FULL.md
│   ├── TEST-RESULTS-SUMMARY.md
│   └── testing/
│       └── TEST-ENDPOINTS.md
│
├── 02-frontend/                          (10 files)
│   ├── COMPONENT-LIBRARY.md
│   ├── DESIGN-SYSTEM.md (link to 00-overview)
│   ├── MOBILE-PATTERNS.md
│   ├── RESPONSIVE-DESIGN.md
│   ├── MOBILE-DRAWER-FIX.md
│   ├── UI-MODERNIZATION.md
│   └── mobile-fixes/
│       ├── CHANGELOG-MOBILE-FIXES.md
│       ├── MOBILE-FIX-SUMMARY.md
│       ├── DEMO-FIXES-ACTUAL.md
│       └── QA-MOBILE-CHECKLIST.md
│
├── 03-backend/                           (11 files)
│   ├── API-REFERENCE.md
│   ├── I18N-HARDCODED-AUDIT.md
│   ├── HARDCODED-STRINGS-AUDIT.csv
│   ├── error-handling/
│   │   ├── ERROR-HANDLING-GUIDE.md
│   │   ├── ERROR-HANDLING-EXAMPLES.md
│   │   ├── ERROR-HANDLING-README.md
│   │   └── ERROR-HANDLING-VERIFICATION.md
│   └── i18n/
│       ├── I18N-GUIDE.md
│       └── I18N-AUDIT-REPORT.md
│
├── 04-env-vars/                          (2 files)
│   ├── ENV-REFERENCE.md
│   └── VERCEL-ENV-SUMMARY.txt
│
├── 05-ci-cd/                             (1 file) ✨ NEW
│   └── CI-CD-README.md
│
├── 06-deploy/                            (6 files)
│   ├── DEPLOYMENT-CHECKLIST.md
│   ├── DEPLOYMENT-OVERVIEW.md
│   ├── VERCEL-DEPLOYMENT.md
│   ├── VERCEL-QUICK-SETUP.md
│   ├── VERCEL-QUICK-REFERENCE.md
│   └── HOSTINGER-DEPLOYMENT.md
│
├── 07-troubleshooting/                   (25 files)
│   ├── QA-INDEX.md
│   ├── QA-SUMMARY.md
│   ├── AUDIT-COMPLETION.md
│   ├── AUDIT-VERIFICATION.md
│   ├── bug-fixes/
│   │   ├── AUDIT-AND-FIXES.md
│   │   ├── AUDIT-EXECUTIVE-SUMMARY.md
│   │   ├── REMAINING-BUGS-ACTION-PLAN.md
│   │   ├── BUG-FIX-PLAN.md
│   │   ├── BUG-REPORT-DEMO-AUDIT.md
│   │   └── DEMO-BUG-FIXES-IMPLEMENTATION.md
│   ├── critical-fixes/
│   │   ├── LOGIN-404-FIX.md
│   │   ├── CRITICAL-FIX-SUMMARY.md
│   │   ├── DEPLOYMENT-READY.md
│   │   └── TESTING-LOGIN-FLOW.md
│   └── project-history/
│       ├── FINAL-WORK-SUMMARY.md
│       ├── PHASE5-COMPLETION-SUMMARY.md
│       └── PHASE5-INDEX.md
│
└── archive/                              (3 files)
    └── app-backups/
        ├── README.md
        └── app-fixed/
            ├── layout.tsx
            └── page.tsx
```

**Total: 80 active documentation files across 8 organized directories**

---

## Before/After Comparison

### 📊 Reorganization Results

**BEFORE:**
- 11 .md files scattered in root directory
- 13 .md files scattered in dpwaiagro/
- 18+ empty directories (.tmux_ai, .agent, .ralphy, backlog, scripts/ci, etc.)
- Missing 05-ci-cd/ directory (referenced but didn't exist)
- Unclear documentation structure

**AFTER:**
- ✅ Root clean: only README.md + CLAUDE.md
- ✅ dpwaiagro/ clean: only README.md
- ✅ 80 documentation files organized in /knowledge/
- ✅ 8 well-organized directories by category
- ✅ All empty directories removed
- ✅ New 05-ci-cd/ documentation created
- ✅ Professional, scalable structure

**Actions Taken:**
- ✅ **Moved 22 files** to appropriate /knowledge/ subdirectories
- ✅ **Deleted 2 obsolete files** (verification, confirmation files)
- ✅ **Archived legacy code** (app-fixed/ to /knowledge/archive/)
- ✅ **Created 9 subdirectories** for better organization:
  - 01-setup-local/testing/
  - 02-frontend/mobile-fixes/
  - 03-backend/error-handling/
  - 03-backend/i18n/
  - 05-ci-cd/ (new)
  - 07-troubleshooting/bug-fixes/
  - 07-troubleshooting/critical-fixes/
  - 07-troubleshooting/project-history/
  - archive/app-backups/
- ✅ **Updated .gitignore** to prevent future clutter
- ✅ **Updated INDEX.md** with complete documentation map

---

## Last Updated
- **Reorganization Date**: 2026-01-25
- **Active Files**: 80 (organized in /knowledge/)
- **Directories**: 8 (00-overview, 01-setup-local, 02-frontend, 03-backend, 04-env-vars, 05-ci-cd, 06-deploy, 07-troubleshooting, archive)
- **Status**: ✅ Professional repository organization complete
- **Root Directory**: Clean (only README.md, CLAUDE.md)
- **Next Review**: Ongoing - maintain this organization for all new documentation
