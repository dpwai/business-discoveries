# Remaining Bugs - Action Plan (5-13)

**Status:** 4/13 bugs COMPLETE. 9 bugs remaining.

## Completed ✅
1. Forgot Password Email (Resend) - Enhanced logging, translations, error handling
2. Header Layout - Fixed alignment, removed absolute positioning
3. Tenant/Farm Switch - Now calls /api/auth/switch-tenant, updates backend
4. Footer - Removed tenant info, fixed links

---

## Remaining Bugs (Priority Order)

### 🔴 **BUG #5: Welcome Page Navigation**
- **Status:** Code reviewed - appears CORRECT
- **Route:** `/dpwai/[tenant_snake]/welcome`
- **Component:** `PremiumWelcome.tsx`
- **Finding:** All links are correct (Dashboards, Forms, Ralph Chat)
- **Action:** VERIFIED - No changes needed

### 🔴 **BUG #6: Dashboards - "New Dashboard" text + Looker embed**
- **File:** `/dpwaiagro/app/dpwai/[tenant_snake]/dashboards/page.tsx`
- **Issues:**
  1. English "New Dashboard" button text (should be Portuguese)
  2. Missing Looker iframe embed
- **Fix Needed:**
  ```tsx
  // Change: "New Dashboard" → "Novo Dashboard"
  // Add: Looker embed display when embedUrl exists
  ```
- **Estimate:** 30 min

###  🔴 **BUG #7: Roff (Chat) - White theme instead of dark**
- **File:** `/dpwaiagro/app/dpwai/[tenant_snake]/ralph-chat/page.tsx`
- **Issue:** Component not inheriting dark theme from context
- **Fix Needed:**
  1. Wrap with ThemeProvider if needed
  2. Apply `dark:` Tailwind classes
  3. Use theme context values for colors
- **Estimate:** 20 min

### 🔴 **BUG #8: "Minhas entradas automatizadas" → "Integrações"**
- **Current:** `/dpwaiagro/app/dpwai/[tenant_snake]/automated-entries/page.tsx`
- **Issues:**
  1. Page title should be "Integrações"
  2. White theme (needs dark mode)
  3. All text in English
- **Fix Needed:**
  1. Rename page/menu label
  2. Apply dark theme
  3. Translate text using i18n
- **Estimate:** 25 min

### 🟡 **BUG #9: Users Management - Missing roles + Modal issues**
- **File:** `/dpwaiagro/app/dpwai/[tenant_snake]/users/page.tsx`
- **Issues:**
  1. Roles not selectable (admin/owner checkboxes only)
  2. Modal won't close on save/outside click
  3. Responsive layout broken on mobile
  4. Zoom breaks hamburger menu/header
- **Fix Needed:**
  1. Add role select dropdown (owner/admin/member/viewer)
  2. Fix modal close handlers (ESC key, outside click, save)
  3. Card layout on mobile, table on desktop
  4. CSS fixes for overflow/zoom issues
- **Estimate:** 60 min

### 🟡 **BUG #10: "Minha Conta" - Fonts hard to read**
- **File:** `/dpwaiagro/app/dpwai/[tenant_snake]/account/page.tsx`
- **Issue:** Typography scaling problems
- **Fix Needed:**
  1. Increase font sizes (body: 16px minimum)
  2. Adjust line-heights
  3. Fix spacing/padding
  4. Ensure WCAG contrast
- **Estimate:** 20 min

### 🟡 **BUG #11: Theme toggle dark/light**
- **Context:** `/dpwaiagro/context/ThemeContext.tsx`
- **Issue:** Toggle button not present or not working
- **Fix Needed:**
  1. Add theme toggle button in footer or header
  2. Verify localStorage persistence
  3. Test dark/light switching on all pages
- **Estimate:** 30 min

### 🟡 **BUG #12: Settings → "Minha Organização"**
- **File:** `/dpwaiagro/app/dpwai/[tenant_snake]/settings/page.tsx`
- **Issues:**
  1. Rename "Configurações" → "Minha Organização"
  2. Organization ID must be read-only (no edit)
  3. Display name should be editable
  4. Add organization switcher (if not present)
- **Fix Needed:**
  1. Update page title and labels
  2. Make ID field `disabled`
  3. Keep display name `readOnly = false`
- **Estimate:** 15 min

### 🟡 **BUG #13: Forms - "Owner" label + Bad fonts + UX broken**
- **Files:**
  - `/dpwaiagro/app/dpwai/[tenant_snake]/forms/page.tsx`
  - `/dpwaiagro/components/FormBuilder/FormBuilderLayout.tsx`
- **Issues:**
  1. "Owner" label appearing inappropriately
  2. Form editor typography is unreadable
  3. Three-column layout breaks on mobile
  4. Theme doesn't match (light/dark)
- **Fix Needed:**
  1. Remove "Owner" column/label
  2. Fix typography (font-size, line-height)
  3. Stack columns responsively on mobile
  4. Apply dark theme styling
- **Estimate:** 90 min

---

## Quick Implementation Order

For fastest completion:
1. **BUG #6** (30 min) - Dashboards text + Looker
2. **BUG #12** (15 min) - Settings rename + lock ID
3. **BUG #10** (20 min) - Minha Conta fonts
4. **BUG #7** (20 min) - Roff dark theme
5. **BUG #8** (25 min) - Integrações page
6. **BUG #11** (30 min) - Theme toggle
7. **BUG #9** (60 min) - Users (complex)
8. **BUG #13** (90 min) - Forms (complex)

**Total Estimated Time:** ~290 min (4.8 hours)

---

## Testing Checklist for All Remaining Bugs

After implementation:
- [ ] `npm run build` - No TypeScript errors
- [ ] Local dev server runs: `npm run dev`
- [ ] All pages render correctly
- [ ] Dark mode applied consistently
- [ ] Mobile responsive (test at 375px, 768px, 1024px)
- [ ] Zoom test (100%, 150%, 200%)
- [ ] No console errors in browser
- [ ] i18n keys working (pt-BR + en-US)
- [ ] Form validation working
- [ ] API calls using correct tenant/token

---

## Notes

- All pages should use `useLanguage()` hook or next-intl
- Default theme is DARK (follow slate-900 palette)
- All text must be translated (no hardcoded English)
- Component must work mobile-first
- Accessibility: min 16px font, 1.5x line-height, WCAG contrast

