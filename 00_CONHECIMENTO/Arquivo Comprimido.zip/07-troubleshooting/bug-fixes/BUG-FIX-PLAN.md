# 🔧 DPWAI Demo Bugs - Fix Implementation Plan

**Date**: 25 January 2026
**Priority**: 🔴 CRITICAL - Demo Blocking
**Est. Time**: 3-4 hours
**Team**: Frontend + Backend

---

## 🎯 Critical Issue #1: Dashboard Counts Show Zero

### Problem
**File**: `app/dpwai/[tenant_snake]/page.tsx`
**Lines**: 32, 38, 44, 50
**Issue**: Hardcoded `0` values instead of actual data counts

```tsx
// CURRENT (WRONG):
<div className="text-3xl font-bold text-gray-900">0</div>  // Line 32
<div className="text-3xl font-bold text-gray-900">0</div>  // Line 38
<div className="text-3xl font-bold text-gray-900">0</div>  // Line 44
<div className="text-3xl font-bold text-gray-900">0</div>  // Line 50
```

### Root Cause
- Page is a static/server component
- No API calls to fetch actual counts
- Counts are hardcoded for demo/placeholder

### Solution
**Option A** (Quick Fix - 30 min): Convert to client component + fetch data
- Change `export default async function` → `'use client'` + `export default function`
- Add `useEffect` to fetch counts from API
- Show counts while loading, update when API responds

**Option B** (Better - 1 hour): Keep server-side, fetch in server component
- Use server-side data fetching
- Pass counts as props to component
- More performant, no hydration mismatch

### Recommended: Option A (Quick & Safe)

**Implementation**:
```tsx
'use client';

import { useState, useEffect } from 'react';

interface DashboardCounts {
  formas: number;
  registros: number;
  usuarios: number;
  fazendas: number;
}

export default function TenantHomePage({ params }: Props) {
  const [counts, setCounts] = useState<DashboardCounts>({
    formas: 0,
    registros: 0,
    usuarios: 0,
    fazendas: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCounts = async () => {
      try {
        const token = localStorage.getItem('accessToken');
        const tenant = params.tenant_snake;

        // Fetch forms count
        const formsRes = await fetch(`/api/agro/${tenant}/forms`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const formsData = await formsRes.json();

        // Fetch users count
        const usersRes = await fetch(`/api/agro/${tenant}/users`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const usersData = await usersRes.json();

        // TODO: Add registros and fazendas counts

        setCounts({
          formas: formsData?.length || 0,
          registros: 0, // TODO
          usuarios: usersData?.length || 0,
          fazendas: 0  // TODO
        });
      } catch (err) {
        console.error('Failed to fetch counts:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCounts();
  }, [tenantSnake]);

  return (
    // ... render counts from state instead of hardcoded 0
    <div className="text-3xl font-bold text-gray-900">{counts.formas}</div>
    // etc.
  );
}
```

### API Endpoints Needed
- `GET /api/agro/{tenant}/forms` - Returns array of forms (count via `.length`)
- `GET /api/agro/{tenant}/users` - Returns array of users (count via `.length`)
- `GET /api/agro/{tenant}/submissions` - Returns submissions (for registros count)
- Tenant endpoint for fazendas count

### Testing
After fix:
- [ ] Load page
- [ ] Verify counts are fetched (check Network tab)
- [ ] Counts should match actual data
- [ ] Switch between properties, counts should update
- [ ] Check loading state while fetching

---

## 🎯 Critical Issue #2: Dashboard Content Not Rendering

### Problem
**File**: `app/dpwai/[tenant_snake]/dashboards/[id]/page.tsx`
**Issue**: Shows placeholder "Dashboard content will be rendered here"
**Effect**: Dashboards are non-functional

### Root Cause
- Dashboard embed URL might be missing
- iframe not rendering
- API not returning embed URL

### Solution

**Step 1**: Check if dashboards have `embedUrl` in database
```bash
# Check Prisma schema
grep -A 5 "model Dashboard" prisma/schema.prisma
```

**Step 2**: Ensure dashboard records have valid URLs
```bash
# Check if dashboards have embedUrl values
# Query the database or API endpoint
```

**Step 3**: Update dashboard viewer to use embedUrl
```tsx
export default function DashboardPage() {
  const [dashboard, setDashboard] = useState(null);

  useEffect(() => {
    fetchDashboard();
  }, [id]);

  if (!dashboard?.embedUrl) {
    return (
      <div className="p-8 text-center">
        <p className="text-gray-500">
          Dashboard não tem uma URL configurada.
          <br />
          Clique em "Editar" para adicionar a URL de embed.
        </p>
      </div>
    );
  }

  return (
    <iframe
      src={dashboard.embedUrl}
      className="w-full h-screen border-0"
      title={dashboard.name}
      sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
    />
  );
}
```

### Testing
- [ ] Create new dashboard with valid embed URL (Looker, etc.)
- [ ] Open dashboard
- [ ] Verify iframe renders content
- [ ] Test with invalid URL (should show error message)

---

## 🎯 Issue #3: Property Selector Not Updating Data

### Problem
**File**: `components/PremiumWelcome.tsx`
**Issue**: Changing properties shows no difference in data
**Effect**: Multi-tenancy appears broken

### Root Cause
- Property selection stored in localStorage but not used in data fetching
- API calls don't respect selected property
- Counts/data not filtered by property

### Solution

**Step 1**: Use property context in data fetching
```tsx
const [selectedFarm, setSelectedFarm] = useState(null);

useEffect(() => {
  // When property changes, refetch all data
  if (selectedFarm) {
    refetchCounts();
  }
}, [selectedFarm]);
```

**Step 2**: Ensure all API calls use correct tenant/property
```tsx
// When fetching, use the currently selected property
const fetchData = async (propertyId: string) => {
  const res = await fetch(`/api/agro/${propertyId}/forms`);
  // ...
};
```

**Step 3**: Verify tenant context is passed correctly
- Check all components have access to current tenant
- All API endpoints should filter by tenant

### Testing
- [ ] Load page
- [ ] Select first property, note form/user counts
- [ ] Switch to second property, counts should change
- [ ] Counts should be different for each property
- [ ] Switch back to first, counts should match original

---

## 📋 Secondary Issues

### Issue #4: Bottom Navigation Missing Labels (Minor)
**File**: `components/PremiumWelcome.tsx` Line 209
**Issue**: Says "Formas" instead of "Formulários"
**Fix**: Change text to match

### Issue #5: No Loading States
**Locations**: Forms page, Users page, Dashboards
**Fix**: Add spinners while fetching

### Issue #6: Session Instability
**Cause**: JWT token expiration without refresh
**Fix**: Implement token refresh logic in auth provider

---

## 🚀 Implementation Checklist

### Priority 1 (Fix Now)
- [ ] Make home page fetch real counts (Option A, 30 min)
- [ ] Ensure dashboard has embedUrl and renders (1 hour)
- [ ] Verify property selector updates data (1 hour)

### Priority 2 (Fix Today)
- [ ] Fix button label typo (5 min)
- [ ] Add loading states (30 min)
- [ ] Test all flows end-to-end (30 min)

### Priority 3 (Fix Later)
- [ ] Implement token refresh (2 hours)
- [ ] Add error boundaries (1 hour)
- [ ] Improve UX (1 hour)

---

## 📞 Files to Modify

```
🔴 CRITICAL:
  app/dpwai/[tenant_snake]/page.tsx
  ├─ Change: Make client component
  ├─ Add: useEffect to fetch counts
  └─ Fix: Display real counts from API

  app/dpwai/[tenant_snake]/dashboards/[id]/page.tsx
  ├─ Fix: Check embedUrl exists
  ├─ Fix: Render iframe if URL exists
  └─ Fix: Show error if URL missing

  components/PremiumWelcome.tsx
  ├─ Fix: Property selector updates parent state
  └─ Fix: Typo "Formas" → "Formulários"

🟠 HIGH:
  API endpoints
  ├─ /api/agro/{tenant}/forms
  ├─ /api/agro/{tenant}/users
  ├─ /api/agro/{tenant}/submissions
  └─ /api/agro/{tenant}/dashboards
  └─ All must filter by tenant properly

  lib/auth/ or auth context
  ├─ Fix: Token refresh on expiration
  └─ Fix: Session persistence
```

---

## 💻 Quick Fix Commands

After making changes:
```bash
# Build to check for TypeScript errors
npm run build

# Run dev server and test
npm run dev

# Manual testing checklist:
# 1. Login
# 2. Check home page counts (should not be 0)
# 3. Switch properties
# 4. Counts should change for each property
# 5. Open dashboard
# 6. Should see rendered content (not placeholder)
# 7. Click property selector
# 8. Data should update
```

---

## ⏱️ Time Estimate

| Task | Estimated Time | Actual |
|------|-----------------|--------|
| Fix home page counts | 30 min | __ |
| Fix dashboard rendering | 1 hour | __ |
| Fix property data filtering | 1 hour | __ |
| Minor fixes (labels, etc) | 30 min | __ |
| Testing & verification | 30 min | __ |
| **TOTAL** | **3-4 hours** | __ |

---

## 🧪 Acceptance Criteria

Demo will be considered FIXED when:
- ✅ Home page shows real counts (not zeros)
- ✅ Dashboards render embedded content
- ✅ Switching properties updates all data
- ✅ No placeholder text visible
- ✅ All navigation works correctly
- ✅ No console errors
- ✅ No broken images/styles

---

**Status**: 🔴 READY FOR IMPLEMENTATION
**Owner**: Frontend Developer
**Target**: Before next demo
**Review**: @DevTeam

