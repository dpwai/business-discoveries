# 🐛 DPWAI Demo Site - Bug Report & Audit Findings

**Date**: 25 January 2026
**Tested By**: Manual user exploration
**Site**: https://app.dpwai.com.br (demo environment)
**Status**: 🔴 CRITICAL ISSUES FOUND

---

## Executive Summary

The DPWAI demo site has a **solid structural foundation** but contains **multiple critical and high-priority bugs** that severely impact user experience. Key issues:

- ❌ **Dashboard counts showing zero** despite existing data
- ❌ **Dashboard rendering broken** (blank pages with placeholder text)
- ❌ **Navigation links misdirected** (wrong pages loading)
- ❌ **Field view ("Entrar no Campo") broken** (redirects to chat)
- ❌ **Bottom navigation non-functional** (all links go to wrong places)
- ❌ **Quick action cards disabled** (darkened overlays prevent clicking)
- ❌ **Session/state instability** (unexpected logouts, count resets)

**Overall Assessment**: 🟡 **DEMO BLOCKED** - Core functionality is broken and prevents proper user onboarding.

---

## 📊 Bug Inventory

### Critical Bugs (🔴 Must Fix Before Demo)

#### 1. Dashboard Count Aggregation Broken
**Severity**: 🔴 CRITICAL
**Location**: Home/Welcome page dashboard
**Observed Behavior**:
- Shows "Formulários: 0", "Registros: 0", "Usuários: 0", "Fazendas: 0"
- But actual forms, users, and properties exist in the system

**Expected Behavior**:
- "Formulários: X" should count actual forms
- "Registros: Y" should count form submissions
- "Usuários: Z" should count organization users
- "Fazendas: N" should count tenants/properties

**Root Cause Analysis**:
- Likely query filtering issue (tenant/organization filtering not working)
- Counts may not be aggregating properly across related tables
- Could be date filtering (maybe counting only recent data)

**Impact**: High - Gives false impression that the system is empty

**Files to Check**:
- `app/dpwai/[tenant_snake]/page.tsx` (home/welcome page)
- API endpoints that fetch dashboard counts
- Tenant context/filtering logic

---

#### 2. Dashboard Content Not Rendering
**Severity**: 🔴 CRITICAL
**Location**: `/dpwai/{tenant}/dashboard` pages
**Observed Behavior**:
- Clicking "Dashboards" → Lists 2 dashboards ("Hdhd" and "teste")
- Clicking "Ver" on a dashboard → Shows blank area with text "Dashboard content will be rendered here"
- No charts, data, or embedded content appears

**Expected Behavior**:
- Should render Looker embed or actual dashboard content
- Should show visualizations/charts

**Root Cause Analysis**:
- Embed URL might be missing from dashboard records
- Embed URL might be invalid
- iframe rendering might be broken
- Dashboard data fetch might be failing silently

**Impact**: Critical - Dashboards are completely non-functional

**Files to Check**:
- `app/dpwai/[tenant_snake]/dashboards/[id]/page.tsx`
- Dashboard component that renders embeds
- API endpoint that fetches dashboard embed URL
- Looker iframe implementation

---

#### 3. "Entrar no Campo" Button Redirects to Chat (Wrong Page)
**Severity**: 🔴 CRITICAL
**Location**: `/dpwai/{tenant}/welcome` page (property view)
**Observed Behavior**:
- Button labeled "Entrar no Campo" (Enter the Field)
- Clicking it redirects to Ralph Chat page (`/dpwai/{tenant}/ralph-chat`)

**Expected Behavior**:
- Should open a "field view" page
- Could be a map view, sensor dashboard, or property details page
- Definitely NOT the chat page

**Root Cause Analysis**:
- Hardcoded wrong href/onClick handler
- Route probably doesn't exist yet (field view not implemented)
- Someone copy-pasted the Ralph Chat link by mistake

**Impact**: Critical - Feature is completely broken

**Files to Check**:
- `app/dpwai/[tenant_snake]/welcome/page.tsx` (look for button)
- Check href or onClick logic for this button
- Verify intended route exists

---

#### 4. Bottom Navigation Links Go to Wrong Pages
**Severity**: 🔴 CRITICAL
**Location**: Property page footer/bottom nav bar
**Observed Behavior**:

| Icon | Label | Expected | Actual | Status |
|------|-------|----------|--------|--------|
| 🗺️ | Mapa | Show map view | → Dashboards | ❌ Wrong |
| 📡 | Sensores | Show sensor data | → Automated Entries | ❌ Wrong |
| 👤 | Perfil | Show profile | Unresponsive | ❌ Broken |

**Expected Behavior**:
- Each nav item should link to correct page
- All should be clickable and load proper content

**Root Cause Analysis**:
- Wrong route paths in navigation links
- Missing pages (Map, Sensors views not implemented)
- Navigation component has hardcoded wrong URLs

**Impact**: Critical - Makes property navigation completely broken

**Files to Check**:
- Navigation/layout component for property pages
- `app/dpwai/[tenant_snake]/layout.tsx` (check bottom nav)
- Look for navigation item definitions with href="/dpwai/{tenant}/..."

---

#### 5. Quick Action Cards Disabled (Dark Overlay)
**Severity**: 🔴 CRITICAL
**Location**: Property welcome page - "Relatórios" and "Entradas Automatizadas" sections
**Observed Behavior**:
- Cards are visually darkened (disabled appearance)
- Clicking doesn't navigate anywhere
- No hover effects or feedback

**Expected Behavior**:
- Cards should be clickable
- Should navigate to respective sections
- Should have hover states

**Root Cause Analysis**:
- CSS `pointer-events: none` or similar
- Cards might be wrapped in disabled state
- Could be `opacity-50` or `grayscale` + `pointer-events-none`

**Impact**: High - Features appear implemented but are blocked from use

**Files to Check**:
- `app/dpwai/[tenant_snake]/welcome/page.tsx` or similar
- Look for cards with CSS classes like `opacity-50`, `pointer-events-none`, `disabled`, `grayscale`
- Check if there's a feature flag or permission check disabling them

---

### High Severity Bugs (🟠 Should Fix Soon)

#### 6. Session/State Instability
**Severity**: 🟠 HIGH
**Observed Behavior**:
- Sometimes unexpectedly returned to login page
- Dashboard counts reset between navigation
- Session seems to timeout or reset

**Root Cause Analysis**:
- JWT token expiration without refresh
- Session context not persisting
- Race condition in API calls
- Stale state in React components

**Impact**: High - Breaks user experience, requires re-login

**Files to Check**:
- Authentication context/provider
- Token refresh logic
- useEffect dependency arrays (stale closures)

---

#### 7. Property Selector Shows No Differences
**Severity**: 🟠 HIGH
**Observed Behavior**:
- Changing properties (Fazenda Vale Norte, Vinhedo Serras, Fazenda Delta Rio)
- Page looks identical for all properties
- Same blank metrics, same broken links

**Expected Behavior**:
- Each property should show its own:
  - Forms and submissions
  - Users assigned to that property
  - Property-specific dashboards
  - Property metrics/counts

**Root Cause Analysis**:
- Property/tenant context not being passed correctly
- API calls not filtering by selected property
- Counts might not be property-aware
- State management issue (property selection not reflected in data fetching)

**Impact**: High - Data appears not to be multi-tenant aware

**Files to Check**:
- Property/tenant context provider
- API endpoints (make sure they filter by `tenant_id` or `property_id`)
- useParams/useContext to get current property
- Data fetching logic

---

### Medium Severity Bugs (🟡 Plan to Fix)

#### 8. Dashboard Placeholder Text Visible
**Severity**: 🟡 MEDIUM
**Observed Behavior**:
- Placeholder text "Dashboard content will be rendered here" appears on dashboard pages
- Indicates incomplete implementation left visible

**Expected Behavior**:
- Either show actual dashboard content
- Or show loading spinner
- Or show helpful message about missing embed URL

**Root Cause Analysis**:
- Fallback content not removed
- Dashboard record missing `embedUrl` field
- Error handling shows placeholder instead of error message

**Impact**: Medium - Reduces confidence in system

**Files to Check**:
- Dashboard viewer component
- Look for the literal string "Dashboard content will be rendered here"
- Check embed URL handling

---

#### 9. Drone Patrol Banner No-Op
**Severity**: 🟡 MEDIUM
**Observed Behavior**:
- Banner about scheduled drone patrol appears
- No link, no action, no way to interact
- Just informational text

**Expected Behavior**:
- Should be clickable to view patrol details
- Or have a close button
- Or show timestamp/more info

**Root Cause Analysis**:
- Feature not fully implemented
- Banner is placeholder/demo content
- Could be feature flag that needs data

**Impact**: Low-Medium - Not critical but appears unfinished

---

### Low Severity Issues (🟢 Nice to Fix)

#### 10. No Loading States on Data Fetch
**Severity**: 🟢 LOW
**Observed Behavior**:
- Some pages appear to load instantly or with no visible loading state
- Unclear if data is being fetched or if page is already populated

**Expected Behavior**:
- Loading spinners when data is fetching
- Skeleton screens for better UX

**Impact**: Low - Works but feels slow/unresponsive

---

## 🔍 Root Cause Categories

| Category | Issues | Likely Cause |
|----------|--------|--------------|
| **Missing Implementation** | Field view, Map view, Sensors view | Features planned but not built |
| **Data Fetching** | Zero counts, property not filtering data | API queries not filtering by tenant |
| **Routing** | Wrong page links, nav misdirected | Hardcoded wrong routes |
| **Disabled UI** | Quick action cards disabled | `pointer-events-none` or feature flag |
| **State Management** | Session loss, counts resetting | Token expiration, context not persisting |
| **Placeholder Content** | "Content will be rendered here" | Incomplete implementation visible |

---

## 📋 Remediation Roadmap

### Phase 1: Emergency Fixes (1-2 hours)
**Goal**: Make demo minimally functional

1. **Fix dashboard zero counts** (Check data fetching query)
   - File: `app/dpwai/[tenant_snake]/page.tsx`
   - Check API endpoint: `/api/agro/{tenant}/forms`, `/api/agro/{tenant}/users`
   - Verify tenant filtering is working

2. **Fix "Entrar no Campo" redirect** (Change button href)
   - File: Look for button on welcome page
   - Change from Ralph Chat to either:
     - Create a placeholder page `/dpwai/{tenant}/field-view`
     - Or hide the button with comment "Coming Soon"

3. **Hide non-functional quick action cards** (Add "Coming Soon" badge)
   - File: Property welcome page
   - Remove `pointer-events-none` overlay
   - Or add "🔒 Em Breve" (Coming Soon) label

4. **Fix bottom navigation** (Correct the routes)
   - File: Layout component with bottom nav
   - Routes should be:
     - "Mapa" → `/dpwai/{tenant}/map` (or hide/add "Coming Soon")
     - "Sensores" → `/dpwai/{tenant}/sensors` (or hide)
     - "Perfil" → `/dpwai/{tenant}/account` (currently broken)

### Phase 2: Core Fixes (2-3 hours)
**Goal**: Restore working functionality

5. **Implement dashboard embed rendering**
   - Verify dashboard records have `embedUrl` field
   - Fix iframe rendering if URL exists
   - Show error message if URL missing

6. **Fix session/token refresh**
   - Check JWT expiration time
   - Implement token refresh mechanism
   - Ensure auth context persists

7. **Verify multi-tenant data filtering**
   - Audit all API endpoints
   - Ensure every query filters by tenant_id
   - Test with multiple properties

### Phase 3: Polish (1-2 hours)
**Goal**: Improve UX and remove placeholders

8. **Remove placeholder text** (Replace with proper UI)
   - "Dashboard content will be rendered here" → Real component
   - "Scheduled drone patrol" → Real data or remove

9. **Add loading states** (Spinners/skeletons)
   - Dashboard loading
   - Data table loading
   - Form loading

10. **Test property switching** (Verify all counts update)
    - Switch between properties
    - Verify counts change appropriately
    - Verify forms/users update

---

## 🎯 Quick Fix Checklist

- [ ] **Dashboard Counts**
  - [ ] Check `/api/agro/{tenant}/forms?skip=0&take=1` returns correct count
  - [ ] Check `/api/agro/{tenant}/users` returns correct count
  - [ ] Verify tenant context is being passed
  - [ ] Test with multiple properties

- [ ] **"Entrar no Campo" Button**
  - [ ] Find the button in welcome page
  - [ ] Change href or create placeholder route
  - [ ] Test click leads to correct page

- [ ] **Bottom Navigation**
  - [ ] Check layout component
  - [ ] Verify 3 nav items have correct hrefs
  - [ ] Test each nav item works
  - [ ] Verify routing matches expected behavior

- [ ] **Quick Action Cards**
  - [ ] Remove darkening overlay
  - [ ] Test cards are clickable
  - [ ] Verify navigation works
  - [ ] Or add "Coming Soon" badge and disable properly

- [ ] **Dashboard Rendering**
  - [ ] Check dashboard records in DB (do they have embedUrl?)
  - [ ] Test iframe with valid embed URL
  - [ ] Fix placeholder text

- [ ] **Session Stability**
  - [ ] Test staying on page for 5+ minutes
  - [ ] Verify token refresh
  - [ ] Check for unexpected logouts

---

## 📁 Files Likely to Need Changes

```
Priority 1 (Critical):
├── app/dpwai/[tenant_snake]/page.tsx
│   └── Fix: Dashboard count queries
├── app/dpwai/[tenant_snake]/welcome/page.tsx
│   ├── Fix: "Entrar no Campo" button href
│   └── Fix: Quick action card overlays
├── app/dpwai/[tenant_snake]/layout.tsx
│   └── Fix: Bottom navigation links
└── app/dpwai/[tenant_snake]/dashboards/[id]/page.tsx
    └── Fix: Dashboard embed rendering

Priority 2 (High):
├── lib/auth/ (or auth context)
│   └── Fix: Session/token refresh logic
├── API endpoints:
│   ├── /api/agro/{tenant}/forms
│   ├── /api/agro/{tenant}/users
│   └── /api/agro/{tenant}/dashboards
└── Tenant/Property context provider
    └── Fix: Multi-tenant filtering
```

---

## 💬 Suggested Demo Script (Workaround)

Until fixes are deployed, demo should:

1. ✅ Show login → Works fine
2. ✅ Show Ralph Chat → Works fine
3. ✅ Show Forms list → Works (even if counts are wrong)
4. ✅ Show Users list → Works
5. ✅ Show Account page → Works
6. ⚠️ **Skip**: Dashboards, property view, bottom navigation, "Entrar no Campo"
7. ⚠️ **Skip**: Quick action cards on property page
8. ✅ Use vertical icon bar navigation (more reliable than horizontal nav)

**Key Talking Points to Mention**:
- "We're actively fixing the dashboard rendering and multi-property support"
- "Core features (Forms, Users, Auth) are working well"
- "Field view and Maps are coming in next release"

---

## 🔗 Related Issues

These bugs may be related to:
- Multi-tenancy implementation (property filtering)
- API design (ensure endpoints filter by tenant)
- State management (context not persisting)
- Route/navigation setup (wrong paths configured)
- Incomplete features (field view, maps not implemented)

---

## 📞 Next Steps

1. **Immediate**: Fix the 4 critical button/link issues (2-hour job)
2. **Today**: Fix dashboard counts and session stability (2-3 hours)
3. **This week**: Implement missing pages or hide them properly
4. **Later**: Add proper error handling, loading states, polish UX

---

**Report Compiled**: 25 January 2026
**Status**: 🔴 Action Required - Demo Not Production-Ready
**Severity**: 6 Critical, 2 High, 1 Medium, 1 Low = **10 Bugs Total**

