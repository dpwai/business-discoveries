# DPWAI App - Audit & Comprehensive Fixes

**Status:** IN PROGRESS
**Date:** 2026-01-25
**Auditor:** Claude Code (Senior Full-Stack + QA)

---

## 13 Critical Bugs - Execution Plan

### 🔴 BUG #1: Forgot Password doesn't send email (Resend)
- **Status:** 🔧 IN PROGRESS
- **Root Cause:** Errors silently caught, no user feedback, no detailed logging
- **Files to Fix:**
  - [ ] `/lib/email/resend.ts` - Add better error handling + logging
  - [ ] `/app/api/auth/forgot-password/route.ts` - Return error to client, log request ID
  - [ ] Add request ID tracing for debugging
- **Acceptance Criteria:**
  - Email is sent when valid user requests reset
  - Resend logs show "sent" status
  - If error: user sees clear message, server logs have details
  - Works in dev and production

### 🔴 BUG #2: Layout - Duplicate hamburger icons & logo misaligned
- **Status:** ⏳ PENDING
- **Root Cause:** TBD - need to check header components
- **Files to Fix:**
  - [ ] Identify duplicate components
  - [ ] Consolidate header
  - [ ] Fix logo alignment
- **Acceptance Criteria:**
  - Only 1 hamburger icon visible
  - Header aligned correctly
  - Works on mobile + desktop

### 🔴 BUG #3: Tenant/Farm switch - changes frontend but not backend
- **Status:** ⏳ PENDING
- **Root Cause:** TBD - check tenant context + API calls
- **Files to Fix:**
  - [ ] Verify tenant context updates all API calls
  - [ ] Check interceptors/fetch wrappers
  - [ ] Confirm backend validates tenant in requests
- **Acceptance Criteria:**
  - Switching farm updates context AND backend data
  - API calls include correct tenantId
  - Dashboard/data changes immediately

### 🟡 BUG #4: Footer - "Tenant Demo Farm" text + deprecated routes
- **Status:** ⏳ PENDING
- **Root Cause:** Footer showing tenant name + bad links
- **Files to Fix:**
  - [ ] Remove tenant name from footer
  - [ ] Fix/remove deprecated routes
  - [ ] Evaluate footer necessity

### 🟡 BUG #5: Welcome page - "Visão do campo" goes to wrong place
- **Status:** ⏳ PENDING
- **Root Cause:** Navigation routing issue
- **Files to Fix:**
  - [ ] Fix welcome page buttons
  - [ ] Correct routes to Chat vs Dashboards

### 🟡 BUG #6: Dashboards - "New Dashboard" English text + missing Looker
- **Status:** ⏳ PENDING
- **Root Cause:** Hardcoded English + incomplete Looker integration
- **Files to Fix:**
  - [ ] Translate "New Dashboard" to Portuguese
  - [ ] Implement Looker embed functionality

### 🟡 BUG #7: Roff (Chat) - white theme instead of dark
- **Status:** ⏳ PENDING
- **Root Cause:** Component not inheriting theme
- **Files to Fix:**
  - [ ] Check Roff component styling
  - [ ] Ensure theme context is applied

### 🟡 BUG #8: "Minhas entradas automatizadas" → "Integrações" (white + English)
- **Status:** ⏳ PENDING
- **Root Cause:** Page not themed, text not translated
- **Files to Fix:**
  - [ ] Rename page/menu item
  - [ ] Fix styling + theme
  - [ ] Translate all text

### 🟡 BUG #9: Users - missing roles, modal won't close, bad responsive + zoom breaks menu
- **Status:** ⏳ PENDING
- **Root Cause:** Incomplete role system + modal issues + layout problems
- **Files to Fix:**
  - [ ] Define roles in backend
  - [ ] Fix modal close behavior
  - [ ] Refactor responsive layout
  - [ ] Fix header overflow with zoom

### 🟡 BUG #10: Minha Conta - fonts are hard to read
- **Status:** ⏳ PENDING
- **Root Cause:** Typography scaling issues
- **Files to Fix:**
  - [ ] Adjust font sizes + line heights
  - [ ] Fix spacing
  - [ ] Ensure accessibility (contrast, minimums)

### 🟡 BUG #11: Theme toggle dark/light - doesn't work in footer
- **Status:** ⏳ PENDING
- **Root Cause:** Theme toggle not implemented or broken
- **Files to Fix:**
  - [ ] Implement/fix theme toggle
  - [ ] Ensure persistence (localStorage)
  - [ ] Test all pages respect theme

### 🟡 BUG #12: "Configurações" → "Minha organização" (rename, lock ID, show org switcher)
- **Status:** ⏳ PENDING
- **Root Cause:** Page not properly configured
- **Files to Fix:**
  - [ ] Rename page title
  - [ ] Disable org ID field
  - [ ] Allow display name edit
  - [ ] Add org switcher

### 🟡 BUG #13: Forms - "Owner" label wrong, font horrible, UX broken
- **Status:** ⏳ PENDING
- **Root Cause:** Styling + UX issues in form builder
- **Files to Fix:**
  - [ ] Remove "Owner" label
  - [ ] Fix typography
  - [ ] Make builder usable
  - [ ] Fix theme

---

## Files Modified (in order)

1. `/lib/email/resend.ts` - Enhanced email error handling
2. `/app/api/auth/forgot-password/route.ts` - Better error response + logging
3. [More files will be added as fixes progress]

---

## Testing Checklist

### Local Testing
- [ ] npm run dev works
- [ ] Build succeeds: npm run build
- [ ] No TypeScript errors

### Feature Testing
- [ ] Bug #1: Forgot password email sent + visible in Resend logs
- [ ] Bug #2: Only 1 hamburger icon, aligned header
- [ ] Bug #3: Tenant switch changes backend data
- [ ] [etc...]

### Production (Vercel)
- [ ] All fixes deployed
- [ ] No regressions
- [ ] Email working in prod
- [ ] Theme persists
- [ ] Routes not deprecated

---

## Notes
- Using request IDs for tracing
- Adding detailed server logs for debugging
- Maintaining i18n consistency (pt-BR primary)
- Dark mode is default (respect light mode as well)
- Mobile-first responsive design

