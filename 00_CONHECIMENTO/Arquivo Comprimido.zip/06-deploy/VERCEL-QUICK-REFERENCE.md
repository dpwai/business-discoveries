# ⚡ Vercel Setup - Rápido

**5 variáveis. Pronto.**

---

## 1. Cria um banco PostgreSQL grátis

→ [neon.tech](https://console.neon.tech) (2 min)

Copia a connection string (com `sslmode=require`)

---

## 2. Cria API key Resend (email)

→ [resend.com/api-keys](https://resend.com/api-keys) (2 min)

Clica Create API Key, copia

---

## 3. Gera JWT Secret seguro

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copia o resultado

---

## 4. Na Vercel, vai em Settings → Environment Variables

Adiciona essas 5:

```
DATABASE_URL = postgresql://neondb_owner:npg_XXXXX@...
JWT_SECRET = a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z
NEXT_PUBLIC_APP_URL = https://app.dpwai.com.br
RESEND_API_KEY = re_xxxxxxxxxxxxx
EMAIL_FROM = DPWAI Agro <noreply@dpwai.com.br>
```

---

## 5. Faz redeploy

Na Vercel → Deployments → ...  → Redeploy

Pronto! 🎉

---

**Detalhes?** Ver `VERCEL_SETUP.md`
