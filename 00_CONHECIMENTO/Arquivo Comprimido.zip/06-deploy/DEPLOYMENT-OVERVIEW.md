# 🚀 DPWAI Deployment Guide

## Configuração do Domínio (dpwai.com.br → app.dpwai.com.br)

### 1. Configurar Domínio na Vercel

1. **Acesse o dashboard da Vercel:**
   - Vá para [vercel.com](https://vercel.com)
   - Clique no projeto `dpwai-app2`
   - Abra a aba **Settings** → **Domains**

2. **Adicione seu subdomínio:**
   - Clique em **Add Domain**
   - Digite `app.dpwai.com.br`
   - Clique em **Add**

3. **Configure DNS (você vai ver as instruções da Vercel):**
   - Vá pro seu registrador de domínio (onde comprou dpwai.com.br)
   - Adicione um record **CNAME**:
     ```
     Type: CNAME
     Name: app
     Value: cname.vercel-dns.com.
     ```
   - Salve as alterações
   - Espere 5-15 minutos para propagar

### 2. Configure Environment Variables na Vercel

Na aba **Settings** → **Environment Variables**, adicione:

```
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret-key
NEXT_PUBLIC_APP_URL=https://app.dpwai.com.br
RESEND_API_KEY=your-resend-key
EMAIL_FROM=DPWAI <noreply@dpwai.com.br>
```

### 3. Manter Landing Page em dpwai.com.br

Você pode:

**Opção A: Criar um projeto separado na Vercel**
- Crie um novo projeto Next.js/outro para a landing
- Deploy em `https://dpwai.com.br`
- A app fica em `https://app.dpwai.com.br`

**Opção B: Adicionar landing como rota**
- Adicione uma página `/` com landing
- Quando usuário autenticado, redireciona pra `/dpwai`
- Isso já tá parcialmente implementado (veja `app/page.tsx`)

### 4. Configurar Branch Protection (GitHub)

1. Vá em **Settings** → **Branches**
2. Clique em **Add rule** para `main`
3. Ative:
   - ✅ Require a pull request before merging
   - ✅ Require status checks to pass before merging
   - ✅ Require branches to be up to date before merging

### 5. Secrets do GitHub Actions (para CI/CD)

Vá em **Settings** → **Secrets and variables** → **Actions** e adicione:

```
VERCEL_TOKEN=<your-vercel-token>
VERCEL_ORG_ID=<your-org-id>
VERCEL_PROJECT_ID=<your-project-id>
```

Onde conseguir:
- `VERCEL_TOKEN`: [vercel.com/account/tokens](https://vercel.com/account/tokens)
- `VERCEL_ORG_ID`: No dashboard, Settings → General (Team ID)
- `VERCEL_PROJECT_ID`: No projeto, Settings → General (Project ID)

---

## 🔍 Checklist Pré-Deploy

- [ ] Build passa localmente: `npm run build`
- [ ] Não há console errors
- [ ] Environment variables configuradas na Vercel
- [ ] Domínio CNAME apontando pra Vercel
- [ ] GitHub secrets configurados
- [ ] Branch protection ativa
- [ ] Vercel preview deploy funciona (PR aberto)

---

## 📊 Fluxo de Deploy

```
git push main
     ↓
GitHub Actions triggered
     ↓
npm ci (install)
npm run lint
npm run typecheck
npm run test
npm run build ✅ (critical)
     ↓
Build passes? → Vercel Production Deploy
     ↓
Auto-deploy to: app.dpwai.com.br
```

---

## 🐛 Troubleshooting

### Build falha na Vercel
- Verifique `NEXT_PUBLIC_APP_URL`
- Rode localmente: `npm run build`
- Check logs: Vercel Dashboard → Deployments

### Domínio não resolve
- Espere 15-30 min para DNS propagar
- Teste com: `nslookup app.dpwai.com.br`
- Verifique CNAME no registrador

### GitHub Actions falha
- Verifique secrets estão corretos
- Rode localmente: `npm ci --only=production && npm run build`
- Check GitHub Actions logs

---

## 📝 Próximos Passos

1. Configure domínio seguindo seções 1-2 acima
2. Aguarde DNS propagar (10-15 min)
3. Teste: `https://app.dpwai.com.br`
4. Pronto! 🎉
