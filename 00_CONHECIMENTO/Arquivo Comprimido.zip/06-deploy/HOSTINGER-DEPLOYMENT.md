# 🎯 Como Configurar Domínio na Hostinger (Passo-a-Passo)

## Seu Domínio: `dpwai.app.com.br` ou `app.dpwai.com.br`?

**Recomendo:** `app.dpwai.com.br` (mais profissional)

---

## PASSO 1: Ir pra Hostinger

1. Acesse: [hostinger.com.br](https://hostinger.com.br)
2. Login com sua conta
3. Clique em **Meus Domínios** (ou "My Domains")

---

## PASSO 2: Verificar/Comprar o Domínio

### Se já tem `dpwai.com.br`:
✅ Já tá bom! Você vai só criar um **subdomínio** (`app`)

### Se NÃO tem `dpwai.com.br`:
1. Na Hostinger, clique em **Registrar Domínio**
2. Digita `dpwai.com.br` na busca
3. Seleciona o plano (geralmente R$ 20-40/ano)
4. Completa a compra
5. Aguarda confirmação por email

---

## PASSO 3: Configurar DNS para `app.dpwai.com.br`

### Se você tem `dpwai.com.br` na Hostinger:

1. **Clique no domínio** `dpwai.com.br`
2. Procure por **DNS** ou **Gerenciar DNS** ou **Advanced**
3. Procure por **Adicionar Registro** ou **Add Record**
4. Adicione um registro **CNAME**:

```
Type: CNAME
Name: app          (só digita "app", não o domínio inteiro)
Value: cname.vercel-dns.com.
TTL: 3600          (deixa default)
```

**Clica em Salvar/Save**

✅ **PRONTO!** Agora `app.dpwai.com.br` aponta pra Vercel

---

## PASSO 4: Confirmar na Vercel

1. Vai pro [Vercel Dashboard](https://vercel.com)
2. Clica no projeto `dpwai-app2`
3. **Settings** → **Domains**
4. Clica **Add Domain**
5. Digita `app.dpwai.com.br`
6. **Add**
7. Aguarda validação (geralmente 5-15 min)

---

## ⏳ Esperar DNS Propagar

Depois que você adiciona o CNAME na Hostinger:
- ⏱️ 5-15 minutos = Propagação mais rápida
- ⏱️ Até 48h = Propagação completa em todos os servidores

**Enquanto espera:**
- Você já consegue acessar via link temporário da Vercel
- `dpwai-app2-xxx.vercel.app`

---

## ✅ Verificar se Funcionou

Depois de 15 min, testa:

### No Terminal:
```bash
nslookup app.dpwai.com.br
```

Deve retornar algo como:
```
app.dpwai.com.br canonical name = cname.vercel-dns.com.
```

### No Browser:
Acessa: `https://app.dpwai.com.br`

Se carregar a app = **SUCESSO!** 🎉

---

## 🚨 Se Não Funcionar

### 1️⃣ Verifica se o CNAME tá correto:
```bash
nslookup app.dpwai.com.br
```

### 2️⃣ Se aparecer erro, volte na Hostinger e:
- Edita o record CNAME
- Verifica se digitou `cname.vercel-dns.com.` **com o ponto no final**
- Salva e espera mais 15 min

### 3️⃣ Se ainda não funcionar:
- Limpa cache do navegador: **Ctrl+Shift+Delete** (ou **Cmd+Shift+Delete**)
- Testa em navegador anônimo
- Espera mais tempo (DNS pode demorar)

---

## 📊 Resumo Visual

```
┌─────────────────────┐
│   Hostinger.com.br  │
│  dpwai.com.br       │
│  └─ app (CNAME)     │
│     → cname.vercel-dns.com.
└────────────────────┬┘
                     │ (aponta pra)
                     ↓
             ┌───────────────┐
             │  Vercel       │
             │  Projeto App  │
             │  dpwai-app2   │
             └───────────────┘
                     │
                     ↓
            https://app.dpwai.com.br ✅
```

---

## 🎯 Quick Checklist

- [ ] Login na Hostinger
- [ ] Aberto meus domínios
- [ ] Selecionei `dpwai.com.br`
- [ ] Cliquei em DNS/Gerenciar DNS
- [ ] Adicionei record CNAME:
  - [ ] Type: CNAME
  - [ ] Name: app
  - [ ] Value: cname.vercel-dns.com.
- [ ] Salvei
- [ ] Fui na Vercel e adicionei domínio
- [ ] Esperei 15 min
- [ ] Testei no browser ✅

---

## 💬 Exemplo Real (copiando da tela):

**Na Hostinger:**
```
┌─────────────────────────────────────┐
│ Adicionar Registro DNS              │
├─────────────────────────────────────┤
│ Type: [CNAME ▼]                     │
│ Name: [app              ]           │
│ Value: [cname.vercel-dns.com.      ]│
│ TTL: [3600           ]              │
│                                     │
│ [SALVAR]                            │
└─────────────────────────────────────┘
```

Depois:
```
✅ app    CNAME    cname.vercel-dns.com.    3600
```

**Pronto!** 🎉

---

## 📞 Dúvidas Comuns

**P: E se eu quiser `dpwai.app.com.br` em vez de `app.dpwai.com.br`?**
R: Você teria que comprar `app.com.br` (domínio separado) e fazer o mesmo. Recomendo `app.dpwai.com.br` por ser mais profissional.

**P: Quanto custa?**
R: Geralmente R$ 20-40/ano o domínio. Vercel é grátis.

**P: Precisa renovar?**
R: Sim, todo ano. Hostinger avisa por email.

---

**É isso! Qualquer dúvida, chama!** 🚀
