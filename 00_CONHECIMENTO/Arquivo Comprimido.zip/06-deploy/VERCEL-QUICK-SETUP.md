# ⚡ VERCEL - TUDO PRONTO PRA COPIAR/COLAR

Sem conversinha. Tudo mastigado e pronto.

---

## 🎯 PASSO 1: Copiar e Rodar no Terminal

Cole isso no terminal pra gerar JWT_SECRET seguro:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

**Resultado será algo assim:**
```
a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z
```

**GUARDA ESSE RESULTADO! Vai usar em breve.**

---

## 🎯 PASSO 2: Criar Banco PostgreSQL Grátis

1. Acesse: **https://console.neon.tech**
2. Login com GitHub
3. Clique **"Create a project"**
4. Deixa padrão, clica **"Create"**
5. Quando terminar, vai pra **"Connection string"**
6. Copia a string que aparece (tem `sslmode=require` no final)

**Vai parecer assim:**
```
postgresql://neondb_owner:npg_EfXot4WI9Kxi@ep-silent-band-ahgf7iuq-pooler.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require
```

**GUARDA ESSA STRING! Vai usar em breve.**

---

## 🎯 PASSO 3: Criar API Key Resend

1. Acesse: **https://resend.com/api-keys**
2. Login (cria conta se não tiver)
3. Clique **"Create API Key"**
4. Dá um nome tipo "dpwai"
5. Clica **"Create"**
6. Copia a chave que aparece

**Vai parecer assim:**
```
re_AUDeD4x6_EvQkUYcYGXXEG2wLW8MzsJyF
```

**GUARDA ESSA CHAVE! Vai usar agora.**

---

## 🎯 PASSO 4: Adicionar na Vercel

**Vai em:** https://vercel.com → Clica projeto "dpwai-app2" → Settings

**Depois clica em:** Environment Variables (lado esquerdo)

**Vai aparecer "Add New". Clica 5 vezes e adiciona essas:**

### Variável 1: DATABASE_URL
```
Variável: DATABASE_URL
Valor: postgresql://neondb_owner:npg_EfXot4WI9Kxi@ep-silent-band-ahgf7iuq-pooler.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require
Environments: ✓ Production  ✓ Preview  ✓ Development
Clica: Save
```

### Variável 2: JWT_SECRET
```
Variável: JWT_SECRET
Valor: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z
Environments: ✓ Production  ✓ Preview  ✓ Development
Clica: Save
```

### Variável 3: NEXT_PUBLIC_APP_URL
```
Variável: NEXT_PUBLIC_APP_URL
Valor: https://app.dpwai.com.br
Environments: ✓ Production  ✓ Preview  ✓ Development
Clica: Save
```

### Variável 4: RESEND_API_KEY
```
Variável: RESEND_API_KEY
Valor: re_AUDeD4x6_EvQkUYcYGXXEG2wLW8MzsJyF
Environments: ✓ Production  ✓ Preview  ✓ Development
Clica: Save
```

### Variável 5: EMAIL_FROM
```
Variável: EMAIL_FROM
Valor: DPWAI Agro <noreply@dpwai.com.br>
Environments: ✓ Production  ✓ Preview  ✓ Development
Clica: Save
```

---

## 🎯 PASSO 5: Redeploy

1. Na Vercel, clica aba **"Deployments"** (topo)
2. Clica os **3 pontinhos (...)** do deploy mais recente
3. Clica **"Redeploy"**
4. Aguarda ficar verde (2-3 min)

---

## ✅ Checklist Final

- [ ] Rodei o comando do JWT_SECRET no terminal
- [ ] Guardei o resultado
- [ ] Criei conta Neon.tech e banco PostgreSQL
- [ ] Copiei a connection string do Neon
- [ ] Criei API key no Resend.com
- [ ] Adicionei 5 variáveis na Vercel
- [ ] Selecionei todos 3 environments pra cada
- [ ] Fiz redeploy
- [ ] Build ficou verde

---

## 🧪 Testar se Funcionou

### Teste 1: Login
1. Acesse: **https://app.dpwai.com.br/login** (ou temp URL se domínio não resolveu ainda)
2. Digita email + senha
3. Se entrar = ✅

### Teste 2: Password Reset (Email)
1. Acesse: **https://app.dpwai.com.br/forgot-password**
2. Digita um email
3. Clica "Reset Password"
4. Vai chegar email em ~10 segundos
5. Se chegou = ✅

### Teste 3: Banco
1. Se testes 1 e 2 funcionaram = banco tá ok ✅

---

## 🚀 Pronto!

Se todos os testes passaram, parabéns! Sua app está 100% viva em produção! 🎉

---

## ⚠️ Copiou Tudo Errado? Aqui Tá os Valores Certos

### Neon.tech
- URL: https://console.neon.tech
- Cria projeto PostgreSQL
- Pega a connection string (tem `sslmode=require`)

### Resend
- URL: https://resend.com/api-keys
- Cria account
- Gera API key (começa com `re_`)

### Terminal JWT
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
- Copia resultado inteiro (64 caracteres hexadecimais)

### Vercel
- Projeto: dpwai-app2
- Settings → Environment Variables
- Add New 5 vezes
- Seleciona Production, Preview, Development
- Save cada uma

---

## 🎯 Valores de Exemplo Prontos (PERSONALIZE COM SEUS):

```
DATABASE_URL=postgresql://neondb_owner:npg_XXXXX@ep-XXXXX-pooler.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require

JWT_SECRET=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z

NEXT_PUBLIC_APP_URL=https://app.dpwai.com.br

RESEND_API_KEY=re_AUDeD4x6_EvQkUYcYGXXEG2wLW8MzsJyF

EMAIL_FROM=DPWAI Agro <noreply@dpwai.com.br>
```

---

**Dúvida? Ver:**
- VERCEL_SETUP.md - Detalhado
- VERCEL_QUICK.md - Resumido
- ENV_VAR_USAGE.md - Técnico
