# 🚀 Vercel Setup Completo - Variáveis + Database

**Status:** Pronto para produção
**Última atualização:** 25 de janeiro de 2026

---

## 📋 Tudo que Precisa Configurar na Vercel

### 1️⃣ Environment Variables (Settings → Environment Variables)

Copie e cole cada uma dessas variáveis na Vercel:

#### **DATABASE_URL** (Obrigatório)
```
postgresql://usuario:senha@host:port/nome_db?sslmode=require
```

**O que é:** Conexão com o banco de dados PostgreSQL
**Exemplo Neon (grátis + rápido):**
```
postgresql://neondb_owner:npg_xxxxxxxxxxxxx@ep-silent-band-ahgf7iuq-pooler.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require
```

**Onde conseguir:**
- Se tiver banco já: use a string de conexão existente
- Se não tiver, crie grátis em [Neon.tech](https://console.neon.tech)
- Ou use [Railway.app](https://railway.app), [Heroku Postgres](https://www.heroku.com/postgres), [AWS RDS](https://aws.amazon.com/rds/)

#### **JWT_SECRET** (Obrigatório)
```
sua-chave-secreta-super-segura-min-32-chars
```

**O que é:** Chave para assinar tokens JWT de autenticação
**Gerar chave segura:**
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

**Requisitos:**
- ✅ Mínimo 32 caracteres
- ✅ Use mix de letras, números, símbolos
- ✅ NÃO use a padrão "dpwai-secret-key-change-in-production"
- ✅ Guarde bem, não compartilhe

#### **NEXT_PUBLIC_APP_URL** (Obrigatório)
```
https://app.dpwai.com.br
```

**O que é:** URL pública da sua app (usada em emails, redirects, etc)
**Importante:**
- ✅ DEVE ser https:// (não http)
- ✅ DEVE ser seu domínio final (app.dpwai.com.br)
- ✅ Sem barra no final (/)
- ✅ Prefix `NEXT_PUBLIC_` = exposto no browser (ok para URL, NÃO para secrets)

#### **RESEND_API_KEY** (Para emails)
```
re_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

**O que é:** API key do Resend para enviar emails (password reset, share links)
**Como conseguir:**
1. Acesse [resend.com](https://resend.com)
2. Faça login ou crie conta
3. Vá em **API Keys**
4. Clique **Create API Key**
5. Copie a key (começa com `re_`)

**Importante:**
- ✅ Obrigatório para password reset funcionar
- ✅ Neon free tier: ~100 emails/mês grátis
- ✅ Se não tiver, password reset vai quebrar

#### **EMAIL_FROM** (Opcional, tem padrão)
```
DPWAI Agro <noreply@dpwai.com.br>
```

**O que é:** Quem envia os emails (nome e endereço)
**Padrão se não setar:**
```
DPWAI <noreply@dpwai.com.br>
```

**Formato correto:**
- `Nome Do Remetente <email@dominio.com>`
- O email deve ser de um domínio verificado no Resend

---

## 📊 Resumo das Variáveis

| Variável | Obrigatório | Tipo | Exemplo |
|----------|------------|------|---------|
| `DATABASE_URL` | ✅ SIM | String (sensível) | `postgresql://...` |
| `JWT_SECRET` | ✅ SIM | String (sensível) | `a1b2c3d4e5f6...` |
| `NEXT_PUBLIC_APP_URL` | ✅ SIM | String (pública) | `https://app.dpwai.com.br` |
| `RESEND_API_KEY` | ✅ SIM | String (sensível) | `re_xxxxx` |
| `EMAIL_FROM` | ❌ NÃO | String (opcional) | `DPWAI <noreply@...>` |

---

## 🗄️ Database Setup - PostgreSQL

### Opção 1: Neon (Recomendado - Rápido e Grátis)

1. Acesse [neon.tech](https://console.neon.tech)
2. Clique **Create a project**
3. Escolha região (us-east-1 é padrão)
4. Depois de criar:
   - Vá em **Connection string**
   - Copie a string (com `sslmode=require`)
   - Cole em `DATABASE_URL` na Vercel

```
postgresql://neondb_owner:npg_XXXXX@ep-XXXXX-pooler.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require
```

### Opção 2: Railway (Grátis, $5/mês depois)

1. Acesse [railway.app](https://railway.app)
2. Login com GitHub
3. Novo projeto → PostgreSQL
4. Depois de criar:
   - Clique no banco → **Data**
   - Copie connection string
   - Cole em `DATABASE_URL`

### Opção 3: AWS RDS (Pago, +profissional)

1. Acesse [aws.amazon.com](https://aws.amazon.com)
2. RDS → Create Database
3. PostgreSQL, free tier eligible
4. Depois de criar:
   - Endpoint do banco está em **Connectivity & security**
   - Cole em `DATABASE_URL`

---

## 🔧 Como Adicionar as Variáveis na Vercel

### Passo 1: Ir pro Dashboard

1. Acesse [vercel.com](https://vercel.com)
2. Clique no projeto `dpwai-app2`
3. Clique aba **Settings**

### Passo 2: Environment Variables

1. Clique **Environment Variables** (na esquerda)
2. Para cada variável abaixo:

```
Variável: DATABASE_URL
Valor: postgresql://neondb_owner:npg_XXXXX@...
Environments: Production, Preview, Development
Clique: Save
```

Repita para:
- `JWT_SECRET`
- `NEXT_PUBLIC_APP_URL`
- `RESEND_API_KEY`
- `EMAIL_FROM` (opcional)

---

## ✅ Checklist de Verificação

### Database
- [ ] Banco criado (Neon, Railway ou RDS)
- [ ] Connection string copiada (com `sslmode=require`)
- [ ] `DATABASE_URL` adicionada na Vercel
- [ ] Testado localmente: `npm run migrate` (ou `npx prisma migrate`)

### JWT
- [ ] Gerada chave segura (32+ caracteres)
- [ ] `JWT_SECRET` adicionada na Vercel
- [ ] NÃO é a chave padrão "dpwai-secret-key-change-in-production"

### App URL
- [ ] Domain registrado (app.dpwai.com.br)
- [ ] `NEXT_PUBLIC_APP_URL` = sua URL final
- [ ] Com https:// (não http://)

### Email
- [ ] Resend account criado
- [ ] API key gerada
- [ ] `RESEND_API_KEY` adicionada na Vercel
- [ ] `EMAIL_FROM` com domínio verificado (ou deixar padrão)

### Vercel
- [ ] Todas as 5 variáveis adicionadas
- [ ] Selecionadas para Production
- [ ] Redeploy feito após adicionar

---

## 🔄 Redeploy Após Adicionar Variáveis

Depois de adicionar todas as variáveis, precisa fazer redeploy:

1. Na Vercel → Deployments (aba no topo)
2. Clique os 3 pontinhos (...) do deploy mais recente
3. Clique **Redeploy**
4. Aguarde build finalizar (2-3 min)

Ou via CLI:
```bash
vercel --prod
```

---

## 🐛 Testar se Funcionou

### 1. Verificar se Database conectou

```bash
# Localmente
npx prisma db push
```

Se funcionar, database está ok.

### 2. Verificar se Email funciona

1. Na app: ir em **Forgot Password**
2. Digitar um email
3. Clicar **Reset Password**
4. Checar inbox (ou spam) por email de reset

Se receber email com link, Resend está configurado.

### 3. Verificar se JWT está ok

1. Fazer login na app
2. Abrir DevTools (F12)
3. Application → Cookies
4. Procurar por `token`
5. Se existir, JWT está funcionando

---

## 📚 Arquivos Relacionados

O app usa essas variáveis em:

- **lib/auth/jwt.ts** - JWT_SECRET para assinar tokens
- **lib/email/resend.ts** - RESEND_API_KEY para enviar emails
- **lib/prisma.ts** - DATABASE_URL para conectar no DB
- **app/layout.tsx** - NEXT_PUBLIC_APP_URL para links

---

## 🆘 Troubleshooting

### ❌ Build falha com "NEXT_PUBLIC_APP_URL is required"

**Causa:** Variável não foi adicionada ou nomeada errado
**Solução:**
1. Ir em Settings → Environment Variables
2. Verificar se `NEXT_PUBLIC_APP_URL` existe
3. Se não, adicionar com valor `https://app.dpwai.com.br`
4. Redeploy

### ❌ Emails não chegam

**Causa:** RESEND_API_KEY inválida ou não configurada
**Solução:**
1. Verificar em resend.com se API key é válida
2. Copiar novamente (sem espaços)
3. Colar em `RESEND_API_KEY` na Vercel
4. Redeploy

### ❌ Database connection error

**Causa:** DATABASE_URL inválida ou banco offline
**Solução:**
1. Copiar string de conexão novamente do banco
2. Verificar se tem `sslmode=require` no final
3. Colar em `DATABASE_URL` na Vercel
4. Redeploy
5. Se continuar: banco pode estar down, testar localmente

### ❌ Login não funciona / JWT error

**Causa:** JWT_SECRET não configurada ou inválida
**Solução:**
1. Gerar nova chave: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
2. Adicionar/atualizar `JWT_SECRET` na Vercel
3. Redeploy
4. Fazer novo login

---

## 🎯 Checklist Final

Antes de considerar pronto:

- [ ] DATABASE_URL adicionada e testada
- [ ] JWT_SECRET gerada e adicionada
- [ ] NEXT_PUBLIC_APP_URL = seu domínio final
- [ ] RESEND_API_KEY adicionada
- [ ] EMAIL_FROM configurado (ou padrão ok)
- [ ] Build passou sem erros
- [ ] Login funciona
- [ ] Password reset envia email
- [ ] App acessível em https://app.dpwai.com.br

**Quando tudo está green:** Seu app está pronto pra produção! 🚀

---

**Perguntas?** Veja:
- **DEPLOYMENT.md** - Guia geral de deploy
- **HOSTINGER_SETUP.md** - Setup do domínio
- **.env.example** (se existir) - Exemplo de variáveis
