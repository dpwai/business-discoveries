# DPWAI Agro - Smart Agricultural Automation Platform

**Status:** ✅ **PRODUCTION READY** (January 25, 2026)

---

## 🚀 Quick Start

```bash
cd dpwaiagro
npm install
npm run dev  # Runs on http://localhost:3000
```

**Full setup guide:** [`/knowledge/01-setup-local/QUICK-START.md`](/knowledge/01-setup-local/QUICK-START.md)

---

## 📚 Documentation

**All documentation is in `/knowledge/`** - organized by category for easy navigation:

| Category | Path | Contents |
|----------|------|----------|
| **Overview** | [`/knowledge/00-overview/`](/knowledge/00-overview/) | Architecture, tech stack, design system |
| **Setup** | [`/knowledge/01-setup-local/`](/knowledge/01-setup-local/) | Quick start, testing, prerequisites |
| **Frontend** | [`/knowledge/02-frontend/`](/knowledge/02-frontend/) | Components, responsive design, mobile fixes |
| **Backend** | [`/knowledge/03-backend/`](/knowledge/03-backend/) | API reference, error handling, i18n |
| **Environment** | [`/knowledge/04-env-vars/`](/knowledge/04-env-vars/) | Environment variables reference |
| **CI/CD** | [`/knowledge/05-ci-cd/`](/knowledge/05-ci-cd/) | Deployment pipeline documentation |
| **Deployment** | [`/knowledge/06-deploy/`](/knowledge/06-deploy/) | Vercel, Hostinger deployment guides |
| **Troubleshooting** | [`/knowledge/07-troubleshooting/`](/knowledge/07-troubleshooting/) | QA, bug fixes, critical fixes |

**Start here:** [`/knowledge/INDEX.md`](/knowledge/INDEX.md) for complete documentation index

**For agents:** [`CLAUDE.md`](CLAUDE.md) - Core guidelines + quick commands

---

## 🛠️ Tech Stack

- **Frontend:** Next.js 14+ | React | Tailwind CSS
- **Backend:** Next.js API Routes | Prisma ORM
- **Database:** PostgreSQL
- **Deployment:** Vercel
- **Testing:** Playwright + ts-node

---

## 📊 Project Status

✅ All responsive tests passing (40/40)
✅ Deployment automated via Vercel
✅ i18n complete (Portuguese + English)
✅ Dark mode implemented globally
✅ Mobile-first design verified
✅ Repository professionally organized (80 docs in /knowledge/, 8 categories)
✅ No scattered files or empty directories

---

**Start here:** [`/knowledge/01-setup-local/QUICK-START.md`](/knowledge/01-setup-local/QUICK-START.md)
