# 🤖 CLAUDE CODE - DPWAI AGRO REPO GUIDE (Framework-First)

> **PRIMARY RULE #1**: All documentation lives in `/knowledge`. **Always search `/knowledge` first.** Never create random markdown elsewhere.
> **PRIMARY RULE #2**: Use parallel orchestration framework for ANY task with 3+ operations. Never work inline for multi-task operations.
> **PRIMARY RULE #3**: ALWAYS cleanup worktrees at end: `bash scripts/orchestration/worktree_manager.sh cleanup-all`

---

## 🚀 ORCHESTRATION FRAMEWORK (MANDATORY)

For tasks involving **3+ operations** (cleanup + build + test, etc.):

```bash
# Framework auto-decides: worktree or inline based on scope
# Then:
# ✅ Creates git worktrees per agent (if large scope)
# ✅ Isolates each operation (zero conflicts)
# ✅ Runs in parallel (2-3x faster)
# ✅ Consolidates results
# ✅ Auto-cleans worktrees

# Quick commands:
bash scripts/orchestration/cleanup_and_organize.sh  # Organize files + docs
bash scripts/orchestration/run_parallel_build.sh    # Full build (cleanup+build+QA)
bash scripts/orchestration/worktree_manager.sh status  # Check worktrees
bash scripts/orchestration/worktree_manager.sh cleanup-all  # CLEANUP (MANDATORY)
```

### When to Use Framework

| Scenario | Use Framework? | Why |
|----------|---|---|
| **3+ independent tasks** (cleanup + build + test) | ✅ YES | Runs in parallel |
| **Large file reorganization** | ✅ YES | Creates worktree for isolation |
| **Single operation** (just build, just test) | ❌ NO | Overhead not worth it |
| **Small tweak** (1-2 files) | ❌ NO | Too simple for framework |

### Framework Auto-Decides: Worktree or Inline?

```
Assessment:
  Scope > Large (15+ files, significant changes) → CREATE WORKTREE
  Scope ≤ Small (1-2 files) → WORK INLINE
  Result: Zero overhead, zero conflicts ✅
```

### 🚨 CRITICAL: ALWAYS CLEANUP AT END

```bash
# MANDATORY at end of any framework task
bash scripts/orchestration/worktree_manager.sh cleanup-all

# Verify cleanup
bash scripts/orchestration/worktree_manager.sh status  # Should show: "No active worktrees"
```

---

## 🎯 CRITICAL: HARDENING KNOWLEDGE BASE (JAN 26, 2026)

**⚠️ READ THIS FIRST** before making ANY changes to the codebase!

### 📖 Complete Knowledge Base
- **[`/DPWAI_HARDENING_KNOWLEDGE_BASE.md`](DPWAI_HARDENING_KNOWLEDGE_BASE.md)** ← **BOOKMARK THIS**
  - Complete prompt for all future work
  - All critical fixes discovered (38 issues)
  - ErrorCode definitions
  - Route handler templates
  - Database patterns
  - i18n requirements
  - Testing checklist
  - **Copy this prompt for ANY new agent/feature work**

### 🔧 Critical Fixes You MUST Know

**Issue #1: Next.js 16 Route Signatures (38+ FILES)**
- ❌ WRONG: `{ params }: { params: { id: string } }`
- ✅ RIGHT: `{ params }: { params: Promise<{ id: string }> }`
- ⚠️ THEN: `const { id } = await params;`
- **Files affected**: All `/app/api/agro/[tenant]/` routes

**Issue #2: verifyAuth() Function**
- ❌ WRONG: `const decoded = await verifyAuth(token);`
- ❌ WRONG: `const decoded = await verifyAuth(req, tenant);`
- ✅ RIGHT: `const auth = await verifyAuth(request);`
- **Always returns**: `{ authenticated, userId, email, tenantId }`

**Issue #3: ErrorCode Type Definition**
- ❌ WRONG: Use error codes not in `ErrorCode` union type
- ✅ RIGHT: Add code to `/lib/errors/normalizer.ts` first, then use
- **Map**: Every code needs entry in `ERROR_CODE_TO_I18N_KEY`

**Issue #4: Prisma JSON Fields**
- ❌ WRONG: `jsonField: null` (type error)
- ✅ RIGHT: `jsonField: undefined`

### 📋 Hardening Sprint Deliverables

**Created in Jan 26, 2026 Sprint:**
- ✅ **Agent 01**: Complete auth system (signup, OTP, password reset, logout)
- ✅ **Agent 02**: Dashboard CRUD + viewer + 24h share links
- ✅ **Agent 03**: Admin screens (users, audit logs, settings, account)
- ✅ **Agent 04**: Mobile QA (100% pass on 375px, 768px, 1024px)
- ✅ **Agent 05**: 16+ E2E tests + 40+ security checks (B+ grade)

**All Documents**:
1. `/HARDENING_SPRINT_FINAL_REPORT.md` - Complete overview
2. `/dpwaiagro/docs/CONTRACTS/hardening_contracts.md` - API contracts
3. `/dpwaiagro/docs/WORKLOG/hardening_parallel.md` - Status dashboard
4. `/dpwaiagro/docs/SECURITY-AUDIT-REPORT.md` - Security findings
5. `/dpwaiagro/tests/e2e/hardening.spec.ts` - Playwright tests (16+)
6. `/dpwaiagro/MOBILE_QA_RESULTS.md` - Mobile testing results

### ⚠️ BEFORE ANY CODE CHANGES

**Checklist**:
- [ ] Read `/DPWAI_HARDENING_KNOWLEDGE_BASE.md`
- [ ] Copy the comprehensive prompt at end
- [ ] Check route signature uses `Promise<params>`
- [ ] Check `verifyAuth(request)` called correctly
- [ ] Check all error codes in `ErrorCode` type
- [ ] Check all UI text has i18n keys
- [ ] Run `npm run build` - must pass
- [ ] Run tests (if applicable)

---

---

## 📍 CRITICAL PATHS

| Item | Path | Purpose |
|------|------|---------|
| **Agent Context** | `/knowledge/00-overview/CLAUDE-CONTEXT.md` | Core context for all future agent work |
| **Architecture** | `/knowledge/00-overview/HOW-THE-REPO-WORKS.md` | System design + tech stack |
| **Docs Index** | `/knowledge/INDEX.md` | Master table of contents |
| **Setup Guide** | `/knowledge/01-setup-local/QUICK-START.md` | Get running locally (5 min) |
| **CI/CD Pipeline** | `/knowledge/05-ci-cd/CI-CD-README.md` | Deployment pipeline documentation |
| **Scripts** | `/scripts/` | All automation scripts live here |

---

## 🚀 QUICK COMMANDS

```bash
# Start development
cd dpwaiagro
npm run dev          # Dev server on http://localhost:3000

# Build + deploy to Vercel
git push origin main # Auto-triggers Vercel deployment

# Run tests
npm run test         # All tests
npm run test:tokens  # Token validation
npm run test:url     # URL validation

# Database
npx prisma studio   # Prisma UI (schema browser)
npx prisma migrate  # Run pending migrations
npm run prisma:seed # Seed database
```

---

## 📚 DOCUMENTATION STRUCTURE

### `/knowledge/00-overview/` - START HERE FOR CONTEXT
- **CLAUDE-CONTEXT.md** ← Read this for agent guidelines
- **ARCHITECTURE.md** - System design + how things work
- **TECH-STACK.md** - Technologies used
- **DESIGN-SYSTEM.md** - UI/design patterns
- **README.md** - Overview index

### `/knowledge/01-setup-local/` - SETUP & TESTING
- **QUICK-START.md** - Get running in 5 minutes
- **PREREQUISITES.md** - Prerequisites checklist
- **TESTING-SETUP.md** - How to run all tests
- **TEST-SUITE-QUICK.md** - Quick test guide
- **TESTING-SUITE-FULL.md** - Exhaustive testing
- **RESEND-EMAIL-SETUP.md** - Email service (password reset)
- **I18N-SETUP.md** - Internationalization (PT-BR + EN)

### `/knowledge/02-frontend/` - FRONTEND DETAILS
- **RESPONSIVE-DESIGN.md** - Mobile responsiveness (QA audit, 40 tests, 100% passing)
- **UI-MODERNIZATION.md** - Modern UI patterns
- **COMPONENT-LIBRARY.md** - React component reference
- **MOBILE-DRAWER-FIX.md** - Mobile-specific fixes
- **MOBILE-PATTERNS.md** - Mobile UX patterns
- **mobile-fixes/** - Mobile-specific bug fixes and improvements
  - **CHANGELOG-MOBILE-FIXES.md** - Mobile fix changelog
  - **MOBILE-FIX-SUMMARY.md** - Summary of mobile fixes
  - **DEMO-FIXES-ACTUAL.md** - Demo implementation details
  - **QA-MOBILE-CHECKLIST.md** - Mobile QA testing checklist

### `/knowledge/03-backend/` - BACKEND & API
- **I18N-HARDCODED-AUDIT.md** - Hardcoded string audit
- **error-handling/** - Phase 5 error handling system
  - **ERROR-HANDLING-GUIDE.md** - Comprehensive error handling architecture
  - **ERROR-HANDLING-EXAMPLES.md** - Code examples and patterns
  - **ERROR-HANDLING-README.md** - Quick start guide
  - **ERROR-HANDLING-VERIFICATION.md** - Verification checklist
- **i18n/** - Internationalization system
  - **I18N-GUIDE.md** - i18n system documentation
  - **I18N-AUDIT-REPORT.md** - Phase 7 i18n audit results

### `/knowledge/04-env-vars/` - ENVIRONMENT VARIABLES
- **ENV-REFERENCE.md** - All env vars + where they're used

### `/knowledge/05-ci-cd/` - CI/CD PIPELINE
- **CI-CD-README.md** - GitHub Actions + Vercel deployment flow

### `/knowledge/06-deploy/` - DEPLOYMENT & HOSTING
- **VERCEL-DEPLOYMENT.md** - Vercel setup (main deployment)
- **VERCEL-QUICK-SETUP.md** - Copy-paste quick start
- **HOSTINGER-DEPLOYMENT.md** - DNS + domain (`app.dpwai.com.br`)
- **DEPLOYMENT-OVERVIEW.md** - Deployment flow
- **DEPLOYMENT-CHECKLIST.md** - Pre-launch checklist

### `/knowledge/07-troubleshooting/` - QA & TROUBLESHOOTING
- **QA-INDEX.md** - QA documentation navigation
- **QA-SUMMARY.md** - QA results summary
- **AUDIT-COMPLETION.md** - Final audit report
- **AUDIT-VERIFICATION.md** - Verification results
- **bug-fixes/** - Bug tracking and fixes
  - **AUDIT-AND-FIXES.md** - Comprehensive bug audit
  - **AUDIT-EXECUTIVE-SUMMARY.md** - Audit summary
  - **REMAINING-BUGS-ACTION-PLAN.md** - Bug action plan
  - **BUG-FIX-PLAN.md** - Bug fix planning
  - **BUG-REPORT-DEMO-AUDIT.md** - Demo bug report
  - **DEMO-BUG-FIXES-IMPLEMENTATION.md** - Demo fixes implementation
- **critical-fixes/** - Critical production fixes
  - **LOGIN-404-FIX.md** - Critical login 404 fix documentation
  - **CRITICAL-FIX-SUMMARY.md** - Critical fix summary
  - **DEPLOYMENT-READY.md** - Deployment readiness verification
  - **TESTING-LOGIN-FLOW.md** - Manual login flow testing guide
- **project-history/** - Historical project documentation
  - **FINAL-WORK-SUMMARY.md** - Complete work summary
  - **PHASE5-COMPLETION-SUMMARY.md** - Phase 5 completion
  - **PHASE5-INDEX.md** - Phase 5 documentation index

### `/knowledge/archive/` - OLD DOCS (REFERENCE ONLY)
- **app-backups/** - Legacy code backups
  - **app-fixed/** - Old app route structure backup
  - **README.md** - Archive documentation
- Keep for reference; not primary docs

---

## 🛠️ SCRIPTS DIRECTORY

All automation scripts live in `/scripts/`:

```
/scripts/
├── dev/          # Local development scripts
├── db/           # Database scripts (migrations, seeding)
├── deploy/       # Deployment automation
├── tools/        # Utility scripts
└── archive/      # Old/unused scripts
```

**Reference `/scripts/README.md` for available scripts.**

---

## 📖 PROJECT OVERVIEW

### Frontend
- **Type:** Next.js 14+ (App Router) + React + Tailwind CSS
- **Location:** `/dpwaiagro/`
- **Package Manager:** npm
- **Start Dev:** `cd dpwaiagro && npm run dev` → http://localhost:3000
- **Build:** `npm run build` (Prisma generate + Next build)
- **Deploy:** Push `main` → Vercel auto-deploys

### Backend
- **Type:** Next.js API Routes (embedded, no separate service)
- **Location:** `/dpwaiagro/app/api/`
- **Auth:** JWT-based (custom email/password)
- **Email:** Resend API for password reset

### Database
- **Type:** PostgreSQL via Prisma ORM
- **Connection:** `DATABASE_URL` env var (Vercel managed)
- **Migrations:** `/dpwaiagro/prisma/migrations/`
- **Schema:** `/dpwaiagro/prisma/schema.prisma`

### Testing
- **Type:** Custom tests with ts-node
- **Location:** `/dpwaiagro/lib/__tests__/`
- **Run:** `npm run test`
- **QA Suite:** 40 responsive tests (100% passing)

### Deployment
- **Host:** Vercel (app.dpwai.com.br)
- **DNS:** Hostinger (CNAME to Vercel)
- **CI/CD:** GitHub Actions (light validation) + Vercel webhook
- **Env Vars:** Set in Vercel dashboard

---

## 🔍 SEARCH STRATEGY FOR FUTURE AGENTS

When looking for information:

1. **Check `/knowledge/INDEX.md` first** - master index
2. **Search by topic:**
   - Frontend → `/knowledge/02-frontend/`
   - Setup → `/knowledge/01-setup-local/`
   - Deployment → `/knowledge/06-deploy/`
   - Env Vars → `/knowledge/04-env-vars/`
   - Troubleshooting → `/knowledge/07-troubleshooting/`
3. **Use filename patterns** - all files are named `TOPIC-SUBTOPIC.md`
4. **For old references:** Check `/knowledge/archive/`

---

## ⚠️ IMPORTANT RULES FOR AGENTS

### DON'T
- ❌ Create markdown files in root (use `/knowledge/XX-topic/`)
- ❌ Create scripts in random places (use `/scripts/XX/`)
- ❌ Modify deployed code without git workflow
- ❌ Ignore test failures (run all tests before committing)

### DO
- ✅ Update `/knowledge/INDEX.md` if adding new docs
- ✅ Use `/scripts/` for any automation
- ✅ Run tests locally: `npm run test`
- ✅ Check `/knowledge/` FIRST before implementing
- ✅ Reference docs by `knowledge/path/to/doc.md`

---

## 📋 REPO STATE

- ✅ Frontend: Next.js 14+ fully functional
- ✅ Testing: 40 responsive tests, 100% passing
- ✅ Deployment: Vercel auto-deploy working
- ✅ i18n: Portuguese (pt-BR) + English complete
- ✅ Dark mode: Global default (slate-950)
- ✅ Mobile: Hamburger menu verified (z-99999, always visible)
- ✅ Docs: Fully consolidated in `/knowledge/` (80 files, 8 categories)
- ✅ Scripts: Centralized in `/scripts/`
- ✅ Repository: Clean (no scattered files, no empty directories)
- ✅ Organization: Professional, scalable structure

---

## 🎯 NEXT MAJOR TASKS

Refer to `/knowledge/INDEX.md` for current project status and remaining work.

---

## 🚨 CRITICAL SECRETS & CONFIG

- **DATABASE_URL:** Set in Vercel (never commit)
- **JWT_SECRET:** Set in Vercel (never commit)
- **RESEND_API_KEY:** Set in Vercel (never commit)
- **NEXT_PUBLIC_APP_URL:** Set in Vercel + env file

See `/knowledge/04-env-vars/ENV-REFERENCE.md` for full list.

---

## 📞 TROUBLESHOOTING QUICK LINKS

- **App won't start?** → `/knowledge/07-troubleshooting/`
- **Build fails?** → `/knowledge/01-setup-local/QUICK-START.md`
- **Tests failing?** → `/knowledge/01-setup-local/TESTING-SETUP.md`
- **Deploy issues?** → `/knowledge/06-deploy/DEPLOYMENT-OVERVIEW.md`
- **Need env vars?** → `/knowledge/04-env-vars/ENV-REFERENCE.md`

---

## 🎯 MAJOR PROJECTS (Copy & Paste Prompts)

### PROJECT 1: UI/UX Fixes (HIGH - 15 commits across 3 phases, 18h)

**Status:** 🎨 **URGENT** - Audit complete, ready for implementation

**What's broken:**
- Core interaction issues (cards not clickable, chat input hidden)
- Language inconsistency (English + Portuguese mixed on same screens)
- Low contrast text (blue on dark blue, WCAG violation)
- Non-standard dropdown behavior (don't close on outside click)
- Missing feedback on actions (no success/error messages)

**Current grade:** C (Functional but frustrating)
**After fixes:** A- (Professional, intuitive, accessible)

**How to start:**
1. Read audit: `/knowledge/02-frontend/UI-UX-AUDIT-FINDINGS.md`
2. Review plan: `/knowledge/02-frontend/UI-UX-FIXES-PLAN.md`
3. Copy prompt: `/dpwaiagro/UI-UX-FIXES-PROMPT.md`
4. Paste into Claude
5. Follow Phase 1 (5 commits, 7.5h) first

**Full details:** `/knowledge/02-frontend/UI-UX-AUDIT-FINDINGS.md`

**Phase sequence:**
- Phase 1 (Critical): Cards, chat, dropdowns, language, contrast (7.5h)
- Phase 2 (High): Tooltips, chat list, form labels, feedback (7h)
- Phase 3 (Medium): Polish, data cleanup, standardization (3.5h)

---

### PROJECT 2: Multi-Tenant Security Fixes (CRITICAL - 6 commits, 13.5h)

**Status:** ⚠️ **CRITICAL** - Audit complete, ready for implementation

**What's broken:**
- 14 unauthenticated API routes (Google Forms, account settings, admin)
- Type safety bug bypasses tenant validation
- Missing hash fields and Integrations model

**Current grade:** D (Unsafe for Production)
**After fixes:** B+ (Production Ready)

**How to start:**
1. Read audit: `/knowledge/08-security/MULTI-TENANT-SECURITY-AUDIT.md`
2. Review plan: `/knowledge/08-security/SECURITY-FIXES-PLAN.md`
3. Copy prompt: `/dpwaiagro/SECURITY-FIXES-PROMPT.md`
4. Paste into Claude
5. Follow 6 commits sequentially

**Full details:** `/knowledge/08-security/README.md`

---

### PROJECT 2: Email + OTP System (Complete)

**Status:** Plan complete, ready for implementation

**How to use:**
1. Open `/IMPLEMENTATION-PROMPT.md`
2. Copy the prompt
3. Paste into Claude
4. Follow along for 10 commits

**Plan details:** `/knowledge/09-otp-email-system/OTP-EMAIL-SYSTEM-PLAN.md`

---

### PROMPT 3: Login UX + Header Fixes

```
YOU ARE WORKING ON DPI – BUSINESS AUTOMATION PLATFORM.
TASK: Fix login UX, remove English text, fix header behavior NOW.

CONTEXT:
* Default language: Portuguese (pt-BR)
* Theme: dark mode
* Login is FIRST screen, NO EXCEPTIONS
* Commit small, objective. No new features.

DO THIS:

1. LOGIN SCREEN (100% PORTUGUESE)
   Replace ALL English strings:
   - "Email or username" → "E-mail ou usuário"
   - "Password" → "Senha"
   - "Forgot your password?" → "Esqueci minha senha"
   - "Sign in" → "Entrar"
   - "Signing in..." → "Entrando..."
   - ALL validations, errors, placeholders → PORTUGUESE

2. REMOVE HEADER FROM LOGIN
   - NO menu sanduíche on /login
   - NO avatar on /login
   - NO navigation on /login
   - Login = clean, centered, focused

3. FIX LOGIN REDIRECT FLOW
   - /login → authenticate → /welcome (CLEAN)
   - No header flickering during auth
   - No menu appearing before login completes

4. HEADER AFTER LOGIN (CORRECT PATTERN)
   Layout (left to right):
   ☰ Menu (LEFT) → Username → (space) → Avatar (RIGHT)

5. VALIDATION CHECKLIST
   [ ] All login text = Portuguese
   [ ] No English anywhere (idle, loading, error)
   [ ] Login has NO header
   [ ] No flickering sanduíche
   [ ] After login: header appears
   [ ] Only ONE menu sanduíche
   [ ] Username visible
   [ ] Avatar top-right corner
   [ ] Clean redirect to /welcome

STOP CONDITION: All items ✓, build passes, app works end-to-end.
```

---

**Last Updated:** 2026-01-25
**Version:** 2.1 (Repository reorganization complete)
**Status:** ✅ Production Ready - Fixed next-intl route injection, added quick prompts

---

## 📖 READ NEXT

→ [`/knowledge/INDEX.md`](knowledge/INDEX.md) for master docs index
→ [`/knowledge/00-overview/HOW-THE-REPO-WORKS.md`](knowledge/00-overview/HOW-THE-REPO-WORKS.md) for system design
→ [`/knowledge/01-setup-local/QUICK-START.md`](knowledge/01-setup-local/QUICK-START.md) to get running locally
