# 🔧 Technology Stack

**Complete list of all technologies, frameworks, and libraries used in DPWAI Agro.**

**Status**: 🟢 Current
**Last Updated**: 25 January 2026
**Purpose**: Reference for understanding project dependencies

---

## 🚀 Runtime & Core

| Technology | Version | Purpose |
|-----------|---------|---------|
| Node.js | 18+ | JavaScript runtime |
| TypeScript | 5 | Type-safe JavaScript |
| npm | Latest | Package manager |

---

## 🎨 Frontend

### Framework & UI
| Technology | Version | Purpose |
|-----------|---------|---------|
| Next.js | 16.1.4 | React framework + SSR + API routes |
| React | 19.2.3 | UI library |
| React DOM | 19.2.3 | React rendering |
| Tailwind CSS | 4 | Utility-first CSS framework |
| PostCSS | 4 | CSS transformation |

### UI Components & Icons
| Technology | Version | Purpose |
|-----------|---------|---------|
| Lucide React | 0.562.0 | Icon library (200+ icons) |
| ApexCharts | 5.3.6 | Chart rendering |
| React ApexCharts | 1.9.0 | React wrapper for charts |
| Flatpickr | 4.6.13 | Date/time picker |
| React Dropzone | 14.3.8 | File upload (drag-drop) |

### State & Context
| Technology | Version | Purpose |
|-----------|---------|---------|
| React Context API | Built-in | Theme, Language, Auth state |
| React Hooks | Built-in | Functional component logic |

### Styling
| Technology | Version | Purpose |
|-----------|---------|---------|
| CSS Modules | Built-in | Component-scoped styles |
| Tailwind CSS | 4 | Utility classes |
| Design Tokens | Custom | Color, spacing, typography |

---

## 🔧 Backend

### API Framework
| Technology | Version | Purpose |
|-----------|---------|---------|
| Next.js API Routes | 16.1.4 | HTTP endpoints (built-in) |

### Authentication & Security
| Technology | Version | Purpose |
|-----------|---------|---------|
| jsonwebtoken | 9.0.3 | JWT token generation & verification |
| jose | 6.1.3 | Alternative JWT handling |
| bcrypt | 6.0.0 | Password hashing (10 salt rounds) |
| @types/bcrypt | 6.0.0 | TypeScript types |

### Database & ORM
| Technology | Version | Purpose |
|-----------|---------|---------|
| Prisma | 5.15.0 | ORM + database abstraction |
| @prisma/client | 5.15.0 | Prisma client |
| pg | 8.11.3 | PostgreSQL driver |

### Validation
| Technology | Version | Purpose |
|-----------|---------|---------|
| zod | 4.3.6 | TypeScript schema validation |

### Email
| Technology | Version | Purpose |
|-----------|---------|---------|
| resend | 6.8.0 | Email service (password reset) |

---

## 🗄️ Database

| Technology | Version | Purpose |
|-----------|---------|---------|
| PostgreSQL | 14+ | Relational database (Neon serverless) |
| Neon | Latest | PostgreSQL hosting (serverless) |

---

## 🧪 Testing & Quality

| Technology | Version | Purpose |
|-----------|---------|---------|
| Playwright | 1.58.0 | E2E testing framework |
| @playwright/test | 1.58.0 | Playwright test runner |
| ts-node | 10.9.2 | Run TypeScript directly |

### Linting & Type Checking
| Technology | Version | Purpose |
|-----------|---------|---------|
| ESLint | 9 | Code linting |
| eslint-config-next | 16.1.4 | Next.js ESLint config |
| TypeScript | 5 | Static type checking |

---

## 🚀 Development Tools

| Technology | Version | Purpose |
|-----------|---------|---------|
| Prettier | Included | Code formatting |
| Turbopack | Built-in | Next.js fast build tool |

---

## 📦 NPM Scripts

```bash
# Development
npm run dev              # Start dev server (localhost:3000)

# Build & Start
npm run build            # Build for production
npm run start            # Start production server

# Database
npm run prisma:generate  # Generate Prisma client
npm run prisma:seed      # Seed database
npm run db:migrate:rls   # Run RLS migrations

# Testing
npm run test             # Run all tests
npm run test:tokens      # Validate design tokens
npm run test:url         # Validate URLs

# Linting
npm run lint             # Run ESLint

# Deployment
npm run vercel-build     # Vercel build process
```

---

## 🌍 External Services

| Service | Purpose | Authentication |
|---------|---------|-----------------|
| Resend | Email sending | API key (RESEND_API_KEY) |
| Neon | PostgreSQL hosting | Connection string (DATABASE_URL) |
| Vercel | App deployment | Automatic (git push) |
| Hostinger | Domain/DNS | Manual (CNAME setup) |

---

## 🔐 Environment Variables

```env
# Database
DATABASE_URL=postgresql://...     # Neon connection

# JWT
JWT_SECRET=...                    # Secret for signing tokens

# Email
RESEND_API_KEY=re_...             # Resend API key

# Optional
NEXT_PUBLIC_API_URL=...           # API URL (public)
VERCEL_ENV=production             # Deployment environment
```

---

## 📊 Version Compatibility

### Node.js
- **Minimum**: 18.17.0
- **Recommended**: 20+
- **Test**: Using Node 18-20

### TypeScript
- **Version**: 5.x
- **Target**: ES2020
- **Module**: ESNext
- **Strict**: true (strict mode enabled)

### React
- **Version**: 19.2.3
- **Hooks**: Full support
- **Server Components**: Not used (client-side app)

### Next.js
- **Version**: 16.1.4
- **Router**: App Router (new)
- **Rendering**: SSR + Static generation
- **API**: Built-in API routes

---

## 📈 Size & Performance

### Bundle Size
- **Main JS**: ~200KB (gzipped)
- **CSS**: ~50KB (gzipped)
- **HTML**: Dynamic (per page)

### Metrics
- **LCP** (Largest Contentful Paint): < 2.5s
- **FID** (First Input Delay): < 100ms
- **CLS** (Cumulative Layout Shift): < 0.1

---

## 🔄 Dependency Updates

### Security
- Dependencies automatically scanned by Dependabot
- Security patches applied promptly
- npm audit run regularly

### Breaking Changes
- Major version updates tested on staging
- Not force-updated, reviewed before applying
- Changelog reviewed for compatibility

---

## 📚 References

- **Next.js**: https://nextjs.org/docs
- **React**: https://react.dev
- **Tailwind**: https://tailwindcss.com
- **Prisma**: https://www.prisma.io/docs
- **TypeScript**: https://www.typescriptlang.org

---

**Last Updated**: 25 January 2026
**Maintained By**: Claude Code
