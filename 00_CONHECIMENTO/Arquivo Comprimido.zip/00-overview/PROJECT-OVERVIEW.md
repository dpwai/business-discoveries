# 🎯 Project Overview - DPWAI Agro

**Project**: DPWAI (Deep Work AI) - Agricultural Management Dashboard
**Status**: 🟢 Production Ready
**Last Updated**: 25 January 2026
**Type**: Full-stack web application (SaaS)

---

## 📌 What is DPWAI Agro?

DPWAI Agro is a comprehensive agricultural management platform that combines:

1. **Business Automation** - Workflow automation and task management
2. **AI Assistants** - Ralph Chat for intelligent assistance
3. **Form Builder** - Custom data collection and submission system
4. **Multi-tenant Dashboard** - Manage multiple agricultural operations

### Use Cases
- Farm data management and analytics
- Crop planning and monitoring
- Resource allocation and scheduling
- Team collaboration and task management
- Data collection via custom forms
- Real-time dashboard insights

---

## 🏗️ System Architecture

### Frontend Layer
- **Framework**: Next.js 16.1.4 with App Router
- **UI Framework**: React 19.2.3
- **Styling**: Tailwind CSS 4 with custom design tokens
- **Default Theme**: Dark mode (enforced)
- **Default Language**: Portuguese (pt-BR)
- **State Management**: React Context (Theme, Language, Auth)
- **Components**: 50+ custom components + Lucide React icons

### Backend Layer
- **API Framework**: Next.js API Routes (embedded)
- **Authentication**: JWT-based with bcrypt password hashing
- **Email Service**: Resend API for transactional emails
- **Session Management**: Custom JWT implementation
- **Multi-tenant**: Database-level tenant isolation

### Database Layer
- **Type**: PostgreSQL (serverless via Neon)
- **ORM**: Prisma ^5.15.0
- **Schema**: 8+ core models (User, Tenant, Form, FormSubmission, etc.)
- **Migrations**: Version-controlled SQL migrations
- **Seeding**: Automated database seed script

### Deployment
- **Primary Host**: Vercel (auto-deploys from main branch)
- **Database Host**: Neon (PostgreSQL serverless)
- **Domain**: app.dpwai.com.br (Hostinger DNS)
- **CI/CD**: GitHub Actions + Vercel webhooks
- **Environment**: Staging (dev) and Production

---

## 🎨 Design System

### Colors (DPWAI Agro Theme)
- **Primary Green**: `#13ec37` - Main action color, CTAs
- **Dark Background**: `#102213` - Deep forest green
- **Light Background**: `#f6f8f6` - Soft light green
- **Text (Light Mode)**: `#0a2540` - Dark slate
- **Text (Dark Mode)**: White/off-white
- **Accents**: `rgba(19, 236, 55, 0.1)` - Primary with transparency

### Typography
- **Font**: Manrope (sans-serif)
- **H1**: 3.5rem (mobile: 2.5rem)
- **H2**: 2.5rem (mobile: 2rem)
- **H3**: 1.5rem
- **Body**: 1rem

### Visual Effects
- **Glassmorphism**: Frosted glass cards with backdrop blur
- **Gradients**: Linear gradients for hero sections
- **Spacing**: 8px base unit (Tailwind default)
- **Radius**: 0.5rem to 1.5rem (rounded, not sharp)

---

## 📊 Core Features

### 1. Authentication & Multi-Tenancy
- Email/password login with bcrypt hashing
- Username-based login support
- Forgot password flow with email reset links
- JWT tokens (access + refresh)
- Multi-tenant user isolation
- Role-based access control (Admin, User)
- Tenant switching in header

### 2. Form Builder (Complete MVP)
- **11 Question Types**:
  - Short Answer (single-line text)
  - Paragraph (multi-line textarea)
  - Multiple Choice (radio buttons)
  - Checkboxes (multi-select)
  - Dropdown (select element)
  - Linear Scale (1-10 slider)
  - Date picker
  - Time picker
  - File Upload (drag-drop)
  - Grid (matrix questions)
  - Embedded content (blocks)

- **Advanced Features**:
  - Live preview with device selector
  - Drag-and-drop reordering
  - Immutable field IDs (UUID-based)
  - Automatic form versioning
  - Real-time submission tracking
  - Conditional logic support
  - Field dependency management

### 3. Dashboard
- Multi-tenant widget system
- Real-time data visualization
- Customizable widget layouts
- Calendar integration
- Performance metrics
- Activity feed

### 4. Ralph Chat
- AI-powered assistant
- Contextual help
- Task automation
- Documentation access

### 5. Data Management
- Submission history with versioning
- Audit trails
- Export capabilities (CSV, PDF)
- Data validation
- Real-time sync

---

## 🔐 Security Features

### Authentication & Authorization
- ✅ Bcrypt password hashing (10 salt rounds)
- ✅ JWT tokens with expiration
- ✅ Multi-tenant isolation at database level
- ✅ Role-based access control
- ✅ Secure password reset flow with token expiration
- ✅ Session management

### Data Protection
- ✅ HTTPS enforced
- ✅ SQL injection prevention (Prisma ORM)
- ✅ XSS prevention (React escaping)
- ✅ CSRF token support (headers)
- ✅ Secure cookies (httpOnly, secure flags)

### Infrastructure
- ✅ Environment variables for secrets
- ✅ No hardcoded credentials
- ✅ Database encryption (Neon SSL)
- ✅ API rate limiting (planned)
- ✅ Request validation (Zod schemas)

---

## 📁 Repository Structure

```
/Users/balzer/dpwai-app2/
├── knowledge/           ← 📚 ALL DOCUMENTATION
├── scripts/             ← 🔧 ALL AUTOMATION SCRIPTS
├── dpwaiagro/           ← 💻 MAIN APPLICATION
│   ├── app/
│   │   ├── api/         ← Backend routes
│   │   ├── dpwai/       ← Tenant-specific pages
│   │   ├── login/       ← Authentication
│   │   └── reset-password/
│   ├── components/
│   │   ├── FormBuilder/ ← Form builder UI
│   │   ├── common/      ← Reusable components
│   │   └── ...
│   ├── lib/
│   │   ├── auth/        ← JWT, sessions
│   │   ├── formEngine/  ← Form versioning
│   │   ├── i18n/        ← Language system
│   │   └── email/       ← Resend integration
│   ├── prisma/
│   │   ├── schema.prisma
│   │   └── migrations/
│   ├── public/          ← Static assets
│   └── package.json
├── CLAUDE.md            ← 🤖 This file (agent guide)
└── README.md            ← Thin pointer to /knowledge
```

---

## 🚀 Development Workflow

### Local Development
1. Clone repository
2. `cd dpwaiagro`
3. `npm install`
4. Create `.env.local` with `DATABASE_URL`
5. `npm run dev` → http://localhost:3000

### Making Changes
1. Create feature branch
2. Make code changes
3. Run `npm run test` to validate
4. Commit with clear message
5. Push to GitHub
6. Create pull request
7. Vercel auto-deploys preview

### Production Deployment
1. Merge PR to `main`
2. GitHub Actions runs validation
3. Vercel auto-deploys to production
4. Domain `app.dpwai.com.br` updated

---

## 📊 Project Statistics

| Metric | Count |
|--------|-------|
| **Components** | 50+ |
| **API Routes** | 12+ |
| **Database Models** | 8 |
| **FormBuilder Question Types** | 11 |
| **Test Files** | 4+ |
| **Documentation Files** | 66+ |
| **Scripts** | 16 |
| **Default Language** | Portuguese (pt-BR) |
| **Default Theme** | Dark |
| **Lines of Code** | 10,000+ |
| **Total Commits** | 200+ |

---

## 🎓 Key Accomplishments

### Phase 1: Foundation ✅
- ✅ Next.js setup with TypeScript
- ✅ Tailwind CSS + design system
- ✅ PostgreSQL + Prisma ORM
- ✅ Authentication (JWT + bcrypt)

### Phase 2: Core Features ✅
- ✅ Multi-tenant dashboard
- ✅ Form builder (11 question types)
- ✅ Email service (Resend)
- ✅ Language system (pt-BR default)

### Phase 3: Optimization ✅
- ✅ Dark mode as default
- ✅ Form versioning system
- ✅ Immutable field IDs
- ✅ Responsive design (40 tests passing)

### Phase 4: Organization ✅
- ✅ Documentation centralized
- ✅ Scripts organized
- ✅ Repository clean and professional
- ✅ Standard patterns established

---

## 🔮 Future Roadmap

### Short-term (1-2 months)
- [ ] API rate limiting
- [ ] Advanced form logic (conditional questions)
- [ ] Bulk import/export
- [ ] User permissions refinement
- [ ] Email template customization

### Medium-term (3-6 months)
- [ ] Mobile app (React Native)
- [ ] Advanced analytics dashboard
- [ ] Webhook integrations
- [ ] API documentation (OpenAPI/Swagger)
- [ ] Data backup & recovery tools

### Long-term (6+ months)
- [ ] Machine learning for predictions
- [ ] Real-time collaboration
- [ ] Advanced reporting engine
- [ ] Integration marketplace
- [ ] White-label platform

---

## 📞 Quick Links

| Need | Location |
|------|----------|
| **Setup** | `/knowledge/01-setup-local/QUICK-START.md` |
| **Architecture** | `/knowledge/00-overview/ARCHITECTURE.md` |
| **Deployment** | `/knowledge/06-deploy/` |
| **Troubleshooting** | `/knowledge/07-troubleshooting/` |
| **Scripts** | `/scripts/README.md` |
| **Design** | `/knowledge/00-overview/DESIGN-SYSTEM.md` |
| **Form Builder** | `/knowledge/02-frontend/FORMS-BUILDER.md` |

---

**Status**: 🟢 Production Ready
**Last Updated**: 25 January 2026
**Maintained By**: Claude Code
