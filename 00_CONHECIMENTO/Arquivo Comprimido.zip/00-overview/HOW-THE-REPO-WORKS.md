# 🔍 How The Repository Works

**A technical guide to understanding the codebase structure and data flow.**

**Status**: 🟢 Complete & Current
**Last Updated**: 25 January 2026
**Audience**: Developers, architects, future maintainers

---

## 📍 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                      BROWSER (React App)                        │
│                      http://localhost:3000                      │
│                                                                 │
└────────────────────────────────┬────────────────────────────────┘
                                 │
                    HTTP/HTTPS Requests & Responses
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                  NEXT.JS 16.1.4 (Full Stack)                   │
│                   /dpwaiagro/app/ (App Router)                 │
│                                                                 │
│  ┌──────────────────────┐        ┌──────────────────────┐     │
│  │  Frontend (React)    │        │  Backend (API Routes)│     │
│  │  - Page components   │        │  - /api/auth/*       │     │
│  │  - UI components     │        │  - /api/agro/*       │     │
│  │  - Forms & inputs    │        │  - /api/admin/*      │     │
│  └──────────────────────┘        └──────────────────────┘     │
│                                                                 │
│  Styling: Tailwind CSS 4 + Custom Design Tokens               │
│  State: React Context (Theme, Language, Auth)                 │
│  Type: TypeScript (strict mode)                                │
│                                                                 │
└────────────────┬────────────────────────────────────┬──────────┘
                 │                                    │
         Database Queries                   Environment Variables
                 │                           (/dpwaiagro/.env)
                 ▼                                    │
┌─────────────────────────────────┐                 │
│                                 │                 │
│  PostgreSQL (Neon Serverless)  │  ◄──────────────┘
│  /dpwaiagro/prisma/schema      │
│                                 │
│  Models:                         │
│  - User                          │
│  - Tenant                        │
│  - Membership                    │
│  - Form                          │
│  - FormVersion                   │
│  - FormSubmission               │
│  - PasswordResetToken           │
│  - (+ custom models)            │
│                                 │
└─────────────────────────────────┘
```

---

## 🎬 Request Flow

### Example 1: User Login

```
1. User fills login form at /login
   └─> Form state in React component

2. User clicks "Entrar" (Sign In)
   └─> onSubmit handler triggered
   └─> POST /api/auth/login (JSON: email, password)

3. Next.js Backend receives request
   └─> /dpwaiagro/app/api/auth/login/route.ts
   └─> Extract email & password from body
   └─> Query database for User by email
   └─> Compare password with bcrypt hash
   └─> If match: Generate JWT token
   └─> Return token + user data (JSON)

4. Frontend receives response
   └─> Store token in localStorage
   └─> Set AuthContext with user data
   └─> Redirect to dashboard

5. Subsequent requests
   └─> Include Authorization header: "Bearer <token>"
   └─> Backend verifies JWT signature
   └─> Extracts user ID from token
   └─> Proceeds with authenticated action
```

### Example 2: Submit Form Data

```
1. User fills out custom form (built with Form Builder)
   └─> Form data collected in React state

2. User clicks "Submit"
   └─> POST /api/agro/[tenant]/forms/[formId]/submit
   └─> Include: formId, formVersionId, fieldValues, userId

3. Backend receives submission
   └─> Validate formVersionId exists
   └─> Validate user belongs to tenant
   └─> Create FormSubmission record
   └─> Link to FormVersion (versioning)
   └─> Store field values as JSON
   └─> Return submissionId (JSON)

4. Frontend shows confirmation
   └─> Display success message
   └─> Clear form or redirect

5. Data is now in database
   └─> Can query all submissions for a form
   └─> Can see which version was used
   └─> Complete audit trail available
```

### Example 3: Change Theme to Dark

```
1. User clicks theme toggle in header
   └─> onClick handler triggered
   └─> Call setTheme('dark')

2. React Context updated
   └─> ThemeContext.tsx state changes
   └─> All consumers re-render with new theme

3. DOM updated
   └─> Tailwind dark: class applied to <html>
   └─> CSS media query or manual class applies dark colors

4. Persist to localStorage
   └─> JSON.stringify({ theme: 'dark' })
   └─> Save to localStorage

5. Next page load
   └─> Pre-hydration script runs (before React loads)
   └─> Check localStorage for saved theme
   └─> Apply class immediately
   └─> No flash of white screen ✅
```

---

## 📦 Directory Deep Dive

### `/dpwaiagro/app/` - Frontend Pages & API Routes

```
app/
├── api/                          ← Backend routes (all HTTP endpoints)
│   ├── auth/
│   │   ├── login/route.ts        ← POST /api/auth/login
│   │   ├── logout/route.ts       ← POST /api/auth/logout
│   │   ├── refresh/route.ts      ← POST /api/auth/refresh
│   │   ├── forgot-password/      ← POST /api/auth/forgot-password
│   │   ├── reset-password/       ← POST /api/auth/reset-password
│   │   ├── switch-tenant/        ← POST /api/auth/switch-tenant
│   │   └── me/tenants/route.ts   ← GET /api/auth/me/tenants
│   │
│   ├── agro/
│   │   └── [tenant]/             ← Tenant-specific APIs
│   │       ├── forms/
│   │       │   ├── route.ts      ← GET/POST/PUT/DELETE forms
│   │       │   └── [formId]/
│   │       │       ├── submissions/route.ts ← GET submissions
│   │       │       └── submit/route.ts ← POST form submission
│   │       └── ...other endpoints
│   │
│   └── admin/
│       └── create-test-users/    ← POST to create test users
│
├── dpwai/                        ← Tenant-scoped pages
│   └── [tenant_snake]/
│       ├── layout.tsx            ← App layout (header, sidebar)
│       ├── page.tsx              ← Dashboard
│       ├── account/              ← User account settings
│       ├── forms/                ← Form management
│       │   ├── page.tsx          ← List forms
│       │   ├── [formId]/
│       │   │   ├── builder/      ← Form builder page
│       │   │   └── records/      ← Form submissions
│       │   └── ...
│       └── ...more pages
│
├── login/                        ← Public auth pages
│   ├── page.tsx
│   └── layout.tsx
│
├── forgot-password/
│   └── page.tsx
│
├── reset-password/
│   └── page.tsx
│
├── page.tsx                      ← Root page (/)
│   └─> Redirects to /login
│
└── layout.tsx                    ← Root layout (all pages)
    └─> Providers (Theme, Language, etc.)
```

### `/dpwaiagro/components/` - Reusable UI Components

```
components/
├── FormBuilder/                  ← Form builder UI (18 files)
│   ├── FormBuilderLayout.tsx     ← 3-column layout
│   ├── QuestionCard.tsx          ← Draggable question
│   ├── FormPreview.tsx           ← Live preview
│   ├── PropertiesPanel.tsx       ← Properties editor
│   └── QuestionTypes/
│       ├── BaseQuestion.tsx      ← Base class
│       ├── ShortAnswer.tsx
│       ├── Paragraph.tsx
│       ├── MultipleChoice.tsx
│       ├── Checkboxes.tsx
│       ├── Dropdown.tsx
│       ├── LinearScale.tsx
│       ├── DateQuestion.tsx
│       ├── TimeQuestion.tsx
│       ├── FileUpload.tsx
│       ├── Grid.tsx
│       └── index.ts              ← Component map
│
├── common/                       ← Reusable UI components
│   ├── Header.tsx
│   ├── Sidebar.tsx
│   ├── Button.tsx
│   ├── Input.tsx
│   ├── Card.tsx
│   └── ...
│
├── form/                         ← Form-specific components
│   ├── FormField.tsx
│   ├── FormError.tsx
│   └── ...
│
├── tables/                       ← Data table components
│   ├── DataTable.tsx
│   └── ...
│
├── ui/                           ← UI primitives
│   ├── Modal.tsx
│   ├── Select.tsx
│   ├── Checkbox.tsx
│   └── ...
│
├── providers/                    ← Context providers
│   ├── ThemeProvider.tsx
│   ├── LanguageProvider.tsx
│   └── ...
│
└── charts/                       ← Chart components
    └── ...
```

### `/dpwaiagro/lib/` - Utilities & Helpers

```
lib/
├── auth/                         ← Authentication utilities
│   ├── session.ts               ← JWT token handling
│   ├── password.ts              ← Password hashing
│   └── ...
│
├── formEngine/                   ← Form versioning & field management
│   ├── fieldIds.ts              ← UUID field ID system
│   ├── versioning.ts            ← Version tracking
│   └── ...
│
├── email/                        ← Email service
│   ├── resend.ts               ← Resend API integration
│   └── templates.ts             ← Email templates
│
├── i18n/                         ← Internationalization
│   ├── LanguageContext.tsx      ← Language state (default: pt)
│   ├── translations.ts          ← All translation keys
│   └── useLanguage.ts           ← Hook to use translations
│
└── __tests__/                    ← Unit tests
    ├── dashboard-tokens.test.ts
    └── url-validation.test.ts
```

### `/dpwaiagro/prisma/` - Database Schema & Migrations

```
prisma/
├── schema.prisma                 ← Prisma schema definition
│   ├── User model               ← Users
│   ├── Tenant model             ← Organizations
│   ├── Membership model         ← User-Tenant relationship
│   ├── Form model               ← Form definitions
│   ├── FormVersion model        ← Form versions (immutable)
│   ├── FormSubmission model     ← User submissions
│   ├── PasswordResetToken       ← Password reset tokens
│   └── ... custom models
│
├── migrations/                   ← Migration files (version controlled)
│   ├── 0_enable_rls_org_security/
│   ├── 1_populate_org_id/
│   └── ... numbered migrations
│
└── seed.ts                       ← Database seeding script
```

### `/scripts/` - Automation Scripts

```
scripts/
├── dev/                          ← Development helpers
│   ├── go.sh                    ← Start dev server
│   ├── install-deps.sh          ← Install dependencies
│   ├── build-now.sh             ← Build project
│   └── restart.sh               ← Restart server
│
├── db/                           ← Database scripts
│   ├── migrate.sh               ← Run migrations
│   └── run-migration.sh         ← Named migration runner
│
├── deploy/                       ← Deployment scripts
│   └── final.sh                 ← Final build & deploy
│
├── tools/                        ← Utility scripts
│   ├── test-flow.ts             ← Automated test suite
│   ├── create-test-users.ts     ← Create test users
│   ├── migrate-field-ids.ts     ← Field ID migration
│   ├── test-password-reset.ts   ← Password reset tests
│   ├── audit-comprehensive.mjs  ← Code audit
│   ├── check-admin.mjs          ← Admin endpoint check
│   └── tmux-ai-framework.sh     ← AI session manager
│
└── archive/                      ← Old scripts
```

---

## 🔐 Authentication Flow (Detailed)

### 1. Login Process

```typescript
// Frontend: /dpwaiagro/components/auth/LoginForm.tsx
const handleLogin = async (email, password) => {
  const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });

  const { accessToken, user, tenant } = await response.json();
  localStorage.setItem('token', accessToken);
  setAuthContext(user);
  navigate('/dpwai/demo-tenant');
};

// Backend: /dpwaiagro/app/api/auth/login/route.ts
export async function POST(request: Request) {
  const { email, password } = await request.json();

  // Find user by email OR username
  const user = await prisma.user.findUnique({
    where: { email: email.includes('@') ? email : undefined },
    OR: [{ username: !email.includes('@') ? email : undefined }]
  });

  if (!user) return Response.json({ error: 'Not found' }, { status: 404 });

  // Verify password with bcrypt
  const passwordValid = await bcrypt.compare(password, user.passwordHash);
  if (!passwordValid) return Response.json({ error: 'Invalid' }, { status: 401 });

  // Get user's tenants
  const memberships = await prisma.membership.findMany({
    where: { userId: user.id },
    include: { tenant: true }
  });

  // Create JWT token
  const token = jwt.sign(
    { userId: user.id, tenantId: memberships[0].tenantId },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );

  return Response.json({ accessToken: token, user, tenant: memberships[0].tenant });
}
```

### 2. Token Usage

```typescript
// Every subsequent request includes token:
const headers = {
  'Authorization': `Bearer ${localStorage.getItem('token')}`,
  'Content-Type': 'application/json'
};

// Backend middleware verifies token:
const token = request.headers.get('Authorization')?.split(' ')[1];
const decoded = jwt.verify(token, process.env.JWT_SECRET);
const userId = decoded.userId;
const tenantId = decoded.tenantId;

// Use userId & tenantId to:
// 1. Fetch user-specific data
// 2. Enforce tenant isolation (only access own tenant)
// 3. Log audit trail
```

---

## 📋 Database Relationships

### User & Tenant Relationship

```
User (1) ──────> Membership (M) ─────> Tenant (1)

One user can belong to multiple tenants (multi-tenant)
Each membership grants access to one tenant
Data is isolated by tenant at query level
```

### Form & Submission Relationship

```
Form (1) ─────> FormVersion (M)
                     │
                     └─> FormSubmission (M)

When form schema changes:
1. New FormVersion created automatically
2. Submission linked to specific FormVersion
3. Can view exactly what form user saw when they submitted
4. Complete form history & versioning preserved
```

### Complete Data Model

```
User
├─ id, email, username, passwordHash
├─ firstName, lastName, createdAt
└─ Membership* (one to many)

Tenant
├─ id, name, snake (lowercase slug)
├─ settings, createdAt
└─ Membership* (one to many)

Membership
├─ id, userId, tenantId
├─ role (Admin, User)
└─ timestamp (created)

Form
├─ id, tenantId, name, description
├─ schema (JSON of fields)
├─ status (ACTIVE, DRAFT, DELETED)
├─ currentVersionId
└─ FormVersion* (one to many)

FormVersion
├─ id, formId, versionNumber
├─ schema (JSON snapshot)
├─ createdAt
├─ changelog
└─ FormSubmission* (one to many)

FormSubmission
├─ id, formVersionId, userId, tenantId
├─ submittedData (JSON)
├─ metadata, submittedAt
└─ userId (who submitted)

PasswordResetToken
├─ id, userId, token
├─ expiresAt
└─ usedAt (null or timestamp)
```

---

## 🌍 Multi-Tenancy Implementation

### Tenant Isolation

```typescript
// Every query includes tenantId filter:

// Get forms for current tenant
const forms = await prisma.form.findMany({
  where: { tenantId: currentUsersTenantId },
  include: { FormVersion: true }
});

// User cannot access other tenant's forms
// Database enforces: form.tenantId === usersTenantId

// Middleware validates:
// 1. User has membership in requested tenant
// 2. Token's tenantId matches request
// 3. Resource's tenantId matches user's tenantId
```

### Tenant Switching

```
User in Header:
  ┌─────────────────────────────────┐
  │ Select Tenant Dropdown          │
  │ ◯ Demo Tenant (selected)        │
  │ ○ Farm Alpha                    │
  │ ○ Farm Beta                     │
  └─────────────────────────────────┘
       │
       └─> Click "Farm Alpha"
           └─> POST /api/auth/switch-tenant
               └─> Update token's tenantId
               └─> Redirect to /dpwai/farm-alpha
               └─> All queries now use farm-alpha context
```

---

## 🎨 Styling & Theming System

### Design Tokens

```typescript
// /dpwaiagro/tailwind.config.ts
// All colors defined in one place

theme: {
  colors: {
    primary: '#13ec37',           // Main brand color
    dark: {
      bg: '#102213',              // Dark background
      text: '#ffffff'
    },
    light: {
      bg: '#f6f8f6',              // Light background
      text: '#0a2540'
    }
  }
}

// Used in components:
<div className="bg-dark-bg text-dark-text dark:bg-dark-bg">
  // Dark mode by default (enforced in ThemeContext)
</div>
```

### Language System

```typescript
// /dpwaiagro/lib/i18n/translations.ts
const translations = {
  pt: {
    label: { email: 'Email', password: 'Senha', ... },
    ui: { submit: 'Enviar', cancel: 'Cancelar', ... },
    error: { notFound: 'Não encontrado', ... }
  },
  en: {
    label: { email: 'Email', password: 'Password', ... },
    ui: { submit: 'Submit', cancel: 'Cancel', ... },
    error: { notFound: 'Not found', ... }
  }
};

// Default: Portuguese (pt)
const [language, setLanguage] = useState('pt');

// Usage:
const label = translations[language].label.email;
// Result: "Email" (pt) or "Email" (en)
```

---

## 📊 Form Builder Internals

### Form Data Structure

```typescript
interface Form {
  id: string;
  tenantId: string;
  name: string;
  description: string;
  schema: FormSchema;
  currentVersionId: string;
}

interface FormSchema {
  fields: FormField[];
  settings: {
    confirmationMessage: string;
    redirectUrl?: string;
  };
}

interface FormField {
  id: string;                    // UUID (immutable)
  type: 'SHORT_ANSWER' | 'PARAGRAPH' | ... (11 types)
  label: string;
  description?: string;
  required: boolean;
  helpText?: string;
  options?: Array<{ label: string, value: string }>;
  validation?: ValidationRules;
  conditionalLogic?: {
    show?: LogicRule[];
    disable?: LogicRule[];
  };
}

// When form is updated:
// 1. Calculate hash of new schema
// 2. Compare with current version
// 3. If different: Create new FormVersion
// 4. Old submissions still linked to old version
// 5. New submissions link to new version
```

### Field ID System

```typescript
// Immutable UUIDs ensure:
// - Field keeps same ID even if label changes
// - Submissions reference by stable ID
// - Form history is trackable
// - No data loss on renames

// Example:
// v1: { id: 'uuid-123', label: 'Name' }
// v2: { id: 'uuid-123', label: 'Full Name' }  ← Same ID!
// Submissions always reference 'uuid-123'
```

---

## 🔄 Data Flow Summary

```
User Action
    │
    ├─> Browser Event (onClick, onChange)
    │   └─> React State Update
    │
    ├─> Component Re-renders
    │   └─> User sees updated UI
    │
    └─> API Call (if needed)
        └─> POST /api/path with data
        └─> Backend validates & processes
        └─> Queries database
        └─> Returns response
        └─> Frontend updates state
        └─> UI reflects server response
```

---

## ⚙️ Environment Variables

Critical variables for operation:

```env
# Database
DATABASE_URL=postgresql://...      # Neon connection string

# JWT
JWT_SECRET=random-secret-key       # Sign JWT tokens

# Email
RESEND_API_KEY=re_...              # Resend API key

# Optional
NEXT_PUBLIC_API_URL=http://...     # For API calls
VERCEL_ENV=production              # Deployment env
```

All vars set in:
- Local: `.env.local`
- Production: Vercel dashboard
- Staging: Vercel preview environment

---

## 🚀 Performance Optimizations

### Frontend
- Code splitting (Next.js automatic)
- Image optimization
- CSS minification
- React lazy loading
- Context memoization

### Backend
- Database connection pooling
- Query optimization
- Response caching
- Compression
- Rate limiting

### Database
- Indexed queries
- Denormalized data where needed
- Pagination for large datasets
- Connection pooling (Neon)

---

## 📖 Read Next

- **Setup**: `/knowledge/01-setup-local/QUICK-START.md`
- **Architecture**: `/knowledge/00-overview/ARCHITECTURE.md`
- **Form Builder**: `/knowledge/02-frontend/FORMS-BUILDER.md`
- **Deployment**: `/knowledge/06-deploy/DEPLOYMENT-OVERVIEW.md`

---

**Last Updated**: 25 January 2026
**Maintained By**: Claude Code
**Purpose**: Understanding the codebase structure and data flow
