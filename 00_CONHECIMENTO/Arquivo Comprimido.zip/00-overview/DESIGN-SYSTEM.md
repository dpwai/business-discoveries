# DPWAI Design System - Quick Reference Card

**Bookmark this file for instant access to design tokens and patterns!**

---

## 🎨 Color Tokens (Most Used)

```css
--color-primary: #0A2540;           /* Main brand color */
--color-accent: #00B3FF;            /* Secondary/accent color */
--color-success: #10b981;           /* Success states */
--color-warning: #f59e0b;           /* Warnings */
--color-danger: #ef4444;            /* Errors/destructive */
--color-text-0: #0a0e1a;            /* Primary text */
--color-text-muted: #8899aa;        /* Disabled/hints */
--color-surface-0: #ffffff;         /* Card backgrounds */
--color-bg-1: #f8fbfd;              /* Page background */
--color-border-1: rgba(10, 14, 26, 0.12);  /* Subtle border */
```

## 📏 Spacing (4px base unit)

```css
--spacing-1: 4px     --spacing-4: 16px      --spacing-8: 32px
--spacing-2: 8px     --spacing-5: 20px      --spacing-10: 40px
--spacing-3: 12px    --spacing-6: 24px      --spacing-12: 48px
```

**Common Usage**:
- Padding: `--spacing-4` (16px)
- Section gap: `--spacing-6` (24px)
- Button padding: `--spacing-3` vertically, `--spacing-4` horizontally

## 🔘 Border Radius (Friendly)

```css
--radius-sm: 6px        /* Buttons, inputs */
--radius-md: 8px        /* Medium elements */
--radius-lg: 12px       /* Cards, panels (DEFAULT) */
--radius-xl: 16px       /* Large sections */
--radius-pill: 9999px   /* Fully rounded */
```

## 🌑 Shadows (3D Depth)

```css
--shadow-sm: 0 2px 4px rgba(...)        /* Small lift */
--shadow-md: 0 4px 12px rgba(...)       /* Card (DEFAULT) */
--shadow-lg: 0 12px 24px rgba(...)      /* Modal/dropdown */
--shadow-xl: 0 20px 40px rgba(...)      /* Large modal */
--shadow-glow: 0 0 0 3px rgba(0, 179, 255, 0.1) /* Focus */
```

## ⏱️ Motion (Keep It Fast!)

```css
--duration-micro: 90ms      /* Very fast - icon clicks */
--duration-fast: 140ms      /* Fast - button presses (DEFAULT) */
--duration-base: 180ms      /* Standard transitions */
--duration-slow: 220ms      /* Slow - modals entering */

--easing-standard: cubic-bezier(0.4, 0, 0.2, 1)    /* Balanced */
--easing-out: cubic-bezier(0, 0, 0.2, 1)           /* Decelerate */
--easing-in: cubic-bezier(0.4, 0, 1, 1)            /* Accelerate */
```

---

## 🔘 Button Classes (Ready to Use!)

### Primary (Main actions)
```jsx
<button className="btn-primary">Click Me</button>
```
- Colors: Dark navy on white, cyan on hover
- States: Lift (-2px) on hover, press on active, 50% opacity when disabled

### Secondary (Alternative actions)
```jsx
<button className="btn-secondary">Cancel</button>
```
- Colors: Light surface with border, darker on hover
- States: Same hover/active as primary

### Danger (Destructive actions)
```jsx
<button className="btn-danger">Delete</button>
```
- Colors: Red background, darker red on hover

---

## 🎴 Card Class

```jsx
<div className="card">
  <h3>Card Title</h3>
  <p>Card content</p>
</div>
```
- ✅ White surface + border + shadow + top highlight
- ✅ Hover lifts (-2px) + stronger shadow
- ✅ Automatically styled with 3D effect

---

## ✍️ Form Inputs

### Date Input
```jsx
<div className="custom-input-date">
  <input type="date" />
</div>
```

### Select Dropdown
```jsx
<select className="select-custom">
  <option>Option 1</option>
</select>
```

### Checkbox
```jsx
<input type="checkbox" className="taskCheckbox" />
```

---

## 🎬 Animation Classes (Plug & Play!)

### Entrance Animations
```jsx
<div className="animate-fade-in">Fades in</div>
<div className="animate-slide-in-up">Slides up</div>
<div className="animate-slide-in-left">Slides left</div>
<div className="animate-scale-in">Scales in</div>
<div className="animate-bounce-in">Bounces in</div>
```

### Exit Animations
```jsx
<div className="animate-fade-out">Fades out</div>
<div className="animate-slide-out-up">Slides up</div>
<div className="animate-slide-out-left">Slides left</div>
```

### Interactive Animations
```jsx
<div className="animate-pulse">Loading...</div>
<div className="animate-spin">Spinner</div>
<div className="animate-bounce">Attention</div>
<div className="animate-shake">Error shake</div>
<div className="animate-typing-dots">Typing...</div>
<div className="animate-glow-pulse">Focus glow</div>
<div className="animate-shimmer">Skeleton loader</div>
```

### Modal Animations
```jsx
<div className="animate-backdrop-in">Backdrop fades + blurs</div>
<div className="animate-modal-in">Modal scales in</div>
```

---

## 🎯 State Requirements (Every Interactive Element!)

### Button/Link States
```css
:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
:active { transform: translateY(0); box-shadow: var(--shadow-sm); }
:disabled { opacity: 0.5; cursor: not-allowed; }
:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 2px; }
```

### Form Input States
```css
:focus { border-color: var(--color-accent); box-shadow: var(--shadow-glow); }
:disabled { opacity: 0.5; background-color: var(--color-bg-2); }
```

---

## 📋 Common Patterns

### Card with Button
```jsx
<div className="card">
  <h3>Title</h3>
  <p>Content</p>
  <button className="btn-primary">Action</button>
</div>
```

### Modal with Animations
```jsx
<div className="animate-backdrop-in">
  <div className="modal-backdrop">
    <div className="animate-modal-in">
      <div className="modal-content">
        <h2>Modal Title</h2>
        <button className="btn-secondary">Close</button>
      </div>
    </div>
  </div>
</div>
```

### Loading State
```jsx
<div className="animate-pulse">Loading...</div>
<div className="animate-shimmer">Skeleton</div>
```

### Error Message
```jsx
<div className="animate-shake">
  <input className="input-error" />
  <p style={{ color: 'var(--color-danger)' }}>Error message</p>
</div>
```

---

## 🚀 Usage in React

### CSS-in-JS (Styled Components)
```javascript
const MyButton = styled.button`
  background-color: var(--color-primary);
  color: white;
  padding: var(--spacing-3) var(--spacing-4);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-sm);
  border: none;
  cursor: pointer;
  transition: all var(--duration-fast) var(--easing-standard);

  &:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
  }

  &:active {
    transform: translateY(0);
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;
```

### Tailwind CSS
```jsx
<button className="px-4 py-3 rounded-md font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-all hover:shadow-md active:shadow-sm disabled:opacity-50">
  Click
</button>
```

### Inline Styles with Tokens
```jsx
<div style={{
  backgroundColor: 'var(--color-surface-0)',
  padding: 'var(--spacing-4)',
  borderRadius: 'var(--radius-md)',
  boxShadow: 'var(--shadow-sm)',
  transition: `all var(--duration-fast) var(--easing-standard)`
}}>
  Content
</div>
```

---

## 💾 Copy-Paste Snippets

### Basic Card Component
```jsx
export function CardComponent() {
  return (
    <div className="card" style={{ padding: 'var(--spacing-6)' }}>
      <h3 style={{ marginBottom: 'var(--spacing-3)' }}>Title</h3>
      <p style={{ color: 'var(--color-text-1)', marginBottom: 'var(--spacing-4)' }}>
        Content goes here
      </p>
      <button className="btn-primary">Action</button>
    </div>
  );
}
```

### Loading Spinner
```jsx
<div className="animate-spin" style={{
  width: '32px',
  height: '32px',
  border: '3px solid var(--color-border-1)',
  borderTop: '3px solid var(--color-accent)',
  borderRadius: 'var(--radius-pill)'
}} />
```

### Form Group
```jsx
<div style={{ marginBottom: 'var(--spacing-6)' }}>
  <label style={{ fontSize: 'var(--font-size-sm)', fontWeight: 'var(--font-weight-semibold)', marginBottom: 'var(--spacing-2)' }}>
    Label
  </label>
  <input
    type="text"
    className="custom-input-date"
    placeholder="Enter text..."
  />
</div>
```

### Empty State
```jsx
<div style={{
  textAlign: 'center',
  padding: 'var(--spacing-12)',
  backgroundColor: 'var(--color-surface-1)',
  borderRadius: 'var(--radius-lg)',
  border: '2px dashed var(--color-border-1)'
}}>
  <div style={{ fontSize: '32px', marginBottom: 'var(--spacing-2)' }}>📭</div>
  <h3 style={{ marginBottom: 'var(--spacing-1)' }}>No items</h3>
  <p style={{ color: 'var(--color-text-muted)' }}>You don't have any items yet</p>
</div>
```

---

## ✅ Checklist Before Shipping

- [ ] Used design tokens for ALL colors (no hardcoded hex)
- [ ] Used spacing scale for ALL padding/margins (no random sizes)
- [ ] Added hover state (lift + shadow or color change)
- [ ] Added active state (press effect)
- [ ] Added disabled state (50% opacity)
- [ ] Added focus state (outline + glow)
- [ ] Used proper border radius (radius-md or radius-lg default)
- [ ] Used appropriate shadow (shadow-sm for small, shadow-md for cards)
- [ ] Mobile-first responsive design
- [ ] Tested with `prefers-reduced-motion` enabled
- [ ] Checked WCAG AA contrast ratio
- [ ] Keyboard navigation works

---

## 🆘 Quick Troubleshooting

| Problem | Solution |
|---------|----------|
| Button doesn't look right | Use `.btn-primary`, `.btn-secondary`, or `.btn-danger` class |
| Color doesn't match | Use `var(--color-*)` instead of hardcoded hex |
| Spacing looks off | Use `var(--spacing-*)` instead of px values |
| Shadow too subtle | Use `var(--shadow-md)` or `var(--shadow-lg)` |
| Animation too slow | Use `var(--duration-fast)` (140ms) or `var(--duration-base)` (180ms) |
| Focus ring missing | Add `:focus-visible { outline: 2px solid var(--color-accent); }` |

---

## 📚 Full Documentation

- **`DESIGN_SYSTEM.md`** - Complete reference guide (500+ lines)
- **`app/design-tokens.css`** - All tokens source (350 lines)
- **`app/design-animations.css`** - All animations source (280 lines)
- **`app/globals.css`** - Component styles source

---

## 🎯 Remember

✅ **Always use tokens** - Never hardcode colors, spacing, shadows
✅ **All interactive elements need states** - Hover, active, disabled, focus
✅ **Use animation classes** - `.animate-*` for entrance/exit/interaction
✅ **Semantic naming** - `--color-primary` not `--color-blue`
✅ **Consistent spacing** - Multiples of 4px (spacing scale)
✅ **Professional polish** - Shadows, highlights, smooth transitions
✅ **Accessibility first** - Focus rings, contrast, keyboard nav
✅ **Mobile-first design** - Design for small screens first

---

**Keep this file handy!** Bookmark or print for quick reference while coding.

**Last Updated**: January 2026
**Status**: Production Ready ✅
