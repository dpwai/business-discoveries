# 📋 Forms Design Guide for Agricultural Operations

**Specific form designs for DPWAI Agro to support farm operations**

**Status**: 🟢 Ready to implement
**Date**: 25 January 2026

---

## Overview

For the farm to use DPWAI Agro effectively, create these 12 core forms. Each uses platform form builder with available field types.

---

## 🌾 GROUP 1: CROP MANAGEMENT (4 forms)

### Form 1.1: Crop Ledger (Reference Data)
**Purpose**: Master record for each crop/plot
**Frequency**: Created once per planting season
**User**: Farm manager

**Fields**:
```
1. Crop Type (SELECT)
   Options: Soja, Milho, Feijão, Trigo, Gado de Corte

2. Gleba/Plot Number (SHORT_ANSWER)
   Example: "Gleba A1", "Field 42"

3. Hectares Planted (NUMBER)
   Example: 250.50

4. Planting Date (DATE_PICKER)

5. Expected Harvest Date (DATE_PICKER)

6. Target Yield (NUMBER)
   Example: 48 (for Soja in bags/hectare)

7. Seed Variety (SHORT_ANSWER)
   Example: "BMX Potencia RR"

8. Supplier (DROPDOWN)
   Options: Select from supply list

9. Soil Analysis Results (FILE_UPLOAD)
   Optional: Attach lab results

10. Notes (LONG_ANSWER)
    Optional field notes
```

**Data Usage**:
- Link all costs/activities to this crop record
- Track yield against target
- Calculate ROI per crop

---

### Form 1.2: Fertilizer Application Log
**Purpose**: Track every fertilizer application
**Frequency**: Multiple times per crop cycle
**User**: Field supervisor or equipment operator

**Fields**:
```
1. Crop Ledger Link (DROPDOWN)
   Show: Crop type + Gleba

2. Fertilizer Type (DROPDOWN)
   Options: [dynamically from supply]
   Example: "NPK 00-20-20", "MAP", "Uréia"

3. Application Date (DATE_PICKER)

4. Quantity Applied (NUMBER)
   Unit: kg or liters (depends on type)
   Example: 250.5

5. Application Method (SELECT)
   Options:
   - Planter (na linhas)
   - Ground Spreader (espalhador)
   - Aerial (aéreo)
   - Top Dressing (cobertura)

6. Equipment Used (DROPDOWN)
   Link to equipment master

7. Cost per Unit (CURRENCY)
   R$ per kg or liter

8. Total Cost (CALCULATED)
   Quantity × Cost per Unit

9. Weather Conditions (SELECT)
   Options: Clear, Cloudy, Light rain, Heavy rain

10. Operator Name (DROPDOWN)
    Select from staff list

11. Notes (LONG_ANSWER)
    Issues, adjustments, observations

12. Photo (FILE_UPLOAD)
    Evidence of application
```

**Data Usage**:
- Build fertilizer cost per crop
- Track application history
- Link to yield for effectiveness analysis

---

### Form 1.3: Pesticide Application Log
**Purpose**: Track herbicide/fungicide/insecticide applications
**Frequency**: As needed (typically 3-5 times per crop)
**User**: Field supervisor

**Fields**:
```
1. Crop Ledger Link (DROPDOWN)

2. Pesticide Name (DROPDOWN)
   Linked to supply inventory

3. Application Date (DATE_PICKER)

4. Quantity Applied (NUMBER)
   Unit: liters or kg

5. Target Pest/Disease (SELECT)
   Options:
   - Weeds (Invasoras)
   - Fungal Disease
   - Insect Pest
   - Other

6. Pest/Disease Name (SHORT_ANSWER)
   Example: "Ferrugem da soja", "Lagarta"

7. Equipment Used (DROPDOWN)

8. Application Method (SELECT)
   Options: Sprayer, Boom, Aerial, Granule

9. Cost per Unit (CURRENCY)

10. Total Cost (CALCULATED)

11. Weather Conditions (SELECT)

12. Compliance Notes (LONG_ANSWER)
    Restrictions, withholding period

13. Operator (DROPDOWN)

14. Photo (FILE_UPLOAD)
```

---

### Form 1.4: Harvest Record
**Purpose**: Document yield and harvest data
**Frequency**: Once per crop per season
**User**: Farm manager

**Fields**:
```
1. Crop Ledger Link (DROPDOWN)

2. Harvest Date (DATE_PICKER)

3. Actual Yield (NUMBER)
   Bags/hectare or tons/hectare

4. Total Quantity Harvested (NUMBER)
   Total bags or tons from gleba

5. Equipment Used (DROPDOWN)
   Usually combine harvester

6. Hours Spent (NUMBER)
   Equipment hours used

7. Operator (DROPDOWN)

8. Cost of Harvest (CURRENCY)
   Fuel, labor, contractor

9. Grain Quality (SELECT)
   Options: Excellent, Good, Fair, Poor

10. Moisture Content (NUMBER)
    % (usually 12-14%)

11. Storage Location (SHORT_ANSWER)
    Silo name or bin

12. Sale Price (CURRENCY)
    R$ per bag/ton

13. Total Revenue (CALCULATED)
    Yield × Price

14. Profit (CALCULATED)
    Revenue - Total Crop Cost

15. Notes (LONG_ANSWER)
    Weather issues, equipment problems

16. Photos (FILE_UPLOAD)
    Harvest documentation
```

**Dashboard Usage**: Show profit per crop, yield vs target, ROI

---

## 🚜 GROUP 2: EQUIPMENT MANAGEMENT (3 forms)

### Form 2.1: Equipment Master Record
**Purpose**: Reference data for each piece of equipment
**Frequency**: Created once per equipment, updated yearly
**User**: Equipment manager

**Fields**:
```
1. Equipment Name (SHORT_ANSWER)
   Example: "Trator Verde 1", "Colhedora 2"

2. Equipment Type (SELECT)
   Options: Tractor, Planter, Sprayer, Harvester, Pump, Other

3. Brand/Manufacturer (DROPDOWN)
   Options: John Deere, AGCO, Claas, etc.

4. Model (SHORT_ANSWER)
   Example: "John Deere 6250R"

5. Year of Manufacture (NUMBER)

6. VIN/Serial Number (SHORT_ANSWER)
   Important for John Deere tracking

7. Purchase Date (DATE_PICKER)

8. Purchase Price (CURRENCY)
   R$

9. Current Hours (NUMBER)
   Odometer reading

10. Fuel Type (SELECT)
    Options: Diesel, Gasoline, Electric

11. Fuel Tank Capacity (NUMBER)
    Liters

12. Operator(s) (DROPDOWN_MULTI)
    Select authorized users

13. Maintenance Schedule (LONG_ANSWER)
    Link to OEM recommendations

14. John Deere Connected ID (SHORT_ANSWER)
    Optional: for IoT integration

15. Photo (FILE_UPLOAD)
    Equipment image
```

---

### Form 2.2: Equipment Usage Log
**Purpose**: Track daily/weekly equipment usage
**Frequency**: After every use
**User**: Equipment operator

**Fields**:
```
1. Equipment (DROPDOWN)
   Link to equipment master

2. Date (DATE_PICKER)

3. Start Hours (NUMBER)
   Odometer at start

4. End Hours (NUMBER)
   Odometer at end

5. Hours Used (CALCULATED)
   End - Start

6. Crop/Activity (DROPDOWN)
   Link to crop ledger or activity

7. Fuel Consumed (NUMBER)
   Liters (can be calculated from hours)

8. Fuel Cost (CURRENCY)
   Total cost

9. Distance Traveled (NUMBER)
   km (if applicable)

10. Operator Name (DROPDOWN)

11. Condition at End (SELECT)
    Options: Excellent, Good, Fair, Issues

12. Issues Found (LONG_ANSWER)
    What needs repair/maintenance

13. Notes (LONG_ANSWER)
    Any problems or observations

14. Photo (FILE_UPLOAD)
    If damage noted
```

**Dashboard Usage**: Track total hours/fuel per equipment, maintenance due dates

---

### Form 2.3: Maintenance & Repair Log
**Purpose**: Document all maintenance and repairs
**Frequency**: As maintenance occurs
**User**: Equipment manager or technician

**Fields**:
```
1. Equipment (DROPDOWN)

2. Maintenance Type (SELECT)
   Options:
   - Scheduled Maintenance
   - Oil Change
   - Filter Change
   - Belt/Hose
   - Repair
   - Inspection
   - Other

3. Date (DATE_PICKER)

4. Hours at Service (NUMBER)
   Equipment odometer

5. Description (LONG_ANSWER)
   What was done

6. Parts Replaced (LONG_ANSWER)
   List of parts

7. Service Provider (DROPDOWN)
   Options: In-house, John Deere dealer, Other contractor

8. Cost (CURRENCY)
   Total maintenance cost

9. Parts Cost (CURRENCY)
   Breakdown

10. Labor Cost (CURRENCY)
    Breakdown

11. Labor Hours (NUMBER)

12. Next Service Due (DATE_PICKER)
    Scheduled next maintenance

13. Status (SELECT)
    Options: Completed, In Progress, Pending

14. Notes (LONG_ANSWER)
    Issues found, recommendations

15. Receipts/Invoices (FILE_UPLOAD)
    Attach documentation
```

**Alert Logic**:
- When equipment hours reach "Next Service Due" hours
- System should notify equipment manager
- Create task for maintenance scheduling

---

## 💰 GROUP 3: FINANCIAL TRACKING (2 forms)

### Form 3.1: Direct Cost Entry
**Purpose**: Record all variable costs per crop
**Frequency**: As expenses occur
**User**: Farm accountant or manager

**Fields**:
```
1. Crop Ledger Link (DROPDOWN)
   Which crop this cost belongs to

2. Cost Category (DROPDOWN)
   Options:
   - Seeds
   - Fertilizers
   - Pesticides
   - Fuel
   - Labor
   - Equipment Rental
   - Contractor Services
   - Other Direct

3. Description (SHORT_ANSWER)
   Specific item purchased

4. Date (DATE_PICKER)
   When expense occurred

5. Supplier (DROPDOWN)
   Castrolanda, local supplier, contractor, etc.

6. Invoice Number (SHORT_ANSWER)

7. Quantity (NUMBER)
   Amount purchased

8. Unit (SELECT)
   Options: kg, L, Hours, Services, Other

9. Unit Price (CURRENCY)
   R$ per unit

10. Total Amount (CALCULATED)
    Quantity × Unit Price

11. Payment Method (SELECT)
    Options: Cash, Check, Credit, Deferred

12. Payment Status (SELECT)
    Options: Paid, Pending, Partial

13. Due Date (DATE_PICKER)

14. Notes (LONG_ANSWER)
    Reference to equipment, conditions, etc.

15. Attachment (FILE_UPLOAD)
    Invoice, receipt, contract
```

**Dashboard Usage**: Sum costs by category per crop → Cost per hectare

---

### Form 3.2: Fixed Cost Allocation
**Purpose**: Track fixed costs (land, equipment depreciation, insurance)
**Frequency**: Monthly
**User**: Farm accountant

**Fields**:
```
1. Cost Type (SELECT)
   Options:
   - Land Rent/Mortgage
   - Equipment Depreciation
   - Insurance
   - Property Tax
   - Administration
   - Storage/Silo
   - Interest on Debt
   - Other Fixed

2. Description (SHORT_ANSWER)

3. Month (DATE_PICKER)
   Select month for cost

4. Amount (CURRENCY)
   Total fixed cost

5. Allocation Method (SELECT)
   How to spread across crops:
   - By Hectares
   - By Revenue
   - Equal Split
   - Manual

6. Crop(s) Affected (DROPDOWN_MULTI)
   Which crops share this cost

7. Reference Document (SHORT_ANSWER)
   Insurance policy, deed, etc.

8. Notes (LONG_ANSWER)
    Explanation and calculation basis

9. Attachment (FILE_UPLOAD)
    Supporting document
```

**Dashboard Logic**: Allocate fixed costs to crops → Complete cost picture

---

## 👥 GROUP 4: LABOR MANAGEMENT (2 forms)

### Form 4.1: Labor Activity Log
**Purpose**: Track daily work and hours
**Frequency**: Daily
**User**: Field supervisor or worker

**Fields**:
```
1. Employee (DROPDOWN)

2. Date (DATE_PICKER)

3. Activity (SELECT)
   Options:
   - Planting
   - Fertilizer Application
   - Spraying
   - Harvesting
   - Equipment Maintenance
   - General Labor
   - Training
   - Other

4. Crop/Equipment Link (DROPDOWN)
   What were they working on

5. Start Time (TIME_PICKER)

6. End Time (TIME_PICKER)

7. Hours (CALCULATED)
   End - Start

8. Location/Field (DROPDOWN)

9. Supervisor Approval (SELECT)
   Options: Approved, Pending, Revision

10. Weather Conditions (SELECT)

11. Productivity Notes (LONG_ANSWER)
    How much was accomplished

12. Issues Encountered (LONG_ANSWER)
    Problems during work

13. Photo/Evidence (FILE_UPLOAD)
    Optional documentation
```

---

### Form 4.2: Payroll Entry
**Purpose**: Record wages and payments
**Frequency**: Weekly or bi-weekly
**User**: HR/Accountant

**Fields**:
```
1. Employee (DROPDOWN)

2. Pay Period (DATE_PICKER)
   Start and end dates

3. Total Hours Worked (NUMBER)
   Sum from labor logs

4. Base Hourly Rate (CURRENCY)
   R$ per hour

5. Regular Hours (NUMBER)
   Hours at base rate

6. Overtime Hours (NUMBER)
   Hours at 1.5x

7. Overtime Rate (CURRENCY)

8. Gross Wages (CALCULATED)
   (Regular × Base) + (Overtime × Rate)

9. Deductions (CURRENCY)
   Tax, insurance, etc.

10. Net Wages (CALCULATED)
    Gross - Deductions

11. Payment Method (SELECT)
    Cash, Bank Transfer, Check

12. Payment Date (DATE_PICKER)

13. Status (SELECT)
    Pending, Completed, Cancelled

14. Notes (LONG_ANSWER)
    Bonuses, special payments, etc.

15. Approval (SELECT)
    Manager signed off
```

---

## 📦 GROUP 5: SUPPLY CHAIN (1 form)

### Form 5.1: Inventory & Purchase Tracking
**Purpose**: Track insumos stock and orders
**Frequency**: As purchases occur
**User**: Supply manager

**Fields**:
```
1. Item Type (SELECT)
   Options: Fertilizer, Seed, Pesticide, Fuel, Other

2. Product Name (DROPDOWN)
   Linked to supply database

3. Supplier (DROPDOWN)
   Castrolanda, vendors, etc.

4. Purchase Date (DATE_PICKER)

5. Quantity Purchased (NUMBER)

6. Unit (SELECT)
   kg, L, bags, etc.

7. Unit Price (CURRENCY)

8. Total Cost (CALCULATED)

9. Invoice Number (SHORT_ANSWER)

10. Expected Delivery (DATE_PICKER)

11. Actual Delivery (DATE_PICKER)

12. Quantity Received (NUMBER)

13. Quality Check (SELECT)
    Options: OK, Damaged, Incorrect, Partial

14. Storage Location (DROPDOWN)
    Warehouse A, Silo B, etc.

15. Current Stock (NUMBER)
    After receiving

16. Reorder Level (NUMBER)
    Alert when below this

17. Attachment (FILE_UPLOAD)
    Invoice, delivery note
```

---

## 🎯 Implementation Priority

### Phase 1 (Week 1): Core Forms
1. ✅ Crop Ledger (1.1)
2. ✅ Equipment Master (2.1)
3. ✅ Direct Cost Entry (3.1)
4. ✅ Labor Activity Log (4.1)

### Phase 2 (Week 2): Operational Forms
5. ✅ Fertilizer Application (1.2)
6. ✅ Equipment Usage Log (2.2)
7. ✅ Payroll Entry (4.2)
8. ✅ Maintenance Log (2.3)

### Phase 3 (Week 3): Supporting Forms
9. ✅ Pesticide Application (1.3)
10. ✅ Harvest Record (1.4)
11. ✅ Fixed Cost Allocation (3.2)
12. ✅ Inventory Tracking (5.1)

---

## 📊 Dashboard Queries

Once forms are in place, these queries power dashboards:

### Cost Dashboard
```sql
SELECT
  crop_type,
  SUM(amount) as total_cost,
  SUM(amount) / hectares as cost_per_hectare
FROM direct_costs
WHERE crop_id = $1
GROUP BY crop_type
```

### Equipment Dashboard
```sql
SELECT
  equipment_name,
  SUM(hours_used) as total_hours,
  SUM(fuel_cost) as total_fuel_cost,
  COUNT(maintenance_logs) as maintenance_count
FROM equipment_usage
LEFT JOIN maintenance_logs
WHERE date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)
GROUP BY equipment_name
```

### Labor Dashboard
```sql
SELECT
  employee_name,
  SUM(hours_worked) as total_hours,
  SUM(gross_wages) as total_wages,
  AVG(hours_per_day) as productivity
WHERE date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)
GROUP BY employee_name
```

### Profitability Dashboard
```sql
SELECT
  crop_type,
  SUM(revenue) - SUM(direct_costs) - SUM(allocated_fixed_costs) as profit,
  (profit / SUM(revenue)) * 100 as profit_margin
FROM harvest_records
LEFT JOIN direct_costs USING (crop_id)
LEFT JOIN fixed_cost_allocation USING (crop_id)
```

---

## 💡 Implementation Tips

1. **Start Simple**: Begin with basic fields, add complexity gradually
2. **Use Dropdowns**: Link costs → crops → harvest data for analysis
3. **Set Defaults**: Pre-fill equipment names, supplier names, categories
4. **Mobile First**: Test all forms on mobile (field workers will use phones)
5. **Bulk Upload**: Add Excel import for historical data (2+ years)
6. **Calculations**: Use form's calculated fields for cost totals
7. **Versioning**: Platform auto-creates new versions when schema changes (good for audit trail)

---

**Ready to implement**: 25 January 2026
**Prepared by**: Claude Code
**For**: DPWAI Agro Agricultural Platform
