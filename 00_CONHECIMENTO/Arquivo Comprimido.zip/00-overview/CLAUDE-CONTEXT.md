# CLAUDE.md - Design System & Project Context

## Project Overview
**DPWAI** (Deep Work AI) - A business automation consultancy platform combining workflow automation, AI assistants, and custom integrations.

Two main systems:
1. **DPWAI AGRO** - Agricultural management dashboard (current focus)
2. **Deep Work AI Flows** - Main website/consultancy landing page

---

## Design System

### Design Tokens & Philosophy

A design system robusto utiliza **design tokens** - valores padronizados para cores, espaçamentos, tipografia e efeitos visuais que servem como fonte única de verdade. Isso garante:
- **Consistência visual** em toda a aplicação
- **Escalabilidade** em mudanças globais (alterar a cor primária afeta toda a UI)
- **Manutenção facilitada** em equipes maiores
- **Implementação de temas** (light mode, dark mode) sem duplicação de código

Todos os valores abaixo estão centralizados em `tailwind.config.ts` e `globals.css` para fácil customização.

### Color Palette

#### DPWAI AGRO (Primary System)
- **Primary Green**: `#13ec37` - Main action color, CTAs, highlights
- **Dark Background**: `#102213` - Deep forest green for dark mode
- **Light Background**: `#f6f8f6` - Soft light green for light mode
- **Primary Dark**: `#0a150c` - Darker variant for depth
- **Text (Light Mode)**: `#0a2540` (slate-900 equivalent)
- **Text (Dark Mode)**: White/off-white
- **Borders/Accents**: rgba(19, 236, 55, 0.1) - Primary with transparency

#### Deep Work AI Flows (Website)
- **Primary**: `#0A2540` - Dark navy blue (main text and primary color)
- **Secondary**: `#00B3FF` - Bright cyan (CTAs, highlights, links)
- **Background**: `#FFFFFF` - White
- **Background Alt**: `#F5F5F7` - Light gray
- **Text**: `#0A2540` (primary dark)
- **Text Light**: `#425466` - Muted text
- **WhatsApp Green**: `#25D366` (for WhatsApp buttons)

#### Modern Color Patterns (2025)
- **Gradient Usage**: Preferred in hero sections and CTAs (linear gradients from primary to secondary or vibrant accents)
  - Example: `linear-gradient(135deg, #0A2540 0%, #00B3FF 100%)`
- **Vibrancy with Neutrals**: Use vibrant secondary colors sparingly for CTAs and highlights, surrounded by ample white space
- **Dark Mode**: Essential for both systems, adapting saturation and brightness while maintaining WCAG AA contrast (4.5:1 minimum)
- **Accent Colors**: Reserve neon/electric tones for UI elements that demand attention (primary CTA, important notifications)

### Typography

#### Fonts
- **DPWAI AGRO**:
  - Display/Primary: `Manrope` (sans-serif)
  - All text: `Manrope` (sans-serif)

- **Deep Work AI Flows**:
  - All text: `Montserrat` (sans-serif, weights: 400, 500, 600, 700)

#### Font Sizes (DPWAI AGRO)
- H1: 3.5rem (mobile: 2.5rem)
- H2: 2.5rem (mobile: 2rem)
- H3: 1.5rem
- Body: 1rem
- Small: 0.875rem
- Tiny: 0.75rem

### Border Radius
- Small: 0.25rem
- Medium: 0.5rem
- Large: 0.75rem
- XL: 1rem
- 2XL: 1.5rem (cards, modals)
- 3XL: 1.5rem (hero sections)
- Full: 9999px (circles, pills)

### Visual Effects

#### Glassmorphism (DPWAI AGRO)
```css
.glass-card {
  background: rgba(25, 51, 30, 0.6);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(19, 236, 55, 0.1);
}
```

#### Hero Gradient (DPWAI AGRO)
```css
.hero-gradient {
  background: linear-gradient(180deg,
    rgba(16, 34, 19, 0) 0%,
    rgba(16, 34, 19, 0.8) 80%,
    #102213 100%
  );
}
```

#### Primary Gradient (Deep Work AI Flows)
```css
.primary-gradient {
  background: linear-gradient(135deg,
    #0A2540 0%,
    #00B3FF 100%
  );
}
```

#### Interactive Effects
- **Hover States**: `-2px` transform (lift effect), opacity transitions
- **Active States**: `scale-95` (press effect) with smooth transitions
- **Focus States**: 1px ring with primary color (required for accessibility)
- **Disabled States**: `opacity-50` with reduced saturation
- **Animations**: Subtle easing transitions (ease-in-out) for professional feel, avoiding jarring changes

---

## Icon Libraries

### DPWAI AGRO
- **Material Symbols Outlined** - Primary icon set
- **Lucide React** - Alternative icons (Plus, ShieldCheck, ShieldOff, UserX, etc.)
- Custom SVG elements for animations (AgroFieldHero)

### Deep Work AI Flows (Website)
All icons are **Heroicons** (outline style):
- Settings/Gears: Cog icon (process automation)
- Robot/AI: Display icon (AI assistants)
- Integration: Link icon (custom integrations)
- WhatsApp: Standard WhatsApp SVG

Logo: Custom hand-drawn automation diagram with dual-gradient (cyan-to-blue gradient)

---

## Branding

### DPWAI AGRO
- **Logo**: Green gradient with organic shapes
- **Tagline**: "Farm Management System"
- **Tone**: Professional, technical, agricultural
- **Language**: Portuguese (pt-BR)

### Deep Work AI Flows
- **Brand Name**: DEEPWORK AI FLOWS
- **Logo**: Hand-drawn automation diagram (blue gradient)
- **Tagline**: "Automação Inteligente para Negócios Reais" (Intelligent Automation for Real Business)
- **Tone**: Consultative, sophisticated, results-focused
- **Language**: Portuguese (pt-BR) with i18n support
- **Call-to-Action**: WhatsApp contact (+55 42 99110955)

---

## UI Libraries & Modern Tech Stack

### Recommended Libraries

**Tailwind CSS** (Primary styling framework)
- Utility-first CSS with extensive class coverage
- Centralized configuration in `tailwind.config.ts`
- Responsive design via breakpoint prefixes (`sm:`, `md:`, `lg:`, etc.)
- Dark mode support through theme variants
- Excellent for building custom design systems without constraints

**Radix UI & shadcn/ui** (Component foundations)
- Radix UI: Unstyled, accessible components (modals, dropdowns, tooltips, etc.)
- shadcn/ui: Pre-styled components built on Radix + Tailwind, installed as source code in your project
- Key advantage: Full control over customization while maintaining accessibility best practices
- ARIA roles, keyboard navigation, and focus management handled automatically
- Perfect for building accessible landing pages and dashboards

**Material Symbols & Lucide React** (Icon libraries)
- Material Symbols (outlined): Professional, comprehensive icon set for DPWAI AGRO
- Lucide React: Clean, lightweight icons for specific use cases
- Heroicons: Used for Deep Work AI Flows website (outline style, consistent aesthetic)

### Design Tokens Implementation

Store all design decisions in centralized locations:
- **Colors**: Define semantic names (`primary`, `secondary`, `success`, `error`) rather than generic names
- **Spacing**: Use consistent multipliers (4px, 8px, 16px, etc.) to create predictable layouts
- **Typography**: Define font families, weights, and sizes as tokens for consistent application
- **Border Radius**: Standardize values (sm, md, lg, xl) across all components
- **Shadows**: Create depth with consistent shadow scales

---

## Component Patterns

### Buttons
```tsx
// Primary button (green/cyan)
<button className="px-6 py-3 bg-primary text-background-dark font-bold rounded-xl hover:bg-primary/90 active:scale-95 transition-all">
  Action
</button>

// Secondary/Ghost button
<button className="px-6 py-3 border border-primary/20 bg-primary/5 text-primary hover:bg-primary/15 rounded-xl transition-all">
  Secondary
</button>
```

### Cards
```tsx
// Glass card with border
<div className="glass-card rounded-2xl p-6 border border-white/10">
  Content
</div>
```

### Form Inputs
```tsx
// Premium input with primary focus
<input className="w-full px-4 py-3 rounded-xl border border-primary/20 bg-primary/5 dark:bg-primary/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all" />
```

### Labels
```tsx
// Premium label (all-caps, tracking)
<label className="text-xs font-bold text-primary uppercase tracking-widest mb-2">
  Field Name
</label>
```

### Hero Section
```tsx
// Landing page hero with strong visual hierarchy
<section className="py-20 px-6 text-center">
  <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
    Clear, compelling value proposition
  </h1>
  <p className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto">
    Concise subtitle explaining the benefit
  </p>
  <button className="bg-primary text-white px-8 py-4 rounded-xl font-bold hover:opacity-90 transition-all">
    Primary CTA
  </button>
</section>
```

### Feature Grid
```tsx
// Reusable features section with icons
<div className="grid md:grid-cols-3 gap-8 mt-12">
  {features.map((feature) => (
    <div key={feature.id} className="p-6 rounded-xl border border-primary/10 hover:border-primary/30 transition-all">
      <div className="text-4xl mb-4">{feature.icon}</div>
      <h3 className="text-lg font-bold mb-3">{feature.title}</h3>
      <p className="text-gray-600 text-sm">{feature.description}</p>
    </div>
  ))}
</div>
```

### Social Proof Section
```tsx
// Testimonials and trust signals
<section className="py-16 bg-gray-50 rounded-2xl">
  <h2 className="text-3xl font-bold text-center mb-12">Trusted by leading companies</h2>
  <div className="flex flex-wrap justify-center gap-12 mb-12">
    {logos.map((logo) => (
      <img key={logo.id} src={logo.src} alt={logo.name} className="h-8 opacity-60 hover:opacity-100 transition-opacity" />
    ))}
  </div>
  <div className="grid md:grid-cols-2 gap-8">
    {testimonials.map((testimonial) => (
      <div key={testimonial.id} className="p-6 bg-white rounded-xl shadow-sm">
        <div className="flex mb-4">⭐⭐⭐⭐⭐</div>
        <p className="text-gray-700 mb-4">"{testimonial.text}"</p>
        <div className="font-bold text-sm">{testimonial.author}</div>
      </div>
    ))}
  </div>
</section>
```

---

## Layout Guidelines

### Spacing Scale
- 0.25rem (1px) - Tiny gaps
- 0.5rem (2px) - Small gaps
- 1rem (4px) - Default
- 1.5rem (6px) - Medium
- 2rem (8px) - Large
- 4rem (16px) - XL
- 5rem (20px) - Section padding

### Container Widths
- Mobile: Full width with 1.5rem padding (24px safe area)
- Tablet: Up to 768px
- Desktop: 1200px max (--container-width)

### Responsive Breakpoints
- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

---

## Landing Page Best Practices

### UX for Conversion

**Clear Value Proposition & Visual Hierarchy**
- Visitor should understand the offering in seconds (above the fold)
- Use strong hierarchy: Large primary heading → Concise subtitle → Prominent CTA
- Ample whitespace directs attention to key elements
- Each section should have a clear focal point with breathing room around it

**Prominent & Focused CTAs**
- **Principle**: One primary CTA per landing page section
- **Visibility**: CTA must appear above fold and repeat at logical breakpoints (after benefits, before FAQ, in footer)
- **Copy**: Use action-oriented verbs ("Get Started", "Book a Demo", "Download Now") instead of generic labels
- **Styling**: Contrast with background, slightly larger size, hover effects that suggest interactivity

**Scannable Content**
- Users scan rather than read thoroughly - use bullet points, short sentences, clear subtitles
- Emphasize benefits over features ("Solve problem X quickly" vs. "Uses technology Y")
- Format with icons, spacing, and visual breaks to reduce cognitive load
- Keep paragraphs short and focused on value

**Social Proof & Trust Signals**
- Include customer testimonials (with names/photos when possible) near CTAs
- Display "Trusted by" logos of recognizable clients
- Show metrics ("1M+ users", "500+ companies") or certifications
- Position proof elements strategically throughout the page to reinforce credibility

**Familiar Layout & Reduced Friction**
- Follow established patterns: hero → features → proof → CTA → FAQ → footer
- Minimize navigation options (landing pages often omit full menus to prevent abandonment)
- Keep pathways to conversion clear and distraction-free
- Use consistent spacing and alignment for predictability

### Mobile-First & Responsive Design

- Start designs for mobile, then expand to larger screens
- Test on real devices at 3G/4G speeds (many users have slower connections)
- Ensure touch targets are at least 44x44px for easy tapping
- Use Tailwind responsive prefixes (`sm:`, `md:`, `lg:`) to adapt layouts fluidly
- Performance critical: Pages over 3 seconds load time see >50% bounce rate on mobile

### Accessibility (a11y) Requirements

**Semantic HTML & Keyboard Navigation**
- Use proper heading hierarchy (h1 → h2 → h3...) for screen reader structure
- All interactive elements must be keyboard accessible via Tab navigation
- Focus indicators must be clearly visible (never remove outlines without providing alternatives)
- Use `<button>` for buttons and `<a>` for links (no `<div>` as clickable elements)

**Color & Contrast**
- Maintain minimum 4.5:1 contrast ratio between text and background (WCAG AA standard)
- Never communicate info by color alone (add icons or text labels for status)
- Test color combinations in both light and dark modes

**Content Accessibility**
- Include descriptive `alt` text for all meaningful images
- Provide captions/transcripts for videos
- Use proper form labels (`<label>` associated with `<input>`)
- Apply ARIA roles/attributes when necessary (modal dialogs, live regions, etc.)

**Testing Tools**
- Use Axe DevTools or Lighthouse audits regularly
- Test with screen readers (NVDA, VoiceOver)
- Validate keyboard navigation flows manually

---

## Reference Examples

### High-Standard UI/UX Sites

**Linear.app** - Issue tracking SaaS
- Minimal, clean design with strategic color accents (purple/blue on neutral background)
- Uses Radix UI components for accessibility
- Strong visual hierarchy with ample whitespace
- Animated interactions enhance without distracting

**Vercel.com** - Frontend deployment platform
- Clear hero: "Deploy web projects with the best frontend developer experience"
- Visible social proof (Google, Uber, Slack logos)
- Subtle motion design on scroll reveals content
- Responsive, accessible, performant

**Cal.com** - Open-source scheduling tool
- Clean, minimal color palette (black, white, yellow accents)
- Uses shadcn/ui for UI components
- Strong mobile responsiveness
- Clear CTA flow (free signup at top and throughout page)

**Stripe.com** - Payment processing (reference for fintech design)
- Sophisticated gradient usage (purple/blue tones)
- Balance between technical content (for developers) and visual appeal
- Interactive diagrams that adapt to screen size
- Exemplary accessibility and keyboard navigation

---

## Authentication & Features

### Password Reset Flow (Resend Integration)
- Email sender: `noreply@dpwai.com.br`
- Token expiry: 30-60 minutes
- Hash: SHA256 (no plain tokens stored)
- Password hash: bcrypt (10+ rounds)
- Token is single-use (prevents replay attacks)

### API Endpoints
- `POST /api/auth/login` - Main login
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Complete password reset
- `POST /api/auth/switch-tenant` - Multi-tenant switching
- `GET /api/auth/me/tenants` - List user's tenants

### Database
- **ORM**: Prisma
- **Database**: PostgreSQL (Neon serverless)
- **Multi-tenancy**: Supported via memberships

---

## Project File Structure

```
/dpwaiagro
├── app/
│   ├── api/                           # API routes
│   │   ├── auth/                      # Authentication endpoints
│   │   ├── agro/[tenant]/            # Tenant-specific routes
│   │   └── ralph/                     # AI assistant routes
│   ├── dpwai/[tenant_snake]/          # Main app (protected)
│   │   ├── account/                   # User profile management
│   │   ├── users/                     # User management (admin)
│   │   ├── welcome/                   # Welcome page (premium design)
│   │   ├── dashboards/                # Data visualization
│   │   ├── forms/                     # Form management
│   │   ├── manual/                    # Manual form builder
│   │   └── ralph-chat/                # AI chat interface
│   ├── login/                         # Login page
│   ├── forgot-password/               # Password recovery
│   ├── reset-password/                # Password reset form
│   └── globals.css                    # Global styles + design tokens
├── components/
│   ├── PremiumWelcome.tsx            # Welcome page component
│   ├── AgroFieldHero.tsx             # Animated hero section
│   ├── ui/                            # Reusable UI components
│   └── auth/                          # Auth-related components
├── lib/
│   ├── auth/                          # Auth utilities
│   ├── prisma.ts                      # Prisma client
│   └── jwt.ts                         # JWT token handling
├── scripts/
│   └── test-password-reset.ts        # Automated testing script
├── prisma/
│   └── schema.prisma                  # Database schema
├── middleware.ts                       # Global middleware (auth protection)
├── tailwind.config.ts                 # Tailwind + custom theme
└── tsconfig.json                      # TypeScript config
```

---

## Development Commands

```bash
# Development
npm run dev                             # Start dev server with Turbopack

# Build & Deploy
npm run build                          # Production build
npm run start                          # Start production server

# Testing
npx ts-node scripts/test-password-reset.ts          # Run password reset test
npx ts-node scripts/test-password-reset.ts --token YOUR_TOKEN  # With token

# Database
npx prisma studio                      # Prisma GUI
npx prisma migrate dev --name <name>   # Create migration
npx prisma generate                    # Regenerate Prisma client
```

---

## Known Issues & Solutions

### Middleware & Auth
- ✅ FIXED: Middleware was too broad, blocking login API
  - Solution: Match only `/dpwai/:path*` routes
- ✅ FIXED: Multiple conflicting login routes
  - Solution: Single `/login` entrypoint, deleted duplicate directories
- ✅ FIXED: useSearchParams() Suspense boundary error
  - Solution: Wrap in `<Suspense>` component

### Build
- ✅ FIXED: node-fetch type errors in test script
  - Solution: Excluded `scripts/` from tsconfig.json

---

## Next Steps / Roadmap

### Authentication & Security
- [ ] Rate limiting on password reset endpoint
- [ ] Email confirmation after password reset
- [ ] Admin dashboard with reset statistics
- [ ] "Revoke all tokens" in account settings
- [ ] Production Resend domain verification

### Landing Page & Marketing
- [ ] Deep Work AI Flows website deployment
- [ ] Implement shadcn/ui component library for consistency
- [ ] Landing page hero section with video/animation
- [ ] Social proof section with client testimonials
- [ ] FAQ accordion component
- [ ] Contact/CTA form with validation
- [ ] i18n implementation for website (EN/PT)
- [ ] Dark mode support for website

### Design System & Components
- [ ] Document design tokens in dedicated component library
- [ ] Create reusable landing page section templates
- [ ] Implement Figma → Tailwind token sync (Style Dictionary)
- [ ] Accessibility audit with Axe DevTools
- [ ] Performance optimization (Core Web Vitals)

### Analytics & Optimization
- [ ] Analytics integration (heatmaps, conversion tracking)
- [ ] A/B testing framework for CTAs
- [ ] Landing page CRO (Conversion Rate Optimization)
- [ ] Mobile performance monitoring
