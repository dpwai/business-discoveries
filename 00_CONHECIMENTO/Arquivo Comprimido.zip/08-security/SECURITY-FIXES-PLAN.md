# 🛡️ SECURITY FIXES IMPLEMENTATION PLAN

**Start Date:** 2026-01-25
**Total Duration:** ~13.5 hours
**Risk Level:** CRITICAL - Fix immediately before production use
**Status:** Ready for implementation

---

## IMPLEMENTATION OVERVIEW

### Commit Sequence (6 Total)

| # | Task | Depends | Status | Effort |
|---|------|---------|--------|--------|
| 1 | Add authentication to Google Forms routes | - | → START HERE | 2.5h |
| 2 | Fix form builder type safety bug | Commit 1 | Waiting | 1h |
| 3 | Fix account route authentication | Commit 2 | Waiting | 1.5h |
| 4 | Add rate limiting + audit logging | Commit 3 | Waiting | 2.5h |
| 5 | Add hash fields to schema | Commit 4 | Waiting | 3h |
| 6 | Create Integrations model | Commit 5 | Waiting | 2.5h |

**Total:** 13.5 hours

---

## COMMIT 1: Add Authentication to Google Forms Routes (2.5 hours)

### What to do:

1. **Create `verifyAuth()` helper** (if doesn't exist):
   ```typescript
   // lib/api/verify-auth.ts
   import { jwtVerify } from 'jose';

   const secret = new TextEncoder().encode(process.env.JWT_SECRET || '');

   export async function verifyAuth(request: NextRequest) {
     const authHeader = request.headers.get('Authorization');
     if (!authHeader?.startsWith('Bearer ')) {
       return null;
     }

     try {
       const token = authHeader.slice(7);
       const { payload } = await jwtVerify(token, secret);
       return {
         userId: payload.sub,
         email: payload.email as string,
         tenantId: payload.tenantId as string
       };
     } catch {
       return null;
     }
   }
   ```

2. **Add auth to 8 Google Forms routes:**

   **File:** `/dpwaiagro/app/api/agro/[tenant]/google-forms/route.ts`
   ```typescript
   // Add at start of GET handler:
   const auth = await verifyAuth(request);
   if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

   // Verify tenant matches JWT:
   const tenant = await prisma.tenant.findUnique({
     where: { snake: params.tenant }
   });
   if (tenant?.id !== auth.tenantId) {
     return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
   }
   ```

   Apply same pattern to:
   - `GET /google-forms`
   - `POST /google-forms`
   - `GET /google-forms/[id]`
   - `PUT /google-forms/[id]`
   - `GET /google-forms/[id]/export`
   - `GET /google-forms/[id]/settings`
   - `PUT /google-forms/[id]/settings`
   - `POST /google-forms/[id]/submissions/import-csv`

3. **Test with curl:**
   ```bash
   # Should fail (no auth):
   curl -X GET http://localhost:3000/api/agro/acme-corp/google-forms
   # Response: 401 Unauthorized

   # Should succeed (with valid JWT):
   curl -X GET http://localhost:3000/api/agro/acme-corp/google-forms \
     -H "Authorization: Bearer <valid-jwt>"
   # Response: 200 OK + form data
   ```

4. **Verify:**
   - `npm run build` succeeds
   - No TypeScript errors
   - All 8 routes require auth

---

## COMMIT 2: Fix Form Builder Type Safety Bug (1 hour)

### What to do:

1. **Locate bug:** `/dpwaiagro/app/api/agro/[tenant]/forms/builder/route.ts` line ~60-62

2. **Current code:**
   ```typescript
   const form = await prisma.form.findUnique({
     where: { id: formId }
   });
   if (form.tenantId !== tenant) {  // ❌ BUG: UUID !== slug string
     return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
   }
   ```

3. **Fix to:**
   ```typescript
   const form = await prisma.form.findFirst({
     where: {
       id: formId,
       tenant: {
         snake: params.tenant  // Use relation to validate tenant
       }
     },
     include: {
       tenant: true
     }
   });
   if (!form) {
     return NextResponse.json({ error: 'Form not found' }, { status: 404 });
   }
   ```

4. **Why this works:**
   - Prisma JOINs on Tenant model
   - Validates both `id` AND `tenant.snake` in single query
   - Returns null if tenant doesn't match
   - Type-safe UUID comparison (no string vs UUID mismatch)

5. **Test:**
   ```bash
   # Create form in tenant A
   # Try to access via tenant B URL (should 404)
   curl -X GET http://localhost:3000/api/agro/tenant-b/forms/builder?formId=form-from-tenant-a
   # Response: 404 Form not found
   ```

---

## COMMIT 3: Fix Account Route Authentication (1.5 hours)

### What to do:

1. **Files to fix:**
   - `/dpwaiagro/app/api/agro/[tenant]/account/language/route.ts`
   - `/dpwaiagro/app/api/agro/[tenant]/account/preference/route.ts`
   - `/dpwaiagro/app/api/agro/[tenant]/users/invite/route.ts`

2. **Current pattern (wrong):**
   ```typescript
   const authHeader = request.headers.get('Authorization');
   if (!authHeader) return 401;  // ❌ Only checks header exists, doesn't validate
   ```

3. **Fix to (all three files):**
   ```typescript
   // Add at route start:
   const auth = await verifyAuth(request);
   if (!auth) {
     return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
   }

   // Verify user belongs to tenant:
   const membership = await prisma.membership.findFirst({
     where: {
       userId: auth.userId,
       tenant: { snake: params.tenant }
     }
   });
   if (!membership) {
     return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
   }
   ```

4. **Special handling for /users/invite:**
   ```typescript
   // Check user has permission to invite (admin or owner):
   if (!membership.isAdmin && !membership.isOwner) {
     return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
   }
   ```

5. **Test:**
   ```bash
   # No auth header (should 401):
   curl -X PATCH http://localhost:3000/api/agro/acme-corp/account/language
   # Response: 401 Unauthorized

   # Invalid token (should 401):
   curl -X PATCH http://localhost:3000/api/agro/acme-corp/account/language \
     -H "Authorization: Bearer invalid-token"
   # Response: 401 Unauthorized

   # Valid token but wrong tenant (should 403):
   curl -X PATCH http://localhost:3000/api/agro/other-corp/account/language \
     -H "Authorization: Bearer <jwt-for-acme-corp>"
   # Response: 403 Forbidden
   ```

---

## COMMIT 4: Add Rate Limiting & Audit Logging (2.5 hours)

### What to do:

1. **Create rate limiter utility:**
   ```typescript
   // lib/api/rate-limit.ts
   const store = new Map<string, { count: number; resetAt: number }>();

   export function rateLimit(
     identifier: string,
     limit: number,
     windowMs: number
   ): { success: boolean; remaining: number } {
     const now = Date.now();
     const record = store.get(identifier);

     if (!record || now > record.resetAt) {
       store.set(identifier, { count: 1, resetAt: now + windowMs });
       return { success: true, remaining: limit - 1 };
     }

     if (record.count >= limit) {
       return { success: false, remaining: 0 };
     }

     record.count++;
     return { success: true, remaining: limit - record.count };
   }
   ```

2. **Apply rate limiting to sensitive routes:**

   **Google Forms POST/PUT (create/update):**
   ```typescript
   const limiter = rateLimit(`${auth.userId}-forms`, 10, 3600000); // 10/hour
   if (!limiter.success) {
     return NextResponse.json(
       { error: 'Rate limit exceeded' },
       { status: 429, headers: { 'Retry-After': '3600' } }
     );
   }
   ```

   **User invite (prevent spam):**
   ```typescript
   const limiter = rateLimit(`${auth.userId}-invites`, 20, 3600000); // 20/hour
   ```

   **Admin endpoint (critical):**
   ```typescript
   const limiter = rateLimit(`create-test-users`, 5, 3600000); // 5/hour per IP
   ```

3. **Create audit logger:**
   ```typescript
   // lib/api/audit-log.ts
   export async function logAuditEvent(
     tenantId: string,
     userId: string,
     action: string,
     resourceType: string,
     resourceId: string,
     changes?: Record<string, any>,
     ipAddress?: string
   ) {
     // If AuditLog model exists, save; otherwise log to console
     console.log(`[AUDIT] ${action} on ${resourceType}`, {
       tenantId,
       userId,
       resourceId,
       changes,
       timestamp: new Date().toISOString(),
       ip: ipAddress
     });
   }
   ```

4. **Add audit logging to sensitive operations:**
   ```typescript
   // After successful form creation:
   await logAuditEvent(
     auth.tenantId,
     auth.userId,
     'CREATE',
     'GoogleForm',
     form.id,
     { name: form.name },
     request.ip
   );
   ```

---

## COMMIT 5: Add Hash Fields to Schema (3 hours)

### What to do:

1. **Add fields to Prisma schema:**

   **File:** `/dpwaiagro/prisma/schema.prisma`

   ```prisma
   model Tenant {
     id              String    @id @default(cuid())
     snake           String    @unique
     org_hash        String    @unique  // ← ADD THIS
     // ... rest of fields

     @@index([org_hash])  // Index for lookups
   }

   model Form {
     id              String    @id @default(cuid())
     form_hash       String    @unique  // ← ADD THIS
     // ... rest of fields

     @@index([form_hash])
   }

   model Dashboard {
     id              String    @id @default(cuid())
     dashboard_hash  String    @unique  // ← ADD THIS
     // ... rest of fields

     @@index([dashboard_hash])
   }
   ```

2. **Create migration:**
   ```bash
   npx prisma migrate dev --name add_hash_fields
   ```

3. **Populate hash values for existing records:**
   ```typescript
   // scripts/migrate-add-hashes.ts
   import crypto from 'crypto';
   import prisma from '@/lib/prisma';

   async function main() {
     // Generate hashes for all tenants
     const tenants = await prisma.tenant.findMany();
     for (const tenant of tenants) {
       if (!tenant.org_hash) {
         const hash = crypto
           .createHash('sha256')
           .update(`org_${tenant.id}_${Date.now()}`)
           .digest('hex')
           .slice(0, 16);

         await prisma.tenant.update({
           where: { id: tenant.id },
           data: { org_hash: hash }
         });
       }
     }

     // Similar for Forms and Dashboards
     // ...
   }

   main().catch(console.error);
   ```

4. **Run migration:**
   ```bash
   npx ts-node scripts/migrate-add-hashes.ts
   ```

5. **Verify:**
   ```bash
   npx prisma studio
   # Check: Tenant.org_hash, Form.form_hash populated
   ```

---

## COMMIT 6: Create Integrations Model (2.5 hours)

### What to do:

1. **Add Integrations model to schema:**

   **File:** `/dpwaiagro/prisma/schema.prisma`

   ```prisma
   model Integration {
     id              String    @id @default(cuid())
     tenantId        String
     tenant          Tenant    @relation(fields: [tenantId], references: [id], onDelete: Cascade)

     type            String    // "slack", "zapier", "webhook", "teams", etc.
     name            String
     description     String?

     isActive        Boolean   @default(true)
     webhookUrl      String?   @db.Text

     // Encrypted credentials (JSON)
     credentials     String    @db.Text  // Use encryption lib before storing

     // Metadata
     lastTriggered   DateTime?
     triggerCount    Int       @default(0)

     createdAt       DateTime  @default(now())
     updatedAt       DateTime  @updatedAt
     createdBy       String    // userId

     @@unique([tenantId, type, name])
     @@index([tenantId])
     @@index([isActive])
   }
   ```

2. **Create migration:**
   ```bash
   npx prisma migrate dev --name add_integrations_model
   ```

3. **Create API routes for integration management:**

   **File:** `/dpwaiagro/app/api/agro/[tenant]/integrations/route.ts` (GET, POST)
   ```typescript
   // GET - List integrations
   // POST - Create new integration
   // Both require auth
   ```

   **File:** `/dpwaiagro/app/api/agro/[tenant]/integrations/[id]/route.ts` (GET, PUT, DELETE)
   ```typescript
   // GET - Get integration details
   // PUT - Update integration
   // DELETE - Remove integration
   // All require auth + permission check
   ```

4. **Add integration creation logic:**
   ```typescript
   // Example: POST /api/agro/[tenant]/integrations
   export async function POST(request, { params }) {
     const auth = await verifyAuth(request);
     if (!auth) return 401;

     const { type, name, webhookUrl, credentials } = await request.json();

     // Validate type is supported
     const validTypes = ['slack', 'zapier', 'webhook', 'teams', 'email'];
     if (!validTypes.includes(type)) {
       return NextResponse.json({ error: 'Invalid integration type' }, { status: 400 });
     }

     // Rate limit: max 10 integrations per tenant
     const existingCount = await prisma.integration.count({
       where: { tenantId: auth.tenantId }
     });
     if (existingCount >= 10) {
       return NextResponse.json({ error: 'Integration limit reached' }, { status: 429 });
     }

     // Create integration
     const integration = await prisma.integration.create({
       data: {
         tenantId: auth.tenantId,
         type,
         name,
         webhookUrl,
         credentials: JSON.stringify(credentials), // Encrypt in production
         createdBy: auth.userId
       }
     });

     return NextResponse.json(integration);
   }
   ```

5. **Verify:**
   ```bash
   npm run build
   npx prisma studio
   # Check: Integration model visible, can create records
   ```

---

## ✅ VALIDATION CHECKLIST

After all 6 commits:

- [ ] All 14 previously-unauthenticated routes now require JWT auth
- [ ] Form builder type safety bug fixed (no more UUID vs string comparison)
- [ ] Account routes validate JWT token (not just header presence)
- [ ] Rate limiting implemented on sensitive endpoints
- [ ] Audit logging in place for sensitive operations
- [ ] Hash fields added to Tenant, Form, Dashboard (backward compatible)
- [ ] Integrations model created and functional
- [ ] `npm run build` passes with no errors
- [ ] All TypeScript types correct
- [ ] No secrets in logs or responses
- [ ] Tests pass (if applicable): `npm run test`

---

## 🧪 SECURITY TESTING

After fixes deployed, run:

### 1. Authentication Testing
```bash
# Should all return 401 or 403:
curl -X GET http://localhost:3000/api/agro/acme-corp/google-forms
curl -X POST http://localhost:3000/api/agro/acme-corp/google-forms \
  -H "Content-Type: application/json" \
  -d '{"name": "test"}'
curl -X PATCH http://localhost:3000/api/agro/acme-corp/account/language
```

### 2. Cross-Tenant Testing
```bash
# Get JWT for tenant A
# Try to access tenant B resources
# Should return 403 Forbidden
```

### 3. Rate Limiting Testing
```bash
# Make 11 form creation requests in rapid succession
# 11th should return 429 Too Many Requests
```

### 4. Type Safety Testing
```bash
# Create form in tenant A
# Access via form builder with tenant B slug
# Should return 404 (not 200)
```

---

## 📋 ROLLOUT STRATEGY

1. **Stage 1:** Deploy commits 1-3 to staging environment
2. **Stage 2:** Run security tests against staging
3. **Stage 3:** Deploy to production with monitoring enabled
4. **Stage 4:** Deploy commits 4-6 to improve robustness
5. **Stage 5:** Audit logs review for 7 days
6. **Stage 6:** Document in knowledge base and declare "Production Ready"

---

## 🎯 After All Fixes

**Security Grade:** Upgrade from D → B+
- ✅ All routes authenticated
- ✅ Type safety enforced
- ✅ Rate limiting in place
- ✅ Audit trails maintained
- ✅ Multi-tenant isolation verified

**Remaining work:** OAuth 2.0, security headers, WAF integration (future commits)

---

**Status:** Ready for implementation
**Start:** Copy prompt from `/dpwaiagro/SECURITY-FIXES-PROMPT.md`
